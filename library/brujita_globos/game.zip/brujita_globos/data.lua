-- Made by pinyol's editor from the project "Munchi's Rescue": change it there.
return {
  title = "Munchi's Rescue",
  tile = 16,
  style = {
    text = 10206223,
    outline = 997391,
    accent = 9153551,
    bad = 10206223,
    heart = 3170864
  },
  sprites = {
    luna = {
      w = 24,
      h = 24,
      frames = 5
    },
    munchi = {
      w = 19,
      h = 20,
      frames = 2
    },
    rama = {
      w = 16,
      h = 16,
      frames = 1
    },
    tierra = {
      w = 16,
      h = 16,
      frames = 1
    },
    avispa = {
      w = 22,
      h = 20,
      frames = 2
    },
    gaviota = {
      w = 28,
      h = 22,
      frames = 2
    },
    serpiente = {
      w = 18,
      h = 20,
      frames = 2
    },
    farol = {
      w = 16,
      h = 22,
      frames = 2
    },
    estrella = {
      w = 12,
      h = 12,
      frames = 8
    },
    cartel = {
      w = 32,
      h = 16,
      frames = 1
    },
    marco_hud = {
      w = 240,
      h = 160,
      frames = 1
    },
    arbol_suave = {
      w = 240,
      h = 256,
      frames = 1
    },
    copa = {
      w = 112,
      h = 31,
      frames = 1
    },
    portada = {
      w = 240,
      h = 160,
      frames = 1
    },
    panel_superior = {
      w = 240,
      h = 14,
      frames = 1
    },
    hud_d0 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d1 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d2 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d3 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d4 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d5 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d6 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d7 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d8 = {
      w = 8,
      h = 8,
      frames = 1
    },
    hud_d9 = {
      w = 8,
      h = 8,
      frames = 1
    },
    sello_pinyol = {
      w = 240,
      h = 160,
      frames = 16
    },
    burbuja0 = {
      w = 24,
      h = 24,
      frames = 1
    },
    burbuja1 = {
      w = 24,
      h = 24,
      frames = 1
    },
    burbuja2 = {
      w = 24,
      h = 24,
      frames = 1
    },
    burbuja_aviso = {
      w = 24,
      h = 24,
      frames = 1
    },
    rayo = {
      w = 16,
      h = 5,
      frames = 1
    },
    cine_arbol = {
      w = 240,
      h = 288,
      frames = 1
    },
    cine_dialogo = {
      w = 224,
      h = 32,
      frames = 12
    },
    cine_dialogo_fin = {
      w = 224,
      h = 32,
      frames = 12
    },
    cine_nube_0 = {
      w = 94,
      h = 22,
      frames = 1
    },
    cine_nube_1 = {
      w = 62,
      h = 18,
      frames = 1
    },
    cine_rama_0 = {
      w = 84,
      h = 32,
      frames = 1
    },
    cine_rama_1 = {
      w = 112,
      h = 32,
      frames = 1
    },
    cine_lagrima = {
      w = 3,
      h = 21,
      frames = 4
    },
    cine_suspiro = {
      w = 20,
      h = 15,
      frames = 4
    },
    cine_vacio = {
      w = 16,
      h = 16,
      frames = 1
    },
    cine_camara = {
      w = 1,
      h = 1,
      frames = 1
    },
    panel_controles = {
      w = 240,
      h = 17,
      frames = 1
    },
    aviso_ui = {
      w = 192,
      h = 28,
      frames = 1
    },
    mensaje_golpe = {
      w = 192,
      h = 28,
      frames = 1
    },
    cine_copa_0 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_copa_1 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_copa_2 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_copa_3 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_copa_4 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_base_0 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_base_1 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_base_2 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_base_3 = {
      w = 240,
      h = 32,
      frames = 1
    },
    cine_base_4 = {
      w = 240,
      h = 32,
      frames = 1
    },
    plataforma_rama = {
      w = 64,
      h = 11,
      frames = 1
    },
    plataforma_suelo = {
      w = 240,
      h = 11,
      frames = 1
    },
    suelo_visual = {
      w = 240,
      h = 48,
      frames = 1
    },
    choque0 = {
      w = 29,
      h = 31,
      frames = 4
    },
    choque1 = {
      w = 29,
      h = 31,
      frames = 4
    },
    choque2 = {
      w = 29,
      h = 31,
      frames = 4
    },
    electro_gaviota = {
      w = 32,
      h = 30,
      frames = 4
    },
    electro_serpiente = {
      w = 30,
      h = 32,
      frames = 4
    },
    nube = {
      w = 32,
      h = 29,
      frames = 6
    }
  },
  kinds = {
    luna = {
      behaviour = "platformer",
      speed = 1.55,
      jump = 4.8,
      animate = 7,
      anims = {
        idle = {0, 1},
        walk = {2, 3},
        hit = {4, 4}
      }
    },
    munchi = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 30
    },
    avispa = {
      behaviour = "patrol",
      speed = 0.6,
      jump = 4.5,
      animate = 5,
      gravity = false
    },
    gaviota = {
      behaviour = "patrol",
      speed = 0.9,
      jump = 4.5,
      animate = 12,
      gravity = false
    },
    serpiente = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 18
    },
    farol = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 25
    },
    estrella = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 5
    },
    cartel = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    copa = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    portada = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    panel_superior = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d0 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d1 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d2 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d3 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d4 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d5 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d6 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d7 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d8 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    hud_d9 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    sello_pinyol = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 9,
      gravity = false
    },
    burbuja0 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    burbuja1 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    burbuja2 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    burbuja_aviso = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    rayo = {
      behaviour = "shot",
      speed = 4.2,
      jump = 4.5,
      animate = 0,
      gravity = false,
      dir = "forward"
    },
    cine_dialogo = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    cine_dialogo_fin = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_nube_0 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    cine_nube_1 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    cine_rama_0 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    cine_rama_1 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    cine_lagrima = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 7,
      gravity = false
    },
    cine_suspiro = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 10,
      gravity = false
    },
    cine_camara = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    panel_controles = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    aviso_ui = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    mensaje_golpe = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_copa_0 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_copa_1 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_copa_2 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_copa_3 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_copa_4 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_base_0 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_base_1 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_base_2 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_base_3 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    cine_base_4 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0,
      gravity = false
    },
    plataforma_rama = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    plataforma_suelo = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    suelo_visual = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8,
      gravity = false
    },
    choque0 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 4,
      gravity = false
    },
    choque1 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 4,
      gravity = false
    },
    choque2 = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 4,
      gravity = false
    },
    electro_gaviota = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 4,
      gravity = false
    },
    electro_serpiente = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 4,
      gravity = false
    },
    nube = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 4,
      gravity = false
    }
  },
  solid = {},
  sounds = {
    salto = {
      recipe = "jump",
      seed = 7
    },
    magia = {
      recipe = "powerup",
      seed = 8
    },
    pop = {
      recipe = "blip",
      seed = 9
    },
    golpe = {
      recipe = "hit",
      seed = 10
    },
    estrella = {
      recipe = "coin",
      seed = 11
    },
    refugio = {
      recipe = "coin",
      seed = 12
    },
    ganar = {
      recipe = "powerup",
      seed = 13
    },
    rayo = {
      recipe = "laser",
      seed = 14
    }
  },
  ending = "Munchi esta a salvo. ¡Miau!",
  cover = nil,
  levels = {
    {
      id = "pinyol_intro",
      name = " ",
      background = 14216111,
      camera = nil,
      backdrops = {},
      music = nil,
      objects = {
        {
          kind = "sello_pinyol",
          x = 0,
          y = 0
        }
      },
      map = nil
    },
    {
      id = "titulo",
      name = " ",
      background = 14216111,
      camera = nil,
      backdrops = {},
      music = nil,
      objects = {
        {
          kind = "portada",
          x = 0,
          y = 0
        }
      },
      map = nil
    },
    {
      id = "cinematica",
      name = " ",
      background = 14216111,
      camera = "cine_camara",
      backdrops = {
        {
          sprite = "cine_arbol",
          parallax = 1
        }
      },
      music = nil,
      objects = {
        {
          kind = "cine_copa_0",
          x = 0,
          y = 0
        },
        {
          kind = "cine_copa_1",
          x = 0,
          y = 32
        },
        {
          kind = "cine_copa_2",
          x = 0,
          y = 64
        },
        {
          kind = "cine_copa_3",
          x = 0,
          y = 96
        },
        {
          kind = "cine_copa_4",
          x = 0,
          y = 128
        },
        {
          kind = "cine_nube_0",
          x = 1,
          y = 161
        },
        {
          kind = "cine_nube_1",
          x = 167,
          y = 249
        },
        {
          kind = "cine_nube_0",
          x = 49,
          y = 341
        },
        {
          kind = "cine_camara",
          x = 239,
          y = 80
        }
      },
      map = {
        w = 15,
        h = 64,
        tiles = {"cine_vacio"},
        cells = {
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        }
      }
    },
    {
      id = "arbol",
      name = "El arbol de Munchi",
      background = 14216111,
      camera = "luna",
      backdrops = {
        {
          sprite = "marco_hud",
          parallax = 0
        },
        {
          sprite = "arbol_suave",
          parallax = 1
        }
      },
      music = nil,
      objects = {
        {
          kind = "plataforma_suelo",
          x = 0,
          y = 960
        },
        {
          kind = "plataforma_rama",
          x = 32,
          y = 896
        },
        {
          kind = "plataforma_rama",
          x = 112,
          y = 832
        },
        {
          kind = "plataforma_rama",
          x = 160,
          y = 768
        },
        {
          kind = "plataforma_rama",
          x = 80,
          y = 704
        },
        {
          kind = "plataforma_rama",
          x = 16,
          y = 640
        },
        {
          kind = "plataforma_rama",
          x = 96,
          y = 576
        },
        {
          kind = "plataforma_rama",
          x = 160,
          y = 512
        },
        {
          kind = "plataforma_rama",
          x = 80,
          y = 448
        },
        {
          kind = "plataforma_rama",
          x = 16,
          y = 384
        },
        {
          kind = "plataforma_rama",
          x = 96,
          y = 320
        },
        {
          kind = "plataforma_rama",
          x = 160,
          y = 256
        },
        {
          kind = "plataforma_rama",
          x = 80,
          y = 192
        },
        {
          kind = "plataforma_rama",
          x = 16,
          y = 128
        },
        {
          kind = "plataforma_rama",
          x = 80,
          y = 64
        },
        {
          kind = "suelo_visual",
          x = 0,
          y = 976
        },
        {
          kind = "copa",
          x = 64,
          y = 7
        },
        {
          kind = "cartel",
          x = 142,
          y = 944
        },
        {
          kind = "farol",
          x = 104,
          y = 682
        },
        {
          kind = "farol",
          x = 104,
          y = 426
        },
        {
          kind = "farol",
          x = 104,
          y = 170
        },
        {
          kind = "serpiente",
          x = 200,
          y = 748
        },
        {
          kind = "serpiente",
          x = 200,
          y = 492
        },
        {
          kind = "serpiente",
          x = 200,
          y = 236
        },
        {
          kind = "avispa",
          x = 178,
          y = 836
        },
        {
          kind = "avispa",
          x = 18,
          y = 582
        },
        {
          kind = "gaviota",
          x = 16,
          y = 712
        },
        {
          kind = "gaviota",
          x = 138,
          y = 326
        },
        {
          kind = "estrella",
          x = 76,
          y = 874
        },
        {
          kind = "estrella",
          x = 156,
          y = 810
        },
        {
          kind = "estrella",
          x = 204,
          y = 746
        },
        {
          kind = "estrella",
          x = 60,
          y = 618
        },
        {
          kind = "estrella",
          x = 140,
          y = 554
        },
        {
          kind = "estrella",
          x = 204,
          y = 490
        },
        {
          kind = "estrella",
          x = 60,
          y = 362
        },
        {
          kind = "estrella",
          x = 140,
          y = 298
        },
        {
          kind = "estrella",
          x = 204,
          y = 234
        },
        {
          kind = "estrella",
          x = 60,
          y = 106
        },
        {
          kind = "munchi",
          x = 112,
          y = 44
        },
        {
          kind = "luna",
          x = 120,
          y = 936
        },
        {
          kind = "panel_controles",
          x = 0,
          y = 1007
        },
        {
          kind = "panel_superior",
          x = 0,
          y = 864
        },
        {
          kind = "hud_d1",
          x = 68,
          y = 868
        },
        {
          kind = "hud_d2",
          x = 76,
          y = 868
        },
        {
          kind = "hud_d3",
          x = 108,
          y = 868
        },
        {
          kind = "hud_d4",
          x = 116,
          y = 868
        }
      },
      map = {
        w = 15,
        h = 64,
        tiles = {"rama", "tierra"},
        cells = {
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        }
      }
    }
  },
  start = nil
}
