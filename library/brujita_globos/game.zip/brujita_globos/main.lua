-- Munchi's Rescue: made with pinyol's editor. The blocks' code is below; kit.lua (a copy of pinyol's
-- lib/kit.lua) does the rest: the levels, the map, the objects that move by themselves, the events.
kit = require("kit")
kit.setup(require("data"))

px = 0
py = 0
feet = 0
previous = 0
grounded = 0
coyote = 0
buffer = 0
safe_x = 0
safe_y = 0
hurt = 0
cool = 0
slot = 0
gx = 0
gy = 0
stars = 0
casts = 0
altura = 0
victoria = 0
ray_cool = 0
rayos = 0
derrotados = 0
pantalla = 0
intro_ticks = 0
cine_ticks = 0
cine_pan = 0
cine_scroll = 0
cine_copa_fuera = 0
cine_final = 0
aviso_t = 0
shock_slot = 0
z0x = 0
z0y = 0
z0t = 0
z1x = 0
z1y = 0
z1t = 0
z2x = 0
z2y = 0
z2t = 0
g0x = 0
g0y = 0
g0t = 0
g1x = 0
g1y = 0
g1t = 0
g2x = 0
g2y = 0
g2t = 0

kit.on("level", "arbol", function()
  px = 0
  py = 0
  feet = 0
  previous = 0
  grounded = 0
  coyote = 0
  buffer = 0
  safe_x = 0
  safe_y = 0
  hurt = 0
  cool = 0
  slot = 0
  gx = 0
  gy = 0
  stars = 0
  casts = 0
  altura = 0
  victoria = 0
  ray_cool = 0
  rayos = 0
  derrotados = 0
  pantalla = 0
  intro_ticks = 0
  cine_ticks = 0
  cine_pan = 0
  cine_scroll = 0
  cine_copa_fuera = 0
  cine_final = 0
  aviso_t = 0
  shock_slot = 0
  z0x = 0
  z0y = 0
  z0t = 0
  z1x = 0
  z1y = 0
  z1t = 0
  z2x = 0
  z2y = 0
  z2t = 0
  g0x = 0
  g0y = 0
  g0t = 0
  g1x = 0
  g1y = 0
  g1t = 0
  g2x = 0
  g2y = 0
  g2t = 0
  pantalla = 2
  previous = 960
  safe_x = 120
  safe_y = 936
  kit.set_lives(5)
  kit.label("top_left", '', "top_left", "shadow")
  kit.label("bottom", '', "bottom", "shadow")
  kit.message('', 0.1)
end)

kit.on("press", "a", function()
  if pantalla == 2 then
    buffer = 8
  end
end)

kit.on("press", "b", function()
  if pantalla == 2 then
    if cool <= 0 then
      gx = math.floor((kit.get(kit.player(), "x") + kit.get(kit.player(), "vx") * 16) / 16) * 16
      gy = math.floor((kit.get(kit.player(), "y") + 8) / 16) * 16
      if gx > 216 then
        gx = 216
      end
      if gx < 0 then
        gx = 0
      end
      if gy >= 16 and gy < 976 then
        if slot == 0 then
          if g0t > 0 then
            kit.destroy(kit.first("burbuja0"))
          end
          g0x = gx
          g0y = gy
          g0t = 300
          kit.spawn("burbuja0", g0x, g0y)
        end
        if slot == 1 then
          if g1t > 0 then
            kit.destroy(kit.first("burbuja1"))
          end
          g1x = gx
          g1y = gy
          g1t = 300
          kit.spawn("burbuja1", g1x, g1y)
        end
        if slot == 2 then
          if g2t > 0 then
            kit.destroy(kit.first("burbuja2"))
          end
          g2x = gx
          g2y = gy
          g2t = 300
          kit.spawn("burbuja2", g2x, g2y)
        end
        slot = (slot + 1) % 3
        cool = 36
        casts = casts + 1
        kit.sound("magia")
        kit.play(kit.player(), "hit")
      end
    end
  end
end)

kit.on("hold", "b", function()
  if pantalla == 2 then
    if (cool <= 0 and kit.get(kit.player(), "vy") < -0.1) and kit.get(kit.player(), "vy") >= -1.8 then
      gx = math.floor((kit.get(kit.player(), "x") + kit.get(kit.player(), "vx") * 16) / 16) * 16
      gy = math.floor((kit.get(kit.player(), "y") + 39) / 16) * 16
      if gx > 216 then
        gx = 216
      end
      if gx < 0 then
        gx = 0
      end
      if gy >= 16 and gy < 976 then
        if slot == 0 then
          if g0t > 0 then
            kit.destroy(kit.first("burbuja0"))
          end
          g0x = gx
          g0y = gy
          g0t = 300
          kit.spawn("burbuja0", g0x, g0y)
        end
        if slot == 1 then
          if g1t > 0 then
            kit.destroy(kit.first("burbuja1"))
          end
          g1x = gx
          g1y = gy
          g1t = 300
          kit.spawn("burbuja1", g1x, g1y)
        end
        if slot == 2 then
          if g2t > 0 then
            kit.destroy(kit.first("burbuja2"))
          end
          g2x = gx
          g2y = gy
          g2t = 300
          kit.spawn("burbuja2", g2x, g2y)
        end
        slot = (slot + 1) % 3
        cool = 36
        casts = casts + 1
        kit.sound("magia")
        kit.play(kit.player(), "hit")
      end
    end
  end
end)

kit.on("hold", "c", function()
  if pantalla == 2 then
    if ray_cool <= 0 then
      kit.spawn_at("rayo", kit.player())
      ray_cool = 18
      rayos = rayos + 1
      kit.sound("rayo")
      kit.play(kit.player(), "hit")
    end
  end
end)

kit.on("tick", function()
  if pantalla == 2 then
    px = kit.get(kit.player(), "x")
    py = kit.get(kit.player(), "y")
    feet = py + 24
    grounded = 0
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 960 + 0.2) and feet >= 960) and px + 22 > 0) and px + 2 < 0 + 240 then
      kit.set(kit.player(), "y", 960 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 896 + 0.2) and feet >= 896) and px + 22 > 32) and px + 2 < 32 + 64 then
      kit.set(kit.player(), "y", 896 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 832 + 0.2) and feet >= 832) and px + 22 > 112) and px + 2 < 112 + 64 then
      kit.set(kit.player(), "y", 832 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 768 + 0.2) and feet >= 768) and px + 22 > 160) and px + 2 < 160 + 64 then
      kit.set(kit.player(), "y", 768 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 704 + 0.2) and feet >= 704) and px + 22 > 80) and px + 2 < 80 + 64 then
      kit.set(kit.player(), "y", 704 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 640 + 0.2) and feet >= 640) and px + 22 > 16) and px + 2 < 16 + 64 then
      kit.set(kit.player(), "y", 640 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 576 + 0.2) and feet >= 576) and px + 22 > 96) and px + 2 < 96 + 64 then
      kit.set(kit.player(), "y", 576 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 512 + 0.2) and feet >= 512) and px + 22 > 160) and px + 2 < 160 + 64 then
      kit.set(kit.player(), "y", 512 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 448 + 0.2) and feet >= 448) and px + 22 > 80) and px + 2 < 80 + 64 then
      kit.set(kit.player(), "y", 448 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 384 + 0.2) and feet >= 384) and px + 22 > 16) and px + 2 < 16 + 64 then
      kit.set(kit.player(), "y", 384 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 320 + 0.2) and feet >= 320) and px + 22 > 96) and px + 2 < 96 + 64 then
      kit.set(kit.player(), "y", 320 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 256 + 0.2) and feet >= 256) and px + 22 > 160) and px + 2 < 160 + 64 then
      kit.set(kit.player(), "y", 256 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 192 + 0.2) and feet >= 192) and px + 22 > 80) and px + 2 < 80 + 64 then
      kit.set(kit.player(), "y", 192 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 128 + 0.2) and feet >= 128) and px + 22 > 16) and px + 2 < 16 + 64 then
      kit.set(kit.player(), "y", 128 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if (((kit.get(kit.player(), "vy") >= 0 and previous <= 64 + 0.2) and feet >= 64) and px + 22 > 80) and px + 2 < 80 + 64 then
      kit.set(kit.player(), "y", 64 - 24)
      kit.set(kit.player(), "vy", 0)
      grounded = 1
    end
    if g0t > 0 then
      if (((kit.get(kit.player(), "vy") >= 0 and previous <= g0y + 0.2) and feet >= g0y) and px + 22 > g0x) and px + 2 < g0x + 24 then
        kit.set(kit.player(), "y", g0y - 24)
        kit.set(kit.player(), "vy", 0)
        grounded = 1
        kit.set(kit.player(), "y", kit.get(kit.player(), "y") - 0.08)
      end
      g0y = g0y + -0.08
      kit.set(kit.first("burbuja0"), "y", g0y)
      g0t = g0t + -1
      if g0t == 60 then
        kit.set_sprite(kit.first("burbuja0"), "burbuja_aviso")
      end
      if g0t == 0 then
        kit.destroy(kit.first("burbuja0"))
        kit.sound("pop")
      end
    end
    if g1t > 0 then
      if (((kit.get(kit.player(), "vy") >= 0 and previous <= g1y + 0.2) and feet >= g1y) and px + 22 > g1x) and px + 2 < g1x + 24 then
        kit.set(kit.player(), "y", g1y - 24)
        kit.set(kit.player(), "vy", 0)
        grounded = 1
        kit.set(kit.player(), "y", kit.get(kit.player(), "y") - 0.08)
      end
      g1y = g1y + -0.08
      kit.set(kit.first("burbuja1"), "y", g1y)
      g1t = g1t + -1
      if g1t == 60 then
        kit.set_sprite(kit.first("burbuja1"), "burbuja_aviso")
      end
      if g1t == 0 then
        kit.destroy(kit.first("burbuja1"))
        kit.sound("pop")
      end
    end
    if g2t > 0 then
      if (((kit.get(kit.player(), "vy") >= 0 and previous <= g2y + 0.2) and feet >= g2y) and px + 22 > g2x) and px + 2 < g2x + 24 then
        kit.set(kit.player(), "y", g2y - 24)
        kit.set(kit.player(), "vy", 0)
        grounded = 1
        kit.set(kit.player(), "y", kit.get(kit.player(), "y") - 0.08)
      end
      g2y = g2y + -0.08
      kit.set(kit.first("burbuja2"), "y", g2y)
      g2t = g2t + -1
      if g2t == 60 then
        kit.set_sprite(kit.first("burbuja2"), "burbuja_aviso")
      end
      if g2t == 0 then
        kit.destroy(kit.first("burbuja2"))
        kit.sound("pop")
      end
    end
    if grounded == 1 then
      coyote = 6
    else
      if coyote > 0 then
        coyote = coyote + -1
      end
    end
    if buffer > 0 and coyote > 0 then
      kit.set(kit.player(), "vy", -4.8)
      buffer = 0
      coyote = 0
      grounded = 0
      kit.sound("salto")
    end
    if buffer > 0 then
      buffer = buffer + -1
    end
    if cool > 0 then
      cool = cool + -1
    end
    if hurt > 0 then
      hurt = hurt + -1
    end
    if ray_cool > 0 then
      ray_cool = ray_cool + -1
    end
    previous = kit.get(kit.player(), "y") + 24
    altura = math.floor((936 - kit.get(kit.player(), "y")) / 16)
    kit.label("top", '', "top", "shadow")
    if kit.get(kit.player(), "y") > safe_y + 152 and hurt == 0 then
      kit.add_lives(-1)
      kit.set(kit.player(), "x", safe_x)
      kit.set(kit.player(), "y", safe_y)
      kit.set(kit.player(), "vx", 0)
      kit.set(kit.player(), "vy", 0)
      previous = safe_y + 24
      hurt = 150
      kit.sound("golpe")
      kit.destroy(kit.first("aviso_ui"))
      kit.spawn("aviso_ui", 24, math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 18)
      kit.set_sprite(kit.first("aviso_ui"), "mensaje_golpe")
      aviso_t = 72
    end
    kit.set(kit.first("panel_controles"), "y", math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 143)
    kit.set(kit.first("panel_superior"), "y", math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864))
    kit.set(kit.first("hud_d1"), "y", math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 4)
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 0 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d0")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 1 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d1")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 2 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d2")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 3 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d3")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 4 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d4")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 5 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d5")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 6 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d6")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 7 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d7")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 8 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d8")
    end
    if math.floor(math.min(math.max(stars, 0), 99) / 10) == 9 then
      kit.set_sprite(kit.first("hud_d1"), "hud_d9")
    end
    kit.set(kit.first("hud_d2"), "y", math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 4)
    if math.min(math.max(stars, 0), 99) % 10 == 0 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d0")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 1 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d1")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 2 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d2")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 3 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d3")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 4 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d4")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 5 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d5")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 6 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d6")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 7 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d7")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 8 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d8")
    end
    if math.min(math.max(stars, 0), 99) % 10 == 9 then
      kit.set_sprite(kit.first("hud_d2"), "hud_d9")
    end
    kit.set(kit.first("hud_d3"), "y", math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 4)
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 0 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d0")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 1 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d1")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 2 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d2")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 3 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d3")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 4 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d4")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 5 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d5")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 6 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d6")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 7 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d7")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 8 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d8")
    end
    if math.floor(math.min(math.max(altura, 0), 99) / 10) == 9 then
      kit.set_sprite(kit.first("hud_d3"), "hud_d9")
    end
    kit.set(kit.first("hud_d4"), "y", math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 4)
    if math.min(math.max(altura, 0), 99) % 10 == 0 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d0")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 1 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d1")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 2 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d2")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 3 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d3")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 4 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d4")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 5 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d5")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 6 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d6")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 7 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d7")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 8 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d8")
    end
    if math.min(math.max(altura, 0), 99) % 10 == 9 then
      kit.set_sprite(kit.first("hud_d4"), "hud_d9")
    end
    if aviso_t > 0 then
      kit.set(kit.first("aviso_ui"), "y", math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 18)
      aviso_t = aviso_t + -1
      if aviso_t == 0 then
        kit.destroy(kit.first("aviso_ui"))
      end
    end
    if z0t > 0 then
      z0t = z0t + -1
      if z0t == 24 then
        kit.destroy(kit.first("choque0"))
        kit.spawn("choque0", z0x, z0y)
        kit.set_sprite(kit.first("choque0"), "nube")
      end
      if z0t == 0 then
        kit.destroy(kit.first("choque0"))
      end
    end
    if z1t > 0 then
      z1t = z1t + -1
      if z1t == 24 then
        kit.destroy(kit.first("choque1"))
        kit.spawn("choque1", z1x, z1y)
        kit.set_sprite(kit.first("choque1"), "nube")
      end
      if z1t == 0 then
        kit.destroy(kit.first("choque1"))
      end
    end
    if z2t > 0 then
      z2t = z2t + -1
      if z2t == 24 then
        kit.destroy(kit.first("choque2"))
        kit.spawn("choque2", z2x, z2y)
        kit.set_sprite(kit.first("choque2"), "nube")
      end
      if z2t == 0 then
        kit.destroy(kit.first("choque2"))
      end
    end
  end
end)

kit.on("touch", "luna", "avispa", function(este, otro)
  if pantalla == 2 then
    if (((hurt == 0 and kit.get(kit.player(), "x") + 18 > kit.get(otro, "x") + 3) and kit.get(kit.player(), "x") + 6 < (kit.get(otro, "x") + 22) - 3) and kit.get(kit.player(), "y") + 23 > kit.get(otro, "y") + 3) and kit.get(kit.player(), "y") + 10 < (kit.get(otro, "y") + 20) - 2 then
      kit.add_lives(-1)
      kit.set(kit.player(), "x", safe_x)
      kit.set(kit.player(), "y", safe_y)
      kit.set(kit.player(), "vx", 0)
      kit.set(kit.player(), "vy", 0)
      previous = safe_y + 24
      hurt = 150
      kit.sound("golpe")
      kit.destroy(kit.first("aviso_ui"))
      kit.spawn("aviso_ui", 24, math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 18)
      kit.set_sprite(kit.first("aviso_ui"), "mensaje_golpe")
      aviso_t = 72
    end
  end
end)

kit.on("touch", "luna", "gaviota", function(este, otro)
  if pantalla == 2 then
    if (((hurt == 0 and kit.get(kit.player(), "x") + 18 > kit.get(otro, "x") + 3) and kit.get(kit.player(), "x") + 6 < (kit.get(otro, "x") + 28) - 3) and kit.get(kit.player(), "y") + 23 > kit.get(otro, "y") + 3) and kit.get(kit.player(), "y") + 10 < (kit.get(otro, "y") + 22) - 2 then
      kit.add_lives(-1)
      kit.set(kit.player(), "x", safe_x)
      kit.set(kit.player(), "y", safe_y)
      kit.set(kit.player(), "vx", 0)
      kit.set(kit.player(), "vy", 0)
      previous = safe_y + 24
      hurt = 150
      kit.sound("golpe")
      kit.destroy(kit.first("aviso_ui"))
      kit.spawn("aviso_ui", 24, math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 18)
      kit.set_sprite(kit.first("aviso_ui"), "mensaje_golpe")
      aviso_t = 72
    end
  end
end)

kit.on("touch", "luna", "serpiente", function(este, otro)
  if pantalla == 2 then
    if (((hurt == 0 and kit.get(kit.player(), "x") + 18 > kit.get(otro, "x") + 3) and kit.get(kit.player(), "x") + 6 < (kit.get(otro, "x") + 22) - 3) and kit.get(kit.player(), "y") + 23 > kit.get(otro, "y") + 3) and kit.get(kit.player(), "y") + 10 < (kit.get(otro, "y") + 20) - 2 then
      kit.add_lives(-1)
      kit.set(kit.player(), "x", safe_x)
      kit.set(kit.player(), "y", safe_y)
      kit.set(kit.player(), "vx", 0)
      kit.set(kit.player(), "vy", 0)
      previous = safe_y + 24
      hurt = 150
      kit.sound("golpe")
      kit.destroy(kit.first("aviso_ui"))
      kit.spawn("aviso_ui", 24, math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 18)
      kit.set_sprite(kit.first("aviso_ui"), "mensaje_golpe")
      aviso_t = 72
    end
  end
end)

kit.on("touch", "luna", "farol", function(este, otro)
  if pantalla == 2 then
    if kit.get(otro, "y") < safe_y then
      safe_x = kit.get(otro, "x") + 18
      safe_y = kit.get(otro, "y") - 2
      kit.sound("refugio")
      kit.destroy(kit.first("aviso_ui"))
      kit.spawn("aviso_ui", 24, math.min(math.max(math.floor(kit.get(kit.player(), "y") - 68), 0), 864) + 18)
      kit.set_sprite(kit.first("aviso_ui"), "aviso_ui")
      aviso_t = 120
    end
  end
end)

kit.on("touch", "luna", "estrella", function(este, otro)
  if pantalla == 2 then
    kit.destroy(otro)
    stars = stars + 1
    kit.sound("estrella")
    kit.label("top_left", '', "top_left", "shadow")
  end
end)

kit.on("touch", "luna", "munchi", function(este, otro)
  if pantalla == 2 then
    victoria = 1
    kit.sound("ganar")
    kit.win('¡Munchi a salvo!')
  end
end)

kit.on("touch", "rayo", "avispa", function(este, otro)
  if pantalla == 2 then
    kit.destroy(este)
    if shock_slot == 0 then
      kit.destroy(kit.first("choque0"))
      z0x = kit.get(otro, "x") - 5
      z0y = kit.get(otro, "y") - 6
      kit.spawn("choque0", z0x, z0y)
      kit.set_sprite(kit.first("choque0"), "choque0")
      z0t = 48
    end
    if shock_slot == 1 then
      kit.destroy(kit.first("choque1"))
      z1x = kit.get(otro, "x") - 5
      z1y = kit.get(otro, "y") - 6
      kit.spawn("choque1", z1x, z1y)
      kit.set_sprite(kit.first("choque1"), "choque1")
      z1t = 48
    end
    if shock_slot == 2 then
      kit.destroy(kit.first("choque2"))
      z2x = kit.get(otro, "x") - 5
      z2y = kit.get(otro, "y") - 6
      kit.spawn("choque2", z2x, z2y)
      kit.set_sprite(kit.first("choque2"), "choque2")
      z2t = 48
    end
    shock_slot = (shock_slot + 1) % 3
    kit.destroy(otro)
    derrotados = derrotados + 1
    kit.sound("pop")
  end
end)

kit.on("touch", "rayo", "gaviota", function(este, otro)
  if pantalla == 2 then
    kit.destroy(este)
    if shock_slot == 0 then
      kit.destroy(kit.first("choque0"))
      z0x = kit.get(otro, "x") - 2
      z0y = kit.get(otro, "y") - 5
      kit.spawn("choque0", z0x, z0y)
      kit.set_sprite(kit.first("choque0"), "electro_gaviota")
      z0t = 48
    end
    if shock_slot == 1 then
      kit.destroy(kit.first("choque1"))
      z1x = kit.get(otro, "x") - 2
      z1y = kit.get(otro, "y") - 5
      kit.spawn("choque1", z1x, z1y)
      kit.set_sprite(kit.first("choque1"), "electro_gaviota")
      z1t = 48
    end
    if shock_slot == 2 then
      kit.destroy(kit.first("choque2"))
      z2x = kit.get(otro, "x") - 2
      z2y = kit.get(otro, "y") - 5
      kit.spawn("choque2", z2x, z2y)
      kit.set_sprite(kit.first("choque2"), "electro_gaviota")
      z2t = 48
    end
    shock_slot = (shock_slot + 1) % 3
    kit.destroy(otro)
    derrotados = derrotados + 1
    kit.sound("pop")
  end
end)

kit.on("touch", "rayo", "serpiente", function(este, otro)
  if pantalla == 2 then
    kit.destroy(este)
    if shock_slot == 0 then
      kit.destroy(kit.first("choque0"))
      z0x = kit.get(otro, "x") - 5
      z0y = kit.get(otro, "y") - 6
      kit.spawn("choque0", z0x, z0y)
      kit.set_sprite(kit.first("choque0"), "electro_serpiente")
      z0t = 48
    end
    if shock_slot == 1 then
      kit.destroy(kit.first("choque1"))
      z1x = kit.get(otro, "x") - 5
      z1y = kit.get(otro, "y") - 6
      kit.spawn("choque1", z1x, z1y)
      kit.set_sprite(kit.first("choque1"), "electro_serpiente")
      z1t = 48
    end
    if shock_slot == 2 then
      kit.destroy(kit.first("choque2"))
      z2x = kit.get(otro, "x") - 5
      z2y = kit.get(otro, "y") - 6
      kit.spawn("choque2", z2x, z2y)
      kit.set_sprite(kit.first("choque2"), "electro_serpiente")
      z2t = 48
    end
    shock_slot = (shock_slot + 1) % 3
    kit.destroy(otro)
    derrotados = derrotados + 1
    kit.sound("pop")
  end
end)

kit.on("level", "pinyol_intro", function()
  pantalla = 0
  intro_ticks = 0
  kit.message('', 0.1)
end)

kit.on("level", "titulo", function()
  pantalla = 1
  kit.message('', 0.1)
end)

kit.on("tick", function()
  if pantalla == 0 then
    intro_ticks = intro_ticks + 1
    if intro_ticks >= 150 then
      kit.goto_level("titulo")
    end
  end
end)

kit.on("press", "a", function()
  if pantalla == 1 then
    kit.goto_level("cinematica")
  end
end)

kit.on("level", "cinematica", function()
  pantalla = 3
  cine_ticks = 0
  cine_pan = 0
  cine_scroll = 0
  cine_copa_fuera = 0
  cine_final = 0
  kit.message('', 0.1)
  kit.spawn("cine_lagrima", 112, 58)
  kit.spawn("cine_lagrima", 137, 66)
end)

kit.on("tick", function()
  if pantalla == 3 then
    cine_ticks = cine_ticks + 1
    if cine_ticks <= 150 then
      cine_scroll = math.floor(2592 * ((cine_ticks / 150) * ((cine_ticks / 150) * (3 - 2 * (cine_ticks / 150)))))
      cine_pan = 0 - cine_scroll
      if cine_scroll > 0 then
        kit.set(kit.first("cine_camara"), "y", 81 + (cine_scroll - 1) % 864)
      end
      if cine_scroll > 512 and cine_copa_fuera == 0 then
        kit.destroy(kit.first("cine_copa_0"))
        kit.destroy(kit.first("cine_copa_1"))
        kit.destroy(kit.first("cine_copa_2"))
        kit.destroy(kit.first("cine_copa_3"))
        kit.destroy(kit.first("cine_copa_4"))
        kit.destroy(kit.first("cine_nube_0"))
        kit.destroy(kit.first("cine_nube_0"))
        kit.destroy(kit.first("cine_nube_1"))
        cine_copa_fuera = 1
      end
      if cine_scroll > 1728 and cine_final == 0 then
        kit.spawn("cine_base_0", 0, 864)
        kit.spawn("cine_base_1", 0, 896)
        kit.spawn("cine_base_2", 0, 928)
        kit.spawn("cine_base_3", 0, 960)
        kit.spawn("cine_base_4", 0, 992)
        kit.spawn("cine_rama_0", 0, 560)
        kit.spawn("cine_rama_1", 128, 688)
        cine_final = 1
      end
    end
    if cine_ticks == 30 then
      kit.destroy(kit.first("cine_lagrima"))
      kit.destroy(kit.first("cine_lagrima"))
    end
    if cine_ticks == 170 then
      kit.spawn("cine_suspiro", 78, 906)
    end
    if cine_ticks == 210 then
      kit.spawn("cine_dialogo", 8, 1024)
    end
    if cine_ticks >= 210 and cine_ticks < 228 then
      kit.set(kit.first("cine_dialogo"), "y", kit.get(kit.first("cine_dialogo"), "y") - 2)
    end
    if cine_ticks == 210 then
      kit.destroy(kit.first("cine_suspiro"))
    end
    if cine_ticks == 298 then
      kit.set_sprite(kit.first("cine_dialogo"), "cine_dialogo_fin")
    end
    if cine_ticks >= 510 then
      kit.goto_level("arbol")
    end
  end
end)

kit.on("press", "a", function()
  if pantalla == 3 and cine_ticks >= 298 then
    kit.goto_level("arbol")
  end
end)

function _init() kit.init() end
function _update() kit.update() end
function _draw() kit.draw() end
