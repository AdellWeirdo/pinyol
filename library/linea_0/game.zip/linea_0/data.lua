-- Made by pinyol's editor from the project "LÍNEA 0": change it there.
return {
  title = "LÍNEA 0",
  tile = 16,
  style = {
    text = 16316664,
    outline = 1052696,
    accent = 16306248,
    bad = 16277576,
    heart = 15749224
  },
  sprites = {
    tren = {
      w = 47,
      h = 25,
      frames = 4
    },
    cabecera = {
      w = 19,
      h = 31,
      frames = 1
    },
    mercado = {
      w = 19,
      h = 31,
      frames = 1
    },
    intercambiador = {
      w = 19,
      h = 31,
      frames = 1
    },
    feria = {
      w = 19,
      h = 31,
      frames = 1
    },
    final = {
      w = 19,
      h = 31,
      frames = 1
    },
    aviso = {
      w = 16,
      h = 2,
      frames = 1
    },
    pasajero = {
      w = 14,
      h = 21,
      frames = 5
    },
    gente = {
      w = 14,
      h = 21,
      frames = 4
    },
    prisas = {
      w = 11,
      h = 21,
      frames = 4
    },
    espera = {
      w = 11,
      h = 21,
      frames = 2
    },
    operadora = {
      w = 11,
      h = 23,
      frames = 4
    },
    tren_triste = {
      w = 47,
      h = 25,
      frames = 2
    },
    tren_contento = {
      w = 47,
      h = 25,
      frames = 4
    },
    maquina = {
      w = 24,
      h = 30,
      frames = 1
    },
    salida = {
      w = 28,
      h = 28,
      frames = 1
    },
    corazon = {
      w = 14,
      h = 11,
      frames = 1
    },
    revisor = {
      w = 12,
      h = 11,
      frames = 2
    },
    abuela = {
      w = 13,
      h = 11,
      frames = 1
    },
    turista = {
      w = 13,
      h = 11,
      frames = 1
    },
    pared = {
      w = 16,
      h = 16,
      frames = 1
    },
    franja = {
      w = 16,
      h = 16,
      frames = 1
    },
    cartel1 = {
      w = 16,
      h = 16,
      frames = 1
    },
    cartel2 = {
      w = 16,
      h = 16,
      frames = 1
    },
    reloj = {
      w = 16,
      h = 16,
      frames = 1
    },
    techo = {
      w = 16,
      h = 16,
      frames = 1
    },
    tunel = {
      w = 16,
      h = 16,
      frames = 1
    },
    via = {
      w = 16,
      h = 16,
      frames = 1
    },
    balasto = {
      w = 16,
      h = 16,
      frames = 1
    },
    anden = {
      w = 16,
      h = 16,
      frames = 1
    },
    banco = {
      w = 16,
      h = 16,
      frames = 1
    },
    suelo = {
      w = 16,
      h = 16,
      frames = 1
    },
    escalon = {
      w = 16,
      h = 16,
      frames = 1
    },
    maleta = {
      w = 16,
      h = 16,
      frames = 1
    },
    azulejo = {
      w = 16,
      h = 16,
      frames = 1
    },
    flecha = {
      w = 16,
      h = 16,
      frames = 1
    },
    vagon = {
      w = 16,
      h = 16,
      frames = 1
    },
    chapa = {
      w = 16,
      h = 16,
      frames = 1
    },
    asiento = {
      w = 16,
      h = 16,
      frames = 1
    },
    barra = {
      w = 16,
      h = 16,
      frames = 1
    },
    tunel_fondo = {
      w = 64,
      h = 160,
      frames = 1
    },
    portada = {
      w = 240,
      h = 160,
      frames = 1
    }
  },
  kinds = {
    tren = {
      behaviour = "platformer",
      speed = 2.4,
      jump = 0,
      animate = 4,
      anims = {
        idle = {0, 0},
        walk = {0, 3},
        hit = {0, 0}
      }
    },
    cabecera = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    mercado = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    intercambiador = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    feria = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    final = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    aviso = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    pasajero = {
      behaviour = "platformer",
      speed = 1.8,
      jump = 4.6,
      animate = 5,
      anims = {
        idle = {0, 0},
        walk = {0, 3},
        hit = {4, 4}
      }
    },
    gente = {
      behaviour = "patrol",
      speed = 0.5,
      jump = 4.5,
      animate = 8
    },
    prisas = {
      behaviour = "patrol",
      speed = 1.1,
      jump = 4.5,
      animate = 4
    },
    espera = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 30
    },
    operadora = {
      behaviour = "platformer",
      speed = 1.6,
      jump = 4.2,
      animate = 5,
      anims = {
        idle = {0, 0},
        walk = {0, 3},
        hit = {0, 0}
      }
    },
    tren_triste = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 0
    },
    tren_contento = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 3
    },
    maquina = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    salida = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    corazon = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    revisor = {
      behaviour = "grid",
      speed = 1.6,
      jump = 4.5,
      animate = 6
    },
    abuela = {
      behaviour = "push",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    turista = {
      behaviour = "push",
      speed = 1,
      jump = 4.5,
      animate = 8
    },
    portada = {
      behaviour = "still",
      speed = 1,
      jump = 4.5,
      animate = 8
    }
  },
  solid = {
    via = true,
    balasto = true,
    suelo = true,
    escalon = true,
    maleta = true,
    chapa = true,
    barra = true
  },
  sounds = {
    parada = {
      recipe = "blip",
      seed = 86706
    },
    dingdong = {
      recipe = "powerup",
      seed = 95969
    },
    huida = {
      recipe = "jump",
      seed = 63408
    },
    choque = {
      recipe = "hit",
      seed = 36167
    },
    ok = {
      recipe = "coin",
      seed = 45389
    },
    ganar = {
      recipe = "powerup",
      seed = 89204
    },
    perder = {
      recipe = "explosion",
      seed = 32073
    }
  },
  ending = "Servicio normalizado. Nadie sabe cómo.",
  cover = {
    text = "LÍNEA 0",
    subtitle = "Pulse A para iniciar el servicio",
    background = 1052696,
    picture = "portada",
    music = "MUS_tema",
    tiled = false
  },
  levels = {
    {
      id = "nivel1",
      name = "Servicio normal",
      background = 1052696,
      camera = "tren",
      backdrops = {
        {
          sprite = "tunel_fondo",
          parallax = 0.4
        }
      },
      music = "MUS_tema",
      objects = {
        {
          kind = "cabecera",
          x = 63,
          y = 97
        },
        {
          kind = "mercado",
          x = 271,
          y = 97
        },
        {
          kind = "espera",
          x = 243,
          y = 107
        },
        {
          kind = "espera",
          x = 451,
          y = 107
        },
        {
          kind = "espera",
          x = 659,
          y = 107
        },
        {
          kind = "espera",
          x = 867,
          y = 107
        },
        {
          kind = "intercambiador",
          x = 479,
          y = 97
        },
        {
          kind = "feria",
          x = 687,
          y = 97
        },
        {
          kind = "final",
          x = 895,
          y = 97
        },
        {
          kind = "tren",
          x = 25,
          y = 103
        }
      },
      map = {
        w = 64,
        h = 10,
        tiles = {"techo", "pared", "reloj", "cartel1", "cartel2", "franja", "banco", "anden", "via", "balasto"},
        cells = {
          1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
          2, 2, 2, 2, 3, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 3, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 3, 2,
          2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 3, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 3, 2, 2, 2, 2, 0, 0, 0,
          2, 2, 4, 2, 2, 2, 5, 2, 2, 0, 0, 0, 0, 2, 2, 4, 2, 2, 2, 5, 2, 2, 0, 0, 0, 0, 2, 2, 4, 2, 2, 2,
          5, 2, 2, 0, 0, 0, 0, 2, 2, 4, 2, 2, 2, 5, 2, 2, 0, 0, 0, 0, 2, 2, 4, 2, 2, 2, 5, 2, 2, 0, 0, 0,
          6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6,
          6, 6, 6, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0,
          2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2,
          2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0,
          2, 7, 2, 2, 2, 2, 2, 7, 2, 0, 0, 0, 0, 2, 7, 2, 2, 2, 2, 2, 7, 2, 0, 0, 0, 0, 2, 7, 2, 2, 2, 2,
          2, 7, 2, 0, 0, 0, 0, 2, 7, 2, 2, 2, 2, 2, 7, 2, 0, 0, 0, 0, 2, 7, 2, 2, 2, 2, 2, 7, 2, 0, 0, 0,
          8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8,
          8, 8, 8, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0,
          9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
          9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
          10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
          10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10
        }
      }
    },
    {
      id = "nivel2",
      name = "Estación tímida",
      background = 1052696,
      camera = "tren",
      backdrops = {
        {
          sprite = "tunel_fondo",
          parallax = 0.4
        }
      },
      music = "MUS_tema",
      objects = {
        {
          kind = "tren",
          x = 25,
          y = 103
        },
        {
          kind = "cabecera",
          x = 63,
          y = 97
        },
        {
          kind = "mercado",
          x = 271,
          y = 97
        },
        {
          kind = "espera",
          x = 243,
          y = 107
        },
        {
          kind = "espera",
          x = 451,
          y = 107
        },
        {
          kind = "espera",
          x = 659,
          y = 107
        },
        {
          kind = "espera",
          x = 867,
          y = 107
        },
        {
          kind = "intercambiador",
          x = 479,
          y = 97
        },
        {
          kind = "feria",
          x = 687,
          y = 97
        },
        {
          kind = "final",
          x = 895,
          y = 97
        },
        {
          kind = "aviso",
          x = 656,
          y = 125
        }
      },
      map = {
        w = 64,
        h = 10,
        tiles = {"techo", "pared", "reloj", "cartel1", "cartel2", "franja", "banco", "anden", "via", "balasto"},
        cells = {
          1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
          2, 2, 2, 2, 3, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 3, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 3, 2,
          2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 3, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 3, 2, 2, 2, 2, 0, 0, 0,
          2, 2, 4, 2, 2, 2, 5, 2, 2, 0, 0, 0, 0, 2, 2, 4, 2, 2, 2, 5, 2, 2, 0, 0, 0, 0, 2, 2, 4, 2, 2, 2,
          5, 2, 2, 0, 0, 0, 0, 2, 2, 4, 2, 2, 2, 5, 2, 2, 0, 0, 0, 0, 2, 2, 4, 2, 2, 2, 5, 2, 2, 0, 0, 0,
          6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6,
          6, 6, 6, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0,
          2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2,
          2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0,
          2, 7, 2, 2, 2, 2, 2, 7, 2, 0, 0, 0, 0, 2, 7, 2, 2, 2, 2, 2, 7, 2, 0, 0, 0, 0, 2, 7, 2, 2, 2, 2,
          2, 7, 2, 0, 0, 0, 0, 2, 7, 2, 2, 2, 2, 2, 7, 2, 0, 0, 0, 0, 2, 7, 2, 2, 2, 2, 2, 7, 2, 0, 0, 0,
          8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8,
          8, 8, 8, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0,
          9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
          9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
          10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
          10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10
        }
      }
    },
    {
      id = "nivel3",
      name = "Transbordo de 2 minutos",
      background = 2119768,
      camera = "pasajero",
      backdrops = {},
      music = "MUS_tema",
      objects = {
        {
          kind = "pasajero",
          x = 27,
          y = 123
        },
        {
          kind = "gente",
          x = 203,
          y = 123
        },
        {
          kind = "gente",
          x = 411,
          y = 75
        },
        {
          kind = "gente",
          x = 731,
          y = 123
        },
        {
          kind = "prisas",
          x = 555,
          y = 123
        },
        {
          kind = "prisas",
          x = 891,
          y = 123
        },
        {
          kind = "corazon",
          x = 401,
          y = 75
        },
        {
          kind = "corazon",
          x = 721,
          y = 59
        },
        {
          kind = "salida",
          x = 962,
          y = 116
        }
      },
      map = {
        w = 64,
        h = 10,
        tiles = {"azulejo", "flecha", "suelo", "escalon", "maleta"},
        cells = {
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4,
          4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4,
          4, 4, 1, 1, 1, 1, 5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
          3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3
        }
      }
    },
    {
      id = "nivel4",
      name = "Tren emocional",
      background = 1052696,
      camera = "operadora",
      backdrops = {},
      music = "MUS_tema",
      objects = {
        {
          kind = "operadora",
          x = 27,
          y = 105
        },
        {
          kind = "maquina",
          x = 84,
          y = 98
        },
        {
          kind = "tren_triste",
          x = 329,
          y = 103
        },
        {
          kind = "espera",
          x = 203,
          y = 107
        }
      },
      map = {
        w = 30,
        h = 10,
        tiles = {"techo", "pared", "reloj", "cartel1", "cartel2", "franja", "banco", "anden", "via", "balasto"},
        cells = {
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2,
          2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2,
          2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 5, 2, 2, 2, 6, 6, 6, 6, 6, 6, 6, 6,
          6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
          2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 7, 2, 2,
          2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
          8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
          9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
          10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10
        }
      }
    },
    {
      id = "nivel5",
      name = "Hora punta",
      background = 1052696,
      camera = "revisor",
      backdrops = {},
      music = "MUS_tema",
      objects = {
        {
          kind = "abuela",
          x = 50,
          y = 83
        },
        {
          kind = "abuela",
          x = 146,
          y = 83
        },
        {
          kind = "turista",
          x = 114,
          y = 67
        },
        {
          kind = "turista",
          x = 178,
          y = 67
        },
        {
          kind = "revisor",
          x = 114,
          y = 115
        }
      },
      map = {
        w = 15,
        h = 10,
        tiles = {"chapa", "vagon", "asiento", "barra"},
        cells = {
          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 3, 2, 2, 3, 2, 2, 1, 1, 2,
          2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 4, 2, 4, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2,
          2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2,
          2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2,
          2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
        }
      }
    }
  },
  start = nil
}
