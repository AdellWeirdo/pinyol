-- LÍNEA 0: made with pinyol's editor. The blocks' code is below; kit.lua (a copy of pinyol's
-- lib/kit.lua) does the rest: the levels, the map, the objects that move by themselves, the events.
kit = require("kit")
kit.setup(require("data"))

obj = 0
fin = 0
dist = 0
amagos = 0
lado = 0
vecina = 0
confianza = 0
cafe = 0

kit.on("level", "nivel1", function()
  obj = 1
  dist = 0
  kit.label("top_right", 'Servicio normal', "top_right")
  kit.label("bottom", 'Próxima estación: Final de Trayecto', "bottom", "shadow")
end)

kit.on("tick", function()
  if obj < 3 then
    dist = dist + math.abs(kit.get(kit.player(), "vx"))
  end
end)

kit.on("tick", function()
  if obj == 10 and (math.abs(kit.get(kit.player(), "x") - kit.get(kit.first("intercambiador"), "x")) < 28 and kit.get(kit.player(), "vx") == 0 or math.abs(kit.get(kit.player(), "x") - kit.get(kit.first("final"), "x")) < 28 and kit.get(kit.player(), "vx") == 0) then
    vecina = 1
  end
end)

kit.on("touch", "tren", "final", function(este, otro)
  if obj == 1 then
    obj = 2
    kit.sound("dingdong")
    kit.message('Un pasajero cree haberse dejado el móvil en Cabecera.', 3)
    kit.label("bottom", 'Próxima estación: Cabecera', "bottom", "shadow")
  end
end)

kit.on("touch", "pasajero", "gente", function(este, otro)
  kit.add_lives(-1)
  kit.play(este, "hit")
  kit.sound("choque")
  kit.message('Disculpe.', 1)
  kit.change(este, "x", -24)
end)

kit.on("level", "nivel2", function()
  obj = 10
  amagos = 0
  vecina = 0
  lado = 0
  kit.label("top_right", 'Estación tímida', "top_right")
  kit.label("bottom", 'Próxima estación: Feria de Muestras', "bottom", "shadow")
end)

kit.on("touch", "operadora", "maquina", function(este, otro)
  if cafe == 0 then
    cafe = 1
    kit.sound("ok")
    kit.message('Café de máquina. Tibio.', 2)
  end
end)

kit.on("tick", function()
  if obj == 40 and kit.count_on("abuela", "asiento") + kit.count_on("turista", "asiento") == 4 then
    obj = 41
    kit.sound("dingdong")
    kit.message('Todos sentados. Puertas cerrándose.', 4)
    fin = 1
  end
end)

kit.on("touch", "tren", "aviso", function(este, otro)
  if obj == 10 and (vecina == 0 and amagos < 3) then
    amagos = amagos + 1
    kit.sound("huida")
    kit.message('La estación no desea recibir visitas.', 2)
    if lado == 0 then
      kit.change(kit.first("feria"), "x", 80)
      kit.change(kit.first("aviso"), "x", 80)
      lado = 1
    else
      kit.change(kit.first("feria"), "x", -80)
      kit.change(kit.first("aviso"), "x", -80)
      lado = 0
    end
  end
end)

kit.on("touch", "pasajero", "prisas", function(este, otro)
  kit.add_lives(-1)
  kit.play(este, "hit")
  kit.sound("choque")
  kit.message('Perdone, tengo prisa.', 1)
  kit.change(este, "x", -24)
end)

kit.on("touch", "operadora", "tren_triste", function(este, otro)
  if obj == 30 then
    kit.ask('El tren no desea salir hoy.', 'Arranca ya.', '¿Estás bien?', 'Te he traído un café.')
  end
end)

kit.on("touch", "tren", "cabecera", function(este, otro)
  if obj == 2 then
    obj = 3
    kit.sound("dingdong")
    kit.message(table.concat({'Pasajeros: 1 · Km reales: ', math.floor(dist / 40 + .5) / 10, ' · Teléfonos: 1 (en su bolsillo)'}), 5)
    kit.label("bottom", 'Servicio normalizado.', "bottom", "shadow")
    fin = 1
  end
end)

kit.on("level", "nivel3", function()
  obj = 20
  kit.set_lives(3)
  kit.countdown(120)
  kit.label("top_right", 'Transbordo', "top_right")
  kit.label("bottom", 'Transbordo: 2 minutos administrativos', "bottom", "shadow")
end)

kit.on("answer", 1, function()
  kit.sound("choque")
  kit.say('Tren', 'Servicio temporalmente emocional.')
end)

kit.on("touch", "pasajero", "corazon", function(este, otro)
  kit.add_lives(1)
  kit.sound("ok")
  kit.destroy(otro)
end)

kit.on("level", "nivel4", function()
  obj = 30
  confianza = 0
  cafe = 0
  kit.set_lives(0)
  kit.label("top_right", 'Tren emocional', "top_right")
  kit.label("bottom", 'Estado del servicio: temporalmente emocional', "bottom", "shadow")
end)

kit.on("touch", "tren", "feria", function(este, otro)
  if obj == 10 then
    obj = 11
    kit.sound("dingdong")
    kit.message(table.concat({'Amagos: ', amagos, ' · Tímido de verdad: el tren.'}), 5)
    kit.label("bottom", 'Estación localizada.', "bottom", "shadow")
    fin = 1
  else
    kit.sound("parada")
    kit.message('Feria de Muestras', 1.2)
  end
end)

kit.on("answer", 2, function()
  confianza = confianza + 1
  kit.say('Tren', 'Nadie me pregunta nunca.')
end)

kit.on("touch", "tren", "mercado", function(este, otro)
  kit.sound("parada")
  kit.message('Mercado Viejo', 1.2)
end)

kit.on("touch", "pasajero", "salida", function(este, otro)
  if obj == 20 then
    obj = 21
    kit.stop_countdown()
    kit.sound("dingdong")
    kit.message('Transbordo completado. Ha durado dos minutos administrativos.', 5)
    fin = 1
  end
end)

kit.on("answer", 3, function()
  if cafe == 1 then
    confianza = confianza + 1
    cafe = 2
    kit.say('Tren', 'Tibio. Como a mí me gusta.')
  else
    kit.say('Tren', 'No veo ningún café.')
  end
end)

kit.on("touch", "tren", "intercambiador", function(este, otro)
  kit.sound("parada")
  kit.message('Intercambiador', 1.2)
end)

kit.on("level", "nivel5", function()
  obj = 40
  kit.set_lives(0)
  kit.label("top_right", 'Hora punta', "top_right")
  kit.label("bottom", 'Hora punta: siente a todo el mundo', "bottom", "shadow")
end)

kit.on("time_up", function()
  kit.lose('Su transbordo ha caducado.')
end)

kit.on("tick", function()
  if obj == 30 and confianza >= 2 then
    obj = 31
    kit.set_sprite(kit.first("tren_triste"), "tren_contento")
    kit.sound("dingdong")
    kit.message('Servicio normalizado. Nadie sabe cómo.', 4)
    kit.set(kit.first("tren_triste"), "vx", 1.5)
    fin = 1
  end
end)

kit.on("level", function()
  fin = 0
  kit.label("top_left", 'LÍNEA 0', "top_left", "big")
end)

kit.on("no_lives", function()
  kit.lose('Demasiados empujones.')
end)

kit.on("every", 1, function()
  if fin > 0 then
    fin = fin + 1
    if fin >= 6 then
      fin = 0
      kit.next_level()
    end
  end
end)

function _init() kit.init() end
function _update() kit.update() end
function _draw() kit.draw() end
