-- Abella: made with pinyol's editor. The blocks' code is below; kit.lua (a copy of pinyol's
-- lib/kit.lua) does the rest: the levels, the map, the objects that move by themselves, the events.
kit = require("kit")
kit.setup(require("data"))

pol = 0
mel = 0
meta = 0
total = 0

kit.on("start", function()
  total = 0
end)

kit.on("touch", "abella", "flor", function(este, otro)
  if pol == 0 then
    pol = 1
    kit.set_sprite(este, "abella_pol")
    kit.sound("pol")
    kit.spawn_at("poncella", otro)
    kit.destroy(otro)
  end
end)

kit.on("touch", "abella", "aranya", function(este, otro)
  pol = 0
  kit.set_sprite(este, "abella")
  kit.sound("pica")
  kit.message('Una teranyina! Has perdut el pol·len.', 2)
  kit.set(este, "x", kit.get(kit.first("rusc"), "x") + 8)
  kit.set(este, "y", kit.get(kit.first("rusc"), "y") + 36)
end)

kit.on("level", "nivel1", function()
  meta = 5
end)

kit.on("level", "nivel2", function()
  meta = 7
end)

kit.on("touch", "abella", "marieta", function(este, otro)
  kit.add_lives(1)
  kit.sound("cor")
  kit.burst_at(otro, 0xFFFFFF)
  kit.destroy(otro)
  kit.message('Marieta de la sort! +1 vida', 2)
end)

kit.on("touch", "abella", "rusc", function(este, otro)
  if pol == 1 then
    pol = 0
    mel = mel + 1
    total = total + 1
    kit.set_sprite(este, "abella")
    kit.sound("mel")
    kit.burst_at(otro, 0xFFE070)
    kit.label("top_left", table.concat({'Mel ', mel, '/', meta}), "top_left")
    if mel >= meta then
      do local v = total if v > (tonumber(stored("rècord", 0)) or 0) then store("rècord", v) end end
      kit.next_level()
    end
  end
end)

kit.on("level", "nivel3", function()
  meta = 9
end)

kit.on("level", function()
  pol = 0
  mel = 0
  kit.set_lives(3)
  kit.label("top_left", table.concat({'Mel ', mel, '/', meta}), "top_left")
  kit.label("top", 'Rècord ' .. stored("rècord", 0), "top")
end)

kit.on("touch", "abella", "cor", function(este, otro)
  kit.add_lives(1)
  kit.sound("cor")
  kit.destroy(otro)
end)

kit.on("touch", "abella", "vespa", function(este, otro)
  kit.add_lives(-1)
  pol = 0
  kit.set_sprite(este, "abella")
  kit.play(este, "hit")
  kit.shake(5)
  kit.sound("pica")
  kit.set(este, "x", kit.get(kit.first("rusc"), "x") + 8)
  kit.set(este, "y", kit.get(kit.first("rusc"), "y") + 36)
end)

kit.on("touch", "abella", "granota", function(este, otro)
  kit.message('Ribbit! Les vespes no travessen els arbres.', 3)
end)

kit.on("every", 4, function()
  if kit.count("poncella") > 0 then
    kit.spawn_at("flor", kit.first("poncella"))
    kit.destroy(kit.first("poncella"))
  end
end)

kit.on("every", 15, function()
  if kit.count("vespa") < 4 then
    kit.spawn("vespa", 24, 24)
    kit.sound("brunzit")
    kit.message('Bzzz! Arriba una vespa.', 1.5)
  end
end)

kit.on("no_lives", function()
  do local v = total if v > (tonumber(stored("rècord", 0)) or 0) then store("rècord", v) end end
  kit.lose('T\'han picat massa!')
end)

function _init() kit.init() end
function _update() kit.update() end
function _draw() kit.draw() end
