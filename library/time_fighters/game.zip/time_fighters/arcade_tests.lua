return function()
 local A=require('arcade');local AI=require('cpu');local R=require('rules')
 local signatures={}
 for pick=1,12 do
  for seed=1,40 do
   local route=A.route(pick,13,seed,13);assert(#route==12 and route[12]==13);local seen={}
   for i,who in ipairs(route) do
    assert(who~=pick and not seen[who]);seen[who]=true
    local cfg=AI.profile(A.level(1,i,12))
    if i>1 then local prev=AI.profile(A.level(1,i-1,12));assert(cfg.think<=prev.think and cfg.step<=prev.step and cfg.error<=prev.error) end
    assert(A.advance(i,12,false)==i)
   end
   local prev=AI.profile(A.level(1,11,12));local boss=AI.profile(A.level(1,12,12));assert(boss.step<prev.step)
   if pick==1 then signatures[table.concat(route,',')]=true end
  end
 end
 local count=0;for _ in pairs(signatures) do count=count+1 end;assert(count>30)
 for who=1,13 do
  assert(#R.patterns[who]==4)
  for _,row in ipairs(R.patterns[who]) do assert(#row==6);for _,c in ipairs(row) do assert(c>=1 and c<=4) end end
  local a,b=R.new(123,1),R.new(123,who)
  for n=1,60 do local x,y=R.next(a),R.next(b);for j=1,2 do assert(x[j].c==y[j].c and x[j].k==y[j].k) end end
 end
 return true
end
