-- Visible bounds of the approved full-body result illustrations.
return {
}
