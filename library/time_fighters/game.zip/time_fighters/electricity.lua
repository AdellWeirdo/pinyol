-- Original pixel geometry: branching arcs inside the accumulator's glass.
-- Deliberately stepped changes of shape rather than rotating straight spokes.
local E={}
local function point(x,y)
 local r=math.sqrt((x/20)^2+(y/23)^2)
 if r>.96 then x=x*.96/r;y=y*.96/r end
 return {x=239+math.floor(x+.5),y=50+math.floor(y+.5)}
end
function E.frame(t,charge)
 local phase=t%108
 if charge<=0 and (phase>=62 or (phase>=32 and phase<42)) then return {} end
 local f=t//3;local count=charge>0 and 5 or 3+(f//2)%3;local arcs={}
 for i=1,count do
  local angle=i*math.pi*2/count+math.sin(t//108*4.1)*2+.17*math.sin(f*.8+i*3)
  local ux,uy=math.cos(angle),math.sin(angle)
  local points={point(0,0)}
  for j=1,4 do
   local p=j/4;local bend=j==4 and 0 or math.sin(f*2.3+i*5.7+j*2.1)*3.4
   points[#points+1]=point(ux*20*p-uy*bend,uy*23*p+ux*bend)
  end
  local forks={}
  for branch=1,2 do
   local side=branch==1 and -1 or 1;local a=angle+side*(.4+.14*math.sin(f+i))
   local start=points[branch+1]
   local tip=point(math.cos(a)*19,math.sin(a)*22)
   local middle=point((start.x-239+tip.x-239)/2+side*2,(start.y-50+tip.y-50)/2-side)
   forks[#forks+1]={start,middle,tip}
  end
  arcs[#arcs+1]={points=points,forks=forks}
 end
 return arcs
end
return E
