-- main.lua already presents the approved Andromina -> Powered by Pinyol intro.
-- The current official engine supports splash.lua; avoid a second engine intro
-- before that approved sequence. Older engines ignore this adapter.
return {update=function()return true end}
