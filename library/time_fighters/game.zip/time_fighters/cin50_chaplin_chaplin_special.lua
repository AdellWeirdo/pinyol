-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_chaplin_assets');local img=Assets.img;local imgsize=Assets.size
-- Only actor cycle and canonical black dust change. Machinery and sound stay intact.
local S={}
function S.actor(f)
 img('CHAPLIN_CRANK',78-56*1.12,293-120*1.12,{frame=((f-100)//9)%8,scale=1.12})
end
function S.cloud(f)
 local puffs={{404,188,1.10,191},{415,234,1.15,195},{378,274,1.20,198},{338,237,1.04,201},{351,191,.88,204}}
 for i,c in ipairs(puffs)do
  local age=f-c[4]
  if age>=0 then
   local dissolve=math.max(0,f-(254+i*2));local sc=c[3]*(.72+.28*math.min(1,age/8));local cel=age<7 and 0 or dissolve==0 and 1+((age//7)%3) or dissolve<12 and 4 or 5
   img('DUST_CHAPLIN_BLACK',c[1]-48*sc+math.sin(age*.12+i)*2,c[2]-48*sc-dissolve*.4,{frame=cel,scale=sc,alpha=math.max(0,1-dissolve/23)})
  end
 end
end
return S
