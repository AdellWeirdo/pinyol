-- Cinematics are presentation only: puzzle simulation and damage stay in main/rules.
local S={duration=330}
local L=require('layout')
local Idle=require('idle')
local idleClock=0
local Cultural=require('cultural_specials')
local Genius=require('genius_specials')
local ids={};for i,c in ipairs(require('roster')) do ids[i]=c.id end
local function actor(who,cx,ground,frame,flip,scale)
 local pivot=L.actors.pivots[who];local origin=flip and 148-pivot or pivot
 local rest=frame<6
 img((rest and 'IDLE_' or 'FIGHTER_')..ids[who],cx-origin*scale,ground-L.actors.feet[who]*scale,{frame=rest and Idle.frame(idleClock) or frame,flip_x=flip,scale=scale})
end
local function prop(name,x,ground,frame,scale,alpha)
 local _,h=imgsize(name);img(name,x,ground-h*scale,{frame=frame,scale=scale,alpha=alpha or 1})
end
local function dust(x,ground,t,scale,tint)
 if t>=0 and t<36 then img('DUST',x-36*scale,ground-48*scale-t*.25,{scale=scale,alpha=math.min(1,t/5)*(1-t/36)*.75,tint=tint}) end
end
function S.sounds(who,f,snd)
 if who>=10 then Genius.sounds(who,f,snd);return end
 if who~=5 then Cultural.sounds(who,f,snd);return end
 if who==5 then
  if f==42 or f==74 then snd('QUILL') end
  if f==65 or f==100 or f==129 or f==170 then snd('PAGES') end
 else
  if f==45 or f==85 then snd('BELL') end
 end
 if f>=110 and f<=250 and f%12==0 then snd('GALLOP',.65) end
 if f==165 or f==198 or f==230 then snd('HIT',.8) end
end
function S.draw(who,f,rival)
 if who>=10 then Genius.draw(who,f,rival);return end
 idleClock=f
 if who~=5 then Cultural.draw(who,f,rival);return end
 local secs=f/60;local name=ids[who]
 img('STAGE_'..name,0,0)
 if f>55 then img('SPECIAL_'..name,0,0,{alpha=math.min(1,(f-55)/35)}) end
 local heroFrame=f<62 and (f//8)%6 or f<92 and 27 or f<250 and 28 or f<280 and 29 or (f//8)%6
 local enemyFrame=f<165 and 0 or f<255 and 13 or 41
 local lift=f>=165 and f<255 and math.abs(math.sin(f*.12))*14 or 0
 if who==5 then
  if f>=80 and f<278 then
   local rise=math.min(1,(f-80)/35)*math.min(1,(278-f)/35)
   local phase=f<105 and 0 or f<155 and 1 or f<198 and 2 or 3
   prop('INK_GIANT',2,158,phase,.4+.6*rise,rise*.88)
   img('INK_GIANT',347,176-136*(.35+.6*rise),{frame=phase,scale=.35+.6*rise,flip_x=true,alpha=rise*.88})
  end
  if f>=43 and f<282 then
   local grow=math.min(1,(f-43)/28);local frame=f<60 and 0 or f<75 and 1 or f<91 and 2 or 3
   prop('BOOK',147+math.sin(secs*2)*2,240,frame,.25+grow*.75,math.min(1,(282-f)/25))
  end
  actor(rival,392,293-lift,enemyFrame,true,1.05)
  local q=f-108
  if q>=0 and q<125 then
   local x=85+q*3.6;prop('QUIJOTE',x,250,(f//5)%6,.92)
   dust(x+25,250,q%32,.8)
  end
  local t=f-146
  if t>=0 and t<135 then
   local x=75+t*3.6;prop('SANCHO',x,287,(f//5+2)%6,.95)
   dust(x+20,287,t%32,.9)
  end
  actor(who,82,293,heroFrame,false,1.18)
  if f>=90 and f<263 then
   for j=0,11 do
    local age=(f-90+j*8)%104;local p=age/104
    img('PAGES',166+p*285,203-math.sin(p*math.pi)*100+(j%3)*12,{frame=(f//6+j)%4,angle=age*4+j*31,scale=.7+(j%3)*.15,alpha=1-p*.5})
   end
  end
 end
 for _,hit in ipairs({165,198,230}) do
  local age=f-hit
  if age>=0 and age<18 then img('HIT',354,180,{scale=1+age*.03,alpha=1-age/18,tint=who==5 and 0xaacbff or 0xffdfa0}) end
 end
 if f>=175 and f<286 then
  local fade=math.min(1,(286-f)/30)
  for j=0,3 do
   img('SMOKE',333+(j%2)*24,191+(j//2)*26-math.sin(f*.04+j)*3,{scale=.85+j*.04,alpha=fade*(.5+.1*math.sin(f*.07+j))})
  end
 end
end
return S
