local S={}
local Assets=require('cin50_cervantes_assets');local img=Assets.img;local imgsize=Assets.size
local Draw=require('cin50_cervantes_cervantes_special');local NewSpecials={draw=function(w,f,r) Draw.draw(f,r) end}
local C=require('cin50_cervantes_roster')
local function text_at(s,x,y,scale,color,align) text(s,x,y,{font='arcade',scale=scale or 1,color=color or 0xffe7a1,gradient=scale and scale>1 and 0xe78332 or nil,outline=0x081126,shadow=0x030712,align=align or 'center'}) end
function S.draw(who,f,rival,side)
 local s={who=who,t=f,side=side};local mirror=side==2
 if s.who==2 then require('cin50_cervantes_curie_special').prepare() end
 if mirror then canvas('CINEMA',480,320);target('CINEMA') end
 NewSpecials.draw(s.who,f,rival)
 -- Full-screen cinematic: decorative outer frame removed.
 if mirror then target();img('CINEMA',0,0,{flip_x=true}) end
 if f>=11 and f<77 then
  if s.who==5 then
   local fade=math.min(1,(f-10)/5,(77-f)/7)
   img('TITLE_SPECIAL_CERVANTES',96,9,{alpha=fade})
   local sweep=96-15+(f-14)/48*318
   clip(math.floor(sweep),9,10,57)
   img('TITLE_SPECIAL_CERVANTES',96,9,{tint=0xffefba,alpha=fade*.30})
   clip()
  elseif s.who==4 then
   local fade=math.min(1,(f-10)/5,(77-f)/7)
   img('TITLE_SPECIAL_MARILYN',123,9,{alpha=fade})
   local sweep=123-16+(f-14)/48*266
   clip(math.floor(sweep),9,12,59)
   img('TITLE_SPECIAL_MARILYN',123,9,{tint=0xfff7d8,alpha=fade*.45})
   clip()
  elseif s.who==3 then
   local fade=math.min(1,(f-10)/5,(77-f)/7)
   img('TITLE_SPECIAL_VANGOGH',92,9,{alpha=fade})
   local sweep=92-20+(f-14)/48*335
   clip(math.floor(sweep),9,10,58)
   img('TITLE_SPECIAL_VANGOGH',92,9,{tint=0xffefb5,alpha=fade*.36})
   clip()
  elseif s.who==2 then
   local fade=math.min(1,(f-10)/5,(77-f)/7)
   -- Gentle flame movement behind the fixed letterforms: the glyphs never squash or drift.
   local flame=1+(.018+.014*math.sin(f*.65))
   img('TITLE_SPECIAL_CURIE',84,9-1,{scale_y=flame,tint=0x6aff17,alpha=fade*(.15+.035*math.sin(f*.8))})
   img('TITLE_SPECIAL_CURIE',84,9,{alpha=fade})
   local sweep=84-20+(f-14)/48*351
   clip(math.floor(sweep),9,12,58)
   img('TITLE_SPECIAL_CURIE',84,9,{tint=0xcaff8a,alpha=fade*.36})
   clip()
  else
   rect(6,13,468,40,0x10192b);box(6,13,468,40,0xd99d4b)
   local label=C[s.who].special
   text_at(label,240,26,textw(label,{font='arcade',scale=2})<=450 and 2 or 1,0xffda87)
  end
 end
end

return S
