local UI=require('ui_style');local C=require('roster');local Select=require('character_select');local Music=require('stage_music');local Soundtrack=require('soundtrack');local Approved=require('cinema_approved')
local G={selected=1,tab=1,zoom=false,page=1,playing=false,unlocks={},clock=0}
local labels={'ILUSTRACIONES','ESCENARIOS','ESPECIAL'}
local arts={{'MODEL_SHEET_','MODEL SHEET'},{'SELECT_','SELECCION'},{'RESULT_WIN_','VICTORIA'},{'RESULT_LOSE_','DERROTA'},{'FINAL_WIN_','VICTORIA TOTAL'},{'GALLERY_CONCEPT_','ARTE CONCEPTUAL'}}
local function label(s,x,y,scale,width,color)
 scale=scale or 1;if width then while scale>.5 and UI.width(s,{scale=scale})>width do scale=scale-.1 end end
 UI.text(s,x,y,{align='center',scale=scale,color=color or UI.GOLD})
end
function G.load(read)local v=read('gallery_clears',{});G.unlocks=type(v)=='table' and v or {}end
function G.is_open(id)return G.unlocks[id]==true end
function G.unlock(id,write)if G.is_open(id)then return false end;G.unlocks[id]=true;write('gallery_clears',G.unlocks);return true end
local function stop()if G.handle then sfx_stop(G.handle);G.handle=nil end;G.playing=false end
function G.enter()stop();G.selected=1;G.tab=1;G.zoom=false;G.page=1;G.clock=0 end
local function specialStage()return G.selected==10 and 'SPECIAL_STAGE_KAFKA' or (G.selected==15 or G.selected>=16)and 'SPECIAL_BG_'..C[G.selected].id or nil end
local function count()return G.tab==1 and #arts or G.tab==2 and (specialStage()and 2 or 1)or 1 end
local function song(volume)if G.zoom then Soundtrack.preview(Music[G.selected],volume)else Soundtrack.sync('gallery',1,volume)end end
function G.update(snd,volume)
 if G.playing then
  G.clock=G.clock+1
  if btnp('b')or G.clock>=(G.selected==15 and 378 or 330)then stop()end
  return false
 end
 if btnp('b')then if G.zoom then G.zoom=false;song(volume);return false else return true end end
 if not G.zoom then
  local all={};for i=1,#C do all[i]=i end
  for _,dir in ipairs({'up','down','left','right'})do if btnp(dir)then G.selected=Select.navigate(G.selected,dir,'arcade',all);snd('SELECT')end end
  if(btnp('a')or btnp('start'))and G.is_open(C[G.selected].id)then G.zoom=true;G.tab=1;G.page=1;song(volume);snd('CONFIRM')end
 else
  if btnp('up')then G.tab=(G.tab-2)%3+1;G.page=1;snd('SELECT')end
  if btnp('down')then G.tab=G.tab%3+1;G.page=1;snd('SELECT')end
  if btnp('left')then G.page=(G.page-2)%count()+1;snd('SELECT')end
  if btnp('right')then G.page=G.page%count()+1;snd('SELECT')end
  if(btnp('a')or btnp('start'))then
   if G.tab==3 then G.playing=true;G.clock=-12;G.handle=sfx('CINEMA_'..C[G.selected].id,.75)else G.page=G.page%count()+1;snd('CONFIRM')end
  end
  song(volume)
 end
 return false
end
function G.draw(t)
 local id=C[G.selected].id
 if G.playing then
  if G.clock<0 then img('PLASMA_BACKGROUND',0,0);img('TRANSITION_WHITE',0,0,{alpha=(G.clock+12)/12})
  else Approved.draw(G.selected,G.clock,9,1);local duration=G.selected==15 and 378 or 330;local a=G.clock<12 and 1-G.clock/12 or G.clock>duration-12 and(G.clock-(duration-12))/12 or 0;if a>0 then img('TRANSITION_WHITE',0,0,{alpha=a})end end
  return
 end
 img('PLASMA_BACKGROUND',0,0)
 if not G.zoom then
  label('GALERIA DE HEROES',240,7,2)
  for i,c in ipairs(C)do
   local x,y,w,h=Select.card(i,'arcade');rect(x,y,w,h,0x302b28)
   if G.is_open(c.id)then local fw,fh=imgsize('CARD_FACE_'..c.id);img('CARD_FACE_'..c.id,x+(w-fw)/2,y+(h-fh)/2)else label('?',x+w/2,y+13,3)end
   box(x,y,w,h,i==G.selected and 0x8edfff or 0x9b784b)
  end
  if G.is_open(id)then img('SELECT_'..id,8,40,{scale=212/230})else label('?',93,112,8);label('ARCHIVO',93,204,1.3);label('BLOQUEADO',93,221,1.3)end
  label(G.is_open(id)and C[G.selected].fullname or '????????????',93,260,1,180)
  label(G.is_open(id)and 'ARTE - ESCENARIOS'or'COMPLETA ARCADE',93,280,1,180)
  label(G.is_open(id)and 'ESPECIAL - MUSICA'or'CON ESTE PERSONAJE',93,296,1,180)
 else
  label(C[G.selected].fullname,240,9,1.8,452)
  if G.tab==3 then
   local aid=specialStage()or'STAGE_'..id;img(aid,60,46,{scale=.75});label('REPRODUCIR ESPECIAL',240,251,1.6,400)
  else
   local aid,caption
   if G.tab==1 then aid=arts[G.page][1]..id;caption=arts[G.page][2]else aid=G.page==2 and specialStage()or'STAGE_'..id;caption=G.page==2 and'ESCENARIO DEL ESPECIAL'or'ESCENARIO'end
   local w,h=imgsize(aid);local scale=math.min(410/w,234/h);img(aid,(480-w*scale)/2,40+(234-h*scale)/2,{scale=scale});label(caption,240,278,1)
  end
  for i,s in ipairs(labels)do label(s,80+(i-1)*160,305,1,150,i==G.tab and UI.GOLD or UI.DIM)end
 end
end
function G.draw_unlock()
 img('PLASMA_BACKGROUND',0,0)
 label('ENHORABUENA!',240,77,3);label('HAS DESBLOQUEADO',240,139,1.8);label('TODOS LOS PERSONAJES.',240,160,1.8);label('YA PUEDES ACCEDER',240,212,1.5);label('A LA GALERIA.',240,234,1.5)
end
return G
