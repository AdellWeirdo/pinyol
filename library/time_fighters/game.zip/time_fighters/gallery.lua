local G={selected=1,tab=1,zoom=false,page=1,playing=false,unlocks={}}
function G.load(read) local v=read('gallery_clears',{});G.unlocks=type(v)=='table' and v or {} end
function G.is_open(id)
 if id=='TESLA' then
  for _,c in ipairs(require('roster')) do if c.id~='TESLA' and c.id~='CHAPLIN' and G.unlocks[c.id]~=true then return false end end
  return true
 end
 return G.unlocks[id]==true
end
function G.unlock(id,write)
 if id=='TESLA' or G.is_open(id) then return false end
 G.unlocks[id]=true;write('gallery_clears',G.unlocks);return true
end
function G.enter() G.selected=1;G.tab=1;G.zoom=false;G.page=1;G.playing=false end
return G
