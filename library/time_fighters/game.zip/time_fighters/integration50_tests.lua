-- Regression fixtures for cinematic integration; no runtime hooks.
local T={}
function T.snapshot()
 local function encode(t)
  if type(t)~='table' then return type(t)..':'..tostring(t) end
  local keys={};for k in pairs(t) do keys[#keys+1]=k end
  table.sort(keys,function(a,b)return tostring(a)<tostring(b) end)
  local out={'{'};for _,k in ipairs(keys) do out[#out+1]=encode(k)..'='..encode(t[k]) end;out[#out+1]='}';return table.concat(out,';')
 end
 return encode(boards)
end
function T.fixture()
 state='play'
 for _,b in ipairs(boards) do b.phase='fixture';b.active=nil;b.events={} end
end
return T
