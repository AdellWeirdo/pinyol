local R=require('rules')
local A=require('cpu')
local L=require('layout')
local E=require('electricity')
return function()
 local quiet,active=0,0
 for t=0,107 do
  local arcs=E.frame(t,0)
  if #arcs==0 then quiet=quiet+1 else
   active=active+1;assert(#arcs>=3 and #arcs<=5)
   for _,arc in ipairs(arcs) do
    assert(#arc.forks==2)
    local paths={arc.points,arc.forks[1],arc.forks[2]}
    for _,path in ipairs(paths) do for _,p in ipairs(path) do
     assert(p.x>=219 and p.x<=259 and p.y>=27 and p.y<=73,'arc escapes glass')
    end end
   end
  end
  assert(#E.frame(t,1)==5,'charged sphere must stay active')
 end
 assert(quiet>=40 and active>=40,'idle electricity needs bursts and pauses')
 assert(E.frame(12,0)[1].points[3].x~=E.frame(15,0)[1].points[3].x or E.frame(12,0)[1].points[3].y~=E.frame(15,0)[1].points[3].y,'bolt shape must animate')
 -- Exercise different AI profiles/timings between draws of the shared stream.
 local easy,final=R.new(20261017,1),R.new(20261017,2)
 for pair=1,30 do
  assert(R.spawn(easy) and R.spawn(final))
  for i=1,2 do
   assert(easy.active.v[i].c==final.active.v[i].c and easy.active.v[i].k==final.active.v[i].k,'shared pair differs')
  end
  local se,sf=easy.seed,final.seed
  local soft=false
  for age=0,260 do
   easy.age=age;local input=A.input(easy,1)
   if age<120 then assert(input==nil,'easy CPU must wait') end
   soft=soft or (input and input.down)
   final.age=age;A.input(final,5)
  end
  assert(not soft,'easy CPU must not accelerate')
  assert(easy.ai.actions<=5 and final.ai.actions>=37,'distinct action rates')
  assert(easy.seed==se and final.seed==sf,'AI modified piece RNG')
  easy.turn=pair;final.turn=pair
 end
 local mistakes=0
 for turn=1,20 do
  easy.turn=turn;easy.age=0;A.input(easy,1);easy.age=200;A.input(easy,1)
  if easy.ai.mistake then mistakes=mistakes+1 end
 end
 assert(mistakes>=14,'easy CPU should often choose a random placement')
 local stream=R.new(20261017,1);local sparks,total=0,0
 for _=1,5000 do for _,v in ipairs(R.next(stream)) do
  if v.k~='ray' then total=total+1;if v.k=='spark' then sparks=sparks+1 end end
 end end
 assert(sparks/total>.07 and sparks/total<.12,'spark frequency must stay close to one in twelve')
 for side=1,2 do for x=1,6 do
  local px=L.cell_at(side,x,12);local frame=L.boards[side]
  assert(px>=frame.leftEdge+3 and px+18<=frame.rightEdge-3,'piece covered by border')
 end end
 local b=R.new(20,1);R.spawn(b)
 assert(L.overload(b)==0,'falling pair is not overload')
 b.grid[2][1]=R.cell(1);assert(L.overload(b)==0)
 b.grid[1][1]=R.cell(1);assert(L.overload(b)==.5)
 b.grid[0][1]=R.cell(1);assert(L.overload(b)==1)
 for pick=1,2 do for winner=1,2 do
  local slots,score=L.result({{character=pick},{character=3-pick}},{1,2},winner)
  assert(slots[1].who==pick and slots[2].who==3-pick,'result swaps sides')
  assert(slots[winner].kind=='WIN_' and slots[3-winner].kind=='LOSE_')
  assert(slots[1].x<slots[2].x and score=='1 - 2')
  for side,slot in ipairs(slots) do
   assert((slot.won~=slot.flip)==(side==1),'result portraits must face each other')
  end
 end end
 return true
end
