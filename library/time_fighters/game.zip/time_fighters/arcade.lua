-- Route randomness is isolated from the identical per-round puzzle streams.
local A={REGULAR_FIGHTS=7}
function A.route(pick,count,seed,boss,previousFirst,eligible,limit,appearances)
 boss=boss or (count==13 and 13 or nil)
 local out={};local allowed={};if eligible then for _,who in ipairs(eligible) do allowed[who]=true end end
 for who=1,count do if who~=pick and who~=boss and (not eligible or allowed[who]) then out[#out+1]=who end end
 local v=(tonumber(seed) or 731)&0x7fffffff;if v==0 then v=731 end
 for i=#out,2,-1 do
  v=v~(v<<13);v=v~(v>>17);v=v~(v<<5);v=v&0x7fffffff
  local j=v%i+1;out[i],out[j]=out[j],out[i]
 end
 -- Choose the least-used eligible opponents. Shuffled tie order keeps the draw random.
 if limit and #out>limit then
  local rank={};for i,who in ipairs(out)do rank[who]=i end
  table.sort(out,function(a,b)
   local x=math.max(0,tonumber(appearances and appearances[a]) or 0)
   local y=math.max(0,tonumber(appearances and appearances[b]) or 0)
   return x==y and rank[a]<rank[b] or x<y
  end)
  while #out>limit do table.remove(out) end
  -- Frequency decides inclusion only; fight order is shuffled independently.
  for i=#out,2,-1 do
   v=v~(v<<13);v=v~(v>>17);v=v~(v<<5);v=v&0x7fffffff
   local j=v%i+1;out[i],out[j]=out[j],out[i]
  end
 end
 -- Avoid the previous campaign's opener without resampling the puzzle RNG.
 -- Swap only among regular opponents; the final boss is appended afterwards.
 if #out>1 and out[1]==tonumber(previousFirst) then
  v=v~(v<<13);v=v~(v>>17);v=v~(v<<5);v=v&0x7fffffff
  local alternate=2+v%(#out-1)
  out[1],out[alternate]=out[alternate],out[1]
 end
 if boss then out[#out+1]=boss end
 return out
end
-- Calibrated from the human-tested1.6.1 Easy Tesla (CPU anchor6.75).
local starts={1,1.4,2,3.25,4.5}
local bosses={3.5,5,6.75,7.75,8.75}
function A.level(base,index,total)
 base=math.max(1,math.min(5,math.floor(base or 3)))
 total=total or (A.REGULAR_FIGHTS+1)
 if index>=total then return bosses[base] end
 local q=math.max(0,math.min(1,(index-1)/math.max(1,total-2)))
 return starts[base]+(bosses[base]-1.25-starts[base])*q
end
function A.advance(index,total,won)
 if not won then return index,false end
 if index>=total then return index,true end
 return index+1,false
end
return A
