-- Deterministic puzzle simulation. Presentation consumes events; it never changes damage.
-- Visible settled rows MIN..H; temporary active headroom extends to HEAD.
-- Only settled placement above MIN (above the screen) causes top-out.
local R={W=6,H=14,MIN=-1,HEAD=-3,SPAWN=4,SPARK_ODDS=12,MAX_SPARK_GAP=16}
local vectors={{0,-1},{1,0},{0,1},{-1,0}}
local ultimateVectors={{0,-1},{1,0},{0,1},{-1,0},{-1,-1},{1,-1},{-1,1},{1,1}}
R.patterns={ -- bottom first; Ken / Donovan, transcribed from Sirlin's original pattern diagrams
 {{1,1,1,1,1,1},{3,3,3,3,3,3},{2,2,2,2,2,2},{4,4,4,4,4,4}},
 {{1,4,1,4,1,4},{1,4,1,4,1,4},{3,3,3,2,2,2},{3,3,3,2,2,2}},
 {{3,3,2,2,4,4},{3,3,2,2,4,4},{2,2,4,4,1,1},{2,2,4,4,1,1}},
 {{1,1,1,2,2,2},{4,4,4,3,3,3},{2,2,2,1,1,1},{3,3,3,4,4,4}},
 {{1,1,2,2,3,3},{4,4,1,1,2,2},{3,3,4,4,1,1},{2,2,3,3,4,4}},
 {{1,2,3,4,1,2},{1,2,3,4,1,2},{3,4,1,2,3,4},{3,4,1,2,3,4}}
}
-- New cultural fighters reuse the approved attack geometries, preserving packet balance.
R.patterns[7]=R.patterns[2];R.patterns[8]=R.patterns[3];R.patterns[9]=R.patterns[4]
R.patterns[10]=R.patterns[1];R.patterns[11]=R.patterns[3];R.patterns[12]=R.patterns[5];R.patterns[13]=R.patterns[6];R.patterns[14]=R.patterns[1]

local function rng(b,n)
 local v=b.seed;v=v~(v<<13);v=v~(v>>17);v=v~(v<<5);b.seed=v&0x7fffffff
 return b.seed%n+1
end
function R.cell(c,k,n) return {c=c,k=k or 'ball',n=n or 0} end
function R.new(seed,character,ruleset)
 local b={seed=seed or 17,character=character or 1,grid={},groups={},events={},pending={},phase='spawn',clock=0,
   turn=0,pairNo=0,score=0,out=0,chain=0,total=0,dead=false,age=0,attackRemainder=0,
   ruleset=ruleset=='ultimate' and 'ultimate' or 'classic'}
 for y=R.HEAD,R.H do b.grid[y]={} end
 b.next=R.next(b);return b
end
function R.event(b,kind,data) data=data or {};data.kind=kind;b.events[#b.events+1]=data end
function R.next(b)
 b.pairNo=b.pairNo+1
 local p={}
 for i=1,2 do p[i]=R.cell(rng(b,4),rng(b,R.SPARK_ODDS)==1 and 'spark' or 'ball') end
 if b.pairNo%25==0 then p[1]=R.cell(0,'ray') end
 -- Keep random sparks; every sliding window of 16 cells must contain one spark.
 for i=1,2 do
  local v=p[i];local dry=b.withoutSpark or 0
  if v.k=='spark' then b.withoutSpark=0
  elseif v.k~='ray' and (dry>=R.MAX_SPARK_GAP-1 or (dry>=R.MAX_SPARK_GAP-2 and i==2 and (b.pairNo+1)%25==0)) then v.k='spark';b.withoutSpark=0
  else b.withoutSpark=dry+1 end
 end
 -- Preserve piece kinds/cadence; recolour deterministically without extra RNG draws.
 -- 'Consecutive sparks' means consecutive sparks in the stream, even with balls between.
 if p[1].k=='spark' and p[2].k=='spark' and p[1].c==p[2].c then p[2].c=p[2].c%4+1 end
 for attempt=1,4 do
  local a=p[1].c+(p[1].k=='spark' and 4 or p[1].k=='ray' and 16 or 0)
  local z=p[2].c+(p[2].k=='spark' and 4 or 0)
  local repeatPair=(a==b.previousA and z==b.previousZ) or (a==b.previousZ and z==b.previousA)
  local last=b.lastSpark;local repeatSpark=false
  for _,v in ipairs(p) do if v.k=='spark' then if v.c==last then repeatSpark=true end;last=v.c end end
  if not repeatPair and not repeatSpark then b.previousA=a;b.previousZ=z;b.lastSpark=last;break end
  for _,v in ipairs(p) do if v.c>0 then v.c=v.c%4+1 end end
 end
 return p
end
function R.get(b,x,y) if x<1 or x>6 or y>R.H or y<R.HEAD then return nil end return b.grid[y][x] end
function R.free(b,x,y) return x>=1 and x<=6 and y>=R.HEAD and y<=R.H and not b.grid[y][x] end
function R.cells(p,x,y,o)
 x=x or p.x;y=y or p.y;o=o or p.o;local d=vectors[o+1]
 return {{x=x,y=y,v=p.v[1]},{x=x+d[1],y=y+d[2],v=p.v[2]}}
end
function R.fits(b,p,x,y,o)
 for _,q in ipairs(R.cells(p,x,y,o)) do if not R.free(b,q.x,q.y) then return false end end return true
end
function R.spawn(b)
 b.receivedSpecial=nil
 b.active={x=4,y=0,o=0,v=b.next,fall=0,lock=0,resets=0};b.next=R.next(b)
 -- Use the remaining visible space before declaring top-out; allow rotation
 -- during the normal lock delay even when the original entry row is occupied.
 if not R.fits(b,b.active) then
  local fits=false
  for y=-1,R.HEAD+1,-1 do
   if R.fits(b,b.active,4,y,0) then b.active.y=y;fits=true;break end
  end
  if not fits then b.dead=true;return false end
 end
 b.phase='fall';b.clock=0;return true
end
function R.move(b,dx)
 local p=b.active;if not p then return false end
 if R.fits(b,p,p.x+dx,p.y,p.o) then p.x=p.x+dx;if p.resets<8 then p.lock=0;p.resets=p.resets+1 end;return true end
 return false
end
function R.rotate(b,direction)
 local p=b.active;if not p then return false end
 local o=(p.o+direction)%4
 for _,k in ipairs({{0,0},{-1,0},{1,0},{0,-1}}) do
  if R.fits(b,p,p.x+k[1],p.y+k[2],o) then
   p.x=p.x+k[1];p.y=p.y+k[2];p.o=o;if p.resets<8 then p.lock=0;p.resets=p.resets+1 end;return true
  end
 end
 -- A single-column well permits a 180-degree swap instead of a horizontal turn.
 if p.o%2==0 and not R.fits(b,p,p.x,p.y,1) and not R.fits(b,p,p.x,p.y,3) then
  o=(p.o+2)%4
  -- Swap in the same two cells: changing only orientation lifts the pair and
  -- lets an unreachable CPU target reset ground contact forever.
  local y=p.y+(p.o==0 and -1 or 1)
  if R.fits(b,p,p.x,y,o) then
   p.y=y;p.o=o
   if p.resets<8 then p.lock=0;p.resets=p.resets+1 end
   return true
  end
 end
 return false
end
local function group_cells(b,id)
 local out={};for y=R.MIN,R.H do for x=1,6 do local v=b.grid[y][x];if v and v.g==id then out[#out+1]={x=x,y=y,v=v} end end end;return out
end
function R.groups(b)
 -- Grow rectangles without splitting an already fused chamber.
 local changed=true
 while changed do
  changed=false;local best
  for y=R.MIN,R.H-1 do for x=1,5 do
   local v=b.grid[y][x]
   if v and v.k=='ball' then
    for yy=y+1,R.H do for xx=x+1,6 do
     local ok=true;local ids={}
     for cy=y,yy do for cx=x,xx do local q=b.grid[cy][cx];if not q or q.k~='ball' or q.c~=v.c then ok=false;break end;if q.g then ids[q.g]=true end end;if not ok then break end end
     if ok then for id in pairs(ids) do for _,q in ipairs(group_cells(b,id)) do if q.x<x or q.x>xx or q.y<y or q.y>yy then ok=false;break end end end end
     if ok then
      local area=(xx-x+1)*(yy-y+1);local same=v.g and b.groups[v.g]
      if not (same and same.x==x and same.y==y and same.w==xx-x+1 and same.h==yy-y+1) and (not best or area>best.area) then best={x=x,y=y,w=xx-x+1,h=yy-y+1,c=v.c,area=area} end
     end
    end end
   end
  end end
  if best then
   b.groupID=(b.groupID or 0)+1;best.id=b.groupID;best.born=b.age;b.groups[best.id]=best
   for y=best.y,best.y+best.h-1 do for x=best.x,best.x+best.w-1 do local old=b.grid[y][x].g;if old then b.groups[old]=nil end;b.grid[y][x].g=best.id end end
   changed=true;R.event(b,'fusion',best)
  end
 end
end
function R.gravity(b)
 local moved=false;local seen={}
 for y=R.H-1,R.MIN,-1 do for x=1,6 do
  local v=b.grid[y][x]
  if v and not seen[v] then
   if v.g and b.groups[v.g] then
    local id=v.g;local cells=group_cells(b,id);local ok=true
    for _,q in ipairs(cells) do local below=R.get(b,q.x,q.y+1);if q.y>=R.H or (below and below.g~=id) then ok=false end;seen[q.v]=true end
    if ok then
     for _,q in ipairs(cells) do b.grid[q.y][q.x]=nil end
     for _,q in ipairs(cells) do b.grid[q.y+1][q.x]=q.v end
     b.groups[id].y=b.groups[id].y+1;moved=true
    end
   elseif R.free(b,x,y+1) then b.grid[y+1][x]=v;b.grid[y][x]=nil;seen[v]=true;moved=true end
  end
 end end
 return moved
end
function R.lock(b)
 local p=b.active
 for _,q in ipairs(R.cells(p)) do if q.y<R.MIN then b.dead=true;R.event(b,'overflow');return end end
 b.turn=b.turn+1;b.chain=0;b.out=0;b.total=0
 for y=R.MIN,R.H do for x=1,6 do local v=b.grid[y][x];if v and v.k=='blocked' then v.n=v.n-1;if v.n<=0 then v.k='ball';R.event(b,'release',{x=x,y=y,c=v.c}) end end end end
 for _,q in ipairs(R.cells(p)) do b.grid[q.y][q.x]=q.v end
 b.active=nil;b.phase='settle';b.clock=0;R.event(b,'lock')
end
function R.chain_multiplier(depth) return 2^math.min(5,math.max(0,depth-1)) end
function R.chain_bonus(depth) return depth>=2 and 1000*(depth-1)^2 or 0 end
function R.clear_set(b)
 local marked,visited={},{};local rays={};local ray=false
 local connections=b.ruleset=='ultimate' and ultimateVectors or vectors
 local function mark(x,y) local v=R.get(b,x,y);if v then marked[v]={x=x,y=y,v=v} end end
 for y=R.MIN,R.H do for x=1,6 do
  local v=b.grid[y][x]
  if v and v.k=='ray' then
   ray=true;mark(x,y);local below=R.get(b,x,y+1)
   if below then rays[below.c]=true else b.score=b.score+10000;R.event(b,'tech') end
  elseif v and v.k=='spark' and not visited[v] then
   local todo,component={{x=x,y=y}},{}
   while #todo>0 do
    local q=table.remove(todo);local a=R.get(b,q.x,q.y)
    if a and not visited[a] and a.c==v.c and (a.k=='ball' or a.k=='spark') then
     visited[a]=true;component[#component+1]=q
     for _,d in ipairs(connections) do todo[#todo+1]={x=q.x+d[1],y=q.y+d[2]} end
    end
   end
   if #component>1 then for _,q in ipairs(component) do mark(q.x,q.y) end end
  end
 end end
 for y=R.MIN,R.H do for x=1,6 do local v=b.grid[y][x];if v and rays[v.c] then mark(x,y) end end end
 -- Only direct adjacency removes counters, never a flood through other counters.
 local adjacent={}
 for _,q in pairs(marked) do for _,d in ipairs(vectors) do local a=R.get(b,q.x+d[1],q.y+d[2]);if a and a.k=='blocked' then adjacent[a]={x=q.x+d[1],y=q.y+d[2],v=a} end end end
 for v,q in pairs(adjacent) do marked[v]=q end
 local cells={};local value=0;local gs={};local ordinary=0
 for y=R.MIN,R.H do for x=1,6 do local v=b.grid[y][x];local q=v and marked[v];if q then
  cells[#cells+1]=q
  if v.k~='ray' then
   local unit=v.k=='blocked' and .5 or 1
   if v.g and b.groups[v.g] and not ray then local g=b.groups[v.g];unit=math.min(g.w,g.h);gs[v.g]=true end
   value=value+unit*(1+math.min(12,R.H-y)*.035);ordinary=ordinary+1
  end
 end end end
 if #cells==0 then return nil end
 if ordinary>0 then b.chain=b.chain+1 end
 local mult=({1,1.5,2.2,3.2,4.5,6})[math.min(6,math.max(1,b.chain))]
 value=value*mult*(ray and .5 or 1)
 local all=true;for y=R.MIN,R.H do for x=1,6 do local v=b.grid[y][x];if v and not marked[v] then all=false end end end
 if all and ordinary>0 then value=value+12;R.event(b,'allclear') end
 local power=math.floor(value+b.attackRemainder);b.attackRemainder=value+b.attackRemainder-power
 local event={cells=cells,groups=gs,count=ordinary,power=power,chain=b.chain,ray=ray}
 b.out=b.out+power;b.total=b.total+ordinary;b.score=b.score+ordinary*100*R.chain_multiplier(b.chain)+power*10
 return event
end
function R.remove(b,clear)
 for _,q in ipairs(clear.cells) do if q.v.g then b.groups[q.v.g]=nil end;b.grid[q.y][q.x]=nil end
end
function R.incoming(b,n,character) if n>0 then b.pending[#b.pending+1]={n=n,original=n,character=character,countdown=5} end end
function R.pending(b) local n=0;for _,p in ipairs(b.pending) do n=n+p.n end;return n end
function R.cancel(b,power)
 local cancelled=0
 for _,p in ipairs(b.pending) do
  local n=math.min(p.n,power//2);p.n=p.n-n;power=power-n*2;cancelled=cancelled+n
  if p.n<=p.original/2 then p.countdown=3 end
 end
 for i=#b.pending,1,-1 do if b.pending[i].n==0 then table.remove(b.pending,i) end end
 if cancelled>0 then R.event(b,'cancel',{n=cancelled}) end
 return power
end
function R.receive(b)
 local dropped={};local order={1,2,3,5,6,4};local wave=0;local duration=0
 b.receivedSpecial=nil
 local function landing(x)
  -- A falling counter lands ABOVE the first occupied cell, never in a cavity
  -- underneath a power gem supported by a neighbouring column.
  for y=R.MIN,R.H do if b.grid[y][x] then return y-1 end end
  return R.H
 end
 for _,p in ipairs(b.pending) do
  if p.specialAttack and p.n>=18 then b.receivedSpecial=p.specialAttack end
  local pattern=R.patterns[p.character]
  -- Every detonation is a separate packet and restarts its character's pattern.
  -- At most one cell per column per six-cell group; entry column 4 comes last.
  for row=0,math.ceil(p.n/6)-1 do
   local quota=math.min(6,p.n-row*6);local placed=0;local full={}
   for _,x in ipairs(order) do
    if placed>=quota then break end
    local y=landing(x)
    if y>=R.MIN then
     local c=pattern[row%#pattern+1][x];local v=R.cell(c,'blocked',p.countdown)
     v.arrival={age=b.age,delay=wave*3,ticks=18}
     b.grid[y][x]=v;dropped[#dropped+1]={x=x,y=y,v=v,wave=wave}
     duration=math.max(duration,wave*3+24);placed=placed+1
    else full[#full+1]=x end
   end
   if placed<quota then
    -- Keep ordinary attacks' column order. Excess cells visibly cross the top;
    -- defeat waits until their arrival animation has completed.
    for i=1,quota-placed do
     local x=full[i];local y=R.MIN-1;local v=R.cell(pattern[row%#pattern+1][x],'blocked',p.countdown)
     v.arrival={age=b.age,delay=wave*3,ticks=18};b.grid[y][x]=v
     dropped[#dropped+1]={x=x,y=y,v=v,wave=wave};duration=math.max(duration,wave*3+24)
    end
    b.overflowPending=true;break
   end
   wave=wave+1
  end
  if b.overflowPending then break end
 end
 b.pending={};b.receiveTicks=duration
 if #dropped>0 then R.event(b,'receive',{cells=dropped});return true end;return false
end
function R.dispatch(b,clear)
 local out=R.cancel(b,clear.power)
 if out>0 then R.event(b,'attack',{n=out,chain=clear.chain,total=clear.count}) end
 b.out=math.max(0,b.out-clear.power)
end
function R.finish(b)
 if b.chain>=2 then
  local bonus=R.chain_bonus(b.chain);b.score=b.score+bonus
  R.event(b,'chain',{chain=b.chain,total=b.total,bonus=bonus})
 end
 R.event(b,'cascade',{chain=b.chain,total=b.total})
 if R.receive(b) then b.phase='received';b.clock=0 else b.phase='spawn' end
end
function R.step(b,input)
 if b.dead then return end;b.age=b.age+1;b.clock=b.clock+1
 if b.phase=='spawn' then R.spawn(b)
 elseif b.phase=='fall' then
  local p=b.active
  if input then
   if input.left then R.move(b,-1) elseif input.right then R.move(b,1) end
   if input.cw then R.rotate(b,1) elseif input.ccw then R.rotate(b,-1) end
  end
  p.fall=p.fall+1;local rate=input and input.down and 2 or math.max(8,36-b.age//1800)
  if R.fits(b,p,p.x,p.y+1,p.o) then
   p.lock=0;if p.fall>=rate then p.y=p.y+1;p.fall=0;if input and input.down then b.score=b.score+1 end end
  else p.fall=0;p.lock=p.lock+1;if p.lock>=24 or (input and input.down and p.lock>=3) then R.lock(b) end end
 elseif b.phase=='settle' then
  if b.clock%3==0 then
   local moved=R.gravity(b)
   if b.settleAfterClear and moved then b.settleMoved=true end
   if not moved then
    -- One landing cue for the whole falling batch, never one impact per cell.
    if b.settleAfterClear and b.settleMoved then R.event(b,'land') end
    b.settleAfterClear=false;b.settleMoved=false
    R.groups(b);local clear=R.clear_set(b)
    if clear then b.clear=clear;b.phase='clear';b.clock=0;R.event(b,'clear',clear)
    else R.finish(b) end
   end
  end
 elseif b.phase=='clear' and b.clock>=24 then
  R.dispatch(b,b.clear);R.remove(b,b.clear);b.clear=nil;b.phase='settle';b.clock=0;b.settleAfterClear=true;b.settleMoved=false
 elseif b.phase=='received' and b.clock>=(b.receiveTicks or 24) then
  if b.overflowPending then b.dead=true;return end
  for y=R.MIN,R.H do for x=1,6 do local v=b.grid[y][x];if v then v.arrival=nil end end end
  b.phase='spawn'
 end
end
function R.clone(b)
 local c=R.new(b.seed,b.character,b.ruleset);c.events={};c.groups={}
 for y=R.MIN,R.H do c.grid[y]={};for x=1,6 do local v=b.grid[y][x];if v then local q=R.cell(v.c,v.k,v.n);q.g=v.g;c.grid[y][x]=q end end end
 for id,g in pairs(b.groups) do local q={};for k,v in pairs(g) do q[k]=v end;c.groups[id]=q end
 c.groupID=b.groupID;c.active=nil;return c
end
function R.plan(b)
 -- Evaluate the 22 legal flat placements. The CPU still moves/rotates/falls through normal controls.
 local best,score
 for o=0,3 do for x=1,6 do
  local c=R.clone(b);local p={x=x,y=b.active.y,o=o,v=b.active.v}
  if R.fits(c,p) then
   while R.fits(c,p,p.x,p.y+1,o) do p.y=p.y+1 end
   local above=false
   for _,q in ipairs(R.cells(p)) do if q.y<R.MIN then above=true else c.grid[q.y][q.x]=R.cell(q.v.c,q.v.k,q.v.n) end end
   for _=1,R.H+3 do if not R.gravity(c) then break end end
   R.groups(c);local clear=R.clear_set(c);local s=above and -1000000 or clear and clear.power*6 or 0
   for col=1,6 do
    local top=R.H+1;for y=R.MIN,R.H do if c.grid[y][col] then top=y;break end end
    local h=R.H+1-top;s=s-h*h*(col==4 and 1.6 or .5)
    for y=R.MIN,R.H do local v=c.grid[y][col];if v then
     local right=R.get(c,col+1,y);local below=R.get(c,col,y+1)
     if right and right.c==v.c and right.k~='blocked' then s=s+2 end
     if below and below.c==v.c and below.k~='blocked' then s=s+2 end
     if v.g then s=s+3 end
    end end
   end
   if not score or s>score then score=s;best={x=x,o=o} end
  end
 end end
 return best or {x=4,o=0}
end
return R
