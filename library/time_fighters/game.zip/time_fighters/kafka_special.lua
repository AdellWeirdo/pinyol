-- Approved Prague exterior proposal. Presentation only, no simulation/RNG writes.
local S={};local C=require('roster');local Idle=require('idle');local K=require('knockdown')
local function dust(t,x,y,scale,alpha)
 img('DUST_KAFKA',x,y,{frame=2+(t//7)%4,scale=scale,alpha=alpha or 1})
end
function S.draw(f,rival,side)
 if side==2 then canvas('KAFKA_CINEMA',480,320);target('KAFKA_CINEMA') end
 img('SPECIAL_STAGE_KAFKA',0,0)
 -- Same 450-frame approved choreography, scheduled into the common 330-frame event.
 local t=12+f*(402/330)
 if t<195 then img('IDLE_'..C[rival].id,280,166,{frame=Idle.frame(t),flip_x=true})
 else img('KNOCKDOWN_'..C[rival].id,258,166,{frame=math.min(5,math.floor((t-195)/8)),flip_x=true}) end
 if t>=100 and t<285 then
  local x=-250+(t-100)*4.2
  for j=0,2 do dust(t+j*11,x-15-j*30,238+(j%2)*10,.65,.45) end
  img('COCKROACH_KAFKA',x,146,{frame=(t//5)%8})
 end
 if t<65 then img('FIGHTER_KAFKA_ENTRY',20,166,{frame=math.min(2,math.floor(math.max(0,t-24)/14))})
 else img('FIGHTER_KAFKA_SPECIAL',20,166,{frame=(t//9)%6}) end
 if t>=195 and t<350 then
  local alpha=t<320 and 1 or math.max(0,(350-t)/30)
  dust(t,291,165,1.32,alpha);dust(t+9,337,192,1.3,alpha);dust(t+20,278,227,1.12,alpha)
 end
 if side==2 then target();img('KAFKA_CINEMA',0,0,{flip_x=true}) end
 -- Lettering always reads normally on both sides. Same display window as other specials.
 if f>=11 and f<77 then
  local scale=76/114;local w=330*scale;local x=(480-w)/2
  img('TITLE_SPECIAL_KAFKA',x,6,{scale=scale,alpha=math.min(1,(f-10)/5,(77-f)/7)})
  clip(math.floor(x-12+(f-14)/48*(w+30)),6,7,76)
  img('TITLE_SPECIAL_KAFKA',x,6,{scale=scale,tint=0xfffad5,alpha=.35})
  clip()
 end
end
return S
