-- Lossless physical banks keep the engine's lifetime registry below320 entries.
-- Logical asset names, dimensions, options, alpha and frame numbering are unchanged.
local B={map=require('sprite_bank_map'),raw=require('sprite_bank_formats'),seen={},canvasIDs={}}
function B.install()
 if B.installed then return end;B.installed=true
 local nativeImg,nativeSize,nativeFrame,nativeCanvas=img,imgsize,frame,canvas
 local function cel(a,n)
  n=math.floor(tonumber(n) or 0);if n<0 or n>=#a[3] then n=0 end
  return a[3][n+1]
 end
 function img(id,x,y,o,k)
  local a=B.map[id];if not a then return nativeImg(id,x,y,o,k) end
  local r=cel(a,type(o)=='table' and o.frame or o);B.seen[r[1]]=true
  if type(o)=='table' then
   local original,alpha=o.frame,o.alpha;o.frame=r[2]
   -- Match NP2K's native32-step alpha fast path when a cel lives in a raw bank.
   local sx=o.scale_x or o.scale or 1;local sy=o.scale_y or o.scale or 1
   if B.raw[r[1]] and alpha and alpha<1 and not o.add and not o.pal and not o.flip_y and (o.angle or 0)==0 and math.abs(sx)==1 and sy==1 then
    local n=math.floor(math.max(0,alpha)*255+.5);o.alpha=math.floor((n+n//128+4)/8)/32
   end
   local result=nativeImg(r[1],x,y,o);o.frame=original;o.alpha=alpha;return result
  end
  return nativeImg(r[1],x,y,r[2],k)
 end
 function imgsize(id)
  local a=B.map[id];if a then return a[1],a[2],#a[3] end
  return nativeSize(id)
 end
 function frame(id,x,y,w,h,scale,n)
  local a=B.map[id];if not a then return nativeFrame(id,x,y,w,h,scale,n) end
  local r=cel(a,n);B.seen[r[1]]=true;return nativeFrame(r[1],x,y,w,h,scale,r[2])
 end
 function canvas(id,...)
  B.canvasIDs[id]=true;return nativeCanvas(id,...)
 end
end
function B.count() local n=0;for _ in pairs(B.seen)do n=n+1 end;for _ in pairs(B.canvasIDs)do n=n+1 end;return n end
return B
