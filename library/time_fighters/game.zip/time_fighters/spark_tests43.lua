return function()
 local R=require('rules');local counts={0,0,0,0};local sparks=0;local previous=nil
 for seed=1,12 do
  local a,b=R.new(seed*7381,1),R.new(seed*7381,12);local last=nil;local prev=nil
  for pair=1,400 do
   local p=pair==1 and a.next or R.next(a);local q=pair==1 and b.next or R.next(b)
   local tokens={};for i=1,2 do
    assert(p[i].c==q[i].c and p[i].k==q[i].k,'shared sequence mismatch')
    tokens[i]=p[i].k..p[i].c
    if p[i].k=='spark' then assert(p[i].c~=last,'same-colour consecutive sparks');last=p[i].c;sparks=sparks+1;counts[last]=counts[last]+1 end
   end
   local key=tokens[1]<tokens[2] and tokens[1]..tokens[2] or tokens[2]..tokens[1];assert(key~=prev,'consecutive pair repeated');prev=key
   assert((p[1].k=='ray')==(pair%25==0),'ray cadence changed')
  end
 end
 assert(sparks/9600>.06 and sparks/9600<.12,'spark frequency changed')
 for _,n in ipairs(counts) do assert(n/sparks>.20 and n/sparks<.30,'spark colours biased') end
 return true
end
