return function()
 local R=require('rules')
 local function key(p) local a=p[1].k..p[1].c;local b=p[2].k..p[2].c;return a<b and a..':'..b or b..':'..a end
 local counts={0,0,0,0};local sparks=0;local balls=0
 for seed=1,8 do
  local a,b=R.new(seed,1),R.new(seed,12);local old=nil
  for n=1,500 do
   local p=n==1 and a.next or R.next(a);local q=n==1 and b.next or R.next(b)
   assert(key(p)~=old,'consecutive repeat, including reverse');old=key(p)
   for i=1,2 do assert(p[i].c==q[i].c and p[i].k==q[i].k,'unequal P1/P2 sequence');local v=p[i];if v.c>0 then counts[v.c]=counts[v.c]+1;balls=balls+1 end;if v.k=='spark' then sparks=sparks+1 end end
   assert((p[1].k=='ray')==(n%25==0),'lightning schedule changed')
  end
 end
 for _,n in ipairs(counts) do assert(n/balls>.22 and n/balls<.28,'colour proportion drift') end
 assert(sparks/balls>.06 and sparks/balls<.12,'spark proportion drift')
 return true
end
