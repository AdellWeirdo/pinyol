local R=require('rules');local Old=require('release16_reference');local A=require('cpu');local SP=require('special_policy')
local T={}
local function cells(b,list) for _,q in ipairs(list) do b.grid[q[2]][q[1]]=R.cell(q[3],q[4]) end end
local function equal(a,b)
 for _,k in ipairs({'seed','pairNo','score','turn','chain','out','dead','phase','clock','total','attackRemainder','groupID','receiveTicks','overflowPending'}) do assert(a[k]==b[k],'classic mismatch: '..k..' '..tostring(a[k])..' '..tostring(b[k])) end
 for y=R.HEAD,R.H do for x=1,6 do local v,w=a.grid[y][x],b.grid[y][x];assert((v==nil)==(w==nil),'classic grid occupancy');if v then for _,k in ipairs({'k','c','n','g'}) do assert(v[k]==w[k],'classic cell '..k) end end end end
 for i=1,2 do assert(a.next[i].k==b.next[i].k and a.next[i].c==b.next[i].c,'classic stream') end
 if a.active then assert(b.active,'classic active');for _,k in ipairs({'x','y','o','fall','lock','resets'}) do assert(a.active[k]==b.active[k],'classic active '..k) end else assert(not b.active,'classic active nil') end
end
function T.unit()
 for _,delta in ipairs({{-1,-1},{1,-1},{-1,1},{1,1}}) do
  for _,mode in ipairs({'classic','ultimate'}) do local b=R.new(19,1,mode);cells(b,{{3,8,2,'spark'},{3+delta[1],8+delta[2],2},{6,14,4}});local c=R.clear_set(b);assert((c~=nil)==(mode=='ultimate'),'diagonal '..mode);if c then assert(c.count==2) end end
 end
 local b=R.new(5,1,'ultimate');cells(b,{{1,10,1,'spark'},{2,11,1},{3,12,1},{4,13,1},{5,14,2},{6,14,1}});assert(R.clear_set(b).count==4,'diagonal chain should stop at colour boundary')
 b=R.new(5,1,'ultimate');cells(b,{{1,10,1,'spark'},{2,11,2},{3,12,1}});assert(not R.clear_set(b),'different colour bridged diagonally')
 b=R.new(5,1,'ultimate');cells(b,{{1,10,1,'spark'},{2,11,1,'blocked'},{3,12,1}});assert(not R.clear_set(b),'blocked ball became diagonal bridge')
 b=R.new(5,1,'ultimate');cells(b,{{1,10,1,'spark'},{1,11,1},{2,12,2,'blocked'},{6,14,3}});local c=R.clear_set(b);assert(#c.cells==2,'blocked diagonal removal changed')
 b=R.new(5,1,'ultimate');cells(b,{{1,R.MIN,1,'spark'},{2,R.MIN+1,1},{6,14,4}});assert(R.clear_set(b).count==2,'top visible diagonal')
 for _,mode in ipairs({'classic','ultimate'}) do
  b=R.new(5,1,mode);cells(b,{{1,10,0,'ray'},{1,11,2},{6,14,2},{4,14,3}});c=R.clear_set(b);assert(c.count==2 and #c.cells==3,'ray changed')
  b=R.new(5,1,mode);cells(b,{{1,13,1},{2,13,1},{1,14,1},{2,14,1}});R.groups(b);assert(b.groups[b.grid[14][1].g].w==2,'rectangular fusion changed');assert(R.clone(b).ruleset==mode,'CPU clone lost mode')
 end
 local a=R.new(91,1,'classic');b=R.new(91,13,'ultimate');for i=1,1200 do local p=R.next(a);local q=R.next(b);for j=1,2 do assert(p[j].c==q[j].c and p[j].k==q[j].k,'ruleset consumed piece RNG') end end
 print('ULTIMATE_UNIT_PASS diagonals colours boundaries rays blocked fusion clone rng classic-reference-300')
end
function T.reference(batch)
 for i=batch*10+1,batch*10+10 do
  local a=R.new(i,1,'classic');local b=Old.new(i,1)
  for y=R.MIN,R.H do for x=1,6 do if (i*37+x*11+y*7)%5~=0 then local c=(i+x+y)%4+1;local kind=(x*3+y+i)%13==0 and 'spark' or 'ball';a.grid[y][x]=R.cell(c,kind);b.grid[y][x]=Old.cell(c,kind) end end end
  R.groups(a);Old.groups(b);local ac=R.clear_set(a);local bc=Old.clear_set(b);assert((ac==nil)==(bc==nil));if ac then assert(ac.count==bc.count and ac.power==bc.power and ac.chain==bc.chain) end;equal(a,b)
 end
end
local function validate(b)
 local refs,counts={},{}
 for y=R.HEAD,R.H do for x,v in pairs(b.grid[y]) do
  assert(x>=1 and x<=6 and (y>=R.MIN or b.overflowPending and y==R.MIN-1),'outside board');assert(not refs[v],'duplicate piece');refs[v]=true
  if v.k=='blocked' then assert(v.n>=1 and v.n<=5,'countdown') end
  if v.g then assert(b.groups[v.g],'orphan group');counts[v.g]=(counts[v.g] or 0)+1 end
 end end
 for id,g in pairs(b.groups) do assert(counts[id]==g.w*g.h,'incomplete rectangle') end
 if b.active and not b.dead then assert(R.fits(b,b.active),'active overlaps') end
end
function T.begin(mode,level)
 T.mode=mode;T.level=level;T.index=0;T.stats={rounds=0,finished=0,capped=0,ticks=0,locks=0,clears=0,attacks=0,sent=0,specials=0,chainSpecials=0,bigSpecials=0,maxChain=0,finisherSpecials=0};T.done=false;T.current=nil
end
function T.step()
 if T.done then return end
 if not T.current then
  T.index=T.index+1
  if T.index>14 then T.done=true;local s=T.stats;print('ULTIMATE_METRICS',T.mode,T.level,s.rounds,s.finished,s.capped,s.ticks,s.locks,s.clears,s.attacks,s.sent,s.specials,s.chainSpecials,s.bigSpecials,s.maxChain,s.finisherSpecials);return end
  local who=T.index;local seed=18371+who*8191+T.level*997
  local mode=T.mode;T.current={boards={R.new(seed,who,mode),R.new(seed,who==13 and 1 or 13,mode)},old={Old.new(seed,who,mode),Old.new(seed,who==13 and 1 or 13,mode)},t=0}
 end
 local c=T.current;c.t=c.t+1;local s=T.stats
 for side=1,2 do
  local b=c.boards[side];local input=A.input(b,T.level);R.step(b,input)
  if c.old then Old.step(c.old[side],input);equal(b,c.old[side]) end
  for _,e in ipairs(b.events) do
   if e.kind=='lock' then SP.reset(b);s.locks=s.locks+1
   elseif e.kind=='clear' then s.clears=s.clears+1;s.maxChain=math.max(s.maxChain,e.chain)
   elseif e.kind=='attack' then R.incoming(c.boards[3-side],e.n,b.character);if c.old then Old.incoming(c.old[3-side],e.n,b.character) end;if e.n>=SP.FINISHER then c.boards[3-side].pending[#c.boards[3-side].pending].specialAttack={side=side,turn=b.turn,n=e.n} end;SP.sent(b,e.n);s.attacks=s.attacks+1;s.sent=s.sent+e.n
   elseif e.kind=='cascade' then local reason=SP.cascade(b,e.chain);if reason and SP.claim(b,b.turn) then s.specials=s.specials+1;if reason=='chain' then s.chainSpecials=s.chainSpecials+1 else s.bigSpecials=s.bigSpecials+1 end end end
  end
  b.events={};if c.old then c.old[side].events={} end
  if c.t%97==0 or b.dead then validate(b) end
 end
 if c.boards[1].dead or c.boards[2].dead or c.t>=60000 then
  if c.boards[1].dead~=c.boards[2].dead then local winner=c.boards[2].dead and 1 or 2;local candidate=c.boards[3-winner].receivedSpecial;if candidate and candidate.side==winner and SP.claim(c.boards[winner],candidate.turn) then s.specials=s.specials+1;s.finisherSpecials=s.finisherSpecials+1 end end
  s.rounds=s.rounds+1;local finished=c.boards[1].dead or c.boards[2].dead;s.finished=s.finished+(finished and 1 or 0);s.capped=s.capped+(finished and 0 or 1);s.ticks=s.ticks+c.t;T.current=nil
 end
end
return T
