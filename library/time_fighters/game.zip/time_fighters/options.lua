-- Settings are independent of the per-round shared puzzle RNG.
local O={}
local function clamp(n,a,b) return math.max(a,math.min(b,math.floor(tonumber(n) or a))) end
function O.load(read)
 -- Legacy numeric choices belong to the old scale; begin the new scale on Normal.
 local current=tonumber(read('difficulty_scale_version',0))==2
 return {difficulty=current and clamp(read('difficulty',3),1,5) or 3,music=clamp(read('music_volume',10),0,10),effects=clamp(read('effects_volume',10),0,10)}
end
function O.adjust(s,row,d)
 local key=row==1 and 'difficulty' or row==2 and 'music' or row==3 and 'effects' or nil
 if not key then return false end
 local old=s[key];s[key]=clamp(old+d,key=='difficulty' and 1 or 0,key=='difficulty' and 5 or 10);return old~=s[key]
end
function O.save(s,write)
 write('difficulty',tostring(s.difficulty));write('music_volume',tostring(s.music));write('effects_volume',tostring(s.effects))
 write('difficulty_scale_version','2')
end
function O.effect_gain(s,g) return (g or 1)*s.effects/10 end
function O.navigate(pick,d) return (pick-1+d*3)%12+1 end
return O
