local R=require('rules');local AI=require('cpu');local A=require('arcade')
local T={}
function T.begin(mode,difficulty)
 T.mode=mode;T.difficulty=difficulty;T.index=0;T.current=nil;T.done=false;T.finished=0;T.capped=0;T.frames=0;T.attacks=0;T.clears=0
end
local function valid(b)
 local seen={}
 for y=R.HEAD,R.H do for x,v in pairs(b.grid[y])do
  assert(x>=1 and x<=6 and (y>=R.MIN or b.overflowPending and y==R.MIN-1),'out-of-board cell')
  assert(not seen[v],'cell aliased');seen[v]=true
  if v.k=='blocked'then assert(v.n>=1 and v.n<=5)end
 end end
 if b.active and not b.dead then assert(R.fits(b,b.active),'active overlaps settled plasma')end
end
function T.step()
 if T.done then return end
 if not T.current then
  T.index=T.index+1
  if T.index>14 then T.done=true;print('BOT17',T.mode,T.difficulty,'finished',T.finished,'capped',T.capped,'ticks',T.frames,'attacks',T.attacks,'clears',T.clears);return end
  local who=T.index;local seed=18371+who*8191+T.difficulty*997
  T.current={b={R.new(seed,who,T.mode),R.new(seed,who==13 and 1 or 13,T.mode)},t=0,level=A.level(T.difficulty,(who-1)%11+1,11)}
 end
 local c=T.current;c.t=c.t+1;T.frames=T.frames+1
 for side=1,2 do
  local b=c.b[side];R.step(b,AI.input(b,c.level))
  for _,e in ipairs(b.events)do
   if e.kind=='attack'then R.incoming(c.b[3-side],e.n,b.character);T.attacks=T.attacks+1
   elseif e.kind=='clear'then T.clears=T.clears+1 end
  end;b.events={}
  if c.t%101==0 or b.dead then valid(b)end
 end
 if c.b[1].dead or c.b[2].dead or c.t>=60000 then
  if c.b[1].dead or c.b[2].dead then T.finished=T.finished+1 else T.capped=T.capped+1 end
  T.current=nil
 end
end
return T
