local T={}
function T.balance()
 local A=require('arcade');local AI=require('cpu');local O=require('options')
 assert(AI.default==3 and O.load(function(_,d)return d end).difficulty==3)
 -- Exact human-tested baseline: Easy boss in1.6.1 was2+4.75.
 local reference=AI.profile(6.75);local normal=AI.profile(A.level(3,11,11))
 for _,k in ipairs({'think','jitter','step','error','drop'})do assert(normal[k]==reference[k],k..' Normal Tesla mismatch')end
 for mode=1,5 do
  local previous
  for stage=1,11 do
   local p=AI.profile(A.level(mode,stage,11))
   if previous then
    for _,k in ipairs({'think','jitter','step','error'})do assert(p[k]<=previous[k],'difficulty fell within route '..k)end
    assert(p.drop>=previous.drop)
   end
   if stage<11 then
    local boss=AI.profile(A.level(mode,11,11));assert(p.step>boss.step,'regular opponent at least as fast as Tesla')
   end
   if mode<5 then
    local harder=AI.profile(A.level(mode+1,stage,11))
    for _,k in ipairs({'think','jitter','step','error'})do assert(p[k]>=harder[k],'mode order reversed '..k)end
    assert(p.drop<=harder.drop)
   end
   previous=p
  end
 end
 print('BALANCE17:55 stages ordered; Tesla hardest; Normal Tesla exact old Easy reference; default Normal PASS')
 return true
end
function T.campaign(who,puzzleMode)
 local Secret=require('secret_character');local Records=require('records');local Stats=require('campaign_stats');local Music=require('soundtrack')
 local bp,b=btnp,btn;btn=function()return false end;btnp=function()return false end
 local function update() _update()end
 local function press(key,at) timer=at or 31;btnp=function(k)return k==key end;update();btnp=function()return false end end
 local function playing() timer=231;update();assert(state=='play')end
 local function finish(winner,score)
  boards[1].score=score;boards[3-winner].dead=true;update();assert(state=='ko');timer=151;update()
 end
 Secret.load(function(_,d)return d end);if who==14 then Secret.unlocked=true end
 Records.load(function(_,d)return d end);mode='arcade';ruleset=puzzleMode;pick=who;difficulty=3;start_arcade()
 assert(Stats.lostRounds==0 and Stats.continues==0 and #arcadeRoute==11)
 timer=121;update();playing();finish(2,11);playing();finish(2,13)
 assert(state=='result' and Stats.lostRounds==2 and Records.run.score==24)
 press('a');assert(state=='continue');press('a');assert(require('end_screens').phase=='victory')
 timer=104;update();assert(state=='intro' and Stats.continues==1 and Records.run.score==24)
 for duel=1,11 do
  if duel>1 then assert(state=='versus');timer=121;update()end
  for roundNo=1,2 do playing();finish(1,100+roundNo)end
  assert(state=='result')
  local starts=Music.starts
  if duel==11 then assert(Music.cue=='REAL_HERO' and Music.finale)end
  press('a')
  if duel==11 then
   if state=='unlock' then press('a');assert(state=='ending')end
   assert(state=='ending' and Music.cue=='REAL_HERO' and Music.starts==starts)
   assert(Stats.lostRounds==2 and Stats.continues==1 and arcadeScore==2257 and Records.run.score==2257)
   press('a',46);assert(state=='record_entry' and not Records.run.active and Music.cue=='REAL_HERO')
   press('a');press('a');press('a');assert(state=='gameover' and Music.cue=='REAL_HERO' and Music.starts==starts)
   assert(Records.rows[1].score==2257 and Records.rows[1].completed)
   timer=900;update();assert(state=='gameover' and Music.starts==starts,'premature closing/restarted music')
   press('a');assert(state=='title' and Music.cue=='HEROES' and not Music.finale and Music.starts==starts+1)
  end
 end
 btnp=bp;btn=b
 print('CAMPAIGN17',who,puzzleMode,'11 fights+continue; real totals2257/2/1; final track continuous; record saved once; title restored PASS')
 return true
end
function T.no_record()
 local H=require('records');local S=require('secret_character');local M=require('soundtrack');local bp,b=btnp,btn
 btn=function()return false end;btnp=function()return false end
 local function press()timer=46;btnp=function(k)return k=='a'end;_update();btnp=function()return false end end
 H.rows={};for i=1,10 do H.rows[i]={score=2000000000,initials='AAA',character='BEETHOVEN',difficulty=3}end
 S.pending=false;mode='arcade';pick=1;difficulty=3;start_arcade();arcadeRoute={13};arcadeIndex=1;opponent=13;start_match()
 for i=1,2 do timer=231;_update();boards[2].dead=true;_update();timer=151;_update()end
 assert(state=='result' and M.cue=='REAL_HERO');S.pending=false;press();assert(state=='ending');press();assert(state=='gameover' and not H.pending and M.cue=='REAL_HERO');press();assert(state=='title' and M.cue=='HEROES')
 btnp=bp;btn=b;print('NO_RECORD17: final→Game Over when top10 not reached; no record screen; normal title music PASS');return true
end
function T.loss_exit()
 local H=require('records');local M=require('soundtrack');local Stats=require('campaign_stats');local E=require('end_screens');local bp,b=btnp,btn
 btn=function()return false end;btnp=function()return false end;H.load(function(_,d)return d end);mode='arcade';pick=4;difficulty=3;start_arcade();timer=121;_update()
 for i=1,2 do timer=231;_update();boards[1].score=200+i;boards[1].dead=true;_update();timer=151;_update()end
 timer=31;btnp=function(k)return k=='a'end;_update();btnp=function()return false end;assert(state=='continue')
 timer=600;_update();assert(E.phase=='fall');timer=673;_update();assert(state=='record_entry' and H.pending.score==403 and Stats.lostRounds==2 and Stats.continues==0)
 for i=1,3 do timer=31;btnp=function(k)return k=='a'end;_update();btnp=function()return false end end
 assert(state=='gameover' and M.cue~='REAL_HERO' and H.rows[1].score==403)
 timer=31;btnp=function(k)return k=='b'end;_update();assert(state=='title' and M.cue=='HEROES');btnp=bp;btn=b
 print('LOSS17: lost rounds and rejected continue correct; loss→record→Game Over→title PASS');return true
end
return T
