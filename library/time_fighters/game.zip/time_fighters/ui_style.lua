-- One native arcade face for interface text. Cinematic artwork remains untouched.
local U={GOLD=0xfff0b8,DIM=0xe3bc68,MENU_DIM=0x777c86}
function U.clean(value)
 local s=tostring(value or '')
 for _,pair in ipairs({{'á','a'},{'é','e'},{'í','i'},{'ó','o'},{'ú','u'},{'ü','u'},{'ñ','n'},
 {'Á','A'},{'É','E'},{'Í','I'},{'Ó','O'},{'Ú','U'},{'Ü','U'},{'Ñ','N'},
 {'à','a'},{'è','e'},{'ò','o'},{'À','A'},{'È','E'},{'Ò','O'}}) do s=s:gsub(pair[1],pair[2]) end
 return s
end
local function style(options)
 local o={};for k,v in pairs(options or {}) do o[k]=v end
 local dim=o.color==U.DIM;local menuDim=o.color==U.MENU_DIM
 o.font='arcade';o.color=menuDim and U.MENU_DIM or dim and U.DIM or U.GOLD
 o.gradient=(o.scale or 1)>1 and (menuDim and 0x51555e or dim and 0xb38739 or 0xee983f) or nil
 o.outline=0x05081b;o.shadow=0x020516
 return o
end
function U.text(s,x,y,o) return text(U.clean(s),x,y,style(o)) end
function U.width(s,o) return textw(U.clean(s),style(o)) end
return U
