-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_mary_assets');local img=Assets.img;local imgsize=Assets.size
-- Isolated cinematic presentation. No puzzle state or RNG changes.
local S={};local C=require('cin50_mary_roster');local Idle=require('cin50_mary_idle');local K=require('cin50_mary_knockdown')
local function hero(f)
 local sc=1.18
 if f<58 or f>=307 then img('IDLE_MARY',80-56*sc,293-120*sc,{frame=Idle.frame(f),scale=sc})
 else
  local order={0,1,2,3,4,5,4,3,2,1};local cel=order[((f-58)//11)%#order+1]
  img('MARY_INVOKE',80-56*sc,293-120*sc,{frame=cel,scale=sc})
 end
end
local function bolt(f)
 if f<45 or f>83 then return end
 local age=f-45;local phase=age//3
 if age>16 and phase%3==2 then return end
 local lastx,lasty=150,-12
 for j=1,7 do
  local y=j*42-10;local x=j==7 and 150 or 150+math.sin(phase*2.4+j*2.7)*23
  for k=-6,6 do line(lastx+k,lasty,x+k,y,0x444cb0)end
  for k=-3,3 do line(lastx+k,lasty,x+k,y,0xa4eaff)end
  for k=-1,1 do line(lastx+k,lasty,x+k,y,0xffffff)end
  if j==3 or j==5 then
   local tip=x+(j==3 and -45 or 44);line(x,y,tip,y+22,0xa4eaff);line(tip,y+22,tip-10,y+46,0xf6ffff)
  end
  lastx,lasty=x,y
 end
 if age<18 then circ(150,284,18-age*.6,0x9adfff);circ(150,284,11-age*.3,0xffffff)end
end
local function creature(f)
 if f<68 then return end
 local center=f<100 and 150 or 150+(f-100)*2.8
 if center>650 then return end
 local cel=f<100 and 0 or ((f-100)*12//70)%12
 img('MARY_CREATURE_WALK',center-128*1.25,293-196*1.25,{frame=cel,scale=1.25})
 if f<75 and f%3~=0 then img('MARY_CREATURE_WALK',center-128*1.25,293-196*1.25,{frame=cel,scale=1.25,tint=0xe3fcff,alpha=(75-f)/9})end
end
local function enemy(who,f)
 local sc=1.05
 if f<150 then img('IDLE_'..C[who].id,392-92*sc,293-120*sc,{frame=Idle.frame(f),flip_x=true,scale=sc})
 elseif f<212 then img('FIGHTER_'..C[who].id,392-92*sc,293-120*sc,{frame=14,flip_x=true,scale=sc})
 else img('KNOCKDOWN_'..C[who].id,392-96*sc,293-120*sc,{frame=K.frame(f-212),flip_x=true,scale=sc})end
end
local function puff(x,y,age,scale)
 if age<0 or age>=40 then return end
 local cel=math.min(5,age//7);local fade=math.min(1,age/5,(40-age)/10)
 img('SMOKE_PUFF_BEETHOVEN',x-48*scale,y-48*scale-age*.25,{frame=cel,scale=scale,alpha=fade*.85})
end
local function clouds(f)
 if f<150 or f>=300 then return end
 local pts={{404,189,1.12,150},{415,236,1.18,154},{380,274,1.23,158},{337,238,1.06,161},{350,193,.9,164}}
 for i,c in ipairs(pts)do
  local age=f-c[4]
  if age>=0 then
   local dissolve=math.max(0,f-(260+i*3));local sc=c[3]*(.72+.28*math.min(1,age/8));local cel=age<7 and 0 or dissolve==0 and 1+((age//7)%3) or dissolve<12 and 4 or 5
   img('SMOKE_PUFF_BEETHOVEN',c[1]-48*sc+math.sin(age*.13+i)*2,c[2]-48*sc-dissolve*.4,{frame=cel,scale=sc,alpha=math.max(0,1-dissolve/23)})
  end
 end
end
function S.draw(f,rival)
 img('STAGE_MARY',0,0)
 if f>40 then img('SPECIAL_MARY',0,0,{alpha=math.min(1,(f-40)/35)})end
 enemy(rival,f);creature(f)
 if f>=100 then for step=110,250,35 do puff(150+(step-100)*2.8-25,286,f-step,.48)end end
 hero(f);bolt(f);clouds(f)
 -- No Mary projectiles, generic waves, floating quill trails or old impact flashes.
end
return S
