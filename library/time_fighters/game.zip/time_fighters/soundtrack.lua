-- One continuous cue through the whole successful campaign closing sequence.
local cues=require('stage_music')
local M={cue=nil,gain=nil,finale=false,starts=0}
local menus={title=true,menu=true,rules_select=true,options=true,select=true,gallery=true,tutorial=true,records=true,record_entry=true,unlock=true,gameover=true}
local combat={intro=true,play=true,special=true,special_return=true,ko=true,draw=true,result=true}
local closing={result=true,unlock=true,ending=true,record_entry=true,gameover=true}
function M.reset() M.cue=nil;M.gain=nil;M.finale=false;M.starts=0 end
function M.begin_finale() M.finale=true end
function M.stop()
 if M.cue then music(nil,0)end
 M.cue=nil;M.gain=nil
end
function M.preview(cue,volume)
 if cue~=M.cue then music(cue,0);M.cue=cue;M.starts=M.starts+1 end
 M.gain=(volume or 0)/10;music_layer(0,M.gain,0)
end
function M.sync(state,stage,volume)
 if state=='title' or state=='menu' or state=='select' then M.finale=false end
 local cue=M.finale and closing[state] and 'REAL_HERO' or menus[state] and 'HEROES' or combat[state] and cues[stage] or nil
 local changed=cue~=M.cue
 if changed then music(cue,0);M.cue=cue;if cue then M.starts=M.starts+1 end end
 local gain=(volume or 0)/10
 if cue and (changed or gain~=M.gain)then music_layer(0,gain,0)end
 M.gain=gain
end
return M
