local R=require('rules')
local L=require('layout')
local T=require('chain_tests')
return function()
 local function board() return R.new(19960529,1) end
 local function full(b,x) for y=R.MIN,R.H do b.grid[y][x]=R.cell(2) end end
 for n=1,5 do
  local b=board();R.incoming(b,n,1);assert(R.receive(b))
  assert(not b.grid[R.H][4],'small attack targets entry column too early')
  local count=0;for x=1,6 do if b.grid[R.H][x] then count=count+1 end end
  assert(count==n)
 end
 local b=board();R.incoming(b,24,1);local seed,pairNo=b.seed,b.pairNo;R.receive(b)
 for row=0,3 do for x=1,6 do
  assert(b.grid[R.H-row][x].c==({1,3,2,4})[row+1],'Napoleon horizontal stripe')
 end end
 assert(b.seed==seed and b.pairNo==pairNo,'incoming attacks altered shared pieces')
 b=board();R.incoming(b,24,2);R.receive(b)
 for row=0,3 do for x=1,6 do
  local colour=row<2 and (x%2==1 and 1 or 4) or (x<=3 and 3 or 2)
  assert(b.grid[R.H-row][x].c==colour,'Cleopatra alternating/base and split upper pattern')
 end end
 b=board();R.incoming(b,6,1);R.incoming(b,6,1);R.receive(b)
 for x=1,6 do assert(b.grid[R.H][x].c==1 and b.grid[R.H-1][x].c==1,'chain packets merged into a single pattern') end
 b=board();full(b,1);R.incoming(b,5,1);R.receive(b)
 for x=2,6 do assert(b.grid[R.H][x] and b.grid[R.H][x].k=='blocked','skip full column before using entry') end
 b=board();full(b,1);full(b,2);R.incoming(b,5,1);R.receive(b)
 local received=b.events[#b.events];assert(#received.cells==5 and b.overflowPending and not b.dead,'excess attack must overflow above the screen after arrival')
 b=board();for x=1,2 do for y=R.H-2,R.H-1 do b.grid[y][x]=R.cell(1) end end
 b.grid[R.H][2]=R.cell(2);R.groups(b);R.incoming(b,1,1);R.receive(b)
 assert(b.grid[R.H-3][1] and b.grid[R.H-3][1].k=='blocked' and not b.grid[R.H][1],'counter teleported into a cavity under a cumulus')
 b=board();T.setup(b,3);local ticks={};local total=0
 for t=1,140 do
  R.step(b)
  for _,e in ipairs(b.events) do if e.kind=='attack' then ticks[#ticks+1]=t;total=total+e.n end end
  b.events={};if b.phase=='spawn' then break end
 end
 assert(#ticks==3 and ticks[1]<ticks[2] and ticks[2]<ticks[3] and total>0 and b.out==0,'chain attacks must be staggered and not resent at finish')
 b=board();for y=1,R.H do b.grid[y][1]=R.cell(2) end
 R.incoming(b,1,1);R.finish(b);assert(b.phase=='received' and L.overload(b)==.5)
 b.grid[1][1]=nil;assert(L.overload(b)==0,'reserved landing cell should not trigger warning before arrival')
 b.age=18;assert(L.overload(b)==1,'landed top cell must trigger critical overload')
 return true
end
