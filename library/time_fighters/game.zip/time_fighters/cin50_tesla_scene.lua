local S={}
local Assets=require('cin50_tesla_assets');local img=Assets.img;local imgsize=Assets.size
local NewSpecials=require('cin50_tesla_genius_specials')
local C=require('cin50_tesla_roster')
local function text_at(s,x,y,scale,color,align) text(s,x,y,{font='arcade',scale=scale or 1,color=color or 0xffe7a1,gradient=scale and scale>1 and 0xe78332 or nil,outline=0x081126,shadow=0x030712,align=align or 'center'}) end
function S.draw(who,f,rival,side)
 local s={who=who,t=f,side=side};local mirror=side==2
 if mirror then canvas('CINEMA',480,320);target('CINEMA') end
 NewSpecials.draw(s.who,f,rival)
 -- Full-screen cinematic: decorative outer frame removed.
 if mirror then target();img('CINEMA',0,0,{flip_x=true}) end
 if f>=11 and f<77 then
  rect(6,13,468,40,0x10192b);box(6,13,468,40,0xd99d4b)
  local label=C[s.who].special
  text_at(label,240,26,textw(label,{font='arcade',scale=2})<=450 and 2 or 1,0xffda87)
 end
end

return S
