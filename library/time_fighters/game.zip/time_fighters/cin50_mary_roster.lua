-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_mary_assets');local img=Assets.img;local imgsize=Assets.size
return {
 {id="BEETHOVEN",name="BEETHOVEN",short="BEETHOVEN",title={"El genio","de","Bonn"},era="Alemania · 1808",special="SINFONÍA DEL DESTINO",quote="El destino llama. Yo respondo.",card="BEETH.",fullname="LUDWIG VAN BEETHOVEN"},
 {id="CURIE",name="MARIE CURIE",short="CURIE",title={"La pionera","del","radio"},era="Polonia · 1911",special="EL RESPLANDOR DEL RADIO",quote="Nada se entiende sin curiosidad.",card="CURIE",fullname="MARIE CURIE"},
 {id="VANGOGH",name="VAN GOGH",short="VAN GOGH",title={"El pintor","de las","estrellas"},era="Países Bajos · 1889",special="LA NOCHE ESTRELLADA",quote="Siempre queda otro color.",card="V.GOGH",fullname="VINCENT VAN GOGH"},
 {id="MARILYN",name="MARILYN MONROE",short="MARILYN",title={"La estrella","de","Hollywood"},era="EE. UU. · 1955",special="EXPOSICIÓN LETAL",quote="Esta escena era para mí.",card="MARILYN",fullname="MARILYN MONROE"},
 {id="CERVANTES",name="CERVANTES",short="CERVANTES",title={"El manco","de","Lepanto"},era="España · 1605",special="LOS GIGANTES DE LA MANCHA",quote="Aún queda mucho por escribir.",card="CERV.",fullname="MIGUEL DE CERVANTES"},
 {id="LEONARDO",name="LEONARDO DA VINCI",short="LEONARDO",title={"El","ingenio","universal"},era="Italia · 1505",special="ARTEFACTO MORTAL",quote="Todo comienza con una pregunta.",card="LEON.",fullname="LEONARDO DA VINCI"},
 {id="FRIDA",name="FRIDA KAHLO",short="FRIDA",title={"El universo","en un","autorretrato"},era="México · 1939",special="RAÍCES DE LA VIDA",quote="Mi mundo tiene sus colores.",card="FRIDA",fullname="FRIDA KAHLO"},
 {id="MARY",name="MARY SHELLEY",short="MARY",title={"La creadora","del","monstruo"},era="Reino Unido · 1818",special="¡ESTÁ VIVO!",quote="Mi imaginación acaba de despertar.",card="MARY",fullname="MARY SHELLEY"},
 {id="CALLAS",name="MARIA CALLAS",short="CALLAS",title={"La voz","del","siglo"},era="Grecia · 1953",special="LA ÚLTIMA ARIA",quote="El último aplauso es para mí.",card="CALLAS",fullname="MARIA CALLAS"},
 {id="CHAPLIN",name="CHARLIE CHAPLIN",short="CHAPLIN",title={"El genio","de la","sonrisa"},era="Reino Unido · 1936",special="TIEMPOS MODERNOS",quote="Una sonrisa cambia toda la escena.",card="CHAPLIN",fullname="CHARLIE CHAPLIN"},
 {id="KUROSAWA",name="AKIRA KUROSAWA",short="KUROSAWA",title={"El maestro","del","encuadre"},era="Japón · 1954",special="LOS SIETE SAMURÁIS",quote="La última toma era la buena.",card="AKIRA",fullname="AKIRA KUROSAWA"},
 {id="AGATHA",name="AGATHA CHRISTIE",short="AGATHA",title={"La reina","del","misterio"},era="Reino Unido · 1934",special="EL ORIENT EXPRESS",quote="Todas las pistas conducían a mí.",card="AGATHA",fullname="AGATHA CHRISTIE"},
 {id="TESLA",name="NIKOLA TESLA",short="TESLA",title={"El arquitecto","del","torneo"},era="Serbia · 1899",special="EL EXPERIMENTO FINAL",quote="La corriente siempre encuentra su camino.",card="TESLA",boss=true,fullname="NIKOLA TESLA"},
 {id="KAFKA",name="FRANZ KAFKA",special="METAMORFOSIS KAFKIANA"}
}
