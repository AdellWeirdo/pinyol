local ElectricTitle=require('tesla_title_electric')
local S={};local C=require('roster');local Idle=require('idle');local K=require('knockdown')
local function hero(f)
 local scale=1.12;local x=82-74*scale;local y=293-120*scale
 if f<58 then img('IDLE_TESLA',x,y,{frame=Idle.frame(f),scale=scale})
 else img('TESLA_HOLD',x,y,{frame=((f-58)//9)%6,scale=scale})end
end
local function enemy(f,rival)
 local scale=1.05;local id=C[rival].id
 if f<152 then img('IDLE_'..id,395-74*scale,293-120*scale,{frame=Idle.frame(f),flip_x=true,scale=scale})
 elseif f<246 then img('FIGHTER_'..id,395-74*scale,293-120*scale,{frame=14,flip_x=true,scale=scale})
 else img('KNOCKDOWN_'..id,395-96*scale,293-120*scale,{frame=K.frame(f-246),flip_x=true,scale=scale})end
end
local function arc(ax,ay,bx,by,f,phase)
 local dx,dy=bx-ax,by-ay;local length=math.sqrt(dx*dx+dy*dy)
 img('TESLA_ARC',(ax+bx)/2-length/2,(ay+by)/2-8,{frame=((f//4)+phase)%6,scale_x=length/180,scale_y=16/36,angle=math.atan(dy,dx)*180/math.pi,alpha=.88})
end
local function cloud(f)
 if f<142 or f>312 then return end
 local puffs={{390,220,1.25,142},{430,190,1.15,143},{430,255,1.18,143},{365,180,1.10,144},{355,255,1.15,144},{395,165,.90,145}}
 for i,p in ipairs(puffs)do local age=f-p[4]
  if age>=0 then
   local dissolve=math.max(0,f-(264+i*3));local scale=p[3]*(.92+.08*math.min(1,age/5));local cel=age<2 and 0 or dissolve==0 and 1+(age//4)%3 or dissolve<13 and 4 or 5
   img('TESLA_DUST',p[1]-48*scale+math.sin(age*.11+i)*1.5,p[2]-48*scale-dissolve*.35,{frame=cel,scale=scale,alpha=math.max(0,1-dissolve/25)})
  end
 end
end
function S.draw(f,rival,side,title)
 if side==2 then canvas('TESLA_REVIEW',480,320);target('TESLA_REVIEW')end
 img('STAGE_TESLA',0,0)
 -- The background globe replaces the discarded foreground machine.
 img('TESLA_GLOBE',188,24,{frame=(f//5)%6})
 if f>=32 and f<280 then
  arc(65,43,194,77,f,0);arc(415,43,286,77,f,3)
  if f>=84 then arc(66,72,197,94,f+12,2);arc(414,72,283,94,f+9,5)end
 end
 enemy(f,rival)
 -- The mirrored cannon originates at Tesla's extended wand and grows toward the rival.
 if f>=135 and f<320 then
  local beamX,beamY=76,120
  local reach=math.min(480-beamX,(f-134)*32)
  -- Keep firing through the entire smoke effect; fade only after the last puff is gone.
  -- The growing reveal ends at the screen edge, never inside the rival silhouette.
  local fade=f<304 and 1 or math.max(0,(320-f)/16)
  clip(beamX,114,reach,190)
  img('TESLA_CANNON',beamX,beamY,{frame=((f-135)//3)%6,flip_x=true,alpha=fade})
  clip()
 end
 hero(f);cloud(f)
 -- Full-screen approved: no outer frame.
 if side==2 then target();img('TESLA_REVIEW',0,0,{flip_x=true})end
 if title and title>0 and f>=11 and f<92 then
  local id='TESLA_TITLE_'..title;local w,h=imgsize(id);local x=(480-w)/2;local y=8
  local fade=math.min(1,(f-10)/5,(92-f)/8)
  -- Blue additive fringe pulses around the transparent lettering; the sharp title stays on top.
  local pulse=.19+.08*((math.sin(f*.22)+1)/2)
  img(id,x-w*.025,y-h*.025,{scale=1.05,tint=0x53cfff,alpha=pulse*fade,add=true})
  for _,o in ipairs({{-2,0},{2,0},{0,-2},{0,2}})do
   img(id,x+o[1],y+o[2],{tint=0x75dcff,alpha=.07*fade,add=true})
  end
  img(id,x,y,{alpha=fade})
  if title==2 then ElectricTitle.draw(f,x,y)end
 end
end
return S
