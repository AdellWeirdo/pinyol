local S={duration=330};local modules={[1]="cin50_beethoven_scene",[2]="cin50_curie_scene",[3]="cin50_vangogh_scene",[4]="cin50_marilyn_scene",[5]="cin50_cervantes_scene",[6]="cin50_leonardo_scene",[7]="cin50_frida_scene",[8]="cin50_mary_scene",[9]="cin50_callas_scene",[10]="cin50_chaplin_scene",[11]="cin50_kurosawa_scene",[12]="cin50_agatha_scene",[13]="cin50_tesla_scene"};local loaded={}
function S.draw(who,f,rival,side)
 if who>=16 then return require("new_characters_special").draw(who,f,rival,side)end
 if who==15 then return require('aretha_special').draw(f,rival,side) end
 if who==10 then return require('kafka_special').draw(f,rival,side) end
 if who==13 then return require('tesla_special').draw(f,rival,side,2) end
 local snapshotHero=who==14 and 10 or who
 local snapshotRival=rival==10 and 14 or rival==14 and 10 or rival
 if not loaded[snapshotHero] then loaded[snapshotHero]=require(modules[snapshotHero]) end
 loaded[snapshotHero].draw(snapshotHero,f,snapshotRival,side)
end
return S
