local R=require('rules')
local function assert_eq(a,b,why) assert(a==b,(why or 'value')..': '..tostring(a)..' ~= '..tostring(b)) end
local function empty() return R.new(314,1) end
local function place(b,x,y,c,k,n) b.grid[y][x]=R.cell(c,k,n);return b.grid[y][x] end
return function()
 local b=empty();place(b,1,R.H,1);place(b,2,R.H-1,1,'spark');assert_eq(R.clear_set(b),nil,'diagonal does not connect')
 place(b,2,R.H,1);local clear=R.clear_set(b);assert_eq(clear.count,3,'orthogonal flood')
 b=empty();place(b,1,R.H,1,'spark');place(b,2,R.H,1,'blocked',5);assert_eq(R.clear_set(b),nil,'spark cannot directly break counters')
 place(b,1,R.H-1,1);clear=R.clear_set(b);assert_eq(clear.count,3,'adjacent counter breaks')
 b=empty();place(b,1,R.H,1);place(b,1,R.H-1,1);place(b,2,R.H,1);place(b,2,R.H-1,1);R.groups(b)
 local g=b.grid[R.H][1].g;assert(g and b.groups[g].w==2 and b.groups[g].h==2,'2x2 chamber')
 b.grid[R.H][1]=nil;assert(not R.gravity(b),'chamber supported by one column stays rigid')
 b=empty();for x=1,2 do for y=R.H-2,R.H-1 do place(b,x,y,2) end end;R.groups(b);assert(R.gravity(b));assert(b.grid[R.H][1] and b.grid[R.H-1][2],'chamber falls together')
 b=empty();place(b,1,R.H,2);place(b,6,R.H,2);place(b,4,R.H,1);place(b,1,R.H-1,0,'ray');clear=R.clear_set(b)
 assert_eq(clear.count,2,'ray clears global colour');assert_eq(#clear.cells,3);R.remove(b,clear);assert(b.grid[R.H][4] and not b.grid[R.H][6],'other colour remains')
 b=empty();place(b,1,R.H,0,'ray');clear=R.clear_set(b);assert_eq(b.score,10000,'floor tech bonus')
 b=empty();R.spawn(b);b.active.x=1;b.active.y=R.H-1;b.active.o=1;place(b,1,R.H,3);R.lock(b);for i=1,15 do R.gravity(b) end
 assert(b.grid[R.H][2] and b.grid[R.H-1][1],'pair splits after locking')
 b=empty();local counter=place(b,1,R.H,2,'blocked',1);R.spawn(b);R.lock(b);assert_eq(counter.k,'ball','counter matures on placement');assert_eq(counter.c,2,'counter keeps its displayed future colour')
 b=empty();R.incoming(b,8,1);local rest=R.cancel(b,10);assert_eq(rest,0);assert_eq(R.pending(b),3);assert_eq(b.pending[1].countdown,3)
 R.receive(b);assert_eq(b.grid[R.H][1].n,3);assert_eq(b.grid[R.H][1].c,1,'Ken bottom red')
 b=empty();for y=0,R.H do place(b,1,y,1) end;assert(R.spawn(b),'side column full is alive');b=empty();place(b,4,0,2);assert(R.spawn(b) and not b.dead,'entry warning became premature defeat');assert(R.rotate(b,1));R.lock(b);assert(not b.dead and b.grid[R.MIN][4],'visible top row must remain playable')
 b=empty();local c=empty();for i=2,26 do local p,q=R.next(b),R.next(c);assert_eq(p[1].c,q[1].c,'identical sequence');if i==25 then assert_eq(p[1].k,'ray') end end
 b=empty();R.spawn(b);b.active.x=1;assert(R.rotate(b,1),'wall kick');assert(R.fits(b,b.active),'rotation stays legal')
 return true
end
