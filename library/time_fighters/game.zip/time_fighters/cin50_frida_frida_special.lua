-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_frida_assets');local img=Assets.img;local imgsize=Assets.size
-- Presentation only: six registered gesture drawings, original plant, approved clouds.
local S={};local C=require('cin50_frida_roster');local Idle=require('cin50_frida_idle');local K=require('cin50_frida_knockdown')
local function hero(f)
 local scale=1.18
 if f<58 or f>=303 then img('IDLE_FRIDA',80-56*scale,293-120*scale,{frame=Idle.frame(f),scale=scale})
 else
  -- Open from the near-idle drawing, then sweep slowly with no repeated return-to-idle snap.
  local cycle={1,2,3,2,1,4};local cel=f<75 and 0 or cycle[((f-75)//14)%6+1]
  img('FRIDA_GESTURE',80-56*scale,293-120*scale,{frame=cel,scale=scale})
 end
end
local function rival(enemy,f)
 local scale=1.05
 if f<192 then img('IDLE_'..C[enemy].id,392-92*scale,293-120*scale,{frame=Idle.frame(f),flip_x=true,scale=scale})
 elseif f<253 then img('FIGHTER_'..C[enemy].id,392-92*scale,293-120*scale,{frame=14,flip_x=true,scale=scale})
 else img('KNOCKDOWN_'..C[enemy].id,392-96*scale,293-120*scale,{frame=K.frame(f-253),flip_x=true,scale=scale})end
end
local function cloud(f)
 if f<192 or f>=307 then return end
 local puffs={{404,188,1.10,192},{416,236,1.15,196},{379,273,1.20,199},{338,238,1.04,202},{350,193,.88,205}}
 for i,c in ipairs(puffs)do
  local age=f-c[4]
  if age>=0 then
   local dissolve=math.max(0,f-(269+i*3));local scale=c[3]*(.72+.28*math.min(1,age/8));local phase=age<7 and 0 or dissolve==0 and 1+((age//7)%3) or dissolve<12 and 4 or 5
   img('DUST_FRIDA_PINK',c[1]-48*scale+math.sin(age*.12+i)*2,c[2]-48*scale-dissolve*.4,{frame=phase,scale=scale,alpha=math.max(0,1-dissolve/23)})
  end
 end
end
function S.draw(f,enemy)
 img('STAGE_FRIDA',0,0)
 if f>40 then img('SPECIAL_FRIDA',0,0,{alpha=math.min(1,(f-40)/35)})end
 if f>75 and f<285 then
  local scale=1.35*math.min(1,(f-75)/65);local _,h=imgsize('SPECIAL_PROP_FRIDA')
  img('SPECIAL_PROP_FRIDA',80,294-h*scale,{frame=(f//7)%4,scale=scale,alpha=math.min(1,(285-f)/20)})
 end
 rival(enemy,f);hero(f);cloud(f)
 -- No waves, floating seeds, generic impact flashes or title box.
end
return S
