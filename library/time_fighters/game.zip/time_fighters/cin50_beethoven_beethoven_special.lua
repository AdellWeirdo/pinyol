-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_beethoven_assets');local img=Assets.img;local imgsize=Assets.size
-- Review3: stage choreography only. No puzzle simulation, score or attack changes.
local B={};local C=require('cin50_beethoven_roster');local Idle=require('cin50_beethoven_idle');local K=require('cin50_beethoven_knockdown')
-- Original energy design inspired by arcade projectile silhouettes; no copied sprites.
local function arc(x,y,r,f,width,bright)
 local layers={{width+3,0x743050},{width+1,0xd05b37},{width,0xffb631},{width*.52,0xffec8c},{1.5,0xffffff}}
 for _,layer in ipairs(layers) do
  local span=layer[1];local px,py
  -- Raster brush along the arc avoids the diagonal seams of polygon strips.
  for j=0,35 do
   local a=-1.29+j*2.58/35
   local taper=math.sin(j/35*math.pi)^.55
   local ripple=math.sin(f*.62+j*.63)*2.4+math.sin(f*.33+j*.34)*1.3
   local rr=r+ripple;local ox=x+math.cos(a)*rr;local oy=y+math.sin(a)*rr*.86
   local size=math.max(.65,span*taper)
   circ(ox,oy,size,layer[2])
   if px and layer[2]==0xffffff then line(px,py,ox,oy,layer[2]) end
   px,py=ox,oy
  end
 end
end
local function wave(f,start,power)
 local age=f-start;if age<0 or age>49 then return end
 local p=math.min(1,age/43);local x=95+p*235;local y=183+math.sin(age*.21)*3;local radius=32+p*(power and 102 or 78)
 arc(x-30,y,radius-15,f+11,3,false);arc(x-15,y,radius-6,f+7,5,false);arc(x,y,radius,f,power and 11 or 9,true)
 -- Animated forks race along the leading edge; staggered tails stretch backwards.
 for n=0,10 do
  local a=-1.16+n*.23;local rr=radius+4;local sx=x+math.cos(a)*rr;local sy=y+math.sin(a)*rr*.86
  if (f+n)%3==0 then circ(sx,sy,1.5,0xffffff) end
 end
 -- Broken, fast horizontal afterimages make the direction unmistakable.
 for n=0,5 do
  local yy=y-44+n*18+math.sin(f*.4+n)*6
  local xx=x+radius*.62-((f*9+n*17)%64)
  line(xx,yy,xx-12-(n%3)*5,yy, n%2==0 and 0xffed8b or 0xe69a37)
 end
 if age>=40 and age<49 then img('HIT',353,165,{scale=1.1+(age-40)*.05,alpha=(49-age)/9,tint=0xffe5a0}) end
end
local function rival(who,f)
 if f<144 then
  img('IDLE_'..C[who].id,392-(148-56)*1.05,293-120*1.05,{frame=Idle.frame(f),flip_x=true,scale=1.05})
 elseif f<210 then
  img('FIGHTER_'..C[who].id,392-(148-56)*1.05,293-120*1.05,{frame=14,flip_x=true,scale=1.05})
 else
  img('KNOCKDOWN_'..C[who].id,392-96*1.05,293-120*1.05,{frame=f<252 and K.frame(f-210) or 5,flip_x=true,scale=1.05})
 end
end
local function cloud(f)
 if f<144 or f>=286 then return end
 local puffs={{405,188,1.16,144},{415,233,1.22,150},{378,274,1.25,156},{336,237,1.08,154}}
 for i,c in ipairs(puffs) do
  local age=f-c[4]
  if age>=0 then
   local fadeStart=245+i*4;local dissolve=math.max(0,f-fadeStart)
   local grow=math.min(1,age/9);local scale=c[3]*(.72+.28*grow)
   local phase=age<7 and 0 or f<fadeStart and 1+((age//8)%3) or dissolve<12 and 4 or 5
   local alpha=dissolve==0 and 1 or math.max(0,1-dissolve/22)
   local x=c[1]+math.sin(age*.13+i)*2.5+dissolve*(i-2)*.28
   local y=c[2]+math.cos(age*.12+i)*2-dissolve*.5
   img('SMOKE_PUFF_BEETHOVEN',x-48*scale,y-48*scale,{frame=phase,scale=scale,alpha=alpha})
  end
 end
end
local function music_note(x,y,size,phase)
 local colour=phase%2==0 and 0xffdf70 or 0xfff2bd
 circ(x,y,2*size,colour);line(x+2*size,y,x+2*size,y-10*size,colour)
 line(x+3*size,y,x+3*size,y-10*size,colour);line(x+2*size,y-10*size,x+7*size,y-7*size,colour)
end

local function magic_staff(f)
 if f<82 or f>=258 then return end
 local fade=math.min(1,(f-82)/14,(258-f)/15)
 -- Five staff lines orbit the piano in a breathing spiral. Segments avoid polygon budget.
 for k=0,4 do
  local lastx,lasty
  for j=0,45 do
   local t=j/45;local angle=t*5.5+f*.023
   local x=173+math.cos(angle)*104
   local y=136+math.sin(angle)*34+(t-.5)*65+k*3
   if lastx then
    line(lastx,lasty,x,y, k==2 and 0xfff2a1 or 0xdca83d)
   end
   lastx,lasty=x,y
  end
 end
 for i=0,7 do
  local t=((f-82+i*16)%128)/128;local angle=t*5.5+f*.023
  local x=173+math.cos(angle)*104;local y=136+math.sin(angle)*34+(t-.5)*65+6
  music_note(x,y,(.75+(i%3)*.16)*fade,f//4+i)
  if (f//3+i)%4==0 then
   line(x-4,y-7,x+4,y-7,0xffffff);line(x,y-11,x,y-3,0xffec8c)
  end
 end
end

function B.draw(f,enemy)
 img('STAGE_BEETHOVEN',0,0)
 if f>40 then img('SPECIAL_BEETHOVEN',0,0,{alpha=math.min(1,(f-40)/30)}) end
 if f>=58 then
  local reveal=math.min(1,(f-58)/34);local scale=1.88*(.72+.28*reveal)
  local bob=math.sin((f-58)*.16)*.8*reveal
  img('BEETHOVEN_PIANO_LIVE',-59,293-196*scale+bob,{frame=((f-58)//3)%12,scale=scale,alpha=math.min(1,(f-58)/14)})
  if f>=96 and f<248 then
   -- Only actual keyboard positions. No lights can cross Beethoven's face.
   for i=0,6 do if ((f//4+i)%7)<2 then
    local sx=126+i*8.1;local sy=148-i*1.65;local x=-59+sx*scale;local y=293-196*scale+sy*scale+bob
    poly({x,y,x+5.7*scale,y-1.2*scale,x+4.6*scale,y+3.0*scale,x-1.1*scale,y+4.2*scale},0xffd56e)
   end end
   magic_staff(f)
  end
 end
 if f<164 or f>252 then rival(enemy,f) end
 for i,start in ipairs({110,137,164,195}) do wave(f,start,i==4) end
 local scale=1.18
 if f<54 or f>=286 then
  img('IDLE_BEETHOVEN',80-56*scale,293-120*scale,{frame=Idle.frame(f),scale=scale})
 else
  local pose=f<80 and 0 or f<96 and 1 or f<254 and 2+(f//12)%2 or 1
  img('BEETHOVEN_CONDUCT',80-56*scale,293-120*scale,{frame=pose,scale=scale})
 end
 cloud(f)
end
return B
