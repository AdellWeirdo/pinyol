-- Approved final-screen revision3 and Game Over revision3.
local UI=require('ui_style');local C=require('roster');local Records=require('records')
local F={}
local function label(s,x,y,scale) UI.text(s,x,y,{align='center',scale=scale or 1}) end
local function number(n,x,y)
 local value=Records.format(n);local scale=2
 if UI.width(value,{scale=scale})>256 then scale=1 end
 label(value,x,y,scale)
end
function F.ending(who,score,lostRounds,continues)
 img('PLASMA_BACKGROUND',0,0)
 label('Enhorabuena!',240,14,3)
 label('Eres un heroe del plasma!',240,48,2)
 img('FINAL_WIN_'..C[who].id,16,78)
 label('PUNTUACION FINAL',340,123);number(score,340,143)
 label('ROUNDS PERDIDOS',340,177);number(lostRounds,340,197)
 label('CONTINUES UTILIZADOS',340,231);number(continues,340,251)
end
function F.gameover()
 img('PLASMA_BACKGROUND',0,0)
 label('GAME OVER',240,80,4);label('Gracias por jugar!',240,132,2)
 local heart={'01100110','11111111','11111111','11111111','01111110','00111100','00011000'}
 local function silhouette(pad,colour)
  for y,row in ipairs(heart)do for x=1,8 do
   if row:sub(x,x)=='1'then rect(208+(x-1)*8-pad,180+(y-1)*8-pad,8+pad*2,8+pad*2,colour)end
  end end
 end
 silhouette(4,0xffffff);silhouette(3,0x050508);silhouette(0,0xf03868)
 rect(220,183,5,5,0xffffff);rect(217,188,3,4,0xffffff)
end
return F
