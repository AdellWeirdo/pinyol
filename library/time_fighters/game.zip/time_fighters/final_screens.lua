-- Approved final-screen revision3 and Game Over revision3.
local UI=require('ui_style');local C=require('roster');local Records=require('records')
local F={}
local function label(s,x,y,scale) UI.text(s,x,y,{align='center',scale=scale or 1}) end
local function number(n,x,y)
 local value=Records.format(n);local scale=2
 if UI.width(value,{scale=scale})>256 then scale=1 end
 label(value,x,y,scale)
end
function F.ending(who,score,lostRounds,continues)
 img('PLASMA_BACKGROUND',0,0)
 label('Enhorabuena!',240,14,3)
 label('Eres un heroe del plasma!',240,48,2)
 img('FINAL_WIN_'..C[who].id,16,78)
 label('PUNTUACION FINAL',340,123);number(score,340,143)
 label('ROUNDS PERDIDOS',340,177);number(lostRounds,340,197)
 label('CONTINUES UTILIZADOS',340,231);number(continues,340,251)
end
function F.gameover()
 img('PLASMA_BACKGROUND',0,0)
 label('GAME OVER',240,80,4);label('Gracias por jugar!',240,132,2)
 local pw,ph=imgsize('GAMEOVER_PEACE');local hw,hh=imgsize('GAMEOVER_HEART')
 local pscale=61.6/math.max(pw,ph);local hscale=64/math.max(hw,hh)
 local total=pw*pscale+8+hw*hscale;local left=(480-total)/2
 img('GAMEOVER_PEACE',left,208-ph*pscale/2,{scale=pscale})
 img('GAMEOVER_HEART',left+pw*pscale+8,208-hh*hscale/2,{scale=hscale})
end
return F
