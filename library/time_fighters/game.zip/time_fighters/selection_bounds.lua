-- Union of approved idle and victory cels: one fixed transform per character.
return {
 ['BEETHOVEN']={12,13,95,120},
 ['CURIE']={21,15,88,120},
 ['VANGOGH']={12,19,104,120},
 ['MARILYN']={26,24,88,120},
 ['CERVANTES']={8,23,96,120},
 ['LEONARDO']={16,17,98,120},
 ['FRIDA']={21,23,99,120},
 ['MARY']={23,16,95,120},
 ['CALLAS']={16,24,101,120},
 ['CHAPLIN']={20,17,93,120},
 ['KUROSAWA']={14,21,101,120},
 ['AGATHA']={28,20,87,120},
 ['KAFKA']={44,10,109,120},
}
