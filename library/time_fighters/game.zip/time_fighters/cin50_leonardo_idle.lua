-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_leonardo_assets');local img=Assets.img;local imgsize=Assets.size
-- Approved six drawn poses, plus one short blink every third breathing cycle.
local I={poseTicks=10,blinkTicks=5,poses=6,frames=7}
function I.frame(t)
 local breathing=I.poseTicks*I.poses*3
 local phase=math.max(0,math.floor(t))%(breathing+I.blinkTicks)
 if phase>=breathing then return 6 end
 return (phase//I.poseTicks)%I.poses
end
return I
