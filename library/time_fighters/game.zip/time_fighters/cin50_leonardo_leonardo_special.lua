-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_leonardo_assets');local img=Assets.img;local imgsize=Assets.size
local S={};local C=require('cin50_leonardo_roster');local Idle=require('cin50_leonardo_idle');local K=require('cin50_leonardo_knockdown')
local flights={{58,14},{96,2},{134,23}}
local function hero(f)
 if f<58 then img('IDLE_LEONARDO',78-56*1.18,293-120*1.18,{frame=Idle.frame(f),scale=1.18})
 else img('LEONARDO_DIRECT',78-56*1.18,293-148*1.18,{frame=((f-58)//9)%6,scale=1.18})end
end
local function flight(f,start,y)
 local age=f-start;if age<0 or age>104 then return end
 local center=-180+age*8;local scale=.68
 img('SPECIAL_PROP_LEONARDO',center-128*scale,y+math.sin(age*.13)*2,{frame=(age//5)%4,scale=scale})
end
local function bomb(f,drop,y)
 local a=f-drop;if a<0 or a>=34 then return end
 local p=a/34;local x=392;local yy=y+(221-y)*p*p
 line(x,yy-9,x+3,yy-16,0x9d8a5e)
 circ(x+3,yy-16,2+(a%2),0xffca55);circ(x+3,yy-17,1,0xfff8c9)
 rect(x-3,yy-10,6,4,0xaa8a51)
 circ(x,yy,9,0x141922);circ(x,yy,7,0x424c58);circ(x-2,yy-2,4,0x68717a);circ(x-3,yy-3,1.5,0xc8c8bf)
end
local function blast(f,hit)
 local age=f-hit;if age<0 or age>=26 then return end
 local ends={2,5,8,12,16,20,23,26};local cel=7
 for i,v in ipairs(ends)do if age<v then cel=i-1;break end end
 -- Eight authored sprite cels, exported to the native packed sprite format.
 img('EXPLOSION_LEONARDO',392-56*1.18,221-56*1.18,{frame=cel,scale=1.18})
end
local function rival(enemy,f)
 local scale=1.05
 if f<164 then img('IDLE_'..C[enemy].id,392-(148-56)*scale,293-120*scale,{frame=Idle.frame(f),flip_x=true,scale=scale})
 elseif f<242 then img('FIGHTER_'..C[enemy].id,392-(148-56)*scale,293-120*scale,{frame=14,flip_x=true,scale=scale})
 else img('KNOCKDOWN_'..C[enemy].id,392-96*scale,293-120*scale,{frame=K.frame(f-242),flip_x=true,scale=scale})end
end
local function cloud(f)
 if f<164 or f>=302 then return end
 local puffs={{404,186,1.15,164},{416,233,1.21,167},{379,273,1.25,171},{338,237,1.08,174},{352,190,.9,177}}
 for i,c in ipairs(puffs)do
  local age=f-c[4]
  if age>=0 then
   local dissolve=math.max(0,f-(264+i*3));local scale=c[3]*(.72+.28*math.min(1,age/8));local phase=age<7 and 0 or dissolve==0 and 1+((age//7)%3) or dissolve<12 and 4 or 5
   img('DUST_DARK_GREY',c[1]-48*scale+math.sin(age*.12+i)*2,c[2]-48*scale-dissolve*.4,{frame=phase,scale=scale,alpha=math.max(0,1-dissolve/23)})
  end
 end
end
function S.draw(f,enemy)
 img('STAGE_LEONARDO',0,0)
 if f>40 then img('SPECIAL_LEONARDO',0,0,{alpha=math.min(1,(f-40)/30)})end
 rival(enemy,f)
 for _,v in ipairs(flights)do flight(f,v[1],v[2])end
 hero(f);cloud(f)
 for _,v in ipairs(flights)do bomb(f,v[1]+72,v[2]+119);blast(f,v[1]+106)end
end
return S
