-- Regression and deterministic bot duels for the expanded board; no runtime hooks.
local R=require('rules');local A=require('cpu');local L=require('layout')
local T={matches=0,finished=0,capped=0,ticks=0,placements=0,attacks=0,clears=0,maxStack=0}
local function valid(b)
 local refs={};local groupCounts={};local count=0
 for y=R.HEAD,R.H do
  assert(type(b.grid[y])=='table','missing expanded row')
  for x,v in pairs(b.grid[y]) do
   assert(x>=1 and x<=6 and (y>=R.MIN or b.overflowPending and y==R.MIN-1),'cell outside board')
   assert(not refs[v],'duplicated piece');refs[v]=true;count=count+1
   if v.k=='blocked' then assert(v.n>=1 and v.n<=5,'bad countdown') end
   if v.g then assert(b.groups[v.g],'orphan group');groupCounts[v.g]=(groupCounts[v.g] or 0)+1 end
  end
 end
 for id,g in pairs(b.groups) do
  assert(g.y>=R.MIN and g.y+g.h-1<=R.H and g.x>=1 and g.x+g.w-1<=6,'group outside board')
  assert(groupCounts[id]==g.w*g.h,'broken fused rectangle')
 end
 if b.active and not b.dead then assert(R.fits(b,b.active),'active pair overlaps stack') end
 T.maxStack=math.max(T.maxStack,count)
end
function T.unit()
 assert(R.H==14 and L.pitch==18 and L.cell==18)
 local _,floor=L.cell_at(1,1,R.H);assert(floor+2+18==290,'floor moved')
 for side=1,2 do for y=R.MIN,R.H-1 do local _,a=L.cell_at(side,1,y);local _,b=L.cell_at(side,1,y+1);assert(b-a==18) end end
 local b=R.new(17,1);local n=0;for y=R.MIN,R.H do for x=1,6 do assert(R.free(b,x,y));n=n+1 end end;assert(n==96)
 assert(not R.free(b,1,R.H+1) and not R.free(b,1,R.HEAD-1))
 R.incoming(b,78,1);R.receive(b);assert(R.spawn(b) and not b.dead,'old capacity now fills to entry')
 b=R.new(17,1);R.incoming(b,96,1);R.receive(b);assert(R.spawn(b) and not b.dead,'spawn lost before exceeding screen');R.lock(b);assert(b.dead,'locking above the screen did not lose')
 for c=1,4 do for n=1,5 do
  b=R.new(99,1);local v=R.cell(c,'blocked',n);b.grid[R.H][1]=v
  for turn=1,n do b.active={x=6,y=R.H-(turn-1)*2,o=0,v={R.cell(2),R.cell(3)}};R.lock(b);assert(v.n==n-turn and v.c==c);assert(v.k==(turn==n and 'ball' or 'blocked')) end
 end end
 b=R.new(8,1);b.grid[R.H][1]=R.cell(1);b.grid[R.H-1][1]=R.cell(0,'ray');b.grid[R.H][6]=R.cell(2)
 local clear=R.clear_set(b);assert(clear and clear.count==1 and #clear.cells==2);R.remove(b,clear);assert(not b.grid[R.H][1] and b.grid[R.H][6])
 assert(require('rules_tests')());assert(require('attack_tests')());assert(require('chain_tests').run())
 return true
end
function T.group(w,h)
 local b=R.new(71,1);for y=R.H-h+1,R.H do for x=1,w do b.grid[y][x]=R.cell(2) end end;R.groups(b)
 local id=b.grid[R.H][1].g;assert(id and b.groups[id].w==w and b.groups[id].h==h)
 assert(not R.gravity(b),'fused deposit fell through floor');valid(b)
 local copy=R.clone(b);valid(copy);assert(copy.grid[R.H][1] and copy.grid[R.H-1][w],'clone lost new bottom rows')
 return true
end
function T.begin(who,level,seed,limit)
 T.current={boards={R.new(seed,who),R.new(seed,who==13 and 1 or 13)},lastTurn={0,0},lastPhase={'',''},who=who,level=level,seed=seed,limit=limit or 60000,tick=0}
end
function T.step()
 local c=T.current;if not c or c.done then return end
 local boards=c.boards;c.tick=c.tick+1;local tick=c.tick
  for side=1,2 do
   local b=boards[side];R.step(b,A.input(b,c.level))
   for _,e in ipairs(b.events) do
    if e.kind=='attack' then R.incoming(boards[3-side],e.n,b.character);T.attacks=T.attacks+1
    elseif e.kind=='clear' then T.clears=T.clears+1 end
   end;b.events={}
   if b.turn~=c.lastTurn[side] or b.phase~=c.lastPhase[side] or tick%300==0 then valid(b);c.lastTurn[side]=b.turn;c.lastPhase[side]=b.phase end
  end
 if boards[1].dead or boards[2].dead or tick>=c.limit then
 local finished=boards[1].dead or boards[2].dead;c.done=true
 T.matches=T.matches+1;T.finished=T.finished+(finished and 1 or 0);T.capped=T.capped+(finished and 0 or 1);T.ticks=T.ticks+tick
 T.placements=T.placements+boards[1].turn+boards[2].turn
 print('CAPACITY_DUEL',c.who,c.level,c.seed,tick,boards[1].turn+boards[2].turn,finished and 'finished' or 'time-limit')
 end
end
return T
