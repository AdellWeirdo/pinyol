-- Presentation only. This module never reads/writes puzzle state or random seeds.
local S={duration=330}
local C=require('roster')
local L=require('layout')
local Idle=require('idle')
local idleClock=0
local colours={0xffd263,0x90f6ff,0xffd74f,0xffe9a5,0xbadfff,0xffd882,0xff6c9f,0x9bdcff,0xffa5db}
local function actor(who,cx,ground,frame,flip,scale)
 local pivot=L.actors.pivots[who];local origin=flip and 148-pivot or pivot
 local rest=frame<6
 img((rest and 'IDLE_' or 'FIGHTER_')..C[who].id,cx-origin*scale,ground-L.actors.feet[who]*scale,{frame=rest and Idle.frame(idleClock) or frame,flip_x=flip,scale=scale})
end
local function prop(who,x,y,f,scale,alpha,angle)
 local _,h=imgsize('SPECIAL_PROP_'..C[who].id)
 img('SPECIAL_PROP_'..C[who].id,x,y-h*scale,{frame=(f//7)%4,scale=scale,alpha=alpha or 1,angle=angle or 0})
end
local function wave(x,y,r,colour,power)
 for n=0,26 do
  local a=-1.30+n*.10;local b=a+.10
  local ax,ay=x+math.cos(a)*r,y+math.sin(a)*r*.85
  local bx,by=x+math.cos(b)*r,y+math.sin(b)*r*.85
  line(ax,ay,bx,by,colour);line(ax+1,ay,bx+1,by,0xffffff)
  if power then line(ax+3,ay,bx+3,by,colour);line(ax+5,ay,bx+5,by,colour) end
 end
end
function S.sounds(who,f,snd)
 if f==45 then snd('QUILL',.55) end
 if f==78 then snd('PAGES',.6) end
 if f==110 or f==145 or f==185 then snd('RAY',.45) end
 if f==192 or f==222 or f==248 then snd('HIT',.55) end
end
function S.draw(who,f,rival)
 idleClock=f
 local colour=colours[who];local fade=math.min(1,math.max(0,(f-40)/35))
 img('STAGE_'..C[who].id,0,0)
 if f>40 then img('SPECIAL_'..C[who].id,0,0,{alpha=fade}) end
 local hero=f<62 and (f//8)%6 or f<95 and 26 or f<250 and 28 or (f//8)%6
 local enemy=f<170 and 0 or f<265 and 14 or 40
 local lift=f>=170 and f<265 and math.abs(math.sin(f*.12))*9 or 0
 -- Back-to-front staging: machinery, rival, effects, hero.
 if who==1 then
  if f>65 and f<282 then prop(who,24,262,f,1.13*math.min(1,(f-65)/25),math.min(1,(282-f)/20)) end
 elseif who==2 then
  if f>65 and f<280 then prop(who,100,264,f,1.03*math.min(1,(f-65)/30)) end
 elseif who==6 then
  for j=0,2 do
   local age=f-85-j*26
   if age>=0 and age<145 then prop(who,-210+age*4.8,154+j*55+math.sin(f*.08+j)*8,f+j*9,.72+j*.12) end
  end
 elseif who==7 then
  if f>75 and f<285 then prop(who,80,294,f,1.35*math.min(1,(f-75)/65),math.min(1,(285-f)/20)) end
 elseif who==8 then
  if f>85 and f<290 then prop(who,60+math.min(230,(f-85)*1.4),293,f,1.25,math.min(1,(f-85)/15)) end
 end
 actor(rival,392,293-lift,enemy,true,1.05)
 if who==3 or who==4 or who==9 then
  local age=f-100
  if age>=0 and age<185 then
   local x=80+age*1.7;local scale=who==3 and 1.1 or who==4 and 1.02 or 1.12
   prop(who,x,282,f,scale,math.min(1,age/18)*math.min(1,(185-age)/20),who==3 and age*.8 or 0)
  end
 end
 actor(who,80,293,hero,false,1.18)
 if who~=6 then
  local pulses=who==1 and {110,132,154,192} or {128,165,202}
  for i,start in ipairs(pulses) do
   local age=f-start
   if age>=0 and age<65 then
    local p=age/65;wave(130+p*270,195,14+p*(i==4 and 115 or 65),colour,i==4 or who==9)
   end
  end
 end
 if who==7 and f>120 and f<270 then
  for i=0,6 do
   local x=120+(f*2+i*35)%300;local y=80+(i*29+f)%160
   circ(x,y,2,colour);line(x,y,x-4,y-5,0xffdca9)
  end
 end
 for _,hit in ipairs({192,222,248}) do
  local age=f-hit
  if age>=0 and age<16 then img('HIT',349,178,{scale=1+age*.025,alpha=1-age/16,tint=colour}) end
 end
 if f>=205 and f<286 then
  local alpha=math.min(1,(286-f)/24)
  for j=0,3 do img('SMOKE',335+(j%2)*26,192+(j//2)*27-math.sin(f*.05+j)*3,{scale=.86,alpha=alpha*.65,tint=colour}) end
 end
end
return S
