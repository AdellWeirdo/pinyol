-- Session seed selection is separate from the per-board deterministic piece stream.
-- Pinyol intentionally restarts math.random identically and exposes no wall clock.
-- Persist the mixed state and include player start timing, instead of restarting a fixed match seed.
local S={DEFAULT=0x3a91d1b7}
local function mix(seed)
 local v=seed;v=v~(v<<13);v=v~(v>>17);v=v~(v<<5);v=v&0x7fffffff
 return v~=0 and v or 0x1f123bb5
end
function S.next(previous,elapsed)
 previous=math.tointeger(previous) or S.DEFAULT
 elapsed=math.tointeger(elapsed) or 0
 local seed=mix(previous~elapsed~0x6d2b79f5)
 if seed==previous then seed=mix(seed+0x1f123bb5) end
 if seed==previous then seed=(previous+1)&0x7fffffff;if seed==0 then seed=1 end end
 return seed
end
function S.round(seed,index) return mix(seed~(index*7919)) end
return S
