-- Additive save key. Old clears, records and settings keep their original keys.
local S={BOSS=13,CHAPLIN=14,KEY='chaplin_unlocked_v1',unlocked=false,pending=false}
function S.load(read) S.unlocked=read(S.KEY,false)==true;S.pending=false end
function S.complete(write)
 if S.unlocked then return false end
 S.unlocked=true;S.pending=true;write(S.KEY,true);return true
end
function S.candidates()
 local out={};for i=1,12 do out[#out+1]=i end
 if S.unlocked then out[#out+1]=S.CHAPLIN end
 return out
end
return S
