local S={BOSS=13,CHAPLIN=14,MARY=8,ARETHA=15,KEY='chaplin_unlocked_v1',MARY_KEY='mary_unlocked_v18',unlocked=false,maryUnlocked=false,pending=false,pendingCharacter=nil,galleryUnlocked=false}
S.order={{14,1,S.KEY},{8,1,S.MARY_KEY},{16,2,'shakespeare_unlocked_v20'},{17,2,'audrey_unlocked_v20'},{18,2,'hitchcock_unlocked_v20'},{19,2,'janis_unlocked_v20'},{13,3,'tesla_unlocked_v20'}}
function S.load(read)
 S.flags={};for _,q in ipairs(S.order)do S.flags[q[1]]=read(q[3],false)==true end
 S.unlocked=S.flags[14];S.maryUnlocked=S.flags[8];S.galleryUnlocked=read('gallery_enabled_v20',false)==true or S.flags[13];S.pending=false;S.pendingCharacter=nil;S.galleryPending=false
end
function S.open(who)
 if who==14 then return S.unlocked end;if who==8 then return S.maryUnlocked end
 for _,q in ipairs(S.order)do if q[1]==who then return S.flags and S.flags[who]==true end end
 return who>=1 and who<=19
end
function S.complete(write,difficulty)
 S.flags=S.flags or {};local who
 for _,q in ipairs(S.order)do if not S.open(q[1])then
  if (difficulty or 3)>=q[2]then who=q[1];S.flags[who]=true;write(q[3],true);if who==14 then S.unlocked=true elseif who==8 then S.maryUnlocked=true end end
  break
 end end
 S.pending=who~=nil;S.pendingCharacter=who;S.galleryPending=who==13
 if who==13 then S.galleryUnlocked=true;write('gallery_enabled_v20',true)end
 return S.pending
end
function S.candidates()
 local out={};for i=1,19 do if S.open(i)then out[#out+1]=i end end;return out
end
function S.encounter(route,seed,pick)
 local locked={};for _,q in ipairs(S.order)do if q[1]~=13 and pick~=q[1] and not S.open(q[1])then locked[#locked+1]=q[1]end end
 if #locked==0 or #route<10 then return nil end
 local v=(tonumber(seed)or 731)&0x7fffffff
 local function nextn(n)v=v~(v<<13);v=v~(v>>17);v=v~(v<<5);v=v&0x7fffffff;return v%n end
 if nextn(4)~=0 then return nil end
 local who=locked[nextn(#locked)+1];local index=6+nextn(5);route[index]=who;return who,index
end
return S
