local O=require('options')
return function()
 assert(require('release17_tests').balance())
 local function read(t) return function(k,d) if t[k]~=nil then return t[k] end;return d end end
 assert(O.load(read({})).difficulty==3,'fresh boot not Normal')
 for oldChoice=1,5 do
  local s=O.load(read({difficulty=tostring(oldChoice),music_volume='4',effects_volume='0'}))
  assert(s.difficulty==3 and s.music==4 and s.effects==0,'legacy migration')
 end
 for choice=1,5 do
  local data={};local s={difficulty=choice,music=7,effects=2};O.save(s,function(k,v)data[k]=v end)
  local restored=O.load(read(data));assert(restored.difficulty==choice and restored.music==7 and restored.effects==2,'explicit choice not retained')
 end
 print('DIFFICULTY17: calibrated curve plus fresh/legacy Normal default and explicit settings persistence PASS')
 return true
end
