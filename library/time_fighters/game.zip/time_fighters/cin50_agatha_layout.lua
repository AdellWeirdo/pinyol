-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_agatha_assets');local img=Assets.img;local imgsize=Assets.size
-- All six cell columns sit inside the Tesla hardware, including their outer pixels.
local L={cell=18,pitch=22,top=6,width=108,redLine=40,
 actors={scale=1,left=188,right=292,floor=258,pivots={56,56,56,56,56,56,56,56,56,56,56,56,56},feet={120,120,120,120,120,120,120,120,120,120,120,120,120}},boards={
 {x=19,leftEdge=16,rightEdge=130,outer=8,inner=138,score=181},
 {x=353,leftEdge=350,rightEdge=464,outer=472,inner=342,score=299}
}}
function L.cell_at(side,x,y) return L.boards[side].x+(x-1)*L.cell,L.top+y*L.pitch end
function L.overload(b)
 -- Falling pieces pass through the red zone normally; only the settled stack is a warning.
 for y=0,1 do for x=1,6 do
  local v=b.grid[y][x];local a=v and v.arrival
  if v and (not a or b.age>=a.age+a.delay+a.ticks) then return y==0 and 1 or .5 end
 end end
 return 0
end
function L.result(boards,wins,winner)
 local slots={}
 for side=1,2 do
  local won=side==winner
  slots[side]={who=boards[side].character,kind=won and 'WIN_' or 'LOSE_',label=won and 'VENCEDOR' or 'DERROTADO',
   -- Victory sources face right; defeat sources face left. Orient each inward.
   x=side==1 and 10 or 248,center=side==1 and 121 or 359,
   flip=(won and side==2) or (not won and side==1),won=won}
 end
 return slots,tostring(wins[1])..' - '..tostring(wins[2])
end
return L
