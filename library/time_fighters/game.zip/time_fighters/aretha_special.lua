-- Exact approved review staging, compressed into the common330-tick cinematic without changing puzzle simulation.
local S={};local C=require('roster');local Idle=require('idle');local K=require('knockdown')
local function actor(id,px,cel,flip)
 local scale=1.65;local pivot=id:sub(1,10)=='KNOCKDOWN_' and 96 or 56
 img(id,px-(flip and (id:sub(1,10)=='KNOCKDOWN_' and 192 or 148)-pivot or pivot)*scale,290-120*scale,{frame=cel,scale=scale,flip_x=flip})
end
function S.draw(f,rival,side)
 local t=f/60
 if side==2 then canvas('CINEMA',480,320);target('CINEMA')end
 img('SPECIAL_BG_ARETHA',0,0)
 if t>.2 then img('SPEAKERS_ARETHA',-20,290-128*2.05,{frame=math.floor(t*9)%6,scale=2.05,alpha=math.min(1,(t-.2)*3)})end
 local rid=C[rival].id
 if t<2.2 then actor('IDLE_'..rid,396,rid=='ARETHA' and math.floor(t*6)%6 or Idle.frame(t*60),false)
 elseif t<4.75 then actor('FIGHTER_'..rid,396,12+math.floor(t*6)%6,false)
 else actor('KNOCKDOWN_'..rid,396,math.min(5,math.floor((t-4.75)*9)),false)end
 local ox=-20+108*2.05;local oy=290-128*2.05+90*2.05;local scale=34*2.05/128
 for j=0,2 do
  local q=(t-(1.25+j*.8))/.95
  if q>=0 and q<1 then local cx=ox+q*(396-ox);local cy=oy+q*(208-oy)
   img('VINYL_ARETHA',cx-72*scale,cy-64*scale,{frame=math.floor((t-1.25-j*.8)*14)%6,scale=scale})
  end
 end
 actor(t<.8 and 'IDLE_ARETHA' or 'CAST_ARETHA',82,math.floor(t*7)%6,false)
 if t>=2.2 and t<5.4 then
  local age=t-2.2;local fade=t>5 and (5.4-t)/.4 or 1
  for j=0,3 do img('DUST_ARETHA_YELLOW',273+(j%2)*45,90+math.floor(j/2)*70,{frame=math.floor(age*9+j)%6,scale=1.8,alpha=fade})end
 end
 if side==2 then target();img('CINEMA',0,0,{flip_x=true})end
 local opacity=t<1.5 and 1 or math.max(0,1-(t-1.5)/.55)
 if t>.12 and opacity>0 then local w=imgsize('TITLE_ARETHA');img('TITLE_ARETHA',(480-w)/2,12,{alpha=opacity})end
 local white=t<.22 and 1-t/.22 or t>6 and math.min(1,(t-6)/.25) or 0
 if white>0 then img('TRANSITION_WHITE',0,0,{alpha=white})end
end
return S
