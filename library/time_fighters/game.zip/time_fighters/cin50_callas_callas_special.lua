-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_callas_assets');local img=Assets.img;local imgsize=Assets.size
-- Presentation only: one authored vocal wave, no small secondary projectiles.
local S={};local C=require('cin50_callas_roster');local Idle=require('cin50_callas_idle');local K=require('cin50_callas_knockdown')
local function hero(f)
 local sc=1.18
 if f<58 or f>=304 then img('IDLE_CALLAS',80-56*sc,293-120*sc,{frame=Idle.frame(f),scale=sc})
 else img('CALLAS_SING',80-56*sc,293-120*sc,{frame=((f-58)//11)%6,scale=sc})end
end
local function rival(who,f)
 local sc=1.05
 if f<165 then img('IDLE_'..C[who].id,392-92*sc,293-120*sc,{frame=Idle.frame(f),flip_x=true,scale=sc})
 elseif f<224 then img('FIGHTER_'..C[who].id,392-92*sc,293-120*sc,{frame=14,flip_x=true,scale=sc})
 else img('KNOCKDOWN_'..C[who].id,392-96*sc,293-120*sc,{frame=K.frame(f-224),flip_x=true,scale=sc})end
end
local function wave(f)
 local age=f-100;if age<0 or age>=125 then return end
 local sc=(.24+math.min(1,age/60)*1.04)*(1+.035*math.sin(age*.45))
 local x=131+age*3.35;local y=216
 img('CALLAS_VOCAL_WAVE',x-128*sc,y-110*sc,{frame=(age//3)%8,scale=sc,alpha=math.min(1,age/6,(125-age)/12)})
end
local function clouds(f)
 if f<165 or f>=303 then return end
 local pts={{404,188,1.12,165},{416,235,1.18,169},{379,274,1.24,172},{337,238,1.06,175},{350,191,.9,178}}
 for i,c in ipairs(pts)do
  local age=f-c[4]
  if age>=0 then
   local dissolve=math.max(0,f-(265+i*3));local sc=c[3]*(.72+.28*math.min(1,age/8));local cel=age<7 and 0 or dissolve==0 and 1+((age//7)%3) or dissolve<12 and 4 or 5
   img('DUST_CALLAS_RED',c[1]-48*sc+math.sin(age*.13+i)*2,c[2]-48*sc-dissolve*.4,{frame=cel,scale=sc,alpha=math.max(0,1-dissolve/23)})
  end
 end
end
function S.draw(f,enemy)
 img('STAGE_CALLAS',0,0)
 if f>40 then img('SPECIAL_CALLAS',0,0,{alpha=math.min(1,(f-40)/35)})end
 rival(enemy,f);hero(f);wave(f);clouds(f)
end
return S
