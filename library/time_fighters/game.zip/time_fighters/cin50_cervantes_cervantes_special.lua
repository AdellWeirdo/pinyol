-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_cervantes_assets');local img=Assets.img;local imgsize=Assets.size
local S={};local C=require('cin50_cervantes_roster');local Idle=require('cin50_cervantes_idle');local K=require('cin50_cervantes_knockdown')
local function puff(x,y,age,scale,alpha)
 if age<0 or age>=42 then return end
 local phase=age<6 and 0 or age<30 and 1+((age//6)%3) or age<36 and 4 or 5
 img('DUST_EARTH',x-48*scale,y-48*scale,{frame=phase,scale=scale,alpha=(alpha or 1)*math.min(1,age/5)*math.min(1,(42-age)/8)})
end
local function book(f)
 if f<44 or f>=291 then return end
 local rise=math.min(1,(f-44)/38);local root=368-rise*108
 local cel=f<79 and 0 or math.min(5,(f-79)//8)
 local fade=math.min(1,(f-44)/9,(291-f)/16)
 img('CERVANTES_FAN_BOOK',82-160,root-220,{frame=cel,alpha=fade})
end
local function rider(f,start,id,scale)
 local age=f-start;if age<0 or age>=142 then return end
 local grow=.30+.70*math.min(1,age/20);local size=scale*grow
 local x=82+age*4.12;local ground=247+math.min(1,age/20)*42
 local w,h=imgsize(id);w=id=='QUIJOTE' and 224 or 192
 img(id,x-w*.5*size,ground-h*size,{frame=(f//5)%6,scale=size})
 for j=0,3 do
  local t=(age+j*8)%36
  puff(x-w*.23*size-j*11-t*.4,ground-4,t,.58+(j%2)*.12,.9)
 end
end
local function rival(enemy,f)
 local scale=1.05
 if f<161 then img('IDLE_'..C[enemy].id,392-(148-56)*scale,293-120*scale,{frame=Idle.frame(f),flip_x=true,scale=scale})
 elseif f<211 then img('FIGHTER_'..C[enemy].id,392-(148-56)*scale,293-120*scale,{frame=14,flip_x=true,scale=scale})
 else img('KNOCKDOWN_'..C[enemy].id,392-96*scale,293-120*scale,{frame=K.frame(f-211),flip_x=true,scale=scale})end
end
local function hero(f)
 if f<58 then img('IDLE_CERVANTES',82-56*1.18,293-120*1.18,{frame=Idle.frame(f),scale=1.18})
 else
  local sequence={0,1,2,3,4,5};local frame=sequence[((f-58)//8)%6+1]
  img('CERVANTES_QUILL',82-56*1.18,293-148*1.18,{frame=frame,scale=1.18})
 end
end
local function cloud(f)
 if f<163 or f>=294 then return end
 local puffs={{403,188,1.18,163},{415,233,1.22,169},{379,273,1.26,174},{337,237,1.09,177},{350,192,.9,184}}
 for i,c in ipairs(puffs)do
  local age=f-c[4]
  if age>=0 then
   local fadeStart=253+i*3;local dissolve=math.max(0,f-fadeStart)
   local scale=c[3]*(.72+.28*math.min(1,age/8));local phase=age<7 and 0 or f<fadeStart and 1+((age//7)%3) or dissolve<12 and 4 or 5
   img('DUST_EARTH',c[1]-48*scale+math.sin(age*.12+i)*2,c[2]-48*scale-dissolve*.4,{frame=phase,scale=scale,alpha=math.max(0,1-dissolve/23)})
  end
 end
end
function S.draw(f,enemy)
 img('STAGE_CERVANTES',0,0)
 if f>40 then img('SPECIAL_CERVANTES',0,0,{alpha=math.min(1,(f-40)/30)})end
 book(f);rival(enemy,f)
 rider(f,114,'QUIJOTE',.78);rider(f,148,'SANCHO',.91)
 hero(f);cloud(f)
end
return S
