-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_kurosawa_assets');local img=Assets.img;local imgsize=Assets.size
-- Presentation only. The entire original samurai asset is rendered uniformly at twice its original size.
local S={}
function S.actor(f)
 img('KUROSAWA_DIRECT',78-56*1.12,293-120*1.12,{frame=((f-100)//10)%8,scale=1.12})
end
function S.samurai(f)
 local x=-250+(f-100)*3.8;local alpha=math.min(1,(f-100)/14)*math.min(1,(270-f)/12);local frame=(f//7)%4
 local oldScale=1.14;local double=oldScale*2
 -- Original four-cel sprite intact: figures, white slashes and water grow together.
 img('SPECIAL_PROP_KUROSAWA',x-128*oldScale,291-196*double,{frame=frame,scale=double,alpha=alpha})
end
function S.cloud(f)
 local pts={{404,188,1.10,191},{415,234,1.15,195},{378,274,1.20,198},{338,237,1.04,201},{351,191,.88,204}}
 for i,c in ipairs(pts)do
  local age=f-c[4]
  if age>=0 then
   local dissolve=math.max(0,f-(254+i*2));local sc=c[3]*(.72+.28*math.min(1,age/8));local cel=age<7 and 0 or dissolve==0 and 1+((age//7)%3) or dissolve<12 and 4 or 5
   img('DUST_KUROSAWA_GREY',c[1]-48*sc+math.sin(age*.12+i)*2,c[2]-48*sc-dissolve*.4,{frame=cel,scale=sc,alpha=math.max(0,1-dissolve/23)})
  end
 end
end
return S
