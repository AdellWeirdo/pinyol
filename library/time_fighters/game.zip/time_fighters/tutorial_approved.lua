-- Native port of frozen tutorial-live.js revision31. Independent scene/text clocks.
-- No RNG, rules, board damage, music transport or save writes in this module.
local T={lessons=require('tutorial_dialogues'),lesson=1,page=1,tick=0,characters=0,textTick=0}
local function chars(s) local a={};for _,v in utf8.codes(s) do a[#a+1]=utf8.char(v) end;return a end
local function empty() return {{},{},{},{},{},{}} end
local function offsets(turn) return table.unpack(({{0,18},{18,0},{0,-18},{-18,0}})[turn+1]) end
local function turn(age,final) return age<16 and 0 or age<30 and 1 or age<44 and 2 or age<58 and 3 or final end
local function width(s) return utf8.len(s)*8 end
local function wrap(s)
 local lines,row={},''
 for w in s:gmatch('%S+') do local trial=row=='' and w or row..' '..w
  if row~='' and width(trial)>152 then lines[#lines+1]=row;row=w else row=trial end
 end
 if row~='' then lines[#lines+1]=row end;return lines
end
local function initDischarge(page)
 local d={pageTick=0,grid=empty(),incoming={},cooldown=24,turns=0,activated=false,detonated=false,clearTick=-999,finished=false,received=false}
 if page==1 then d.active={col=2,y=-36,colors={0,0}}
 else
  if page==3 then for x,col in ipairs(d.grid) do for r=0,9+(x-1)%2 do col[#col+1]={c=(r+x-1)%4,k='ball'} end end end
  for row=0,2 do for col=0,5 do d.incoming[#d.incoming+1]={col=col,c=(row+col)%4,start=24+row*24+col*2,target=272-(#d.grid[col+1]+row)*18,landed=false} end end
 end
 return d
end
local function initChain() return {phase='trigger',phaseTick=0,stage=0,y=-36,blueY=254,greenY=254,clears={},done=false} end
local function initSupercell()
 local d={grid=empty(),y=-36,target=74,detonated=false,removed={},pageTick=0}
 for x=0,5 do for r=0,(x==2 and 10 or 11) do d.grid[x+1][#d.grid[x+1]+1]={c=(r+x)%4==0 and (r+x)%3 or 3,y=272-r*18} end end
 d.grid[3][11].c=3;return d
end
function T.enter(lesson,page)
 lesson=lesson or 1;page=page or 1;local changed=lesson~=T.lesson;local pageChanged=page~=T.page
 if changed or page==1 then T.tick=0;T.grid=empty();T.active=nil;T.cooldown=0;T.pairs=0;T.overloaded=false end
 if lesson==3 then
  if changed or page==1 or not T.sparkDemo then T.sparkDemo={y=page==2 and 236 or -36,redGone=false,clears={},fourDone={false,false},pageTick=0} end
  if pageChanged then T.sparkDemo.pageTick=0 end
  if page==3 then T.sparkDemo={y=-36,redGone=true,clears={},fourDone={false,false},pageTick=0} end
 end
 if lesson==4 then
  if changed or page==1 or not T.cumulusDemo then T.cumulusDemo={rows=page==2 and 3 or 1,cols=2,partial=0,cooldown=24,pageTick=0,detonated=false,clearTick=-1,fusedTick=-999} end
  if pageChanged then T.cumulusDemo.pageTick=0;T.cumulusDemo.cooldown=math.max(24,T.cumulusDemo.cooldown) end
 end
 if lesson==5 and (changed or pageChanged or page==1 or not T.dischargeDemo) then T.dischargeDemo=initDischarge(page);T.overloaded=false end
 if lesson==6 and (changed or page==1 or page==3 or not T.chainDemo) then T.chainDemo=initChain() end
 if lesson==6 and page==2 and pageChanged then T.chainDemo.phaseTick=0 end
 if lesson==7 and (changed or page==1 or not T.supercellDemo) then T.supercellDemo=initSupercell() end
 if lesson==7 and pageChanged then T.supercellDemo.pageTick=0 end
 T.lesson=lesson;T.page=page;T.text=T.lessons[lesson].pages[page];T.letters=chars(T.text);T.textTick=0;T.characters=0;T.lines=wrap(T.text);T.height=28+14*#T.lines
end
function T.complete() return T.characters>=#T.letters end
function T.confirm()
 if not T.complete() then T.characters=#T.letters;T.textTick=T.characters*3;return false end
 if T.page<#T.lessons[T.lesson].pages then T.enter(T.lesson,T.page+1)
 elseif T.lesson<#T.lessons then T.enter(T.lesson+1,1)
 else return true end
 return false
end
local function fx(n) if T.sound then T.sound(n) end end
local function basic()
 local danger=T.page==4
 if (T.page==1 and T.tick%40==1) or (danger and T.tick%48==12) then fx('BOOT_CLING') end
 if T.overloaded or T.page==1 then return end
 if not T.active then
  if T.cooldown>0 then T.cooldown=T.cooldown-1;return end
  local col=danger and 3 or ({3,2,4,1,5,0})[T.pairs%6+1]
  if not danger and #T.grid[col+1]>=12 then table.remove(T.grid[col+1],1);table.remove(T.grid[col+1],1) end
  T.active={col=col,y=-36,age=0,turn=0,colors={T.pairs%4,(T.pairs+1)%4}}
 end
 local a=T.active;a.age=a.age+1;local tr=T.page==3 and a.age>=32 and a.age<72 and 1 or 0
 if tr~=a.turn then fx('ROTATE') end;a.turn=tr
 local targetY=254-#T.grid[a.col+1]*18;a.y=math.min(targetY-(tr==1 and 18 or 0),a.y+(danger and 8 or 2.4))
 if a.y>=targetY then local col=T.grid[a.col+1];col[#col+1]=a.colors[2];col[#col+1]=a.colors[1];T.active=nil;T.pairs=T.pairs+1;T.cooldown=danger and 5 or 12;fx('LOCK')
  if danger and #col>16 then T.overloaded=true;fx('BOOT_ZAP');fx('KO') end
 end
end
local function clear(d,x,y) d.clears[#d.clears+1]={tick=T.tick,x=x,y=y} end
local function sparkUpdate()
 local d=T.sparkDemo;d.pageTick=d.pageTick+1
 if T.page<3 then
  if not d.redGone then
   d.y=math.min(T.page==1 and 236 or 254,d.y+3.6)
   if T.page==2 and d.y>=254 then d.redGone=true;d.blueY=236;clear(d,389,272);clear(d,407,272);fx('LOCK');fx('PLASMA_CLEAR') end
  elseif d.blueY then local old=d.blueY;d.blueY=math.min(272,d.blueY+3.6);if old<272 and d.blueY==272 then fx('LOCK') end end
 else
  for i=0,1 do local elapsed=d.pageTick-24-i*180;if elapsed>=81 and not d.fourDone[i+1] then d.fourDone[i+1]=true;for j=0,1 do clear(d,371+(i*2+j)*18,272) end;fx('LOCK');fx('PLASMA_CLEAR') end end
 end
end
local function cumulusUpdate()
 local d=T.cumulusDemo;d.pageTick=d.pageTick+1;if d.detonated then return end
 if not d.active then
  if d.cooldown>0 then d.cooldown=d.cooldown-1;return end
  if T.page==1 or d.rows<2 or d.partial>0 then
   if d.rows>=6 then return end
   local side=d.rows==2 and d.cols<4;d.active={kind=side and 'side' or 'top',col=side and d.cols or d.partial,y=-36,age=0,turn=0}
  else d.active={kind='trigger',col=0,y=-36,age=0,turn=0} end
 end
 local a=d.active;a.age=a.age+1;local tr=turn(a.age,a.kind=='top' and 1 or 0);if tr~=a.turn then fx('ROTATE') end;a.turn=tr
 local targetY=a.kind=='side' and 254 or 272-d.rows*18;a.y=math.min(targetY,a.y+3)
 if a.y>=targetY then
  if a.kind=='trigger' then d.detonated=true;d.clearTick=T.tick;d.active=nil;fx('LOCK');fx('PLASMA_CLEAR')
  else
   if a.kind=='side' then d.cols=d.cols+1 else d.partial=d.partial+2;if d.partial>=d.cols then d.rows=d.rows+1;d.partial=0 end end
   d.fusedTick=T.tick;d.active=nil;d.cooldown=42;fx('LOCK');fx('FUSE')
  end
 end
end
local function dischargeUpdate()
 local d=T.dischargeDemo;d.pageTick=d.pageTick+1;if T.overloaded then return end
 if T.page==1 then
  if not d.detonated then
   if d.pageTick<24 then return end
   d.active.y=math.min(200,d.active.y+(d.active.y>160 and 1.8 or 3))
   if d.active.y>=200 then d.detonated=true;d.finished=true;d.clearTick=T.tick;d.active=nil;fx('LOCK');fx('PLASMA_CLEAR') end
  end;return
 end
 for _,p in ipairs(d.incoming) do if not p.landed and d.pageTick>=p.start+30 then p.landed=true;local col=d.grid[p.col+1];col[#col+1]={c=p.c,k='blocked',n=5};if p.col==0 then fx('BLOCK_RECEIVE') end end end
 d.received=true;for _,p in ipairs(d.incoming) do if not p.landed then d.received=false end end;if not d.received then return end
 if not d.active then
  if d.cooldown>0 then d.cooldown=d.cooldown-1;return end
  if T.page==2 and d.activated then return end
  local order=T.page==2 and {2,3,1,4,0} or {3,2,3};local col=order[d.turns%#order+1]
  d.active={col=col,y=-36,colors={d.turns%4,(d.turns+1)%4}}
 end
 local a=d.active;local targetY=254-#d.grid[a.col+1]*18;a.y=math.min(targetY,a.y+(T.page==3 and 6 or 5))
 if a.y>=targetY then
  local col=d.grid[a.col+1];col[#col+1]={c=a.colors[2],k='ball'};col[#col+1]={c=a.colors[1],k='ball'};d.turns=d.turns+1;d.active=nil;d.cooldown=24;d.activated=true
  for _,column in ipairs(d.grid) do for _,cell in ipairs(column) do if cell.k=='blocked' then cell.n=cell.n-1;if cell.n==0 then cell.k='ball' else d.activated=false end end end end
  fx('LOCK');if #col>16 then T.overloaded=true;fx('BOOT_ZAP');fx('KO') end
 end
end
local function chainClear(color,positions)
 local d=T.chainDemo;d.stage=d.stage+1;d.phaseTick=0;for _,p in ipairs(positions) do clear(d,p[1],p[2]) end;fx('PLASMA_CLEAR')
 if color==0 then d.phase='red-burst' elseif color==1 then d.phase='blue-burst' else d.phase='done';d.done=true;d.chargeTick=T.tick end
end
local function chainUpdate()
 local d=T.chainDemo;d.phaseTick=d.phaseTick+1
 if d.phase=='trigger' then
  if d.phaseTick<36 then return end;d.y=math.min(254,d.y+2.6);if d.y==254 then chainClear(0,{{371,272},{389,272},{371,236},{371,254}}) end
 elseif d.phase=='red-burst' and d.phaseTick>=30 then d.phase='blue-fall';d.phaseTick=0
 elseif d.phase=='blue-fall' then d.blueY=math.min(272,d.blueY+1.5);if d.blueY==272 then d.phase='blue-ready';d.phaseTick=0;fx('LOCK') end
 elseif d.phase=='blue-ready' and T.page>=2 and d.phaseTick>=48 then chainClear(1,{{389,272},{407,272}})
 elseif d.phase=='blue-burst' and d.phaseTick>=30 then d.phase='green-fall';d.phaseTick=0
 elseif d.phase=='green-fall' then d.greenY=math.min(272,d.greenY+1.5);if d.greenY==272 then d.phase='green-ready';d.phaseTick=0;fx('LOCK') end
 elseif d.phase=='green-ready' and T.page>=3 and d.phaseTick>=48 then chainClear(2,{{407,272},{425,272}}) end
end
local function supercellUpdate()
 local d=T.supercellDemo;d.pageTick=d.pageTick+1
 if not d.detonated then
  if d.pageTick<36 then return end;local targetY=T.page==1 and 38 or d.target;d.y=math.min(targetY,d.y+2)
  if T.page==1 and d.y==38 and not d.hoverTick then d.hoverTick=T.tick;fx('BOOT_CLING') end
  if T.page==2 and d.y==d.target then
   d.detonated=true;d.clearTick=T.tick
   for x,col in ipairs(d.grid) do local keep={};for _,p in ipairs(col) do if p.c==3 then d.removed[#d.removed+1]={x=353+(x-1)*18,y=p.y} else keep[#keep+1]=p end end;d.grid[x]=keep end
   d.grid[3][#d.grid[3]+1]={c=2,y=d.y-18};fx('LOCK');fx('PLASMA_CLEAR')
  end
 elseif T.tick-d.clearTick>=30 then
  local landed=false;for _,col in ipairs(d.grid) do for r,p in ipairs(col) do local targetY=272-(r-1)*18;if p.y<targetY then local old=p.y;p.y=math.min(targetY,p.y+2.8);if old<targetY and p.y==targetY then landed=true end end end end
  if landed and T.tick%5==0 then fx('LOCK') end
 end
end
function T.update(sound)
 T.sound=sound;T.tick=T.tick+1
 if not T.complete() then
  T.textTick=T.textTick+1;local n=math.min(#T.letters,T.textTick//3)
  if n>T.characters then T.characters=n;if n%2==1 and T.letters[n]:match('[A-Za-z0-9]') then fx('TUTORIAL_TEXT') end end
 end
 if T.lesson==2 then basic() elseif T.lesson==3 then sparkUpdate() elseif T.lesson==4 then cumulusUpdate() elseif T.lesson==5 then dischargeUpdate() elseif T.lesson==6 then chainUpdate() elseif T.lesson==7 then supercellUpdate() end
end
local function ball(c,x,y) img('BALL',math.floor(x+.5),math.floor(y+.5),{frame=c*4+(T.tick//8)%4}) end
local function spark(c,x,y) img('SPARK',math.floor(x+.5)-7,math.floor(y+.5)-7,{frame=c*4+(T.tick//8)%2}) end
local function glyphs(s,x,y)
 for _,ch in ipairs(chars(s)) do local code=utf8.codepoint(ch);img('TUT_FONT_'..(code<256 and code//64 or 0),math.floor(x)-2,y-2,{frame=code<256 and code%64 or 63});x=x+8 end
end
local function dischargeFx(clears,duration)
 duration=duration or 18
 for _,p in ipairs(clears) do local age=T.tick-p.tick;if age>=0 and age<duration then img('DISCHARGE',p.x-27,p.y-27,{frame=math.min(2,age//(duration/3))}) end end
end
local function drawSparks()
 local d=T.sparkDemo
 if T.page<3 then
  if not d.redGone then ball(0,389,272);ball(0,407,272);ball(1,389,d.y-18);spark(0,389,d.y)
  elseif d.blueY then ball(1,389,d.blueY) end
 else
  for i=0,3 do if not d.fourDone[i//2+1] then ball(i,371+i*18,272) end end
  for pair=0,1 do local elapsed=d.pageTick-24-pair*180;if elapsed>=0 and not d.fourDone[pair+1] then local y=math.min(254,-36+elapsed*3.6);for j=0,1 do spark(pair*2+j,371+(pair*2+j)*18,y) end end end
 end
 dischargeFx(d.clears)
end
local function drawCumulus()
 local d=T.cumulusDemo;local left=371
 if not d.detonated then
  if d.rows==1 then ball(1,left,272);ball(1,left+18,272)
  else local age=T.tick-d.fusedTick;local frame=age<12 and 3+math.min(2,age//6) or 4+(T.tick//8)%2;img('CUMULUS_'..d.cols..'_'..d.rows,left,290-d.rows*18,{frame=frame}) end
  for col=0,d.partial-1 do ball(1,left+col*18,272-d.rows*18) end
  local a=d.active;if a then local dx,dy=offsets(a.turn);local x=left+a.col*18
   if a.kind=='trigger' then ball(1,x,a.y-18);spark(1,x+dx,a.y-18+dy) else ball(1,x,a.y);ball(1,x+dx,a.y+dy) end
  end
 else local age=T.tick-d.clearTick;if age>=0 and age<18 then for col=0,d.cols-1,2 do for row=0,d.rows-1,2 do img('DISCHARGE',left-18+col*18,245-row*18,{frame=math.min(2,age//6)}) end end end end
end
local function drawDischarge()
 local d=T.dischargeDemo
 if T.page==1 then
  if not d.detonated then img('CUMULUS_2_4',389,218,{frame=1+(T.tick//8)%2});ball(0,389,d.active.y-18);spark(0,389,d.active.y)
  else local age=T.tick-d.clearTick;if age<18 then for r=0,4,2 do img('DISCHARGE',371,245-r*18,{frame=age//6}) end end end;return
 end
 local function cell(p,x,y)
  if p.k=='blocked' then img('BLOCK_COLORED',x,math.floor(y+.5),{frame=p.c*4+1});local n=p.n;glyphs(tostring(n),math.floor(x+5),math.floor(y+5)) else ball(p.c,x,y) end
 end
 for x,col in ipairs(d.grid) do for r,p in ipairs(col) do cell(p,353+(x-1)*18,272-(r-1)*18) end end
 for _,p in ipairs(d.incoming) do local elapsed=d.pageTick-p.start;if not p.landed and elapsed>=0 then local q=math.min(1,elapsed/30);cell({c=p.c,k='blocked',n=5},353+p.col*18,-36+(p.target+36)*q*q) end end
 if d.active then local a=d.active;ball(a.colors[1],353+a.col*18,a.y);ball(a.colors[2],353+a.col*18,a.y+18) end
end
local function drawChain()
 local d=T.chainDemo
 if d.stage<1 then ball(0,371,272);ball(0,389,272);ball(0,371,d.y-18);spark(0,371,d.y) end
 if d.stage<2 then spark(1,389,d.blueY);ball(1,407,272) end
 if d.stage<3 then spark(2,407,d.greenY);ball(2,425,272) end
 dischargeFx(d.clears,24)
 if d.stage>=2 then glyphs('REACCION',375,92);glyphs('EN CADENA',371,106);glyphs('X'..d.stage..'!',395,124) end
 if d.chargeTick then local age=T.tick-d.chargeTick;if age<90 then img('TRANSITION_WHITE',353,2,{scale_x=108/480,scale_y=288/320,alpha=.18*(1-age/90)*(.6+.4*math.sin(age*.35))}) end end
end
local function drawSupercell()
 local d=T.supercellDemo;local frame=(T.tick//7.2)%6
 if not d.detonated then img('RAY_CORONA',386,math.floor(d.y+.5)-3,{frame=frame}) end
 for x,col in ipairs(d.grid) do for _,p in ipairs(col) do ball(p.c,353+(x-1)*18,p.y) end end
 if not d.detonated then
  ball(2,389,d.y-18);img('RAY',389,math.floor(d.y+.5),{frame=frame})
  if T.page==1 and d.hoverTick then img('RAY',389,math.floor(d.y+.5),{frame=frame,alpha=.15+.4*(.5+.5*math.sin((T.tick-d.hoverTick)*math.pi/40)),add=true}) end
 else local age=T.tick-d.clearTick;if age<30 then for _,p in ipairs(d.removed) do img('DISCHARGE',p.x-9,p.y-9,{frame=math.min(2,age//10),scale=.5}) end end end
end
local function drawText()
 local consumed=0
 for i,row in ipairs(T.lines) do
  local n=math.max(0,math.min(utf8.len(row),T.characters-consumed));local y=75+(i-1)*14
  if n>0 then
   local words={};for w in row:gmatch('%S+') do words[#words+1]=w end
   local total=0;for _,w in ipairs(words) do total=total+width(w) end
   local gap=#words>1 and (152-total)/(#words-1) or 999
   if i<#T.lines and #words>1 and gap<=10 then
    local used,offset=0,0
    for j,w in ipairs(words) do local letters=chars(w);local part={};for k=1,math.max(0,math.min(#letters,n-used)) do part[#part+1]=letters[k] end
     glyphs(table.concat(part),154+offset+math.floor((j-1)*gap),y);offset=offset+width(w);used=used+#letters+1
    end
   else local letters=chars(row);local part={};for k=1,n do part[#part+1]=letters[k] end;glyphs(table.concat(part),#T.lines==1 and math.floor(230-width(row)/2) or 154,y) end
  end
  consumed=consumed+utf8.len(row)+1
 end
end
function T.draw()
 img('PLASMA_BACKGROUND',0,0);img('TUT_HEADER_'..T.lesson,0,0)
 local blink=T.tick%180>=173;local cel=blink and 0 or not T.complete() and T.tick%24<11 and 2 or 1
 img('TUT_TESLA',-49,48,{frame=cel,scale_x=232/202,scale_y=283/246})
 img('TUT_PANEL',147,65,{scale_x=166,scale_y=T.height-14,alpha=.36})
 img('TUT_FRAME_'..T.height,140,58);drawText()
 img('WELL_GLASS',334,0,{alpha=.5});local warning=T.lesson==2 and T.page==4 or T.lesson==5 and T.page==3
 img('WELL_RED',334,0,{alpha=warning and .3+.5*(.5+.5*math.sin(T.tick*math.pi*2/48)) or .32})
 clip(334,0,146,320)
 if T.lesson==2 then
  for x,col in ipairs(T.grid) do for r,c in ipairs(col) do ball(c,353+(x-1)*18,272-(r-1)*18) end end
  local a=T.active;if a then local dx,dy=offsets(a.turn);local x=math.max(353-math.min(0,dx),math.min(443-math.max(0,dx),353+a.col*18));ball(a.colors[1],x,a.y);ball(a.colors[2],x+dx,a.y+dy) end
 elseif T.lesson==3 then drawSparks() elseif T.lesson==4 then drawCumulus() elseif T.lesson==5 then drawDischarge() elseif T.lesson==6 then drawChain() elseif T.lesson==7 then drawSupercell() end
 clip();img('TUT_COIL',334,0)
 if T.lesson==2 and T.page==1 and (T.tick//20)%2==0 then img('TUT_COIL',334,0,{alpha=.55,add=true}) end
 if T.overloaded then
  local color=T.tick%12<6 and 0x99eaff or 0xe465ff
  for _,x in ipairs({342,472}) do local px,py=x,3;for y=16,294,13 do local nx=x+(y+T.tick)%7-3;line(px,py,nx,y,color);px,py=nx,y end end
 end
end
return T
