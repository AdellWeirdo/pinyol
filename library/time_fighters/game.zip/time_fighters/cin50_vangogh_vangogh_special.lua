-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_vangogh_assets');local img=Assets.img;local imgsize=Assets.size
-- Presentation-only review. No puzzle state, random sequence or scoring changes.
local V={};local C=require('cin50_vangogh_roster');local Idle=require('cin50_vangogh_idle')
local starts={112,148,184,220}
local paint={0x164bc8,0xffd140,0x1dc6cd,0xf45242,0xffe99a}
local function hero(f)
 if f<60 then
  img('IDLE_VANGOGH',80-56*1.18,293-120*1.18,{frame=Idle.frame(f),scale=1.18});return
 end
 local phase
 if f<88 then phase=f<74 and 0 or 1
 elseif f<112 then phase=1
 elseif f<258 then
  local age=f-112
  for _,s in ipairs(starts)do if f>=s then age=f-s end end
  phase=age<5 and 1 or age<12 and 2 or age<19 and 3 or age<26 and 4 or age<31 and 5 or 0
 else phase=5 end
 img('VANGOGH_BRUSH',80-56*1.18,293-148*1.18,{frame=phase,scale=1.18})
end
local function droplets(f,start)
 local age=f-start;if age<0 or age>30 then return end
 for j=0,13 do
  local t=age/30;local x=384+(j%5-2)*age*.8;local y=220+(j//5-1)*age*.65+age*age*.027
  circ(x,y,math.max(1,4-age*.09),paint[j%5+1])
  if age<15 then circ(x-1,y-1,1,0xfff0aa)end
 end
end
local function shot(f,start,power)
 local age=f-start;if age<0 or age>41 then return end
 local p=age/41;local x=135+p*205;local y=224+math.sin(p*math.pi)*-3
 local grow=.48+.52*math.min(1,age/7)
 local scale=(power and 1.38 or 1.15)*grow
 -- Both sprites are thick animated paint, released at the brush tip, never above the hand.
 local fanScale=(power and 1.25 or 1.04)*grow
 if age<35 then img('PAINT_FAN',x-92*fanScale,y-54*fanScale,{frame=(age//3)%4,scale=fanScale,alpha=math.min(1,age/3)})end
 img('PAINT_COMET',x-100*scale,y-42*scale,{frame=(age//3)%4,scale=scale})
 for j=0,9 do
  local xx=x-30-j*9;local yy=y+math.sin(f*.5+j)* (12+(j%3)*4)
  local r=2+(j%3)*.7
  circ(xx,yy,r,paint[(j+1)%5+1]);circ(xx-1,yy-1,1,0xffe99a)
 end
end
local function rival(enemy,f)
 local scale=1.05;local x=392-(148-56)*scale;local y=293-120*scale
 if f<153 then img('IDLE_'..C[enemy].id,x,y,{frame=Idle.frame(f),flip_x=true,scale=scale})
 else
  local phase=f<189 and 0 or f<225 and 1 or f<261 and 2 or 3
  -- Same real character silhouette, progressively coated by persistent paint masks.
  local shake=f<270 and math.sin(f*1.5)*1.1 or math.sin(f*.12)*.6
  img('PAINTED_'..C[enemy].id,x+shake,y,{frame=phase,flip_x=true,scale=scale})
  if phase==3 then
   for j=0,5 do
    local age=(f*1.4+j*13)%35;local dx=365+j*9
    circ(dx,247+age,1.6,paint[j%5+1])
   end
  end
 end
end
function V.draw(f,enemy)
 img('STAGE_VANGOGH',0,0)
 if f>40 then img('SPECIAL_VANGOGH',0,0,{alpha=math.min(1,(f-40)/30)})end
 rival(enemy,f)
 for i,start in ipairs(starts)do shot(f,start,i==4);droplets(f,start+41)end
 hero(f)
end
return V
