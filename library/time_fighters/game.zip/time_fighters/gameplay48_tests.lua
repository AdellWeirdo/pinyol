local R=require('rules')
local T={maxGap=0,cells=0,sparks=0}
function T.stream(seed)
 local a,b=R.new(seed,1),R.new(seed,13)
 local gap,last,prev=0,nil,nil
 for pair=1,600 do
  local p=pair==1 and a.next or R.next(a)
  local q=pair==1 and b.next or R.next(b)
  local tokens={}
  for i=1,2 do
   assert(p[i].k==q[i].k and p[i].c==q[i].c,'shared sequence')
   tokens[i]=p[i].k..p[i].c;T.cells=T.cells+1
   if p[i].k=='spark' then
    assert(p[i].c~=last,'spark colour repeated');last=p[i].c;gap=0;T.sparks=T.sparks+1
   else gap=gap+1;T.maxGap=math.max(T.maxGap,gap);assert(gap<=15,'16 cells without a spark') end
  end
  local key=tokens[1]<tokens[2] and tokens[1]..tokens[2] or tokens[2]..tokens[1]
  assert(key~=prev,'repeated pair');prev=key
  assert((p[1].k=='ray')==(pair%25==0),'ray cadence')
 end
end
return T
