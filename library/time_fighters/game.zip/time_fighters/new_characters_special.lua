-- Faithful native port of the four approved review sequences. Simulation remains frozen outside this module.
local C=require('roster');local S={}
local function picture(id,x,y,f,scale,alpha,flip)img(id,x,y,{frame=f or 0,scale=scale or 1,alpha=alpha or 1,flip_x=flip or false})end
local function actor(id,cx,f,scale,flip)
 local w=imgsize(id);local pivot=w==192 and 96 or 56
 picture(id,cx-(flip and w-pivot or pivot)*scale,293-120*scale,f,scale,1,flip)
end
function S.draw(who,f,rival,side)
 local id=C[who].id;local rid=C[rival].id
 if side==2 then canvas('CINEMA',480,320);target('CINEMA')end
 img('SPECIAL_BG_'..id,0,0)
 if f<265 then actor((f<133 and'IDLE_'or'FIGHTER_')..rid,396,f<133 and (f//12)%6 or 12+(f//8)%6,1.05,true)
 else actor('KNOCKDOWN_'..rid,396,math.min(5,(f-265)//8),1.05,true)end
 if id=='SHAKESPEARE'then
  if f>=42 and f<285 then local emerge=math.min(1,(f-42)/35);local travel=math.max(0,math.min(1,(f-77)/57));local z=.3+emerge*.95;local cx=125+travel*242;picture('YORICK_SHAKESPEARE',cx-80*z,192-80*z,(f//7)%6,z,f>260 and(285-f)/25 or 1)end
 elseif id=='AUDREY'then
  if f>=42 and f<90 then local z=.15+math.min(1,(f-42)/30)*.95;picture('DIAMOND_AUDREY',58-80*z,160-80*z,(f//6)%6,z,math.min(1,(f-42)/8))end
  for j=0,2 do local p=(f-(80+j*35))/53;if p>=0 and p<=1 then picture('DIAMOND_AUDREY',100+p*285-62,170-62-math.sin(p*math.pi)*12,(f//5+j)%6,.78)end end
 elseif id=='HITCHCOCK'then
  if f>=58 and f<264 then local p=math.max(0,math.min(1,(f-76)/90));local cx=-45+p*445;local a=f<76 and(f-58)/18 or f>245 and(264-f)/19 or 1;picture('NORMAN_HITCHCOCK',cx-56*1.18,293-120*1.18,((f-58)//7)%6,1.18,a)end
 elseif id=='JANIS'then
  for j=0,2 do local p=(f-(80+j*35))/53;if p>=0 and p<=1 then local z=.1+.68*math.min(1,p/.24);picture('HEART_JANIS',90+p*295-122*z,220-math.sin(p*math.pi)*10-80*z,(f//5+j)%6,z,math.min(1,p*20+.2))end end
 end
 actor((f<42 and'IDLE_'or'CAST_')..id,78,f<42 and(f//15)%6 or math.min(5,1+((f-42)//12)%5),1.18,false)
 local start=id=='HITCHCOCK'and 151 or 133
 if f>=start and f<299 then local a=f>276 and(299-f)/23 or math.min(1,(f-start)/4);for j=0,5 do picture('DUST_'..id,279+(j%2)*47,95+(j//2)*63,((f-start)//7+j)%6,1.2,a)end end
 if side==2 then target();img('CINEMA',0,0,{flip_x=true})end
 if f>=8 and f<106 then local w=imgsize('TITLE_'..id);local a=f<84 and math.min(1,(f-8)/8)or(106-f)/22;picture('TITLE_'..id,(480-w)/2,7,0,1,a)end
end
return S
