local H=require('records')
local function reader(t) return function(k,d) if t[k]~=nil then return t[k] end;return d end end
return function()
 H.load(reader({}));assert(#H.rows==0 and H.rank(0)==1)
 H.begin('CERVANTES',3);H.add(100);H.add(200);assert(H.run.score==300)
 assert(H.finish(false) and not H.finish(false));H.add(900);assert(H.pending.score==300)
 H.letters={2,3,4};local data={};local writes=0
 local function write(k,v)data[k]=v;writes=writes+1 end
 assert(H.save(write)==1 and not H.save(write) and writes==1,'duplicate record')
 assert(H.rows[1].initials=='BCD' and H.rows[1].score==300)
 H.load(reader(data));assert(H.rows[1].score==300 and H.rows[1].character=='CERVANTES' and H.rows[1].difficulty==3)
 for i=1,15 do H.begin('CURIE',i%5+1);H.add(i*1000);assert(H.finish(i%2==0));H.save(write) end
 assert(#H.rows==10 and H.rows[1].score==15000 and H.rows[10].score==6000)
 H.begin('CHAPLIN',1);H.add(6000);assert(not H.finish(false),'tie displaced older last place')
 H.begin('CHAPLIN',1);H.add(6001);assert(H.finish(false) and H.pending.rank==10);H.save(write)
 H.begin('FRIDA',5);H.add(15000);assert(H.finish(true) and H.pending.rank==2,'equal scores not stable');H.save(write)
 assert(H.rows[1].character=='CURIE' and H.rows[2].character=='FRIDA' and #H.rows==10)
 H.load(reader(data));for i=2,#H.rows do assert(H.rows[i-1].score>=H.rows[i].score) end
 H.begin('MARY',2);H.add(123456789);assert(H.finish(true));H.save(write)
 assert(data[H.KEY][1].score=='123456789','score precision lost in storage')
 H.load(reader(data));assert(H.format(H.rows[1].score)=='123.456.789')
 H.load(reader({[H.KEY]={{initials='BAD!',score=99,character='CURIE'},{initials='AAA',score='broken',character='CURIE'},false,{initials='BBB',score=5,character='INVALID'}}}))
 assert(#H.rows==1 and H.rows[1].score==0,'malformed save handling')
 H.begin('CURIE',3);H.finish(false);H.change(-1);assert(H.name()=='ZAA');H.change(1);assert(H.name()=='AAA')
 H.cursor=3;H.change(25);assert(H.name()=='AAZ')
 print('RECORDS: accumulation, one-time finish/save, top10 replacement, stable ties, large-score persistence, initial wrapping PASS')
 return true
end
