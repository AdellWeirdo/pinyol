-- Campaign totals survive matches and continues; reset only on a new Arcade run.
local C={lostRounds=0,continues=0}
function C.begin() C.lostRounds=0;C.continues=0 end
function C.round(winner) if winner==2 then C.lostRounds=C.lostRounds+1 end end
function C.continue_used() C.continues=C.continues+1 end
return C
