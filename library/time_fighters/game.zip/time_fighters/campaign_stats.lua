-- Campaign totals survive matches and continues; reset only on a new Arcade run.
local C={lostRounds=0,continues=0}
function C.begin() C.lostRounds=0;C.continues=0;C.matchCommitted=false;C.bonusAwarded=false end
function C.match_begin() C.matchCommitted=false end
function C.commit(won,points,final)
 if C.matchCommitted then return 0 end;C.matchCommitted=true
 if not won then return 0 end
 local award=math.max(0,math.floor(points or 0))
 if final and C.continues==0 and not C.bonusAwarded then award=award+100000;C.bonusAwarded=true end
 return award
end
function C.round(winner) if winner==2 then C.lostRounds=C.lostRounds+1 end end
function C.continue_used() C.continues=C.continues+1 end
return C
