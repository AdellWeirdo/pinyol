-- Browser host supplies a separate volatile P2 mask through the documented file API.
-- No persistent saves, engine changes or shared P1 buttons are used.
local I={held=0,previous=0,ages={}}
local bits={up=1,down=2,left=4,right=8,a=16,b=32,start=64}
function I.update()
 I.previous=I.held;I.held=tonumber(file('assets/local_input.txt')) or 0
 for name,bit in pairs(bits) do I.ages[name]=(I.held&bit)~=0 and (I.ages[name] or 0)+1 or 0 end
end
function I.down(name) return (I.held&(bits[name] or 0))~=0 end
function I.pressed(name,hold,every)
 local bit=bits[name] or 0;local age=I.ages[name] or 0
 return I.down(name) and ((I.previous&bit)==0 or (hold and age>hold and (age-1-hold)%(every or hold)==0)) or false
end
function I.puzzle() return {left=I.pressed('left',12,4),right=I.pressed('right',12,4),down=I.down('down'),cw=I.pressed('a'),ccw=I.pressed('b')} end
return I
