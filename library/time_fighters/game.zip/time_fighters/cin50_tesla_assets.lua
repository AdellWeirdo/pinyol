local map={}
local S={}
function S.img(id,x,y,o)
 if id=='IDLE_CERVANTES'or id=='IDLE_FRIDA'or id=='IDLE_KUROSAWA'or id=='IDLE_TESLA'or id=='IDLE_MARILYN'then return img(id,x,y,o)end
 if id=='IDLE_KAFKA' or id=='FIGHTER_KAFKA' then
  o=o or {};x=x+(o.flip_x and 18 or -18)*(o.scale or 1)
 end
 return img(map[id] or id,x,y,o)
end
function S.size(id) return imgsize(map[id] or id) end
return S
