require('sprite_banks').install()
local UI=require('ui_style')
local text,textw=UI.text,UI.width
local R=require('rules')
local Sequence=require('sequence')
local AI=require('cpu')
local L=require('layout')
local E=require('electricity')
local Arcade=require('arcade')
local SP=require('special_policy')
local NewSpecials=require('new_specials')
local Approved=require('cinema_approved')
local Andromina=require('andromina_frames')
local Pose=require('pose_bounds')
local Idle=require('idle')
local Report=require('result_report')
local C=require('roster')
local Options=require('options')
local Select=require('character_select')
local SelectionBounds=require('selection_bounds')
local ResultBounds=require('result_bounds')
local TitleScreen=require('title_screen')
local Local=require('local_input')
local Boot=require('boot_frames')
local Soundtrack=require('soundtrack')
local Gallery=require('gallery')
local Records=require('records')
local EndScreens=require('end_screens')
local FinalScreens=require('final_screens')
local Campaign=require('campaign_stats')
local recordExit='records'
local Tutorial=require('tutorial_approved')
local Secret=require('secret_character')
local Notice=require('gameplay_notices')
local MusicTitles=require('music_titles')
local StageCues=require('stage_music')
mode='arcade';pick2=2;ready={false,false}
local PLAYABLE=12
local MENU_ITEMS={'ARCADE','VERSUS','OPCIONES','TUTORIAL','RECORDS'}
local Knockdown=require('knockdown')
local CLIPS={entrada={18,19,20,21},reposo={0,1,2,3,4,5},peligro={0,1,2,3,4,5},
 ataque_ligero={22,23,24,25},ataque_medio={6,7,8,9,10,11},ataque_fuerte={26,27,28,29},
 especial={26,27,28,29},defensa={30,31,32,33},impacto_leve={12,13,16,17},
 impacto_fuerte={12,13,14,15,16,17},recuperacion={16,17,0},victoria={34,35,36,37},derrota={38,39,40,41}}
local sounds={
 MOVE={wave='square',freq=400,sustain=.015,decay=.04,volume=.12},
 ROTATE={wave='triangle',freq=720,slide=1400,sustain=.02,decay=.05,volume=.18},
 LOCK={wave='noise',freq=300,sustain=.015,decay=.06,lowpass=.3,volume=.2},
 SELECT={wave='square',freq=900,arp=1.5,arp_time=.035,sustain=.04,decay=.05,volume=.18},
 CONFIRM={wave='saw',freq=300,slide=1200,sustain=.07,decay=.15,volume=.18},
 FUSE={wave='sine',freq=220,slide=800,sustain=.08,decay=.17,volume=.2},
 RAY={wave='noise',freq=1500,slide=-2200,sustain=.12,decay=.25,highpass=.3,volume=.28},
 HIT={wave='noise',freq=120,slide=-200,sustain=.04,decay=.12,punch=.4,volume=.28},
 ROUND={wave='triangle',freq=380,slide=550,sustain=.12,decay=.2,volume=.22},
 KO={wave='noise',freq=100,slide=-160,sustain=.14,decay=.6,punch=.4,volume=.32},
 CANNON={wave='noise',freq=70,slide=-80,sustain=.16,decay=.5,lowpass=.45,punch=.5,volume=.4},
 WATER={wave='noise',freq=460,slide=-230,sustain=.25,decay=.65,lowpass=.45,volume=.32},
 SPECIAL={wave='saw',freq=240,slide=2600,arp=1.5,arp_time=.12,sustain=.18,decay=.25,volume=.26},
 CORGI={wave='square',freq=390,slide=-1200,sustain=.035,decay=.10,volume=.14},
 BOOT_ZAP={wave='noise',freq=1800,slide=-3800,sustain=.025,decay=.18,highpass=.3,volume=.22},
 BOOT_CLING={wave='sine',freq=2200,arp=1.5,arp_time=.025,sustain=.025,decay=.65,volume=.17},
 BOOT_SHINE={wave='triangle',freq=3300,sustain=.015,decay=.42,volume=.07},
 QUILL={wave='noise',freq=1400,slide=-900,sustain=.035,decay=.11,highpass=.55,volume=.14},
 PAGES={wave='noise',freq=680,slide=450,sustain=.03,decay=.13,highpass=.3,volume=.12},
 GALLOP={wave='noise',freq=95,slide=-50,sustain=.02,decay=.08,lowpass=.25,volume=.16},
 BELL={wave='sine',freq=780,arp=2,arp_time=.03,sustain=.06,decay=1,volume=.18}
}
state,pick,round,wins,boards='boot',1,1,{0,0},{}
timer,simTicks,matchSeed=0,0,0
difficulty=AI.default
opponent=2;arcadeRoute={};arcadeIndex=1;arcadeBase=AI.default;arcadeComplete=false;arcadeScore=0;matchScore=0
matchReport=Report.new();local secondReport=Report.new();local secondScore=0
local visual=0;local actors={};local transfers={};local messages={};local fx={};local notices={}
local firstHit=false;local pause=false;local pauseChoice=1;local resultWinner=1;local stage=1;local sphere=0
local special=nil;local specials={};local pendingRoundWinner=nil
settings={difficulty=AI.default,music=10,effects=10};menuChoice=1;optionChoice=1
ruleset='classic';rulesChoice=1
local engineSfx=sfx
function sfx(id,gain,opts) return engineSfx(id,Options.effect_gain(settings,gain),opts) end
local function snd(id,gain)
 if id=='MENU_BACK' then id='CONFIRM'
 elseif id=='CONFIRM' and (state=='menu' or state=='rules_select' or state=='options' or state=='records' or state=='record_entry' or state=='gallery') then id='TITLE_START' end
 sfx(id,gain or 1)
end
local lastLandingFrame=-1
local function landing_sound(side)
 if lastLandingFrame~=visual then snd('LOCK',(side==1 or mode=='versus') and .6 or .3);lastLandingFrame=visual end
end
local voiceHandle=nil
local function announce(id)
 if voiceHandle then sfx_stop(voiceHandle) end
 voiceHandle=sfx('VOICE_'..id,.9)
end
-- Give the recorded phrases room to finish before releasing the puzzle.
local INTRO_CALL,INTRO_END=126,230
local function text_at(s,x,y,scale,color,align)
 text(s,x,y,{font='arcade',scale=scale or 1,color=color or 0xffe7a1,gradient=scale and scale>1 and 0xe78332 or nil,
  outline=0x081126,shadow=0x030712,align=align or 'center'})
end
local function small(s,x,y,color,align) text(s,x,y,{font='arcade',color=color or 0xcbdfff,outline=0x081126,align=align or 'center'}) end
local function tiny(s,x,y,color,align) text(s,x,y,{font='arcade',color=color or 0xffebbc,outline=0x081126,align=align or 'center'}) end
local menuMusic=false
local function go(s)
 if s=='result' and mode=='arcade' and resultWinner==1 and wins[1]>=2 and opponent==Secret.BOSS and #arcadeRoute>0 and arcadeIndex==#arcadeRoute then Soundtrack.begin_finale() end
 menuMusic=s=='title' or s=='menu' or s=='rules_select' or s=='options' or s=='select' or s=='records' or s=='record_entry' or s=='tutorial' or s=='unlock' or s=='gallery'
 if s=='select' then Select.reset(visual);ready={false,false} end
 if s=='continue' then EndScreens.enter() end
 state=s;timer=0;Soundtrack.sync(s,stage,settings.music)
end
local function finish_arcade_records(completed)
 difficulty=arcadeBase;arcadeRoute={};ready={false,false}
 recordExit='gameover'
 if Records.finish(completed) then go('record_entry') else go('gameover') end
end
local function message(s,side,colour,life)
 messages[#messages+1]={text=s,side=side,color=colour or 0xffdf74,life=Notice.life(life),age=0}
 if #messages>5 then table.remove(messages,1) end
end
local function act(side,clip,duration)
 local a=actors[side];if not a then return end
 a.clip=clip;a.t=0;a.duration=duration or 40
end
local function coord(side,x,y) return L.cell_at(side,x,y) end
local function stage_id() return 'STAGE_'..C[stage].id end
local roundSeeds={}
local function start_round()
 -- Advance and persist at every round, including retries and new opponents.
 matchSeed=Sequence.next(stored('piece_sequence_seed',Sequence.DEFAULT),ticks())
 while roundSeeds[matchSeed] do matchSeed=Sequence.next(matchSeed,0) end
 roundSeeds[matchSeed]=true
 store('piece_sequence_seed',tostring(matchSeed))
 local sharedSeed=matchSeed
 boards={R.new(sharedSeed,pick,ruleset),R.new(sharedSeed,opponent,ruleset)}
 actors={{who=pick,clip='entrada',t=0,duration=72},{who=opponent,clip='entrada',t=0,duration=72}}
 transfers={};messages={};fx={};notices={};firstHit=false;specials={};special=nil;pendingRoundWinner=nil;sphere=0;pause=false
 go('intro');announce(round>=3 and 'ROUND_FINAL' or 'ROUND_'..round)
end
function start_match()
 if mode=='versus' then opponent=pick2 elseif #arcadeRoute==0 then opponent=pick==1 and 2 or 1 end
 wins={0,0};round=1;stage=opponent;simTicks=0;matchScore=0;matchReport=Report.new();secondReport=Report.new();secondScore=0;start_round()
end
function start_arcade()
 local routeSeed=Sequence.next(stored('arcade_route_seed',731),ticks());store('arcade_route_seed',tostring(routeSeed))
 local history=stored('arcade_opponent_counts_v1',{});if type(history)~='table' then history={} end
 local appearances={};for i,c in ipairs(C)do appearances[i]=math.max(0,tonumber(history[c.id]) or 0)end
 arcadeRoute=Arcade.route(pick,#C,routeSeed,Secret.BOSS,stored('arcade_previous_first',0),Secret.candidates(),10,appearances)
 for _,who in ipairs(arcadeRoute)do if who~=Secret.BOSS then history[C[who].id]=tostring(appearances[who]+1)end end
 store('arcade_opponent_counts_v1',history)
 store('arcade_previous_first',tostring(arcadeRoute[1]))
 arcadeIndex=1;arcadeBase=difficulty;arcadeComplete=false;arcadeScore=0;Campaign.begin()
 Records.begin(C[pick].id,arcadeBase)
 opponent=arcadeRoute[arcadeIndex];difficulty=Arcade.level(arcadeBase,arcadeIndex,#arcadeRoute);go('versus')
end
local function route(side,x,y,q)
 local rail=L.boards[side].inner
 if q<.65 then return x+(rail-x)*q/.65,y+(50-y)*q/.65 end
 return rail+(239-rail)*(q-.65)/.35,50
end
local function burst(side,e)
 local limit=math.min(20,#e.cells)
 for i=1,limit do local c=e.cells[i];local x,y=coord(side,c.x,c.y)
  transfers[#transfers+1]={side=side,x=x+9,y=y+9,c=c.v.c,age=-i%4,life=44}
 end
 if #transfers>64 then for i=#transfers,65,-1 do table.remove(transfers,i) end end
end
local function process(side)
 local b=boards[side]
 for _,e in ipairs(b.events) do
  if e.kind=='lock' then SP.reset(b);if side==1 or mode=='versus' then landing_sound(side) end
  elseif e.kind=='land' then landing_sound(side)
  elseif e.kind=='fusion' then snd('FUSE',.5)
  elseif e.kind=='release' then notices[#notices+1]={side=side,x=e.x,y=e.y,t=20,c=e.c}
  elseif e.kind=='clear' then
   if side==1 then Report.clear(matchReport,e.chain) else Report.clear(secondReport,e.chain) end
   burst(side,e);local gain=(side==1 or mode=='versus') and .8 or .45
   snd('PLASMA_CLEAR',gain)
   if e.chain>1 then message('REACCION EN CADENA x'..e.chain..'!',side,0x86edff)
   elseif e.count>=4 then message('DESCARGA '..e.count..'!',side) end
   if not firstHit and e.power>0 then firstHit=true;message('¡PRIMER GOLPE!',side,0xffffff) end
  elseif e.kind=='tech' then message('BONO TÉCNICO!',side,0xe5abff)
  elseif e.kind=='allclear' then message('¡BOBINA VACÍA!',side,0x8bffba)
  elseif e.kind=='cancel' then act(side,'defensa',32);snd('RAY',.5);message('CONTRAATAQUE!',side,0x8bffba)
  elseif e.kind=='chain' then
   message('BONO CADENA +'..e.bonus,side,0xffe497)
  elseif e.kind=='cascade' then
   local reason=SP.cascade(b,e.chain)
   if reason and SP.claim(b,b.turn) then specials[#specials+1]={side=side,who=b.character,chain=e.chain,reason=reason} end
  elseif e.kind=='attack' then
   if side==1 then Report.attack(matchReport,e.n) else Report.attack(secondReport,e.n) end
   local target=boards[3-side];R.incoming(target,e.n,b.character);SP.sent(b,e.n)
   if e.n>=SP.FINISHER then target.pending[#target.pending].specialAttack={side=side,turn=b.turn,n=e.n} end
   local clip=e.n>=14 and 'ataque_fuerte' or e.n>=6 and 'ataque_medio' or 'ataque_ligero'
   act(side,clip,46);act(3-side,e.n>=14 and 'impacto_fuerte' or 'impacto_leve',42)
   fx[#fx+1]={kind='send',side=side,age=0,n=e.n}
  elseif e.kind=='receive' then
   snd('BLOCK_RECEIVE',.75);fx[#fx+1]={kind='receive',side=side,age=0,cells=e.cells};act(side,'impacto_fuerte',42)
  end
 end
 b.events={}
end
local function begin_special(s)
 special=s;special.t=-12;go('special');snd('CINEMA_'..C[s.who].id);act(s.side,'especial',360)
end
function preview_special(side) begin_special({side=side or 1,who=boards[side or 1].character,n=24}) end
local function finish_round(winner)
 matchScore=matchScore+boards[1].score;secondScore=secondScore+boards[2].score
 if mode=='arcade' then arcadeScore=Records.add(boards[1].score);Campaign.round(winner) end
 resultWinner=winner;wins[winner]=wins[winner]+1;act(winner,'victoria',99999);act(3-winner,'derrota',99999)
 if mode=='arcade' and winner==1 and wins[1]>=2 and #arcadeRoute>0 and arcadeIndex==#arcadeRoute and opponent==Secret.BOSS then Gallery.unlock(C[pick].id,store);Secret.complete(store) end
 go('ko');announce('KO');store('best',math.max(stored('best',0),boards[1].score))
end
function _init()
 show(0);backdrop(0x060b18);music();Soundtrack.reset();menuMusic=false
 for name,recipe in pairs(sounds) do sound(name,recipe) end
 Gallery.load(stored);Secret.load(stored);Records.load(stored);settings=Options.load(stored);menuChoice=1;optionChoice=1;mode='arcade';pick2=2;ready={false,false}
 state='andromina';timer=0;visual=0;snd('ANDROMINA');pick=1;difficulty=settings.difficulty;arcadeRoute={};arcadeIndex=1;arcadeComplete=false;arcadeScore=0
end
function _update()
 Local.update()
 visual=visual+1;timer=timer+1;sphere=math.max(0,sphere-1)
 for i=#messages,1,-1 do local m=messages[i];m.age=m.age+1;if m.age>m.life then table.remove(messages,i) end end
 for i=#transfers,1,-1 do local e=transfers[i];e.age=e.age+1;if e.age==35 then sphere=24 end;if e.age>e.life then table.remove(transfers,i) end end
 for i=#fx,1,-1 do local e=fx[i];e.age=e.age+1;if e.age>44 then table.remove(fx,i) end end
 for i=#notices,1,-1 do notices[i].t=notices[i].t-1;if notices[i].t<0 then table.remove(notices,i) end end
 for _,a in ipairs(actors) do a.t=a.t+1;if a.t>a.duration and a.clip~='reposo' and a.clip~='victoria' and a.clip~='derrota' then a.clip='reposo';a.t=0 end end
 if state=='andromina' then
  if timer>=#Andromina then go('boot') end
 elseif state=='boot' then
  if timer==16 then snd('BOOT_ZAP') end
  if timer==30 then snd('BOOT_CLING');snd('BOOT_SHINE') end
  if timer>=150 or btnp('start') or btnp('a') then go('title') end
 elseif state=='title' then if btnp('start') or btnp('a') then menuChoice=1;go('menu');snd('TITLE_START') end
 elseif state=='menu' then
  if btnp('up') then menuChoice=(menuChoice-2)%#MENU_ITEMS+1;snd('SELECT') end
  if btnp('down') then menuChoice=menuChoice%#MENU_ITEMS+1;snd('SELECT') end
  if btnp('b') then go('title') elseif btnp('start') or btnp('a') then
   if menuChoice<3 then
    mode=menuChoice==1 and 'arcade' or 'versus';difficulty=settings.difficulty
 arcadeRoute={};ready={false,false};rulesChoice=1;go('rules_select')
   elseif menuChoice==3 then optionChoice=1;go('options')
   elseif menuChoice==4 then Tutorial.enter();go('tutorial')
   elseif menuChoice==5 then Records.highlight=nil;Records.lastResult=nil;go('records')
   end;snd('CONFIRM')
  end
 elseif state=='rules_select' then
  if btnp('up') or btnp('down') then rulesChoice=3-rulesChoice;snd('SELECT') end
  if btnp('b') then go('menu');snd('SELECT')
  elseif btnp('a') or btnp('start') then
   ruleset=rulesChoice==1 and 'ultimate' or 'classic';go('select');snd('TITLE_START')
  end
 elseif state=='records' then
  if btnp('a') or btnp('start') or btnp('b') then menuChoice=#MENU_ITEMS;go('menu');snd('MENU_BACK') end
 elseif state=='record_entry' then
  if btnp('up',15,5) then Records.change(1);snd('SELECT') end
  if btnp('down',15,5) then Records.change(-1);snd('SELECT') end
  if btnp('left') or btnp('b') then Records.cursor=math.max(1,Records.cursor-1);snd('SELECT') end
  if btnp('right') then Records.cursor=math.min(3,Records.cursor+1);snd('SELECT') end
  local confirm=timer>12 and btnp('start')
  if timer>12 and btnp('a') then
   if Records.cursor<3 then Records.cursor=Records.cursor+1;snd('CONFIRM') else confirm=true end
  end
  if confirm then Records.save(store);go(recordExit);recordExit='records';snd('CONFIRM') end
 elseif state=='options' then
  if btnp('up') then optionChoice=(optionChoice-2)%4+1;snd('SELECT') end
  if btnp('down') then optionChoice=optionChoice%4+1;snd('SELECT') end
  local delta=btnp('left') and -1 or btnp('right') and 1 or 0
  if delta~=0 and Options.adjust(settings,optionChoice,delta) then
   difficulty=settings.difficulty;Options.save(settings,store)
   if menuMusic then music_layer(0,settings.music/10,80) end;snd('SELECT')
  end
  if btnp('b') or (optionChoice==4 and (btnp('a') or btnp('start'))) then go('menu');snd('MENU_BACK') end
 elseif state=='gallery' then
  if btnp('b') then
   if Gallery.zoom then Gallery.zoom=false else Gallery.playing=false;go('menu') end
  elseif not Gallery.zoom then
   local change=false
   if btnp('up',15,5) then Gallery.selected=(Gallery.selected-2)%#C+1;change=true end
   if btnp('down',15,5) then Gallery.selected=Gallery.selected%#C+1;change=true end
   if btnp('left') then Gallery.tab=(Gallery.tab-2)%3+1;change=true end
   if btnp('right') then Gallery.tab=Gallery.tab%3+1;change=true end
   if change then Gallery.playing=false;Soundtrack.sync('gallery',1,settings.music);snd('SELECT') end
   if (btnp('a') or btnp('start')) and Gallery.is_open(C[Gallery.selected].id) then
    if Gallery.tab==3 then
     Gallery.playing=not Gallery.playing
     if Gallery.playing then Soundtrack.preview(StageCues[Gallery.selected],settings.music) else Soundtrack.sync('gallery',1,settings.music) end
    else Gallery.zoom=true end;snd('CONFIRM')
   end
  elseif Gallery.tab==1 and (btnp('left') or btnp('right')) then Gallery.page=Gallery.page%2+1;snd('SELECT')
  elseif btnp('a') or btnp('start') then Gallery.zoom=false end
 elseif state=='tutorial' then
  if btnp('b') then go('menu')
  elseif btnp('a') then
   if Tutorial.confirm() then go('menu');snd('CONFIRM') end
  end
  if state=='tutorial' then Tutorial.update(snd) end
 elseif state=='continue' then
  local nextState,event=EndScreens.update(timer,btnp('a') or btnp('start'),btnp('b'))
  if event=='fall' then snd('KO',.5) elseif event=='victory' then snd('CHARACTER_CLING',.75) elseif event=='tick' then snd('SELECT',.35) end
  if nextState=='continue' then Campaign.continue_used();start_match() elseif nextState=='finish' then finish_arcade_records(false) end
 elseif state=='gameover' then
  if timer>12 and (btnp('a') or btnp('start') or btnp('b')) then go('title') end
 elseif state=='select' then
  if not ready[1] then
   for _,direction in ipairs({'left','right','up','down'}) do
    if btnp(direction) then pick=Select.navigate(pick,direction,mode);snd('SELECT') end
   end
  end
  if mode=='versus' then
   if not ready[2] then
    for _,direction in ipairs({'left','right','up','down'}) do
     if Local.pressed(direction) then pick2=Select.navigate(pick2,direction,mode);snd('SELECT') end
    end
    if Local.pressed('a') or Local.pressed('start') then
     pick2=Select.confirm(pick2,2,visual);ready[2]=true;snd('CHARACTER_CLING',.75)
    end
   end
   if Local.pressed('b') then pick2=Select.cancel(2,pick2);ready[2]=false end
  end
  if btnp('b') then
   if ready[1] then pick=Select.cancel(1,pick);ready[1]=false else go('menu') end
  elseif (btnp('start') or btnp('a')) and not ready[1] then
   pick=Select.confirm(pick,1,visual);ready[1]=true;snd('CHARACTER_CLING',.75)
  end
  if mode=='arcade' and ready[1] and visual-Select.confirmed[1]>=Select.confirmTicks then
   start_arcade()
  elseif mode=='versus' and ready[1] and ready[2] then
   opponent=pick2;arcadeRoute={};go('versus')
  end
 elseif state=='versus' then if timer>120 or ((btnp('a') or btnp('start') or (mode=='versus' and (Local.pressed('a') or Local.pressed('start')))) and timer>20) then start_match() end
 elseif state=='intro' then
  if timer==INTRO_CALL then announce('START') end
  if timer>INTRO_END then go('play') end
 elseif state=='play' then
  if pause then
   if btnp('up') or btnp('down') or (mode=='versus' and (Local.pressed('up') or Local.pressed('down'))) then pauseChoice=3-pauseChoice;snd('SELECT',.5) end
   if btnp('b') then pause=false;snd('SELECT',.5)
   elseif btnp('a') or btnp('start') or (mode=='versus' and (Local.pressed('a') or Local.pressed('start'))) then
    pause=false;snd('TITLE_START',.5)
    if pauseChoice==2 then difficulty=arcadeBase;arcadeRoute={};ready={false,false};menuChoice=1;go('menu') end
   end
   return
  end
  if btnp('start') or (mode=='versus' and Local.pressed('start')) then pause=true;pauseChoice=1;snd('SELECT',.5);return end
  simTicks=simTicks+1
  local input={left=btnp('left',12,4),right=btnp('right',12,4),down=btn('down'),cw=btnp('a') or btnp('c'),ccw=btnp('b')}
  if input.left or input.right then snd('MOVE',.4) end;if input.cw or input.ccw then snd('ROTATE',.7) end
  local input2=mode=='versus' and Local.puzzle() or AI.input(boards[2],difficulty)
  if mode=='versus' then
   if input2.left or input2.right then snd('MOVE',.4) end
   if input2.cw or input2.ccw then snd('ROTATE',.7) end
  end
  R.step(boards[1],input);R.step(boards[2],input2);process(1);process(2)
  if mode=='versus' and boards[1].dead and boards[2].dead then
   go('draw');announce('KO');act(1,'derrota',99999);act(2,'derrota',99999)
  elseif boards[1].dead or boards[2].dead then
   local winner=boards[2].dead and 1 or 2;local candidate=boards[3-winner].receivedSpecial
   if candidate and candidate.side==winner and SP.claim(boards[winner],candidate.turn) then
    specials[#specials+1]={side=winner,who=boards[winner].character,reason='finisher'}
   end
   local chosen;for _,s in ipairs(specials) do if s.side==winner then chosen=s;break end end
   specials={}
   if chosen then pendingRoundWinner=winner;begin_special(chosen) else finish_round(winner) end
  elseif #specials>0 then begin_special(table.remove(specials,1)) end
 elseif state=='special_return' then
  if timer>=12 then
   go('play');for _,a in ipairs(actors) do a.clip='reposo';a.t=0 end
   if pendingRoundWinner then local winner=pendingRoundWinner;pendingRoundWinner=nil;specials={};finish_round(winner)
   elseif #specials>0 then begin_special(table.remove(specials,1)) end
  end
 elseif state=='special' then
  special.t=special.t+1
  local f=special.t
  if f>=NewSpecials.duration then
   special=nil;go('special_return');for _,a in ipairs(actors) do a.clip='reposo';a.t=0 end
  end
 elseif state=='draw' then
  if timer>150 then start_round() end
 elseif state=='ko' then
  if timer>150 then if wins[1]>=2 or wins[2]>=2 then go('result');announce(resultWinner==1 and 'WIN' or 'LOSE') else round=round+1;start_round() end end
 elseif state=='result' then
  local confirm=btnp('start') or btnp('a') or btnp('b') or (mode=='versus' and (Local.pressed('a') or Local.pressed('start') or Local.pressed('b')))
  if timer>30 and confirm then
   if mode=='arcade' and resultWinner==1 and #arcadeRoute>0 then
    local nextIndex,done=Arcade.advance(arcadeIndex,#arcadeRoute,true)
    if done then arcadeComplete=true;go(Secret.pending and 'unlock' or 'ending')
    elseif btnp('b') then Soundtrack.stop();difficulty=arcadeBase;arcadeRoute={};ready={false,false};go('select')
    else Soundtrack.stop();arcadeIndex=nextIndex;opponent=arcadeRoute[arcadeIndex];difficulty=Arcade.level(arcadeBase,arcadeIndex,#arcadeRoute);go('versus');snd('CONFIRM') end
   elseif mode=='arcade' then
    Soundtrack.stop();if btnp('b') then finish_arcade_records(false)else go('continue')end
   elseif btnp('b') or Local.pressed('b') then Soundtrack.stop();go('select');ready={false,false}
   else Soundtrack.stop();start_match() end
  end
 elseif state=='unlock' then
  if timer>30 and (btnp('start') or btnp('a') or btnp('b')) then Secret.pending=false;go('ending');snd('CONFIRM') end
 elseif state=='ending' then
  if timer>45 and (btnp('start') or btnp('a') or btnp('b')) then finish_arcade_records(true) end
 end
end
local function lightning(ax,ay,bx,by,strength,colour,core,thickness)
 local lastx,lasty=ax,ay
 for i=1,8 do local p=i/8;local offset=i==8 and 0 or math.sin(i*3.7+visual*.7)*strength
  local x=ax+(bx-ax)*p+offset;local y=ay+(by-ay)*p-offset
  if thickness then
   for dx=-thickness,thickness do line(lastx+dx,lasty,x+dx,y,colour or 0x3c92ed) end
   for dx=-1,1 do line(lastx+dx,lasty,x+dx,y,core or 0xe5fbff) end
  else line(lastx,lasty,x,y,colour or 0x3c92ed);line(lastx+1,lasty,x+1,y,core or 0xe5fbff) end
  lastx,lasty=x,y
 end
end
local function portrait(who,x,y,flip,kind)
 -- Every portrait source faces right; side alone determines mirroring.
 img((kind or 'PORTRAIT_')..C[who].id,x,y,{flip_x=flip})
end
local function fighter(side,override,x,y,size)
 local a=actors[side] or {who=side==1 and pick or opponent,clip='reposo',t=visual}
 if not override and a.clip=='reposo' and boards[side] then
  if L.overload(boards[side])>0 then override='peligro' end
 end
 if (override or a.clip)=='derrota' then
  local scale=size or .9;local px=x or (side==1 and L.actors.left or L.actors.right);local py=y or L.actors.floor
  img('KNOCKDOWN_'..C[a.who].id,px-96*scale,py-120*scale,{frame=Knockdown.frame(a.t),flip_x=side==2,scale=scale});return
 end
 local dazed=(override or a.clip)=='peligro'
 local resting=(override or a.clip)=='reposo'
 local frames=CLIPS[override or a.clip];local loop=(override or a.clip)=='reposo' or (override or a.clip)=='peligro'
 local index=loop and (a.t//(dazed and 10 or 8))%#frames+1 or math.min(#frames,a.t//7+1)
 local flip=side==2;local scale=size or L.actors.scale
 local px=x or (side==1 and L.actors.left or L.actors.right);local py=y or L.actors.floor
 local pivot=L.actors.pivots[a.who]
 local frameIndex=resting and Idle.frame(a.t) or frames[index]
 local kafkaPose=C[a.who].id=='KAFKA' and not dazed and not resting
 local kafkaClips={entrada={'ENTRY',3},ataque_ligero={'LIGHT',5},ataque_medio={'MEDIUM',5},ataque_fuerte={'HEAVY',6},especial={'SPECIAL',6},defensa={'COUNTER',6},impacto_leve={'HIT',6},impacto_fuerte={'HIT',6},recuperacion={'HIT',6},victoria={'WIN',3}}
 local kclip=kafkaPose and kafkaClips[override or a.clip]
 if kclip then frameIndex=math.min(kclip[2]-1,a.t//7) end
 local assetId=(dazed and 'DAZED_' or resting and 'IDLE_' or 'FIGHTER_')..C[a.who].id
 local poseId=(dazed and 'DAZED_' or resting and 'IDLE_' or '')..C[a.who].id;local bounds=Pose[poseId][frameIndex+1]
 if kclip then assetId='FIGHTER_KAFKA_'..kclip[1];bounds=Pose[assetId][frameIndex+1] end
 local minx=flip and 148-bounds[3] or bounds[1];local maxx=flip and 148-bounds[1] or bounds[3]
 local drawx=px-(flip and 147-pivot or pivot)*scale
 local drawy=py-L.actors.feet[a.who]*scale
 -- Wide attack cels can approach the centre, while their whole silhouette stays clear of the rails.
 local stable=SelectionBounds[C[a.who].id] or Pose['IDLE_'..C[a.who].id][1]
 local safeMin=flip and 148-stable[3] or stable[1];local safeMax=flip and 148-stable[1] or stable[3]
 drawx=math.max(146-safeMin*scale,math.min(334-safeMax*scale,drawx))
 img(assetId,drawx,drawy,
  {frame=frameIndex,flip_x=flip,scale=scale})
 if (override or a.clip)=='peligro' then
  for j=0,2 do
   local phase=visual*.075+j*math.pi*2/3;local sx=px+math.cos(phase)*16;local sy=drawy+bounds[2]*scale-5+math.sin(phase)*4
   img('DAZE_STAR',math.floor(sx)-5,math.floor(sy)-5)
  end
 end
end
local SpecialOrb=require('special_orb')
local function orb(v,x,y,phase,alpha)
 if v.k=='ball' then img('BALL',x,y,{frame=(v.c-1)*4+phase,alpha=alpha or 1})
 elseif v.k=='spark' then img('SPARK',x-7,y-7,{frame=(v.c-1)*4+(phase%2),alpha=alpha or 1})
 elseif v.k=='ray' then img('RAY',x,y,{frame=SpecialOrb.frame(visual),alpha=alpha or 1})
 else
  img('BLOCK_COLORED',x,y,{frame=(v.c-1)*4+1,alpha=alpha or 1})
  -- Center the visible digit, outline and shadow in the 18x18 ball.
  -- The narrower '1' needs no horizontal shadow extension.
  text(tostring(v.n),x+9,y+5,{align='center',shadow_x=v.n==1 and 0 or 1})
 end
end
local function plasma(c,phase,x,y,w,h)
 local cols=math.floor(w/18+.5);local rows=math.floor(h/L.pitch+.5)
 img('CUMULUS_'..cols..'_'..rows,x,y,{frame=(c-1)*3+phase-1})
end
local function incoming_y(b,v,target)
 if not v.arrival then return target end
 local a=v.arrival;local p=math.max(0,math.min(1,(b.age-a.age-a.delay)/a.ticks))
 return -24+(target+24)*p*p
end
local function draw_board(side)
 local b=boards[side];local bx=L.boards[side].x;local phase=(visual//8)%4
 local well=L.boards[side];img('WELL_GLASS',well.leftEdge-16,0,{alpha=.5})
 local danger=L.overload(b)>0
 img('WELL_RED',well.leftEdge-16,0,{alpha=danger and .52 or .32})
 for x=well.leftEdge,well.rightEdge-5,8 do line(x,L.redLine,x+4,L.redLine,danger and 0xff5270 or 0xe34458) end
 local cleared={};if b.clear then for _,q in ipairs(b.clear.cells) do cleared[q.v]=true end end
 -- Collect visible cells without changing their physics or interpolation.
 local settled,falling={},{}
 for y=R.MIN-1,R.H do for x=1,6 do local v=b.grid[y][x]
  if v and not v.g then local px,py=coord(side,x,y)
   if not cleared[v] or b.clock<9 then settled[#settled+1]={v=v,x=px,y=incoming_y(b,v,py+2),alpha=cleared[v] and .7 or 1} end
  end
 end end
 if b.active then
  local p=b.active;local extra=0
  if R.fits(b,p,p.x,p.y+1,p.o) then local rate=side==1 and btn('down') and 2 or math.max(8,36-b.age//1800);extra=math.min(.95,p.fall/rate)*L.pitch end
  for _,q in ipairs(R.cells(p)) do local x,y=coord(side,q.x,q.y);if y+extra> -18 then falling[#falling+1]={v=q.v,x=x,y=y+2+extra,alpha=1} end end
 end
 -- Every corona is behind every settled/blocked/falling ball and plasma group.
 for _,list in ipairs({settled,falling}) do for _,p in ipairs(list) do SpecialOrb.corona(p.v,p.x,p.y,p.alpha,visual) end end
 for _,p in ipairs(settled) do orb(p.v,p.x,p.y,phase,p.alpha) end
 for id,gr in pairs(b.groups) do
  local v=b.grid[gr.y] and b.grid[gr.y][gr.x]
  if v and not (cleared[v] and b.clock>=9) then
   local x,y=coord(side,gr.x,gr.y);local age=b.age-gr.born
   plasma(gr.c,age<10 and 1 or 2+(visual//8)%2,x,y+2,gr.w*18,gr.h*L.pitch)
  end
 end
 for _,p in ipairs(falling) do orb(p.v,p.x,p.y,phase,p.alpha) end
 if danger and (visual//18)%2==0 then tiny('SOBRECARGA',bx+54,309,0xffa2c0) end
end
local function draw_overload(side)
 local b=boards[side];local urgency=L.overload(b);if urgency==0 then return end
 local f=L.boards[side];local speed=urgency==1 and 5 or 3
 -- Arcs stay on the copper rails and base. They never cross playable cells.
 for rail=1,2 do
  local x=rail==1 and f.outer or f.inner
  lightning(x,4,x,294,1.5,0x8950dd)
  for i=1,(urgency==1 and 4 or 2) do
   local y=8+(visual*speed+i*67+rail*31)%234
   lightning(x,y,x,math.min(294,y+38),2,0x74dfff)
  end
 end
 lightning(f.outer,301,f.inner,301,1.5,0x8769eb)
 local p=(visual*speed)%130/130
 local x=f.outer+(f.inner-f.outer)*p
 circ(x,301,2,0xf1fcff)
end
local function draw_fx()
 for _,e in ipairs(transfers) do
  local p=math.max(0,e.age/e.life);local q=math.min(1,p/.82)
  if p<.2 then img('DISCHARGE',e.x-18,e.y-18,{frame=math.min(2,math.floor(p*15)),scale=.5,alpha=1-p/.2}) end
  local ax,ay=route(e.side,e.x,e.y,math.max(0,q-.15));local bx,by=route(e.side,e.x,e.y,q)
  lightning(ax,ay,bx,by,2,({0xff597c,0x4ca8ff,0x4afa8a,0xffd752})[e.c] or 0xc488ff)
 end
 for _,e in ipairs(fx) do
  if e.kind=='send' and e.age<22 then local rx=L.boards[3-e.side].inner;lightning(239,50,rx,50,4)
  elseif e.kind=='receive' and e.age<20 then
   local rail=L.boards[e.side].inner;lightning(239,50,rail,50,4)
   for j=1,math.min(6,#e.cells) do local c=e.cells[j];local x,y=coord(e.side,c.x,c.y)
    lightning(rail,50,x+9,math.max(0,incoming_y(boards[e.side],c.v,y+2)),3)
   end
  end
 end
 for _,e in ipairs(notices) do local x,y=coord(e.side,e.x,e.y);img('DISCHARGE',x-9,y-9,{scale=.5,frame=(visual//4)%3,alpha=e.t/30}) end
end
local function ambient_energy()
 local energy=math.min(1,sphere/24);local pulse=.5+.5*math.sin(visual*.055)
 -- Resting current appears as intermittent flashes, never a permanent drawn bolt.
 for i,p in ipairs({{138,162},{201,214},{265,278},{318,342}}) do
  if energy>0 or (visual+i*29)%150<16 then
   lightning(p[1],50,p[2],50,1+pulse+energy*2,0x304aab,energy>0 and 0xd6faff or 0x6caff3)
  end
 end
 local arcs=E.frame(visual,energy)
 local function stroke(points,branch)
  for j=2,#points do
   local a,b=points[j-1],points[j]
   line(a.x-1,a.y,b.x-1,b.y,0x3548b5);line(a.x+1,a.y,b.x+1,b.y,0x3548b5)
   if not branch then
    line(a.x,a.y-1,b.x,b.y-1,0x4655cd);line(a.x,a.y+1,b.x,b.y+1,0x4655cd)
    line(a.x+1,a.y,b.x+1,b.y,0x70cfff)
   end
   line(a.x,a.y,b.x,b.y,branch and 0xa3e5ff or 0xf5ffff)
  end
 end
 -- Forks first, then white-hot trunks: the outline reads at native resolution.
 for _,arc in ipairs(arcs) do for _,fork in ipairs(arc.forks) do stroke(fork,true) end end
 for _,arc in ipairs(arcs) do
  stroke(arc.points,false)
  local tip=arc.points[#arc.points];pset(tip.x,tip.y,0xf5ffff)
 end
 circ(239,50,#arcs>0 and 2+energy or 1+pulse*.4,#arcs>0 and 0xf6ffff or 0x85b4d9)
end
local function hud()
 img('HUD',0,0)
 ambient_energy()
 for side=1,2 do
  local b=boards[side];local nx=side==1 and 173 or 289
  SpecialOrb.corona(b.next[1],nx,33,1,visual);SpecialOrb.corona(b.next[2],nx,51,1,visual)
  orb(b.next[1],nx,33,(visual//8)%4);orb(b.next[2],nx,51,(visual//8)%4)
  local cx=side==1 and 185 or 295
  rect(cx-42,73,84,15,0x263337);box(cx-42,73,84,15,0xb99b54)
  tiny('SIG.',nx+9,20,0xffefc9);tiny(C[b.character].short,cx,77)
  tiny('PUNTOS',L.boards[side].score,275)
  text_at(string.format('%06d',math.min(999999,b.score)),L.boards[side].score,289,1,0xc9edff)
  local n=Notice.incoming(b)
  if n>0 then small((n>=31 and 'PELIGRO' or n>=11 and 'ALERTA' or 'AVISO')..' '..string.format('%02d',n),side==1 and 185 or 295,94,0xffd46f) end
  for i=1,2 do local x=(side==1 and 160+i*14 or 320-i*14);circ(x,312,3,wins[side]>=i and 0xffd05b or 0x25344e);box(x-3,309,7,7,0xa26c35) end
 end
 if mode=='versus' then
  tiny('VERSUS',240,272,0x92ddff);tiny('1P / 2P',240,287,0x92ddff)
 else
  tiny('DUELO',240,267,0x92ddff)
  tiny(arcadeIndex..' / '..math.max(1,#arcadeRoute),240,279,0xffebbc)
  tiny(({'M.FAC','FACIL','NORMAL','DIFIC.','EXP.'})[arcadeBase],240,291,0x92ddff)
 end
 tiny('ROUND '..round,240,305,0xffe1a0)
end
local function fight_scene()
 img(stage_id(),0,0)
 -- Ambient sparks and torch flicker stay outside the two logical wells.
 for i=1,4 do local x=150+(i*43+visual//3)%180;pset(x,110+(i*37+visual//5)%120,0xe1ad58) end
 draw_board(1);draw_board(2);fighter(1);fighter(2);hud();draw_fx();draw_overload(1);draw_overload(2)
 if state=='play' then
  local first=math.max(1,#messages-2)
  for i=first,#messages do local m=messages[i]
   text_at(m.text,240,108+(i-first)*16,1,m.color)
  end
 end
end
local function selection_lines(value,width)
 local rows={};local current=''
 for word in value:gmatch('%S+') do
  local trial=current=='' and word or current..' '..word
  if current~='' and textw(trial,{scale=1})>width then rows[#rows+1]=current;current=word else current=trial end
 end
 if current~='' then rows[#rows+1]=current end
 return rows
end
-- The same native arcade face as the rest of the interface, with generous margins.
local function random_mark(x,y,w,h)
 text_at('?',x+w/2,y+(h-24)/2,3,UI.GOLD)
end
local function selection_grid()
 for _,who in ipairs(Select.visible()) do
  local x,y,w,h=Select.card(who,mode)
  rect(x,y,w,h,0x302b28)
  if who==Select.RANDOM then random_mark(x,y,w,h)
  else
   local scale=mode=='versus' and .83 or 1
   img('CARD_FACE_'..C[who].id,x+(w-42*scale)/2,y+(h-46*scale)/2,{scale=scale})
  end
  box(x,y,w,h,0x9b784b);line(x+1,y+1,x+w-2,y+1,0xc49a5a);line(x+1,y+h-2,x+w-2,y+h-2,0x624323)
  for side=1,mode=='versus' and 2 or 1 do
   local chosen=side==1 and pick or pick2
   if ready[side] and Select.randomLocked[side] then chosen=Select.RANDOM end
   if who==chosen then
    local colour=side==1 and 0x8edfff or 0xff967a;local inset=side==1 and -1 or 1
    box(x+inset,y+inset,w-2*inset,h-2*inset,colour)
    lightning(x,y,x+w-1,y,2,colour,0xffffff);lightning(x+w-1,y,x+w-1,y+h-1,2,colour,0xffffff)
    lightning(x+w-1,y+h-1,x,y+h-1,2,colour,0xffffff);lightning(x,y+h-1,x,y,2,colour,0xffffff)
   end
  end
 end
end
local function selection_dual()
 img('PLASMA_BACKGROUND',0,0)
 text_at('ESCOGED A VUESTROS HEROES',240,9,1,UI.GOLD)
 local previews={Select.preview(pick,1,visual),Select.preview(pick2,2,visual)}
 img('SELECT_'..C[previews[1]].id,8,52,{scale=.78})
 img('SELECT_'..C[previews[2]].id,328,52,{scale=.78,flip_x=true})
 text_at(ready[1] and '1P LISTO' or '1P',80,35,1,UI.GOLD)
 text_at(ready[2] and '2P LISTO' or '2P',400,35,1,UI.GOLD)
 selection_grid()
 for side,who in ipairs(previews) do
  local center=side==1 and 80 or 400;local random=(side==1 and pick or pick2)==Select.RANDOM
  local titles=random and {'PERSONAJE','ALEATORIO'} or C[who].title
  for i,title in ipairs(titles) do tiny(title,center,233+(i-1)*9) end
  if not random then
   for i,lineText in ipairs(selection_lines(C[who].era,146)) do tiny(lineText,center,262+(i-1)*9) end
  end
  local name=random and 'AL AZAR' or C[who].fullname or C[who].name
  for i,lineText in ipairs(selection_lines(name,146)) do tiny(lineText,center,284+(i-1)*10) end
 end
end
local function selection_arcade()
 img('PLASMA_BACKGROUND',0,0)
 text_at('ESCOGE A TU HEROE',240,7,2,UI.GOLD)
 local who=Select.preview(pick,1,visual);local random=pick==Select.RANDOM
 img('SELECT_'..C[who].id,8,40,{scale=212/230})
 selection_grid()
 if not random then
  -- Keep one union-based scale/anchor through idle and victory, never re-fit individual cels.
  local b=SelectionBounds[C[who].id]
  -- Marilyn's previously approved visible height is the common standard.
  local reference=SelectionBounds.MARILYN
  local height=(reference[4]-reference[2])*102/(reference[3]-reference[1])
  local scale=height/(b[4]-b[2])
  local asset='IDLE_'..C[who].id;local frame=Idle.frame(visual)
  if ready[1] then asset='FIGHTER_'..C[who].id;frame=34+math.min(3,(visual-Select.confirmed[1])//8) end
  img(asset,200-(b[1]+b[3])*scale/2,252-b[4]*scale,{frame=frame,scale=scale})
 end
 local fullName=random and 'SELECCION ALEATORIA' or C[who].fullname or C[who].name
 text_at(fullName,93,260,1,UI.GOLD)
 local descriptor=random and '' or table.concat(C[who].title,' ')
 local rows=selection_lines(descriptor,176)
 for i,title in ipairs(rows) do tiny(title,93,(#rows==1 and 280 or 276)+(i-1)*9) end
 if not random then for i,lineText in ipairs(selection_lines(C[who].era,176)) do tiny(lineText,93,299+(i-1)*10) end end

end
local function selection()
 if mode=='versus' then selection_dual() else selection_arcade() end
end
local function versus_name(who,x)
 local rows={};local row=''
 for word in C[who].name:gmatch('%S+') do
  local trial=row=='' and word or row..' '..word
  if textw(trial,{font='arcade',scale=2})>210 and row~='' then rows[#rows+1]=row;row=word else row=trial end
 end
 rows[#rows+1]=row
 for i,label in ipairs(rows) do text_at(label,x,#rows==1 and 14 or 4+(i-1)*18,2) end
end
local function versus()
 img('STAGE_CERVANTES',0,0);shade(0,0,480,320)
 local p=math.min(1,timer/24);portrait(pick,-200+212*p,40,false,'VERSUS_');portrait(opponent,468-200*p,40,true,'VERSUS_')
 -- Full-height arcade discharge: violet halo, blue body and white-hot core.
 local pulse=(visual//4)%3
 lightning(223,-16,254,336,12,0x512b92,0xa56cff,9+pulse)
 lightning(226,70,208,112,7,0xa56cff,0xd9faff,2)
 lightning(247,215,267,252,7,0xa56cff,0xd9faff,2)
 lightning(223,-16,254,336,12,0xb17bff,0xf3ffff,5)
 local w,h=imgsize('VS');img('VS',240-w/2,150-h/2)
 versus_name(pick,109);versus_name(opponent,369)
 small(mode=='versus' and '1P CONTRA 2P · AL MEJOR DE TRES' or ('COMBATE '..arcadeIndex..' / '..math.max(1,#arcadeRoute)..' · AL MEJOR DE TRES'),240,290,0xffdf8c)
 tiny(mode=='versus' and 'DOS JUGADORES LOCALES' or ('DIFICULTAD '..AI.levels[arcadeBase].name),240,306,0xa9dcff)
end
local function special_scene()
 local s=special;Approved.draw(s.who,s.t,actors[3-s.side].who,s.side)
end

local function result()
 local victory=resultWinner==1
 local winner=boards[resultWinner].character
 img('PLASMA_BACKGROUND',0,0)
 -- Approved framed portraits: exactly the equal slots used in the review viewer.
 for side=1,2 do
  local who=boards[side].character
  img((side==resultWinner and 'RESULT_WIN_' or 'RESULT_LOSE_')..C[who].id,side==1 and 8 or 314,68)
 end
 text_at(mode=='versus' and ('GANA '..resultWinner..'P') or (victory and 'VICTORIA' or 'DERROTA'),240,24,3,UI.GOLD)
 text_at(Records.format(wins[1])..'-'..Records.format(wins[2]),240,86,3,UI.GOLD)
 local labels={{'CADENA','MAX.'},{'PLASMA','ENVIADO'},{'PUNTOS'}}
 local report=mode=='versus' and resultWinner==2 and secondReport or matchReport
 local score=mode=='versus' and resultWinner==2 and secondScore or matchScore
 local values={report.maxChain,report.sent,score}
 for i,rows in ipairs(labels) do
  local y=141+(i-1)*43
  for j,label in ipairs(rows) do text_at(label,240,y+(j-1)*9,1) end
  text_at(Records.format(values[i]),240,y+12+(#rows-1)*9,1)
 end
 text(C[winner].quote,240,287,{align='center'})
end

local function paragraph(s,x,y,width,font,colour,gap)
 local lineText='';local row=0
 for word in s:gmatch('%S+') do
  local trial=lineText=='' and word or lineText..' '..word
  if textw(trial,{font=font})>width and lineText~='' then
   text(lineText,x,y+row*(gap or 12),{font=font,color=colour});row=row+1;lineText=word
  else lineText=trial end
 end
 if lineText~='' then text(lineText,x,y+row*(gap or 12),{font=font,color=colour});row=row+1 end
 return row*(gap or 12)
end
local function gallery_scene()
 local who=Gallery.selected;local id=C[who].id;local unlocked=Gallery.is_open(id)
 img('PLASMA_BACKGROUND',0,0)
 if Gallery.zoom and unlocked then
  if Gallery.tab==1 and Gallery.page==2 then img('SELECT_'..id,148,40)
  else img((Gallery.tab==1 and 'GALLERY_CONCEPT_' or 'STAGE_')..id,0,0) end
  tiny(C[who].fullname or C[who].name,240,8)
  return
 end
 text_at('GALERIA DE HEROES',240,12,2,UI.GOLD)
 local cleared=0;for i=1,12 do if Gallery.is_open(C[i].id) then cleared=cleared+1 end end
 tiny('CAMPAÑAS '..cleared..' / 12',104,43)
 for i=1,#C do
  local y=64+(i-1)*16;local open=Gallery.is_open(C[i].id)
  -- Short native names keep the two columns distinct; full name appears in the preview.
  text(open and C[i].short or '????????????',19,y,{color=i==who and UI.GOLD or UI.MENU_DIM})
 end
 for i,label in ipairs({'ARTE','ESCENA','MUSICA'}) do tiny(label,240+(i-1)*83,49,Gallery.tab==i and UI.GOLD or UI.DIM) end
 line(204,65,467,65,0x977c4d)
 if not unlocked then
  text_at('?',336,106,5,UI.GOLD)
  tiny('ARCHIVO BLOQUEADO',336,174)
  local hint=id=='TESLA' and 'COMPLETA ARCADE CON' or 'COMPLETA ARCADE CON'
  tiny(hint,336,207)
  tiny(id=='TESLA' and 'LOS DOCE HEROES' or 'ESTE PERSONAJE',336,223)
  tiny(id=='TESLA' and ('PROGRESO: '..cleared..' / 12') or 'DESBLOQUEA ARTE Y MUSICA',336,259)
 elseif Gallery.tab<3 then
  img((Gallery.tab==1 and 'GALLERY_CONCEPT_' or 'STAGE_')..id,205,78,{scale=.54})
  for i,row in ipairs(selection_lines(C[who].fullname or C[who].name,260)) do tiny(row,335,260+(i-1)*11) end
 else
  img('CARD_FACE_'..id,315,85,{scale=1})
  local w=Gallery.playing and math.sin(visual*.15)*9 or 0
  for i=0,10 do local h=4+math.abs(math.sin(i*.9+visual*.1))*w;rect(283+i*10,164-h,5,4+h*2,0xffcf72) end
  for i,row in ipairs(selection_lines(MusicTitles[who],252)) do tiny(row,336,205+(i-1)*12) end
 end
end

local function tutorial_scene()
 local lesson=Tutorial.lessons[Tutorial.step];local b=Tutorial.board
 img('STAGE_TESLA',0,0);shade(0,0,334,320)
 rect(7,7,316,32,0x0a1829);box(7,7,316,32,0xb89a59)
 text_at('LA BOBINA DE TESLA',165,17,1,0xffe4a9)
 for i=1,#Tutorial.lessons do
  local x=30+(i-1)*38;rect(x,44,28,4,i<=Tutorial.step and 0xffd78d or 0x46647a)
 end
 rect(9,56,312,110,0x102339);box(9,56,312,110,0xb89a59)
 small(lesson.title,165,64,0xffdf8b)
 local y=84;for _,lineText in ipairs(lesson.lines) do y=y+paragraph(lineText,19,y,291,'report',0xe1f0f7,12) end
 img('IDLE_TESLA',8,176,{frame=Idle.frame(visual),scale=1.05})
 rect(163,178,158,114,0x102339);box(163,178,158,114,0xb89a59)
 small('LECCIÓN '..Tutorial.step..' / '..#Tutorial.lessons,242,187,0xffdf8b)
 if Tutorial.chain>0 then small('CADENA x'..Tutorial.chain,242,250,0x8ee6ff) end
 img('WELL_GLASS',334,0,{alpha=.5});img('WELL_RED',334,0,{alpha=Tutorial.step==8 and .52 or .32})
 local cleared={};if b.clear then for _,q in ipairs(b.clear.cells) do cleared[q.v]=true end end
 -- Hidden tutorial uses the same layer order, without changing its simulation.
 for row=R.MIN-1,R.H do for col=1,6 do local v=b.grid[row][col]
  if v and not v.g and (not cleared[v] or b.clock<9) then SpecialOrb.corona(v,353+(col-1)*18,20+row*L.pitch,1,visual) end
 end end
 if b.active then for _,q in ipairs(R.cells(b.active)) do if q.y>=0 then SpecialOrb.corona(q.v,353+(q.x-1)*18,20+q.y*L.pitch,1,visual) end end end
 for row=R.MIN-1,R.H do for col=1,6 do
  local v=b.grid[row][col]
  if v and not v.g and (not cleared[v] or b.clock<9) then orb(v,353+(col-1)*18,20+row*L.pitch,(visual//8)%4) end
 end end
 for _,g in pairs(b.groups) do plasma(g.c,2+(visual//8)%2,353+(g.x-1)*18,20+g.y*L.pitch,g.w*18,g.h*L.pitch) end
 if b.active then for _,q in ipairs(R.cells(b.active)) do if q.y>=0 then orb(q.v,353+(q.x-1)*18,20+q.y*L.pitch,(visual//8)%4) end end end
 for x=350,459,8 do line(x,40,x+4,40,0xe34458) end
 img('TUTORIAL_COIL',334,0)
 if Tutorial.step==8 then lightning(342,5,342,294,2);lightning(472,5,472,294,2) end
end

local function continue_scene()
 EndScreens.draw_continue(pick,timer)
end

local function record_character(id)
 for _,c in ipairs(C) do if c.id==id then return c end end
 return C[1]
end
local function records_scene()
 img('PLASMA_BACKGROUND',0,0)
 text_at('RÉCORDS',240,17,3,0xffedb1)
 small('LOS DIEZ MEJORES EXPERIMENTOS',240,52,0xc6eaff)
 tiny('POS',28,79,0xc9a76e);tiny('INICIALES',102,79,0xc9a76e)
 text('PUNTOS',264,79,{font='arcade',color=0xc9a76e,align='right'})
 tiny('HEROE',326,79,0xc9a76e);tiny('NIVEL',428,79,0xc9a76e)
 for i=1,Records.LIMIT do
  local y=98+(i-1)*17;local row=Records.rows[i]
  local colour=(i==1 or i==Records.highlight) and UI.GOLD or UI.DIM
  tiny(string.format('%02d',i),28,y,colour)
  text_at(row and row.initials or '---',102,y,1,colour)
  text(row and Records.format(row.score) or '----------',264,y,{font='arcade',color=colour,outline=0x05081b,align='right'})
  if row then
   text(record_character(row.character).short,326,y,{font='arcade',color=0xb6d1eb,align='center'})
   tiny(AI.levels[row.difficulty].short,428,y,0xb6d1eb)
  end
 end
 if Records.lastResult and not Records.lastResult.qualified then
  small('TUS PUNTOS: '..Records.format(Records.lastResult.score)..' · FUERA DEL TOP 10',240,272,0xffdf8e)
 else tiny('RÉCORDS LOCALES · PUNTOS TOTALES DE ARCADE',240,272,0xc8e4f5) end
 text_at('VOLVER',240,292,2,UI.GOLD)
end
local function record_entry_scene()
 local p=Records.pending;if not p then records_scene();return end
 EndScreens.draw_record(p)
end

function _draw()
 cls(0x070d1c)
 if state=='andromina' then
  img(Andromina[math.min(#Andromina,timer+1)],0,0)
 elseif state=='boot' then
  img(Boot[math.min(#Boot,math.max(1,timer+1))],0,0)
 elseif state=='title' then
  TitleScreen.draw()
 elseif state=='menu' then
  img('PLASMA_BACKGROUND',0,0)
  for i,label in ipairs(MENU_ITEMS) do
   local y=64+(i-1)*40;local selected=menuChoice==i
   text(label,240,y,{font='arcade',scale=3,align='center',color=selected and UI.GOLD or UI.MENU_DIM,
    gradient=selected and 0xee983f or 0x9aabdc,outline=0x05081b,shadow=0x020516})
  end
 elseif state=='rules_select' then
  img('PLASMA_BACKGROUND',0,0)
  shade(0,0,480,320);rect(126,108,228,103,0x001621);img('PAUSE_TESLA',100,84)
  text_at('ELIGE EL MODO',240,128,1,UI.GOLD)
  text_at('ULTIMATE',240,147,2,rulesChoice==1 and UI.GOLD or UI.DIM)
  text_at('CLASICO',240,179,2,rulesChoice==2 and UI.GOLD or UI.DIM)
 elseif state=='options' then
  img('PLASMA_BACKGROUND',0,0)
  text_at('OPCIONES',240,28,3,UI.GOLD)
  local labels={'DIFICULTAD','MUSICA','EFECTOS'}
  for i,label in ipairs(labels) do
   local y=98+(i-1)*53;local colour=optionChoice==i and UI.GOLD or UI.DIM
   text_at(label,28,y,2,colour,'left')
   if i==1 then text_at(AI.levels[settings.difficulty].name,452,y,2,colour,'right')
   else
    local v=i==2 and settings.music or settings.effects
    text_at(v==0 and 'SILENCIO' or (v*10)..'%',452,y,2,colour,'right')
    box(276,y+24,176,6,0x667992)
    if v>0 then rect(278,y+26,172*v/10,2,0xe7b65c) end
   end
  end
  text_at('VOLVER',240,274,2,optionChoice==4 and UI.GOLD or UI.MENU_DIM)
 elseif state=='gallery' then gallery_scene()
 elseif state=='records' then records_scene()
 elseif state=='record_entry' then record_entry_scene()
 elseif state=='tutorial' then Tutorial.draw()
 elseif state=='continue' then continue_scene()
 elseif state=='gameover' then FinalScreens.gameover()
 elseif state=='select' then selection()
 elseif state=='versus' then versus()
 elseif state=='result' then result()
 elseif state=='unlock' then
  img('PLASMA_BACKGROUND',0,0)
  text_at('NUEVO PERSONAJE',240,19,2,UI.GOLD);text_at('DISPONIBLE',240,46,2,UI.GOLD)
  img('RESULT_WIN_CHAPLIN',161,77,{scale=1})
  text_at('CHARLIE CHAPLIN',240,280,1,UI.GOLD)
 elseif state=='ending' then FinalScreens.ending(pick,arcadeScore,Campaign.lostRounds,Campaign.continues)
 elseif state=='special' then
  local f=special.t
  if f<0 then fight_scene();img('TRANSITION_WHITE',0,0,{alpha=math.max(0,(f+12)/12)})
  else
   special_scene()
   local white=f<12 and 1-f/12 or f>=318 and (f-318)/11 or 0
   if white>0 then img('TRANSITION_WHITE',0,0,{alpha=math.min(1,white)}) end
  end
 elseif state=='special_return' then fight_scene();img('TRANSITION_WHITE',0,0,{alpha=math.max(0,1-timer/12)})
 else
  fight_scene()
  if state=='intro' then text_at(timer<INTRO_CALL and (round>=3 and 'Round final' or 'Round '..round) or '¡Dale caña!',240,120,2,0xffe7a4)
  elseif state=='draw' then
   text_at('EMPATE',240,110,3,0xffe6a9);small('SE REPITE EL ROUND',240,155,0xffffff)
  elseif state=='ko' then
   text_at('K.O.',240,110,4,0xffe6a9)
   text_at('GANA '..C[boards[resultWinner].character].name,240,155,1,0xffffff)
  elseif pause then
   shade(0,0,480,320);rect(126,108,228,103,0x001621);img('PAUSE_TESLA',100,84)
   text_at('PAUSA',240,120,2);text_at('CONTINUAR',240,148,2,pauseChoice==1 and UI.GOLD or UI.MENU_DIM);text_at('MENU',240,176,2,pauseChoice==2 and UI.GOLD or UI.MENU_DIM)
  end
 end
end
