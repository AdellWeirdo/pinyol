-- Local arcade leaderboard. Recording a result never consumes puzzle randomness.
local H={LIMIT=10,KEY='arcade_records_v1',rows={},run=nil,pending=nil,letters={1,1,1},cursor=1,highlight=nil}
local function score(n)
 n=tonumber(n) or 0
 if n~=n then return 0 end
 return math.max(0,math.min(2000000000,math.floor(n)))
end
local valid={};for i,c in ipairs(require('roster')) do if not c.boss then valid[c.id]=true end end
local function insert(rows,row)
 local rank=#rows+1
 for i,v in ipairs(rows) do if row.score>v.score then rank=i;break end end
 if rank>H.LIMIT then return nil end
 table.insert(rows,rank,row);while #rows>H.LIMIT do table.remove(rows) end
 return rank
end
function H.load(read)
 H.rows={};H.run=nil;H.pending=nil;H.highlight=nil;H.lastResult=nil
 local raw=read(H.KEY,{})
 if type(raw)~='table' then return end
 for i=1,math.min(100,#raw) do
  local v=raw[i]
  if type(v)=='table' and type(v.initials)=='string' and v.initials:match('^[A-Z][A-Z][A-Z]$') and valid[v.character] then
   insert(H.rows,{initials=v.initials,score=score(v.score),character=v.character,
    difficulty=math.max(1,math.min(5,score(v.difficulty or 3))),completed=v.completed==true})
  end
 end
end
function H.begin(character,difficulty)
 H.run={score=0,character=character,difficulty=difficulty,active=true};H.pending=nil;H.highlight=nil;H.lastResult=nil
end
function H.add(points)
 if H.run and H.run.active then H.run.score=score(H.run.score+score(points)) end
 return H.run and H.run.score or 0
end
function H.rank(points)
 points=score(points)
 for i,v in ipairs(H.rows) do if points>v.score then return i end end
 if #H.rows<H.LIMIT then return #H.rows+1 end
 return nil
end
function H.finish(completed)
 if not H.run or not H.run.active then return false end
 H.run.active=false;H.pending=nil;H.highlight=nil
 local rank=H.rank(H.run.score)
 H.lastResult={score=H.run.score,qualified=rank~=nil}
 if not rank then return false end
 H.pending={score=H.run.score,character=H.run.character,difficulty=H.run.difficulty,completed=completed==true,rank=rank}
 H.letters={1,1,1};H.cursor=1
 return true
end
function H.change(delta) H.letters[H.cursor]=(H.letters[H.cursor]-1+delta)%26+1 end
function H.name() return string.char(64+H.letters[1],64+H.letters[2],64+H.letters[3]) end
function H.save(write)
 if not H.pending then return nil end
 local v=H.pending
 local row={initials=H.name(),score=v.score,character=v.character,difficulty=v.difficulty,completed=v.completed}
 local rank=insert(H.rows,row)
 -- Strings preserve integer scores through the engine's float32 JSON reader.
 local persisted={}
 for i,r in ipairs(H.rows) do persisted[i]={initials=r.initials,score=tostring(r.score),character=r.character,difficulty=r.difficulty,completed=r.completed} end
 write(H.KEY,persisted)
 H.pending=nil;H.highlight=rank
 return rank
end
function H.format(n)
 local digits=string.format('%d',score(n));local reversed=digits:reverse():gsub('(%d%d%d)','%1.')
 return (reversed:reverse():gsub('^%.',''))
end
return H
