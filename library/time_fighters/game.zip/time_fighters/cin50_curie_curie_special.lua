-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_curie_assets');local img=Assets.img;local imgsize=Assets.size
-- Review3: stage choreography only. No puzzle simulation, score or attack changes.
local B={};local C=require('cin50_curie_roster');local Idle=require('cin50_curie_idle');local K=require('cin50_curie_knockdown')
-- Original energy design inspired by arcade projectile silhouettes; no copied sprites.
local function arc(x,y,r,f,width,bright)
 local layers={{width+3,0x124b29},{width+1,0x26a84c},{width,0x69f336},{width*.52,0xd3ff83},{1.5,0xffffff}}
 for _,layer in ipairs(layers) do
  local span=layer[1];local px,py
  -- Raster brush along the arc avoids the diagonal seams of polygon strips.
  for j=0,29 do
   local a=-1.29+j*2.58/29
   local taper=math.sin(j/29*math.pi)^.55
   local ripple=math.sin(f*.62+j*.76)*2.4+math.sin(f*.33+j*.41)*1.3
   local rr=r+ripple;local ox=x+math.cos(a)*rr;local oy=y+math.sin(a)*rr*.86
   local size=math.max(.65,span*taper)
   circ(ox,oy,size,layer[2])
   if px and layer[2]==0xffffff then line(px,py,ox,oy,layer[2]) end
   px,py=ox,oy
  end
 end
end
local function wave(f,start,power)
 local age=f-start;if age<0 or age>49 then return end
 local p=math.min(1,age/43);local x=125+p*205;local y=183+math.sin(age*.21)*3;local radius=32+p*(power and 102 or 78)
 arc(x-30,y,radius-15,f+11,3,false);arc(x-15,y,radius-6,f+7,5,false);arc(x,y,radius,f,power and 11 or 9,true)
 -- Animated forks race along the leading edge; staggered tails stretch backwards.
 for n=0,10 do
  local a=-1.16+n*.23;local rr=radius+4;local sx=x+math.cos(a)*rr;local sy=y+math.sin(a)*rr*.86
  if (f+n)%3==0 then circ(sx,sy,1.5,0xffffff) end
 end
 -- Broken, fast horizontal afterimages make the direction unmistakable.
 for n=0,5 do
  local yy=y-44+n*18+math.sin(f*.4+n)*6
  local xx=x+radius*.62-((f*9+n*17)%64)
  line(xx,yy,xx-12-(n%3)*5,yy, n%2==0 and 0xdbff9d or 0x5ce96b)
 end
 if age>=40 and age<49 then img('HIT',353,165,{scale=1.1+(age-40)*.05,alpha=(49-age)/9,tint=0xc6ff9f}) end
end
local function rival(who,f)
 if f<144 then
  img('IDLE_'..C[who].id,392-(148-56)*1.05,293-120*1.05,{frame=Idle.frame(f),flip_x=true,scale=1.05})
 elseif f<210 then
  img('FIGHTER_'..C[who].id,392-(148-56)*1.05,293-120*1.05,{frame=14,flip_x=true,scale=1.05})
 else
  img('SKELETON_CURIE',392-56*1.05,293-120*1.05,{frame=((f-252)//7)%4,scale=1.05})
 end
end
local function cloud(f)
 if f<144 or f>=286 then return end
 local puffs={{405,188,1.16,144},{415,233,1.22,150},{378,274,1.25,156},{336,237,1.08,154}}
 for i,c in ipairs(puffs) do
  local age=f-c[4]
  if age>=0 then
   local fadeStart=245+i*4;local dissolve=math.max(0,f-fadeStart)
   local grow=math.min(1,age/9);local scale=c[3]*(.72+.28*grow)
   local phase=age<7 and 0 or f<fadeStart and 1+((age//8)%3) or dissolve<12 and 4 or 5
   local alpha=dissolve==0 and 1 or math.max(0,1-dissolve/22)
   local x=c[1]+math.sin(age*.13+i)*2.5+dissolve*(i-2)*.28
   local y=c[2]+math.cos(age*.12+i)*2-dissolve*.5
   img('DUST_RADIOACTIVE',x-48*scale,y-48*scale,{frame=phase,scale=scale,alpha=alpha})
  end
 end
end

local function orbit_point(f,plane,t,scale)
 local a=plane*math.pi/3+f*.014
 local u=math.cos(t)*91*scale;local v=math.sin(t)*32*scale
 return 236+u*math.cos(a)-v*math.sin(a),149+u*math.sin(a)+v*math.cos(a)
end
local function atom(f)
 if f<54 or f>=288 then return end
 local scale=math.min(1,(f-54)/38,(288-f)/24)
 local pulse=1+math.sin(f*.25)*.035
 scale=scale*pulse
 -- Crossed, precessing atom orbits: clear graphic shape, all movement deterministic.
 for plane=0,2 do
  local px,py
  for j=0,38 do
   local x,y=orbit_point(f,plane,j*math.pi*2/38,scale)
   if px then
    line(px,py,x,y,0x45b64e);line(px,py-1,x,y-1,0xb0ff70)
   end
   px,py=x,y
  end
 end
 -- A translucent neon aura surrounds a dense, depth-sorted cluster of nucleons.
 img('CURIE_AURA',236-56*scale,149-56*scale,{scale=scale,alpha=.13+.025*math.sin(f*.18)})
 img('CURIE_AURA',236-56*scale*.72,149-56*scale*.72,{scale=scale*.72,alpha=.12})
 local sites={{0,-20,0},{-16,-10,-7},{15,-10,-8},{-23,5,0},{23,5,-1},{-12,19,-4},{12,20,-4},{0,4,-13},{-10,-8,12},{10,-8,13},{-14,9,12},{12,10,13},{0,24,7},{0,-24,8},{0,2,20},{-26,-5,-8},{25,-7,-7}}
 local balls={};local angle=f*.019
 for i,v in ipairs(sites) do
  local x=v[1]*math.cos(angle)+v[3]*math.sin(angle)
  local z=-v[1]*math.sin(angle)+v[3]*math.cos(angle)
  balls[#balls+1]={x=x,y=v[2]+math.sin(f*.055+i)*.55,z=z,i=i}
 end
 table.sort(balls,function(a,b)return a.z<b.z end)
 for _,v in ipairs(balls) do
  local depth=(v.z+29)/58;local r=(8.7+depth*1.7)*scale
  local x=236+v.x*scale;local y=149+v.y*scale
  circ(x,y,r+1.1*scale,0x113c21)
  circ(x,y,r,v.i%2==0 and 0x62b83c or 0x77b957)
  circ(x-1.6*scale,y-1.7*scale,r*.74,v.i%2==0 and 0xb1fb45 or 0xc8ef9e)
  circ(x-3*scale,y-3.4*scale,r*.28,0xf0ffbd)
 end
 -- Six fast electrons, with short curved fading trails rather than fixed painted rays.
 for plane=0,2 do for k=0,1 do
  local t=f*(.155+plane*.018)+k*math.pi+plane
  for trail=5,1,-1 do
   local x,y=orbit_point(f,plane,t-trail*.11,scale)
   circ(x,y,(3.7-trail*.45)*scale,trail>3 and 0x328e43 or 0x8bec66)
  end
  local x,y=orbit_point(f,plane,t,scale)
  circ(x,y,6.5*scale,0x287d37);circ(x,y,4.3*scale,0xa8ff65);circ(x-1,y-1,2*scale,0xffffff)
 end end
 for _,start in ipairs({110,137,164,195}) do
  local age=f-start
  if age>=0 and age<8 then
   local radius=(31+age*4)*scale
   for j=0,11 do
    local a=j*math.pi/6+f*.1;local x=236+math.cos(a)*radius;local y=149+math.sin(a)*radius
    line(x,y,x+math.cos(a)*7,y+math.sin(a)*7,0xd9ffb0)
   end
  end
 end
end
local function hero(f)
 local scale=1.18;local pose
 if f<54 or f>=286 then
  img('IDLE_CURIE',72-56*scale,293-120*scale,{frame=Idle.frame(f),scale=scale});return
 end
 if f<82 then pose=25 elseif f<110 then pose=26 else
  local age=f-195
  for _,start in ipairs({110,137,164,195}) do if f>=start then age=f-start end end
  pose=age<4 and 27 or age<11 and 28 or age<18 and 29 or 26
  if f>=254 then pose=f<268 and 29 or 24 end
 end
 img('FIGHTER_CURIE',72-56*scale,293-120*scale,{frame=pose,scale=scale})
 -- Green plasma at the releasing hand connects the character with the atom.
 if f>=96 and f<250 then
  local launch=pose==27 or pose==28
  local x=launch and 128 or 107;local y=launch and 231 or 224
  circ(x,y,10+math.sin(f*.6)*2,0x318e48);circ(x,y,7,0x8dfd64);circ(x-1,y-1,3,0xeaffbd)
  for j=0,5 do
   local t=((f*3+j*11)%72)/72
   local sx=x+(236-x)*t;local sy=y+(149-y)*t+math.sin(t*6+f*.3)*7
   circ(sx,sy,1.8,0xa7ff77)
  end
 end
end
-- Prepared before the main screen switches to its mirrored CINEMA target.
function B.prepare()
 canvas('CURIE_AURA',112,112);target('CURIE_AURA')
 circ(56,56,54,0x5dff00)
 target()
end
function B.draw(f,enemy)
 img('STAGE_CURIE',0,0)
 if f>40 then img('SPECIAL_CURIE',0,0,{alpha=math.min(1,(f-40)/30)}) end
 atom(f)
 if f<164 or f>252 then rival(enemy,f) end
 for i,start in ipairs({110,137,164,195}) do wave(f,start,i==4) end
 hero(f);cloud(f)
end
return B
