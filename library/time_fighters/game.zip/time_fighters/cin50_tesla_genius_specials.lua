-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_tesla_assets');local img=Assets.img;local imgsize=Assets.size
-- New cinematic assets, no simulation, damage or RNG changes here.
local S={}
local C=require('cin50_tesla_roster');local L=require('cin50_tesla_layout');local Idle=require('cin50_tesla_idle');local K=require('cin50_tesla_knockdown')
local function actor(who,x,frame,f,flip)
 local rest=frame==0
 img((rest and 'IDLE_' or 'FIGHTER_')..C[who].id,x-(flip and 148-56 or 56)*1.12,293-120*1.12,{frame=rest and Idle.frame(f) or frame,flip_x=flip,scale=1.12})
end
local function prop(who,x,ground,f,scale,alpha)
 img('SPECIAL_PROP_'..C[who].id,x,ground-196*scale,{frame=(f//7)%4,scale=scale,alpha=alpha or 1})
end
local function bolt(ax,ay,bx,by,f,size)
 local px,py=ax,ay
 for i=1,12 do
  local q=i/12;local d=i==12 and 0 or math.sin(f*.9+i*4.7)*13
  local x=ax+(bx-ax)*q+d;local y=ay+(by-ay)*q-d
  for k=-size,size do line(px+k,py,x+k,y,0x7755d9) end
  for k=-2,2 do line(px+k,py,x+k,y,0x80dfff) end
  line(px,py,x,y,0xffffff);px,py=x,y
 end
end
function S.sounds(who,f,snd)
 if f==45 then snd(who==12 and 'QUILL' or who==13 and 'BOOT_CLING' or 'BELL',.65) end
 if f==85 then snd(who==12 and 'BELL' or 'PAGES',.6) end
 if f>=110 and f<=245 and f%24==0 then snd(who==10 and 'GALLOP' or 'RAY',.4) end
 if f==170 or f==205 or f==240 then snd('HIT',.5) end
end
function S.draw(who,f,rival)
 img('STAGE_'..C[who].id,0,0)
 if f>45 then img('SPECIAL_'..C[who].id,0,0,{alpha=math.min(1,(f-45)/30)}) end
 if who==11 and f>45 then
  for i=0,35 do local x=(i*71+f*3)%480;local y=(i*43+f*8)%320;line(x,y,x-4,y+14,0x6b91b5) end
 end
 if who==10 and f>75 and f<285 then
  for j=0,2 do local age=f-75-j*23
   if age>0 then prop(who,-180+j*105+math.min(180,age*7),290,f+j*7,.83,math.min(1,age/12)*math.min(1,(285-f)/18)) end
  end
 end
 if f<240 then
  actor(rival,395,f<165 and 0 or 14,f,true)
 else
  img('KNOCKDOWN_'..C[rival].id,299,173,{frame=K.frame(f-240),flip_x=true})
 end
 if who==11 then
  if f>100 and f<270 then prop(who,-250+(f-100)*3.8,291,f,1.14,math.min(1,(f-100)/14)*math.min(1,(270-f)/12)) end
 elseif who==12 then
  if f>100 and f<278 then prop(who,-305+(f-100)*4.5,291,f,1.42,math.min(1,(f-100)/15)) end
  if f>115 and f<275 then
   for i=0,8 do local q=((f+i*13)%85)/85;img('PAGES',125+q*345,170-math.sin(q*3.14)*65+(i%3)*20,{frame=(f//6+i)%4,scale=.55,angle=f*2+i*25}) end
  end
 elseif who==13 then
  if f>75 and f<285 then
   prop(who,116,280,f,1.08,math.min(1,(f-75)/25)*math.min(1,(285-f)/20))
   for j=0,2 do if f>105+j*20 then bolt(240,85,350+j*22,250,f+j*5,3+j) end end
  end
 end
 actor(who,78,f<62 and 0 or f<100 and 26 or f<275 and 28 or 0,f,false)
 for _,start in ipairs({170,205,240}) do
  local t=f-start
  if t>=0 and t<15 then img('HIT',347,173,{scale=1.1+t*.03,alpha=1-t/15}) end
 end
 if f>190 and f<288 then
  for i=0,4 do img('SMOKE',320+(i%3)*24,215+(i//3)*28-math.sin(f*.09+i)*4,{scale=.9,alpha=math.min(.8,(f-190)/30)*math.min(1,(288-f)/18)}) end
 end
end
return S
