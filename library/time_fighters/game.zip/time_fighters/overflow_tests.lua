-- The red band is a warning; only actual overflow above the screen loses.
local R=require('rules');local L=require('layout')
local T={}
local function fill(b,x) for y=R.MIN,R.H do b.grid[y][x]=R.cell(2,'blocked',5) end end
function T.boundary()
 local _,y=L.cell_at(1,1,R.MIN);assert(y+2>=0)
 local _,above=L.cell_at(1,1,R.MIN-1);assert(above+2<0)
 for x=1,6 do for o=0,3 do
  if not (o==1 and x==6 or o==3 and x==1) then
   local b=R.new(9,1);local y=o==0 and R.MIN+1 or R.MIN
   b.active={x=x,y=y,o=o,v={R.cell(1),R.cell(3)}}
   assert(R.fits(b,b.active));R.lock(b);assert(not b.dead,'visible placement lost')
   b=R.new(9,1);b.active={x=x,y=y-1,o=o,v={R.cell(1),R.cell(3)}}
   assert(R.fits(b,b.active));R.lock(b);assert(b.dead,'offscreen placement survived')
   for row=R.MIN,R.H do for col=1,6 do assert(not b.grid[row][col],'failed lock inserted half a pair') end end
  end
 end end
 return true
end
function T.escape()
 for fullColumn=0,1 do
  local b=R.new(23,1)
  if fullColumn==1 then fill(b,4) else b.grid[0][4]=R.cell(2,'blocked',5) end
  assert(R.spawn(b) and not b.dead and b.active.y<0,'premature entry defeat')
  assert(R.move(b,-1));local ticks=0
  repeat R.step(b,{down=true});ticks=ticks+1 until b.turn>0 or b.dead or ticks>100
  assert(not b.dead and b.turn==1 and b.grid[R.H][3],'could not escape into free column')
 end
 local b=R.new(13,1);b.grid[0][4]=R.cell(2,'blocked',5)
 assert(R.spawn(b));assert(R.rotate(b,1));R.lock(b)
 assert(not b.dead and b.grid[R.MIN][4] and b.grid[R.MIN][5],'last visible row unavailable')
 assert(L.overload(b)==1,'topmost visible row not warned')
 return true
end
function T.incoming()
 for _,n in ipairs({90,96,97,120}) do
  local b=R.new(72,1);local seed=b.seed;R.incoming(b,n,3);R.finish(b)
  assert(b.seed==seed and b.phase=='received' and not b.dead)
  assert((not not b.overflowPending)==(n>96),'wrong incoming capacity')
  local duration=b.receiveTicks
  for i=1,duration-1 do R.step(b);assert(not b.dead,'defeat before attack arrival') end
  R.step(b);assert(b.dead==(n>96),'overflow did not resolve at arrival')
  if n<=96 then assert(R.spawn(b) and not b.dead,'visible stack killed at entry') end
 end
 local b=R.new(31,1);fill(b,1);R.incoming(b,1,1);R.receive(b)
 assert(not b.overflowPending and b.grid[R.H][2],'small packet stopped skipping full columns')
 b=R.new(31,1);for x=1,6 do fill(b,x) end;R.incoming(b,1,1);R.finish(b)
 assert(b.overflowPending and b.grid[R.MIN-1][1]);for _=1,b.receiveTicks do R.step(b) end;assert(b.dead)
 return true
end
return T
