local S={}
local Assets=require('cin50_beethoven_assets');local img=Assets.img;local imgsize=Assets.size
local Draw=require('cin50_beethoven_beethoven_special');local NewSpecials={draw=function(w,f,r) Draw.draw(f,r) end}
local C=require('cin50_beethoven_roster')
local function text_at(s,x,y,scale,color,align) text(s,x,y,{font='arcade',scale=scale or 1,color=color or 0xffe7a1,gradient=scale and scale>1 and 0xe78332 or nil,outline=0x081126,shadow=0x030712,align=align or 'center'}) end
function S.draw(who,f,rival,side)
 local s={who=who,t=f,side=side};local mirror=side==2
 if mirror then canvas('CINEMA',480,320);target('CINEMA') end
 NewSpecials.draw(s.who,f,rival)
 -- Full-screen cinematic: decorative outer frame removed.
 if mirror then target();img('CINEMA',0,0,{flip_x=true}) end
 if f>=11 and f<77 then
  if s.who==1 then
   local fade=math.min(1,(f-10)/5,(77-f)/7)
   img('TITLE_SPECIAL_BEETHOVEN',82,10,{alpha=fade})
   -- Light is clipped to the transparent title sprite, never a rectangle behind it.
   local sweep=82-28+(f-15)/46*372
   for _,band in ipairs({{-7,28,.22},{0,14,.72},{5,4,.95}}) do
    local x=math.floor(sweep+band[1])
    clip(x,10,band[2],52)
    img('TITLE_SPECIAL_BEETHOVEN',82,10,{tint=0xfffacf,alpha=fade*band[3]})
   end
   clip()
   for _,star in ipairs({{133,26,24},{235,24,40},{351,28,55}}) do
    local age=f-star[3]
    if age>=0 and age<8 then
     local radius=age<4 and age+1 or 8-age
     line(star[1]-radius,star[2],star[1]+radius,star[2],0xfff9b2)
     line(star[1],star[2]-radius,star[1],star[2]+radius,0xfff9b2)
     pset(star[1],star[2],0xffffff)
    end
   end
  else
   rect(6,13,468,40,0x10192b);box(6,13,468,40,0xd99d4b)
   local label=C[s.who].special
   text_at(label,240,26,textw(label,{font='arcade',scale=2})<=450 and 2 or 1,0xffda87)
  end
 end
end

return S
