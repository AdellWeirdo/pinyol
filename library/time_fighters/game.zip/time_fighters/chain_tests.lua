local R=require('rules')
local T={}
function T.setup(b,depth)
 for y=-2,R.H do b.grid[y]={} end
 b.groups={};b.events={};b.pending={};b.active=nil;b.clear=nil
 b.phase='settle';b.clock=0;b.chain=0;b.out=0;b.total=0;b.score=0;b.attackRemainder=0
 -- Each coloured ball falls onto its matching spark only after the previous
 -- colour disappears: red -> blue -> green -> yellow. No direct event injection.
 b.grid[R.H][1]=R.cell(1,'spark');b.grid[R.H][2]=R.cell(1)
 for colour=2,depth do
  b.grid[R.H-1][colour]=R.cell(colour)
  b.grid[R.H][colour+1]=R.cell(colour,'spark')
 end
end
function T.run()
 for depth=1,4 do
  local b=R.new(1776,1);T.setup(b,depth)
  local frames=0
  repeat R.step(b);frames=frames+1 until b.phase=='spawn' or frames>=300
  assert(frames<300 and b.chain==depth,'gravity chain did not resolve')
  local clears,chains,expected,attacks=0,0,0,0
  for _,e in ipairs(b.events) do
   if e.kind=='clear' then
    clears=clears+1;assert(e.chain==clears)
    expected=expected+e.count*100*R.chain_multiplier(e.chain)+e.power*10
   elseif e.kind=='chain' then
    chains=chains+1;assert(e.chain==depth and e.bonus==R.chain_bonus(depth))
   elseif e.kind=='attack' then attacks=attacks+1;assert(e.chain==attacks) end
  end
  assert(clears==depth and chains==(depth>=2 and 1 or 0) and attacks==depth,'each chain link must send its own attack')
  assert(b.score==expected+R.chain_bonus(depth),'chain points missing or awarded twice')
  if depth>=3 then assert(b.score>=5000,'long chains should award substantial points') end
 end
 local b=R.new(40,1);T.setup(b,3);R.incoming(b,100,2)
 for _=1,140 do R.step(b);if b.phase=='received' then break end end
 local chain,attack=false,0
 for _,e in ipairs(b.events) do
  if e.kind=='chain' then chain=e.chain==3 end
  if e.kind=='attack' then attack=attack+e.n end
 end
 assert(chain and attack<=3,'a counterattack chain must qualify even when it sends at most one cell per link')
 return true
end
return T
