-- Six drawn cels: impact, imbalance, airborne, landing, bounce, lying hold.
local K={}
function K.frame(t)
 local ends={8,16,25,31,37}
 for i,v in ipairs(ends) do if t<v then return i-1 end end
 return 5
end
return K
