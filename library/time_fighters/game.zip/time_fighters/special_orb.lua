-- Presentation only. The rules still identify this piece as k='ray'.
local S={}
function S.frame(ticks) return ((ticks*5)//36)%6 end -- six 120 ms frames at 60 Hz; no white flash
function S.corona(v,x,y,alpha,ticks)
 if v.k=='ray' then img('RAY_CORONA',x-3,y-3,{frame=S.frame(ticks),alpha=alpha or 1}) end
end
return S
