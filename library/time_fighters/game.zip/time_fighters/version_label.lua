-- Always follows the package metadata; no second version string to maintain.
local V={}
function V.label()
 local metadata=file('game.json') or ''
 return (metadata:match('"subtitle"%s*:%s*"([^"]+)"') or 'Version desconocida')
end
function V.display()
 return V.label():gsub("^[Vv]ersion%s*", "v."):lower()
end
function V.draw()
 text(V.display(),240,305,{font='version_thin',color=0xe7e0c9,align='center'})
end
return V
