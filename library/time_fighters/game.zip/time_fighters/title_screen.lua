-- Rebuilt arcade labels; the approved logo, balls and plasma remain unchanged.
local Version=require('version_label')
local T={}
function T.draw()
 img('TITLE_SCREEN',0,0)
 img('TITLE_FOOTER_BG',0,270)
 local w=imgsize('TITLE_START_LABEL');img('TITLE_START_LABEL',240-w/2,272)
 w=imgsize('TITLE_COPY_LABEL');img('TITLE_COPY_LABEL',240-w/2,292)
 Version.draw()
end
return T
