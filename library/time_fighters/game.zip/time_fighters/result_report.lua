-- Match-wide player performance. Outcome never changes the puzzle rules or damage.
local P={}
function P.new() return {maxChain=0,sent=0} end
function P.clear(report,chain) report.maxChain=math.max(report.maxChain,chain or 0) end
function P.attack(report,n) report.sent=report.sent+math.max(0,n or 0) end
function P.grade(report)
 if report.maxChain>=5 or report.sent>=160 then return 'S'
 elseif report.maxChain>=3 or report.sent>=100 then return 'A'
 elseif report.maxChain>=2 or report.sent>=50 then return 'B'
 elseif report.sent>=15 then return 'C' end
 return 'D'
end
return P
