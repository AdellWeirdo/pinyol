local R=require('rules')
local T={step=1,t=0,board=nil,started=false,done=false,chain=0}
T.lessons={
 {title='MI BOBINA DE PLASMA',lines={'Soy Nikola Tesla. Mi máquina enfrenta','a los grandes genios de la historia.','Mueve la pareja con IZQ y DER.','Mantén ABAJO para acelerar la caída.'}},
 {title='ORIENTA LA ENERGÍA',lines={'ESPACIO gira la pareja de plasma.','Colócala donde tengas más espacio.','Mi bobina siempre tiene seis columnas.','Prueba ESPACIO y las flechas.'}},
 {title='LA CHISPA CORRECTA',lines={'Una chispa rompe plasma conectado','de su color. Las chispas no repiten','el color de la chispa anterior.','ESPACIO: observa esta descarga roja.'}},
 {title='CÚMULOS DE PLASMA',lines={'Une un rectángulo del mismo color,','de al menos dos por dos, para fusionarlo.','Los cúmulos aumentan tus ataques.','ESPACIO: forma y rompe un cúmulo.'}},
 {title='COMBO EN CADENA',lines={'¡No basta con romper muchas bolas!','Al caer las que quedan, otra chispa','puede provocar una nueva explosión.','ESPACIO: observa tres descargas encadenadas.'}},
 {title='FICHAS BLOQUEADAS',lines={'Tus descargas envían energía al rival.','Se convierte en plasma bloqueado.','Su color indica qué será al liberarse;','el número baja al colocar tus parejas.'}},
 {title='EL RAYO Y LOS ESPECIALES',lines={'El rayo elimina el color que toca.','Una cadena de tres puede desatar','el especial de tu genio. Los ataques','muy grandes también pueden activarlo.'}},
 {title='EVITA LA SOBRECARGA',lines={'La zona roja avisa de peligro.','No dejes que se bloquee la entrada','central de tu bobina. Gana dos rounds','para vencer. ¡La energía está en ti!'}}
}
function T.reset(step)
 T.step=step or 1;T.t=0;T.started=false;T.done=false;T.chain=0
 local b=R.new(4981+T.step,13);for y=R.HEAD,R.H do b.grid[y]={} end;b.events={};b.groups={};b.active=nil;b.phase='fixture';T.board=b
 local c=R.cell
 if T.step<=2 then b.next={c(1),c(2)};R.spawn(b);b.active.y=3
 elseif T.step==3 then b.grid[R.H][2]=c(1,'spark');b.grid[R.H][3]=c(1);b.grid[R.H][4]=c(1)
 elseif T.step==4 then for y=R.H-1,R.H do for x=2,3 do b.grid[y][x]=c(2) end end;b.grid[R.H-1][4]=c(2,'spark')
 elseif T.step==5 then
  b.grid[R.H][1]=c(1,'spark');b.grid[R.H][2]=c(1)
  for colour=2,3 do b.grid[R.H-1][colour]=c(colour);b.grid[R.H][colour+1]=c(colour,'spark') end
 elseif T.step==6 then for x=1,6 do b.grid[R.H][x]=c(x%4+1,'blocked',5) end
 elseif T.step==7 then for x=1,6 do b.grid[R.H][x]=c(x%2+1) end;b.grid[R.H-1][2]=c(0,'ray')
 else for y=1,R.H do for x=1,6 do if x~=4 or y>3 then b.grid[y][x]=c((x+y)%4+1) end end end end
end
function T.update(input,snd)
 if input.cw and T.step>2 and T.started then T.reset(T.step);T.t=99 end
 T.t=T.t+1;local b=T.board
 if T.step<=2 then
  R.step(b,input)
  if b.phase=='spawn' or b.dead then T.reset(T.step);T.done=true end
 else
  if input.cw or T.t==100 then T.started=true;b.phase='settle';b.clock=0 end
  if T.started and not T.done then
   if T.step==6 then
    R.step(b,{down=true});b.events={}
    if b.turn>=5 then T.done=true end
   elseif T.step==8 then T.done=true
   else
    R.step(b)
    for _,e in ipairs(b.events) do if e.kind=='clear' then T.chain=e.chain;snd('PLASMA_CLEAR',.5) elseif e.kind=='fusion' then snd('FUSE',.5) end end;b.events={}
    if b.phase=='spawn' then T.done=true end
   end
  end
 end
end
return T
