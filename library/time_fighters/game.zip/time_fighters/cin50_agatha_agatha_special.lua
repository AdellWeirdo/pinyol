-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_agatha_assets');local img=Assets.img;local imgsize=Assets.size
-- Presentation-only replacement. Train, pages, hit sprites and audio retain their original placement and timing.
local S={}
function S.actor(f)
 img('AGATHA_DIRECT',78-56*1.12,293-120*1.12,{frame=((f-100)//11)%8,scale=1.12})
 img('AGATHA_GOLD_STROKE',78-56*1.12,293-120*1.12,{scale=1.12})
end
function S.cloud(f)
 for i=0,4 do
  local age=f-191;local dissolve=math.max(0,f-267)
  local cel=age<7 and 0 or dissolve==0 and 1+((age//7+i)%3) or dissolve<12 and 4 or 5
  local sc=.9;local alpha=math.min(.8,(f-190)/30)*math.min(1,(288-f)/18)
  img('DUST_AGATHA_WHITE',320+(i%3)*24,205.1+(i//3)*28-math.sin(f*.09+i)*4,{frame=cel,scale=sc,alpha=alpha})
 end
end
return S
