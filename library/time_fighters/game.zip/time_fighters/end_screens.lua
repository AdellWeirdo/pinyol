-- Approved Continue / new-record layouts. Only presentation and exit timing.
local UI=require('ui_style')
local C=require('roster')
local L=require('layout')
local Pose=require('pose_bounds')
local K=require('knockdown')
local Records=require('records')
local S={phase='countdown',since=0}
local function label(s,x,y,scale,color)
 UI.text(s,x,y,{align='center',scale=scale or 1,color=color or UI.GOLD})
end
function S.enter() S.phase='countdown';S.since=0;S.number=10 end
function S.update(t,confirm,cancel)
 if S.phase=='countdown' then
  if t>=600 or cancel then S.phase='fall';S.since=t;S.number=0;return nil,'fall'
  elseif t>12 and confirm then S.phase='victory';S.since=t;S.number=math.max(0,10-t//60);return nil,'victory'
  elseif t%60==0 then return nil,'tick' end
 elseif t-S.since>=72 then return S.phase=='victory' and 'continue' or 'finish' end
end
function S.draw_continue(who,t)
 local id=C[who].id;img('PLASMA_BACKGROUND',0,0)
 label('CONTINUAR?',240,20,3)
 label(tostring(S.phase=='countdown' and math.max(0,10-t//60) or S.number),240,65,5)
 local scale=1.65;local foot=307;local px=240
 if S.phase=='fall' then
  img('KNOCKDOWN_'..id,px-96*scale,foot-120*scale,{scale=scale,frame=K.frame(t-S.since)})
 else
  local win=S.phase=='victory';local f=win and 34+math.min(3,(t-S.since)//7) or (t//10)%6
  local aid=(win and 'FIGHTER_' or 'DAZED_')..id
  if win and (who==15 or who>=16) then aid='WIN_'..id;f=math.min(5,(t-S.since)//7) end
  if win and id=='KAFKA' then aid='FIGHTER_KAFKA_WIN';f=math.min(2,(t-S.since)//7) end
  local y=foot-L.actors.feet[who]*scale
  img(aid,px-L.actors.pivots[who]*scale,y,{scale=scale,frame=f})
  if not win then
   local b=Pose['DAZED_'..id][f+1]
   for j=0,2 do
    local a=t*.075+j*math.pi*2/3
    img('DAZE_STAR',px+math.cos(a)*24-5,y+b[2]*scale-9+math.sin(a)*5)
   end
  end
 end
end
function S.draw_record(p)
 img('PLASMA_BACKGROUND',0,0)
 label('NUEVO RECORD',240,21,3)
 local id=C[1].id
 for _,c in ipairs(C) do if c.id==p.character then id=c.id;break end end
 img('RESULT_WIN_'..id,4,65,{scale=1.25})
 label('INTRODUCE TU NOMBRE',336,78,1)
 local points=Records.format(p.score);local size=3
 while size>1 and UI.width(points,{scale=size})>250 do size=size-1 end
 label(points,336,118,size);label('PUNTOS',336,150,1)
 label('PUESTO '..string.format('%02d',p.rank),336,178,2)
 for i=1,3 do
  local x=282+(i-1)*54;local selected=i==Records.cursor
  label(string.char(64+Records.letters[i]),x,224,4,selected and UI.GOLD or UI.DIM)
  line(x-17,267,x+16,267,selected and UI.GOLD or UI.DIM)
 end
end
return S
