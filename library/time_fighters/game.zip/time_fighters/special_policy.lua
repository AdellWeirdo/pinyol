-- Presentation qualification only; never adds damage or changes puzzle outcomes.
-- More than 25 sent cells in one resolved placement, including its cascade.
local S={BIG=26,FINISHER=18}
function S.reset(b) b.specialSent=0 end
function S.sent(b,n) b.specialSent=(b.specialSent or 0)+n end
function S.claim(b,turn)
 b.specialTurns=b.specialTurns or {};if b.specialTurns[turn] then return false end
 b.specialTurns[turn]=true;return true
end
function S.cascade(b,depth)
 if depth>=3 then return 'chain' end
 if (b.specialSent or 0)>=S.BIG then return 'big' end
end
return S
