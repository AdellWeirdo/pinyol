-- Difficulty changes decisions and inputs, never the shared piece RNG or puzzle rules.
local R=require('rules')
local A={default=3,levels={
 {name='MUY FÁCIL',short='M. FÁCIL',think=240,jitter=90,step=72,error=100,drop=0},
 {name='FÁCIL',short='FÁCIL',think=180,jitter=75,step=52,error=97,drop=0},
 {name='NORMAL',short='NORMAL',think=120,jitter=60,step=36,error=90,drop=0},
 {name='DIFÍCIL',short='DIFÍCIL',think=75,jitter=40,step=24,error=65,drop=12},
 {name='EXPERTO',short='EXPERTO',think=40,jitter=25,step=16,error=35,drop=40}
}}
-- Internal arcade anchors are not additional selectable modes. Offsetting the
-- original curve by two preserves old Very Easy exactly as the new Normal.
local profiles={A.levels[1],A.levels[2],A.levels[3],A.levels[4],A.levels[5],
 {name='EXPERTO',short='EXPERTO',think=15,jitter=15,step=10,error=12,drop=65},
 {name='EXPERTO',short='EXPERTO',think=0,jitter=0,step=7,error=0,drop=100}}
local function random(a,n)
 local v=a.seed;v=v~(v<<13);v=v~(v>>17);v=v~(v<<5);a.seed=v&0x7fffffff
 return a.seed%n+1
end
local function random_placement(b,a)
 local choices={}
 for o=0,3 do for x=1,6 do
  if R.fits(b,b.active,x,b.active.y,o) then choices[#choices+1]={x=x,o=o} end
 end end
 return choices[random(a,math.max(1,#choices))] or {x=4,o=0}
end
function A.profile(level)
 level=math.max(1,level or A.default)
 if level>=#profiles then
  local cfg={};for k,v in pairs(profiles[#profiles]) do cfg[k]=v end
  cfg.step=math.max(4,math.floor(cfg.step-(level-#profiles)*1.2+.5));return cfg
 end
 local lo=math.floor(level);local q=level-lo;local cfg={}
 for k,v in pairs(profiles[lo]) do
  cfg[k]=type(v)=='number' and math.floor(v+(profiles[lo+1][k]-v)*q+.5) or v
 end
 return cfg
end
function A.input(b,level)
 if b.dead or b.phase~='fall' then return nil end
 local cfg=A.profile(level)
 local a=b.ai
 if not a then a={seed=(b.seed~0x51a735)&0x7fffffff};b.ai=a end
 if a.turn~=b.turn then
  a.turn=b.turn;a.target=nil;a.actions=0
  a.thinkUntil=b.age+cfg.think+(cfg.jitter>0 and random(a,cfg.jitter) or 0)
  a.moveAt=a.thinkUntil;a.soft=random(a,100)<=cfg.drop
 end
 if b.age<a.thinkUntil then return nil end
 if not a.target then
  a.mistake=random(a,100)<=cfg.error
  a.target=a.mistake and random_placement(b,a) or R.plan(b)
 end
 local p=b.active;local move=b.age>=a.moveAt
 if move then a.moveAt=b.age+cfg.step;a.actions=a.actions+1 end
 return {left=move and p.x>a.target.x,right=move and p.x<a.target.x,
  cw=move and p.o~=a.target.o,
  down=a.soft and p.x==a.target.x and p.o==a.target.o and b.age%6<4}
end
return A
