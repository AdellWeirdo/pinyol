local T={}
function T.unit()
 local C=require('roster');local Secret=require('secret_character');local Select=require('character_select');local A=require('arcade');local R=require('rules');local N=require('gameplay_notices')
 assert(#C==14 and C[10].id=='KAFKA' and C[13].boss and C[14].id=='CHAPLIN')
 local saved={};local read=function(k,d) if saved[k]~=nil then return saved[k] end;return d end;local write=function(k,v) saved[k]=v end
 Secret.load(read);assert(not Secret.unlocked and #Select.visible()==13)
 for _,mode in ipairs({'arcade','versus'}) do for cursor=1,13 do for _,direction in ipairs({'left','right','up','down'}) do assert(Select.navigate(cursor,direction,mode)~=14) end end end
 local previous
 for pick=1,12 do for seed=1,100 do
  local route=A.route(pick,14,seed,13,previous,Secret.candidates());assert(#route==12 and route[#route]==13);local seen={}
  for _,i in ipairs(route) do assert(i~=pick and i~=14 and not seen[i]);seen[i]=true end
  if previous and previous~=pick then assert(route[1]~=previous) end;previous=route[1]
 end end
 assert(Secret.complete(write) and saved.chaplin_unlocked_v1==true and Secret.pending);assert(not Secret.complete(write));Secret.load(read);assert(Secret.unlocked and not Secret.pending and #Select.visible()==14)
 local ax,ay=Select.card(13,'arcade');local bx,by=Select.card(14,'arcade');assert(ax==bx and by>ay)
 for pick=1,14 do if pick~=13 then
  local route=A.route(pick,14,995+pick,13,nil,Secret.candidates());assert(#route==13 and route[#route]==13)
  local seen={};for _,i in ipairs(route) do assert(i~=pick and not seen[i]);seen[i]=true end
 end end
 local found=false;for t=0,1000 do if Select.preview(13,1,t)==14 then found=true end end;assert(found)
 local b=R.new(100,1);assert(N.incoming(b)==0);R.incoming(b,7,10);assert(N.incoming(b)==7)
 b.pending={};b.grid[R.H][1]=R.cell(1,'blocked',5);b.grid[R.H][1].arrival={age=0,delay=9,ticks=18}
 b.age=26;assert(N.incoming(b)==1);b.age=27;assert(N.incoming(b)==0);assert(N.life()==106 and N.life(80)==100)
 -- Secret does not consume a different puzzle sequence or change Chaplin's old attack pattern.
 assert(R.patterns[14]==R.patterns[1] and R.patterns[10]==R.patterns[1])
 local x,y=R.new(7788,10),R.new(7788,14)
 for n=1,1000 do local p,q=R.next(x),R.next(y);for j=1,2 do assert(p[j].c==q[j].c and p[j].k==q[j].k) end end
 Secret.unlocked=false;Secret.pending=false
 print('RELEASE16: roster, 1200 locked routes, 13 unlocked routes, no repeated opener, secret saves, selector, warning arrivals and shared sequences PASS')
 return true
end
function T.tutorial()
 local U=require('tutorial_approved');local expected={4,4,3,2,3,3,2,4};local total=0
 for lesson=1,8 do
  assert(#U.lessons[lesson].pages==expected[lesson]);total=total+expected[lesson]
  for page=1,expected[lesson] do
   U.enter(lesson,page);assert(U.height<=238 and not U.complete());U.update();local tick=U.tick
   local y=U.active and U.active.y;local before=U.characters;assert(not U.confirm() and U.complete());assert(U.tick==tick and (not U.active or U.active.y==y))
   -- Scene state remains independent after instant text reveal.
   for i=1,1200 do U.update() end
   if lesson==1 or lesson==8 then assert(not U.active and #U.grid[1]==0) end
  end
 end
 assert(total==25)
 U.enter(2,1);for i=1,100 do U.update() end;assert(not U.active and U.pairs==0)
 U.enter(2,2);for i=1,50 do U.update() end;assert(U.active and U.active.turn==0)
 U.enter(2,3);local rotated=false;for i=1,240 do U.update();if U.active and U.active.turn==1 then rotated=true end end;assert(rotated)
 U.enter(3,1);for i=1,200 do U.update() end;assert(not U.sparkDemo.redGone)
 U.enter(3,2);for i=1,60 do U.update() end;assert(U.sparkDemo.redGone and U.sparkDemo.blueY==272)
 U.enter(3,3);for i=1,450 do U.update() end;assert(U.sparkDemo.fourDone[1] and U.sparkDemo.fourDone[2])
 U.enter(4,1);for i=1,1400 do U.update() end;assert(U.cumulusDemo.cols==4 and U.cumulusDemo.rows>=4)
 U.enter(4,2);for i=1,300 do U.update() end;assert(U.cumulusDemo.detonated)
 U.enter(5,1);for i=1,250 do U.update() end;assert(U.dischargeDemo.finished and not U.dischargeDemo.active)
 U.enter(5,2);for i=1,1400 do U.update() end;assert(U.dischargeDemo.activated and U.dischargeDemo.turns==5)
 U.enter(5,3);for i=1,1500 do U.update() end;assert(U.overloaded)
 U.enter(6,1);for i=1,400 do U.update() end;assert(U.chainDemo.stage==1)
 U.enter(6,2);for i=1,200 do U.update() end;assert(U.chainDemo.stage==2)
 U.enter(6,3);for i=1,600 do U.update() end;assert(U.chainDemo.stage==3 and U.chainDemo.done)
 U.enter(7,1);for i=1,200 do U.update() end;assert(U.supercellDemo.y==38 and U.supercellDemo.hoverTick)
 U.enter(7,2);for i=1,300 do U.update() end;assert(U.supercellDemo.detonated and #U.supercellDemo.removed>30)
 for _,col in ipairs(U.supercellDemo.grid) do for _,p in ipairs(col) do assert(p.c~=3) end end
 U.enter(8,4);U.confirm();assert(U.confirm()==true)
 print('TUTORIAL: 8 lessons /25 dialogues, max panel height, independent reveal, directed rotations, bursts, horizontal/vertical growth, incoming activation, overflow, chain x3, supercell and exit PASS')
 return true
end
function T.campaigns()
 local Secret=require('secret_character');local Records=require('records');local AI=require('cpu')
 local originalBtnp,originalBtn=btnp,btn;btn=function()return false end;btnp=function()return false end
 local campaigns,rounds=0,0
 for _,gameMode in ipairs({'classic','ultimate'}) do for who=1,14 do if who~=13 then
  Secret.load(function(_,d)return d end);if who==14 then Secret.unlocked=true end
  mode='arcade';ruleset=gameMode;pick=who;difficulty=3;start_arcade();assert(opponent~=who)
  local total=rawlen(arcadeRoute);local expected=11;assert(total==expected)
  for duel=1,total do
   assert(state=='versus' and arcadeIndex==duel);timer=121;_update();assert(state=='intro')
   for roundNo=1,2 do
    timer=231;_update();assert(state=='play');boards[1].score=100+roundNo;boards[2].dead=true;_update();assert(state=='ko');timer=151;_update();rounds=rounds+1
    assert(state==(roundNo==1 and 'intro' or 'result'))
   end
   timer=31;btnp=function(key)return key=='a' end;_update();btnp=function()return false end
   if duel==total then
    assert(state==(who==14 and 'ending' or 'unlock'));assert(Secret.unlocked and stored(Secret.KEY,false)==true)
   else assert(state=='versus') end
  end
  assert(arcadeScore==expected*203 and Records.run.score==expected*203)
  if state=='unlock' then timer=31;btnp=function(key)return key=='a' end;_update();btnp=function()return false end;assert(state=='ending') end
  timer=46;btnp=function(key)return key=='a' end;_update();btnp=function()return false end;assert(state=='record_entry' or state=='records');assert(not Records.run.active)
  campaigns=campaigns+1
 end end end
 btnp=originalBtnp;btn=originalBtn
 print('CAMPAIGNS',campaigns,'rounds',rounds,'all heroes / both modes / native state flow and once-only score PASS')
 return true
end
return T
