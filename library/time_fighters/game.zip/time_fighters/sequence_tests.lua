return function(batch)
 batch=batch or 0
 local S=require('sequence');local R=require('rules')
 local previous=S.DEFAULT;local seen={}
 for session=1,200 do
  -- Even identical input timing after relaunch must advance the saved seed.
  local seed=S.next(previous,270)
  assert(seed>0 and seed~=previous and not seen[seed],'new session repeated its saved seed')
  seen[seed]=true;previous=seed
  if session%4==batch then
  for round=1,3 do
   local shared=S.round(seed,round)
   assert(shared>0)
   if round>1 then assert(shared~=S.round(seed,round-1)) end
   local human,cpu=R.new(shared,1),R.new(shared,6)
   for pair=1,75 do
    -- Extra CPU decisions / board ages never draw from the piece stream.
    human.age=human.age+37;cpu.age=cpu.age+91
    require('cpu').input(cpu,1)
    local a,b=R.next(human),R.next(cpu)
    for i=1,2 do assert(a[i].c==b[i].c and a[i].k==b[i].k,'players received different streams') end
   end
  end
  end
 end
 assert(S.next(tostring(previous),270)==S.next(previous,270),'saved seed lost precision')
 assert(S.next(S.DEFAULT,200)~=S.next(S.DEFAULT,201),'start timing ignored')
 -- Preserve the existing generator frequencies; no bags or extra sparks are introduced.
 if batch~=0 then return true end
 local totals={0,0,0,0};local sparks,coloured,rays=0,0,0
 for seed=1,8 do
  local board=R.new(S.round(S.next(S.DEFAULT,seed*317),1),1)
  for pair=1,2500 do
   local values=pair==1 and board.next or R.next(board)
   for _,v in ipairs(values) do
    if v.k=='ray' then rays=rays+1;assert(pair%25==0)
    else coloured=coloured+1;totals[v.c]=totals[v.c]+1;if v.k=='spark' then sparks=sparks+1 end end
   end
  end
 end
 assert(rays==800,'ray cadence changed')
 assert(sparks/coloured>.075 and sparks/coloured<.12,'spark proportion changed')
 for c=1,4 do assert(totals[c]/coloured>.24 and totals[c]/coloured<.26,'colour balance changed') end
 return true
end
