local R=require('rules');local AI=require('cpu')
local function fixture(x,bottom,o,level)
 local b=R.new(1729,12)
 for y=2,R.H do
  if x>1 then b.grid[y][x-1]=R.cell(1) end
  if x<6 then b.grid[y][x+1]=R.cell(2) end
  if y>bottom then b.grid[y][x]=R.cell(1) end
 end
 b.phase='fall';b.active={x=x,y=o==0 and bottom or bottom-1,o=o,v={R.cell(3),R.cell(4)},fall=0,lock=0,resets=0}
 b.ai={turn=0,seed=1,target={x=x,o=1},thinkUntil=0,moveAt=0,actions=0,soft=false}
 return b
end
local function occupied(b)
 local rows={};for _,q in ipairs(R.cells(b.active)) do rows[#rows+1]=q.x..':'..q.y end;table.sort(rows);return table.concat(rows,',')
end
return function(column,floor,chosenLevel)
 local scenarios,maxTicks=0,0
 for x=column,column do for bottom=floor,floor do for _,o in ipairs({0,2}) do for _,direction in ipairs({-1,1}) do
  local b=fixture(x,bottom,o);local pair=b.active.v;local space=occupied(b)
  assert(R.rotate(b,direction),'vertical swap refused at floor')
  assert(occupied(b)==space,'vertical swap lifted/shifted pair')
  assert(b.active.o==(o+2)%4 and b.active.resets==1,'rotation/reset contract')
  assert(R.fits(b,b.active),'rotation overlaps stack')
  assert(R.rotate(b,direction) and occupied(b)==space and b.active.o==o,'swap back changed occupied cells')
  assert(b.active.v==pair,'piece identities changed')
 end end end end
 -- The exact unreachable CPU target from the reported symptom, on all levels,
 -- at both edges and every supported floor. It must fix the pair and progress.
 for x=column,column do for bottom=floor,floor do for _,o in ipairs({0,2}) do for level=chosenLevel,chosenLevel do
  local b=fixture(x,bottom,o);local pair=b.active.v;local ticks=0
  while b.turn==0 and ticks<600 do
   local space=occupied(b);R.step(b,AI.input(b,level));ticks=ticks+1
   if b.active then assert(occupied(b)==space,'grounded CPU pair left its two cells') end
  end
  assert(b.turn==1 and not b.dead and not b.active,'CPU never fixed its pair')
  assert(b.grid[bottom][x] and b.grid[bottom-1][x],'locked pair missing')
  local a,z=b.grid[bottom][x],b.grid[bottom-1][x]
  assert((a==pair[1] and z==pair[2]) or (a==pair[2] and z==pair[1]),'pair lost/duplicated')
  local old=b.turn
  for _=1,60 do R.step(b) end
  assert(b.active and b.turn==old,'next pair did not spawn')
  scenarios=scenarios+1;maxTicks=math.max(maxTicks,ticks)
 end end end end
 -- Continuous player rotations must also exhaust the same eight-reset budget.
 for _,down in ipairs({false,true}) do
  local b=fixture(4,R.H,2);local ticks=0
  while b.turn==0 and ticks<60 do R.step(b,{cw=true,down=down});ticks=ticks+1 end
  assert(b.turn==1 and ticks<=32,'holding rotation stalled lock')
 end
 -- Preserve normal flat-space rotation and horizontal wall kicks.
 local b=R.new(1,1);R.spawn(b);b.active.y=5
 for i=1,4 do assert(R.rotate(b,1));assert(b.active.o==i%4 and b.active.y==5) end
 b.active.x=1;assert(R.rotate(b,-1) and b.active.x==2 and b.active.o==3,'left wall kick changed')
 b.active.x=6;b.active.o=0;assert(R.rotate(b,1) and b.active.x==5 and b.active.o==1,'right wall kick changed')
 narrowWellScenarios=(narrowWellScenarios or 0)+scenarios;narrowWellMaxTicks=math.max(narrowWellMaxTicks or 0,maxTicks)
 return true
end
