-- Selection presentation has its own clock; it never draws from the puzzle RNG.
local S={RANDOM=13,COUNT=12,confirmTicks=72,confirmed={0,0},randomLocked={false,false}}
function S.reset(t)
 S.entered=t or 0;S.confirmed={0,0};S.randomLocked={false,false}
end
local Secret=require("secret_character")
function S.visible() local list=Secret.candidates();list[#list+1]=S.RANDOM;return list end
function S.preview(cursor,side,t)
 if cursor~=S.RANDOM then return cursor end
 local list=Secret.candidates();return list[((math.max(0,(t or 0)-(S.entered or 0))//4)+(side-1)*5)%#list+1]
end
function S.card(i,mode)
 if mode=='versus' then
  if i==S.RANDOM then return 284,42,40,44 end
  if i==Secret.CHAPLIN then return 284,90,40,44 end
  return 152+((i-1)%3)*44,42+((i-1)//3)*48,40,44
 end
 if i==S.RANDOM then return 430,40,46,50 end
 if i==Secret.CHAPLIN then return 430,94,46,50 end
 return 280+((i-1)%3)*50,40+((i-1)//3)*54,46,50
end
function S.navigate(cursor,direction,mode)
 local x,y,w,h=S.card(cursor,mode);x=x+w/2;y=y+h/2
 local horizontal=direction=='left' or direction=='right'
 local sign=(direction=='left' or direction=='up') and -1 or 1
 local best,bestScore
 for _,i in ipairs(S.visible()) do if i~=cursor then
  local a,b,c,d=S.card(i,mode);a=a+c/2;b=b+d/2
  local along=horizontal and (a-x)*sign or (b-y)*sign
  local across=math.abs(horizontal and b-y or a-x)
  if along>0 then
   local score=along+across*5
   if not bestScore or score<bestScore then best=i;bestScore=score end
  end
 end end
 if best then return best end
 -- Wrap to the opposite edge, prioritising the same row/column.
 for _,i in ipairs(S.visible()) do if i~=cursor then
  local a,b,c,d=S.card(i,mode);a=a+c/2;b=b+d/2
  local across=math.abs(horizontal and b-y or a-x)
  local edge=horizontal and a*sign or b*sign
  local score=across*1000+edge
  if not bestScore or score<bestScore then best=i;bestScore=score end
 end end
 return best or cursor
end
function S.confirm(cursor,side,t)
 S.randomLocked[side]=cursor==S.RANDOM;S.confirmed[side]=t
 return S.preview(cursor,side,t)
end
function S.cancel(side,current)
 local cursor=S.randomLocked[side] and S.RANDOM or current
 S.randomLocked[side]=false;S.confirmed[side]=0
 return cursor
end
return S
