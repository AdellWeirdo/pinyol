-- Exact approved snapshot, private dependencies and asset IDs.
local Assets=require('cin50_marilyn_assets');local img=Assets.img;local imgsize=Assets.size
-- Presentation-only review: camera crowd replaces the former prop and energy waves.
local M={};local C=require('cin50_marilyn_roster');local Idle=require('cin50_marilyn_idle');local K=require('cin50_marilyn_knockdown')
local flashes={105,121,137,153,170,187,204,221,237}
local function puff(x,y,age,scale,alpha)
 if age<0 or age>42 then return end
 local phase=age<6 and 0 or age<30 and 1+((age//6)%3) or age<36 and 4 or 5
 img('SMOKE_PUFF_BEETHOVEN',x-48*scale,y-48*scale,{frame=phase,scale=scale,alpha=(alpha or 1)*math.min(1,age/5)*math.min(1,(42-age)/8)})
end
local function hero(f)
 if f<48 then
  img('IDLE_MARILYN',76-56*1.18,293-120*1.18,{frame=Idle.frame(f),scale=1.18});return
 end
 -- A single progressive kiss: the release is never repeated during the special.
 local ends={58,69,80,90,99,110,123,137,151,165,177}
 local frame=11
 for i,limit in ipairs(ends)do if f<limit then frame=i-1;break end end
 -- Last two drawings only: same extended arm, tiny breath, no replay of the kiss.
 if f>=177 then frame=10+((f-177)//22)%2 end
 img('MARILYN_KISS',76-56*1.18,293-148*1.18,{frame=frame,scale=1.18})
end

local function crowd(f)
 if f<78 or f>=267 then return end
 local age=f-78;local x=-335+age*4.72
 -- Several staggered approved rounded puffs follow feet, never baked into the crowd.
 for j=0,4 do
  local phase=(age+j*9)%36
  puff(x+25+j*48-phase*.65,282,phase,.72+(j%2)*.17,.84)
 end
 img('MARILYN_PAPARAZZI',x,97,{frame=(age//5)%4,scale=1})
 -- Oversized photographic starbursts: expanding white core, eight broad rays,
 -- and delayed neighbouring bulbs. Same nine F2 audio cues; no new sounds.
 local points={{165,35},{100,55},{278,77},{233,83},{167,119},{286,136},{106,111}}
 local function burst(fx,fy,age,power)
  if age<0 or age>=9 then return end
  local envelope=age<2 and (.85+age*.15) or (1-(age-2)/7)
  local size=(68+math.sin(age*1.8)*5)*envelope*power
  local inner=12*envelope*power
  local function star(radius,waist,colour)
   local pts={}
   for j=0,15 do
    local angle=j*math.pi/8;local r=j%2==0 and radius or waist
    pts[#pts+1]=fx+math.cos(angle)*r;pts[#pts+1]=fy+math.sin(angle)*r
   end
   poly(pts,colour)
  end
  star(size,inner*1.5,0xffd7a0)
  star(size*.79,inner,0xffffe6)
  circ(fx,fy,math.max(2,22*envelope*power),0xfff0ce)
  star(size*.56,inner*.65,0xffffff)
  circ(fx,fy,math.max(2,14*envelope*power),0xffffff)
  for j=0,3 do
   local angle=j*math.pi/2+age*.22
   local rr=size*.69+age*2
   local sx=fx+math.cos(angle)*rr;local sy=fy+math.sin(angle)*rr
   circ(sx,sy,math.max(1,3-age*.25)*power,0xffffff)
  end
 end
 for i,start in ipairs(flashes) do
  local age=f-start
  if age>=0 and age<13 then
   local v=points[(i-1)%#points+1]
   burst(x+v[1],97+v[2],age,1)
   local neighbour=points[(i+1)%#points+1]
   burst(x+neighbour[1],97+neighbour[2],age-3,.64)
  end
 end
end
local function rival(enemy,f)
 local scale=1.05
 if f<160 then img('IDLE_'..C[enemy].id,392-(148-56)*scale,293-120*scale,{frame=Idle.frame(f),flip_x=true,scale=scale})
 elseif f<211 then img('FIGHTER_'..C[enemy].id,392-(148-56)*scale,293-120*scale,{frame=14,flip_x=true,scale=scale})
 else img('KNOCKDOWN_'..C[enemy].id,392-96*scale,293-120*scale,{frame=K.frame(f-211),flip_x=true,scale=scale})end
end
local function impact_cloud(f)
 if f<164 or f>=295 then return end
 local puffs={{404,187,1.15,164},{414,232,1.2,168},{381,272,1.25,171},{338,239,1.05,174},{350,190,.88,180}}
 for i,c in ipairs(puffs)do
  local age=f-c[4]
  if age>=0 then
   local fadeStart=254+i*3;local dissolve=math.max(0,f-fadeStart)
   local grow=math.min(1,age/8);local scale=c[3]*(.72+.28*grow)
   local phase=age<7 and 0 or f<fadeStart and 1+((age//7)%3) or dissolve<12 and 4 or 5
   img('SMOKE_PUFF_BEETHOVEN',c[1]-48*scale+math.sin(age*.12+i)*2,c[2]-48*scale-dissolve*.4,{frame=phase,scale=scale,alpha=math.max(0,1-dissolve/23)})
  end
 end
end
function M.draw(f,enemy)
 img('STAGE_MARILYN',0,0)
 if f>40 then img('SPECIAL_MARILYN',0,0,{alpha=math.min(1,(f-40)/30)})end
 rival(enemy,f);crowd(f);hero(f);impact_cloud(f)
end
return M
