return function()
 local A=require('arcade');local count,signatures=0,{}
 for _,unlocked in ipairs({false,true})do
  local eligible={};for i=1,12 do eligible[#eligible+1]=i end;if unlocked then eligible[#eligible+1]=14 end
  for _,pick in ipairs(eligible)do
   local appearances,previous={},nil;local regular=#eligible-1
   for campaign=1,regular*30 do
    local route=A.route(pick,14,campaign*8191+pick*997,13,previous,eligible,10,appearances)
    assert(#route==11 and route[11]==13);local seen={}
    for i,who in ipairs(route)do
     assert(who~=pick and not seen[who] and (who~=14 or unlocked));seen[who]=true
     if i<11 then appearances[who]=(appearances[who] or 0)+1 end
    end
    if previous then assert(route[1]~=previous)end;previous=route[1]
    local lo,hi=math.huge,0
    for _,who in ipairs(eligible)do if who~=pick then lo=math.min(lo,appearances[who] or 0);hi=math.max(hi,appearances[who] or 0)end end
    assert(hi-lo<=1,'unfair exposure')
    if campaign%regular==0 then assert(hi==lo,'frequency cycle did not balance')end
    if pick==1 then signatures[table.concat(route,',')]=true end
    count=count+1
   end
  end
 end
 local n=0;for _ in pairs(signatures)do n=n+1 end;assert(n>500)
 -- Tesla remains the hardest, with gradual escalation across the new eleven duels.
 local previous=0;for i=1,11 do local level=A.level(3,i,11);assert(level>=previous);previous=level end
 assert(A.level(3,11,11)>A.level(3,10,11))
 print('ARCADE161',count,'balanced campaigns; 10 regular + Tesla, no duplicates/self, first-rival variety, equal frequency cycles and final difficulty PASS')
 return true
end
