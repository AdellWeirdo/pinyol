-- Presentation only: pending packets plus counters still travelling into the well.
local N={}
function N.incoming(b)
 local n=require('rules').pending(b)
 for _,row in pairs(b.grid) do for _,v in pairs(row) do
  local a=v and v.arrival
  if a and b.age<a.age+a.delay+a.ticks then n=n+1 end
 end end
 return n
end
function N.life(base) return math.floor((base or 85)*1.25+.5) end
return N
