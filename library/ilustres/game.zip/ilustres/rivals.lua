-- The personal rivals (GDD 8.2): before the arcade's fight with one's rival, a short scene. The two meet in a picture
-- of their own (art/rivals.py) and say four lines, each typed out in a box with the speaker's face and name; A shows
-- the rest of a line or goes on, START skips it all; then the VS screen. Rivalries of ideas, not of history.
local hud = require("hud")
local gfx = require("gfx")
local F = require("fighters")

local M = {}

-- {a, b, lines}: a stands on the picture's left, b on its right; each line {who, words}
M.SCENES = {
  {"dali", "miro", {
    {"dali", "JOAN! HAS VINGUT A PINTAR-ME UN ESTEL AL BIGOTI?"},
    {"miro", "HE VINGUT A ESBORRAR-TE'L. AMB TRES TRAÇOS EN TINC PROU."},
    {"dali", "TRES TRAÇOS! JO EN NECESSITO UN DE SOL: EL MEU."},
    {"miro", "DONCS PINTEM. QUI QUEDI DRET, SIGNA LA TELA."}}},
  {"gaudi", "cerda", {
    {"gaudi", "SENYOR CERDÀ, DES D'AQUÍ DALT LA SEVA CIUTAT SEMBLA UN TAULELL D'ESCACS."},
    {"cerda", "I LA SEVA CATEDRAL, MESTRE, UNA OBRA QUE NO S'ACABA MAI."},
    {"gaudi", "EL MEU CLIENT NO TÉ PRESSA. A LA NATURA NO HI HA CAP ANGLE RECTE."},
    {"cerda", "PER AIXÒ ALS MEUS CARRERS HI VAIG POSAR XAMFRANS. COMENCEM."}}},
  {"fabra", "verdaguer", {
    {"verdaguer", "MESTRE FABRA, HA PUJAT FINS AL CANIGÓ PER CORREGIR-ME ELS ACCENTS?"},
    {"fabra", "HE PUJAT PERQUÈ TOTHOM EL PUGUI LLEGIR IGUAL, MOSSÈN."},
    {"verdaguer", "LA POESIA NO ES CORREGEIX. ES CANTA."},
    {"fabra", "CANTI, DONCS. JO LI PORTO LA PARTITURA."}}},
  {"casals", "caballe", {
    {"casals", "SENYORA, AQUESTA NIT EL VIOLONCEL OBRE EL CONCERT."},
    {"caballe", "MESTRE, AL LICEU LA PRIMERA NOTA SEMPRE ÉS MEVA."},
    {"casals", "LLAVORS FEM UN DUO. QUI DESAFINI, PERD."},
    {"caballe", "QUE S'AIXEQUI EL TELÓ!"}}},
  {"rodoreda", "catala", {
    {"rodoreda", "CATERINA, BAIXES DE LA MUNTANYA AMB TOTA LA SOLITUD A L'ESQUENA."},
    {"catala", "I TU, MERCÈ, VENS DE LA PLAÇA AMB TOTS ELS COLOMS."},
    {"rodoreda", "ELS MEUS COLOMS VOLEN. QUÈ FAN, LES TEVES PEDRES?"},
    {"catala", "AGUANTEN. COM JO. PROVA DE MOURE'M."}}},
  {"llull", "brossa", {
    {"llull", "COMBINO LES LLETRES PER TROBAR LA VERITAT, JOVE."},
    {"brossa", "I JO LES DESMUNTO PER TROBAR-NE UNA DE MILLOR."},
    {"llull", "LA MEVA RODA TÉ NOU PRINCIPIS. I LA TEVA?"},
    {"brossa", "UN BARRET DE COPA I UN CONILL. ENDAVANT, MESTRE!"}}},
  {"rusinol", "tapies", {
    {"rusinol", "A SITGES PINTEM LA LLUM, TÀPIES. TU PINTES LA PARET?"},
    {"tapies", "LA PARET TAMBÉ PARLA. NOMÉS CAL ESCOLTAR-LA."},
    {"rusinol", "JO ESCOLTO EL MAR, I EL MAR CANTA MÉS FORT."},
    {"tapies", "DONCS QUE PARLI LA MATÈRIA."}}},
  {"pla", "peret", {
    {"pla", "TANTA GUITARRA A AQUESTES HORES... A L'EMPORDÀ, DE NIT, ES CONVERSA."},
    {"peret", "DONCS CONVERSEM A RITME DE RUMBA, SENYOR PLA!"},
    {"pla", "HO APUNTARÉ AL QUADERN: AVUI, UN PERET."},
    {"peret", "APUNTI-HO DE PRESSA, QUE LA RUMBA NO S'ESPERA!"}}},
  {"patufet", "tio", {
    {"patufet", "TIÓ! DIUEN QUE SI ET PICO, CAGARÀS TORRONS!"},
    {"tio", "I SI JO ET PICO A TU, PATUFET, ON ET TROBARAN?"},
    {"patufet", "A LA PANXA DEL BOU NO, QUE JA HI HE ESTAT!"},
    {"tio", "DONCS SOTA LA MEVA MANTA. PICA, SI POTS!"}}},
  {"princesa", "gaudi", {
    {"princesa", "MESTRE, EL SEU DRAC DE TRENCADÍS ÉS MOLT BONIC. EL MEU ERA DE VERITAT."},
    {"gaudi", "I EL VAS DOMAR TU SOLA, DIUEN. SENSE CAVALLER."},
    {"princesa", "EL CAVALLER VA ARRIBAR TARD. COM LES SEVES OBRES."},
    {"gaudi", "LES BONES OBRES NO TENEN PRESSA. VINGA, PRINCESA."}}},
  {"timbaler", "verdaguer", {
    {"timbaler", "MOSSÈN, VOSTÈ CANTA LA MUNTANYA. JO LA FAIG SONAR."},
    {"verdaguer", "EL TEU TAMBOR VA ESPANTAR UN EXÈRCIT, NOI. A MI NO M'ESPANTA."},
    {"timbaler", "QUE DECIDEIXI L'ECO DE MONTSERRAT."},
    {"verdaguer", "QUE PARLI LA MUNTANYA, DONCS."}}},
}

function M.art(s) return s.pic or "RIVAL_" .. s[1]:upper() .. "_" .. s[2]:upper() end

-- The arcade's story around the fights, in the same box: the invitation that starts it (on the chosen one's home
-- stage) and the producer's last word after his defeat (on his set). A line's speaker "narrator" has no face.
local function say(template, ...) return string.format(T(template), ...) end

function M.prologue(d)
  local st = require("stage").LIST[d.stage]
  return {d.key, nil, tag = "PRÒLEG", pic = st and st.far, px = -80, {
    {"narrator", say("UN SOBRE DAURAT ARRIBA A CASA DE %s.", d.name)},
    {"narrator", "«US CONVIDEM A IL·LUSTRES: EL COMBAT DEFINITIU DE LA CULTURA CATALANA. EN DIRECTE.»"},
    {"narrator", "«DOTZE COMBATS. UN SOL CAMPIÓ. LES CÀMERES JA RODEN.» SIGNAT: J.J."},
    {d.key, d.quote}}}
end

function M.epilogue(d)
  return {"productor", d.key, tag = "EPÍLEG", pic = "BG_FAR_PLATO", px = -80, {
    {"productor", "TALLEM! ... NO. NO TALLEM. AQUESTA PRESA ÉS PERFECTA."},
    {d.key, d.wins.productor or d.wins.default or d.quote},
    {"productor", "EL TROFEU ÉS TEU. I L'AUDIÈNCIA, TAMBÉ. JO ME'N VAIG A ESCRIURE LA SEGONA TEMPORADA."}}}
end

function M.find(a, b) -- the scene of a against b, either way round, if its picture is there
  for _, s in ipairs(M.SCENES) do
    if (s[1] == a and s[2] == b) or (s[1] == b and s[2] == a) then return gfx.has(M.art(s)) and s or nil end
  end
end

local SPEED, WAIT = 2, 150 -- ticks a letter; ticks a whole line stays before the next comes by itself
local FADE = 24

function M.new(scene) return {scene = scene, line = 1, from = FADE} end

-- returns "done" once the last line is over (or START), else nil
function M.tick(r, t)
  if btnp("start") then return "done" end
  local words = T(r.scene[3][r.line][2])
  local full = t - r.from >= (utf8.len(words) or #words) * SPEED
  if t < r.from then return nil end
  if btnp("a") and not full then -- the rest of the line at once
    r.from = t - (utf8.len(words) or #words) * SPEED
  elseif (btnp("a") and full) or (full and t - r.from > (utf8.len(words) or #words) * SPEED + WAIT) then
    if r.line == #r.scene[3] then return "done" end
    r.line, r.from = r.line + 1, t
    sfx("SND_MOVE", 0.4)
  end
end

local BOX_X, BOX_Y, BOX_W, BOX_H = 8, 228, 464, 84 -- the dialogue box, over the picture's calm lower quarter
local FACE_W, FACE_H = 50, 37
M.BOX = {BOX_X, BOX_Y, BOX_W, BOX_H}
local NAME = {color = 0xFFE070, gradient = 0xFF8020}
local NAME_B = {color = 0x90D8FF, gradient = 0x4090E0, align = "right"}
local LINE = {font = "small", color = 0xFFFFFF, plain = true}
local LINE_B = {font = "small", color = 0xFFFFFF, plain = true, align = "right"}
local TAG = {font = "small", align = "center", color = 0xFFE070}
local NARRATOR = {font = "small", align = "center", color = 0xFFE8B0, plain = true}
local HINT = {font = "small", align = "right", color = 0xC0C8E0}

function M.draw(r, t)
  local s = r.scene
  if not gfx.pic(M.art(s), s.px or 0, 0) then rect(0, 0, 480, 320, 0x0C1428) end
  if s.pic then shade(0, 0, 480, 320) end -- (a stage behind the words: darker, it is not the scene's own picture)
  if t < FADE then for _ = 1, (FADE - t) // 6 do shade(0, 0, 480, 320) end end
  local tag = T(s.tag or "RIVAL") -- the scene's title, and how to skip it
  local tw = math.max(100, textw(tag, TAG) + 24)
  hud.plate(240 - tw // 2, 6, tw, 22)
  hud.cap(tag, 240, 11, TAG)
  local skip = T("START: SALTA")
  local w = textw(skip, HINT) + 16
  hud.plate(472 - w, 6, w, 22)
  hud.cap(skip, 464, 11, HINT)
  local who, words = s[3][r.line][1], s[3][r.line][2]
  local d = F.by_key[who]
  local right = who == s[2] -- the speaker's face and name on their own side of the box, as they stand
  rect(BOX_X, BOX_Y, BOX_W, BOX_H, 0x0A0C16)
  box(BOX_X, BOX_Y, BOX_W, BOX_H, 0xC09030)
  local shown = math.max(0, (t - r.from) // SPEED)
  if not d then -- the narrator: no face, the words in the middle of the box
    hud.wrap(words, 240, BOX_Y + 22, BOX_W - 48, 16, NARRATOR, shown)
    if shown >= (utf8.len(T(words)) or #words) and t // 20 % 2 == 0 then
      tri(BOX_X + BOX_W - 18, BOX_Y + BOX_H - 12, BOX_X + BOX_W - 10, BOX_Y + BOX_H - 12, BOX_X + BOX_W - 14, BOX_Y + BOX_H - 7, 0xFFE070)
    end
    return
  end
  local fx = right and BOX_X + BOX_W - 10 - FACE_W or BOX_X + 10
  gfx.portrait(d.portrait, fx, BOX_Y + 10, "c")
  box(fx - 1, BOX_Y + 9, FACE_W + 2, FACE_H + 2, 0xC09030)
  local tx = right and fx - 12 or fx + FACE_W + 12
  hud.cap(d.name, tx, BOX_Y + 12, right and NAME_B or NAME)
  hud.wrap(words, tx, BOX_Y + 36, BOX_W - FACE_W - 44, 14, right and LINE_B or LINE, shown)
  local n = utf8.len(T(words)) or #words
  if shown >= n and t // 20 % 2 == 0 then -- the line is out: a sign that A goes on
    local ax = right and BOX_X + 14 or BOX_X + BOX_W - 14
    tri(ax - 4, BOX_Y + BOX_H - 12, ax + 4, BOX_Y + BOX_H - 12, ax, BOX_Y + BOX_H - 7, 0xFFE070)
  end
end

return M
