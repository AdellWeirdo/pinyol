-- The fighters: who they are, every blow they have, what they say. Times in ticks (60 a second), distances in
-- screen pixels. A box is {x, y, w, h} from the feet: x forward from the body's middle, y up is negative. Damage
-- follows the GDD's ranges (light 30-45, strong 60-90, special 80-140, SUPER 220-300, throw 90-120).
--
-- Frames, five per generated sheet (art/sheets.py, in this order). 0-49 are the first strip (SPR_<NAME>), 50-79
-- the second (SPR_<NAME>2: one picture holds 64 frames at most):
--   0-4 idle, 5-9 walk, 10 block, 11 crouch, 12 crouching block, 13 jump, 14 jump kick, 15-16 light punch,
--   17-19 strong punch, 20-21 light kick, 22-24 strong kick, 25-26 sweep, 27-29 throw, 30 hit high, 31 hit low,
--   32 falling, 33 lying, 34 getting up, 35-39 special, 40-44 SUPER, 45-47 victory, 48-49 taunt,
--   50-54 jump (take-off, rise, top, fall, landing), 55 crouching jab, 56-57 crouching uppercut, 58-59 air punches,
--   60-61 dash, 62 backstep, 63-64 roll, 65-69 second special, 70-74 intro, 75-79 SUPER's second half.
local F = {}

F.frames = {idle = {0, 1, 2, 3, 4}, walk = {5, 6, 7, 8, 9}, block = 10, crouch = 11, cblock = 12, jump = 13,
            jkick = 14, hurt = 30, hurt_low = 31, fall = 32, lie = 33, rise = 34, throw = {27, 28, 29},
            win = {45, 46, 47}, taunt = {48, 49}, super = {40, 41, 42, 43, 44, 75, 76, 77, 78, 79},
            squat = 50, rise_air = 51, top = 52, drop = 53, land = 54,
            dash = {60, 61}, back = 62, roll = {63, 64}, intro = {70, 71, 72, 73, 74}}
F.STRIP = 50 -- frames from here are in the second picture
F.CHUNK = 10 -- frames to a piece of a sheet: SPR_<NAME>_C0..C4 and SPR_<NAME>2_C0..C2 (tools/pk_split.py, run by art.py): on the console a sheet
-- of 600 KB found no block in a heap that had run a while and its fighter was invisible, pieces of 100-200 KB find room (gfx.fighter)

-- Shared by both: a crouching jab (mid) and a crouching uppercut that knocks jumpers out of the air.
local function normals(t)
  t.DA = {s = {11}, a = {55}, r = {11}, startup = 4, active = 3, recovery = 8, dmg = 30, stun = 14, bstun = 10,
          box = {18, -84, 76, 22}, push = 5, crouch = true, chain = {DA = true, DC = true, B = true}, cancel = true}
  t.DB = {s = {57}, a = {56}, r = {57}, startup = 7, active = 5, recovery = 20, dmg = 66, stun = 20, bstun = 14,
          box = {6, -214, 70, 150}, push = 8, crouch = true, cancel = true}
  return t
end

-- s/a/r: the frames shown while a blow starts, hits and recovers. chain: normals it can go on to when it touched;
-- cancel: a special or SUPER can cut it short when it touched. Air blows (J*) have one frame.
F.dali = {
  key = "dali", name = "SALVADOR DALÍ", short = "DALÍ", alias = "EL GENI PARANOIC", style = "SURREALISME",
  quote = "«LA REALITAT TAMBÉ ÉS UN SOMNI»", stats = {4, 3, 3, 5}, art = "SPR_DALI", portrait = 0,
  super_bg = "BG_SUPER_DALI", colour = 0x3A4AA0, stage = "cadaques", ending_art = "END_DALI",
  hp = 960, walk = 2.6, back = 2.2,
  vs = {default = "SÓC L'ÚNIC GENI DEL TORNEIG. ELS ALTRES SÓN DECORAT.",
        gaudi = "ARQUITECTE, LES TEVES TORRES ES FONDRAN COM EL MEU RELLOTGE.",
        miro = "JOAN! TU PINTES ESTRELLES. JO SÓC UNA ESTRELLA.",
        fabra = "MESTRE FABRA, AVUI ELS MEUS BIGOTIS NO TENEN ORTOGRAFIA.",
        dali = "UN ALTRE DALÍ? IMPOSSIBLE. O GENIAL."},
  wins = {default = "SURREALISME: QUAN EL RIVAL NO ENTÉN QUÈ L'HA TOCAT.",
          gaudi = "LA TEVA CATEDRAL ÉS BONICA, PERÒ LA MEVA BOGERIA ÉS MÉS ALTA.",
          miro = "LES TEVES ESTRELLES BRILLEN. LES MEVES ES FONEN AMB ESTIL.",
          fabra = "CORREGEIX AIXÒ, MESTRE: GALA, GENI, GLÒRIA. TOT AMB G.",
          dali = "NOMÉS HI HA UN DALÍ. L'ALTRE ERA UN SOMNI."},
  rival = "miro",
  ending = {"DALÍ TORNA A PORTLLIGAT AMB EL TROFEU DEL TORNEIG.",
            "AL CAP DE TRES DIES, EL TROFEU ES FON.",
            "«PERFECTE», DIU. «ARA ÉS UNA OBRA MEVA.»",
            "EL PINTA EN UNA TELA GEGANT: EL COMBAT QUE VA GUANYAR ABANS DE COMENÇAR-LO."},
  moves = normals({
    A = {s = {15}, a = {16}, r = {15}, startup = 4, active = 3, recovery = 8, dmg = 32, stun = 15, bstun = 11,
         box = {24, -134, 74, 24}, push = 5, chain = {B = true, FC = true, DA = true}, cancel = true},
    B = {s = {17}, a = {18}, r = {19}, startup = 10, active = 4, recovery = 22, dmg = 60, stun = 22, bstun = 16,
         box = {40, -132, 110, 26}, push = 10, cancel = true},
    C = {s = {20}, a = {21}, r = {20}, startup = 5, active = 3, recovery = 10, dmg = 38, stun = 16, bstun = 11,
         box = {22, -146, 86, 28}, push = 6, chain = {B = true, FC = true}, cancel = true},
    FC = {s = {22}, a = {23}, r = {24}, startup = 11, active = 4, recovery = 18, dmg = 78, stun = 22, bstun = 16,
          box = {28, -186, 100, 44}, push = 10, cancel = true},
    DC = {s = {26}, a = {25}, r = {26}, startup = 7, active = 4, recovery = 20, dmg = 60, stun = 0, bstun = 14,
          box = {20, -30, 106, 30}, hits = "low", push = 8, knock = true, crouch = true, cancel = true},
    J = {frame = 14, startup = 4, active = 14, dmg = 55, stun = 18, bstun = 12, box = {6, -72, 76, 46}, hits = "high",
         push = 5},
    JA = {frame = 58, startup = 3, active = 10, dmg = 42, stun = 16, bstun = 10, box = {14, -96, 70, 40},
          hits = "high", push = 4},
    JB = {frame = 59, startup = 6, active = 8, dmg = 68, stun = 20, bstun = 14, box = {-10, -110, 110, 70},
          hits = "high", push = 6},
    special = {s = {35, 36}, a = {37}, r = {38, 39}, startup = 13, active = 2, recovery = 26, kind = "special",
               spawn = "clock", name = "RELLOTGE TOU"},
    special2 = {s = {65, 66}, a = {67}, r = {68, 69}, startup = 12, active = 18, recovery = 18, kind = "special",
                spawn = "melt", name = "PERSISTÈNCIA"},
    super = {length = 84, spawn = "rain", name = "EXPLOSIÓ DE RELLOTGES"},
  }),
}

F.gaudi = {
  key = "gaudi", name = "ANTONI GAUDÍ", short = "GAUDÍ", alias = "L'ARQUITECTE IMPOSSIBLE", style = "MODERNISME",
  quote = "«LA NATURA ÉS LA MEVA MESTRA»", stats = {4, 4, 2, 4}, art = "SPR_GAUDI", portrait = 3,
  super_bg = "BG_SUPER_GAUDI", colour = 0x8A5A30, stage = "parkguell", ending_art = "END_GAUDI",
  hp = 1060, walk = 2.2, back = 1.9,
  vs = {default = "LA LÍNIA RECTA ÉS DELS HOMES. LA CORBA ÉS DE DÉU.",
        cerda = "SENYOR CERDÀ, LA SEVA QUADRÍCULA NO TÉ CAP CORBA. AVUI EN TINDRÀ.",
        dali = "SENYOR DALÍ, LA LÍNIA RECTA ÉS DELS HOMES. LA CORBA ÉS DE DÉU.",
        miro = "JOVE MIRÓ, EL TRENCADÍS JA ERA ABSTRACTE ABANS QUE TU.",
        fabra = "VÓS CONSTRUÏU LA LLENGUA, JO LES PEDRES. VEGEM QUI AGUANTA.",
        gaudi = "UN ALTRE GAUDÍ? EL TEMPLE ENCARA NO ESTÀ ACABAT."},
  wins = {default = "LA NATURA ÉS LA MEVA MESTRA. I AVUI M'HA ENSENYAT BÉ.",
          cerda = "UNA CRUÏLLA ÉS BONICA. UNA CORBA, ETERNA.",
          dali = "ELS TEUS RELLOTGES ES FONEN. LES MEVES PEDRES, NO.",
          miro = "BONS COLORS, NOI. ARA FALTA L'ESTRUCTURA.",
          fabra = "UNA LLENGUA ES FA PEDRA A PEDRA, MESTRE. COM UN TEMPLE.",
          gaudi = "EL MEU CLIENT NO TÉ PRESSA. JO TAMPOC."},
  rival = "cerda",
  ending = {"GAUDÍ PUJA A LA BASTIDA MÉS ALTA DE LA SAGRADA FAMÍLIA.",
            "COL·LOCA EL TROFEU AL CIM D'UNA TORRE QUE ENCARA NO EXISTEIX.",
            "«QUAN L'ACABIN», DIU, «JA EL TROBARAN.»",
            "A BAIX, BARCELONA ENCÉN ELS FOCS. ENCARA QUEDA MOLT PER FER."},
  moves = normals({
    A = {s = {15}, a = {16}, r = {15}, startup = 5, active = 3, recovery = 8, dmg = 36, stun = 15, bstun = 11,
         box = {28, -130, 64, 24}, push = 5, chain = {B = true, FC = true, DA = true}, cancel = true},
    B = {s = {17}, a = {18}, r = {19}, startup = 11, active = 4, recovery = 18, dmg = 82, stun = 22, bstun = 16,
         box = {34, -134, 84, 30}, push = 12, cancel = true},
    C = {s = {20}, a = {21}, r = {20}, startup = 6, active = 3, recovery = 10, dmg = 40, stun = 16, bstun = 11,
         box = {24, -116, 78, 28}, push = 6, chain = {B = true, FC = true}, cancel = true},
    FC = {s = {22}, a = {23}, r = {24}, startup = 12, active = 4, recovery = 19, dmg = 85, stun = 22, bstun = 16,
          box = {28, -156, 88, 34}, push = 12, cancel = true},
    DC = {s = {26}, a = {25}, r = {26}, startup = 8, active = 4, recovery = 20, dmg = 65, stun = 0, bstun = 14,
          box = {20, -30, 98, 30}, hits = "low", push = 8, knock = true, crouch = true, cancel = true},
    J = {frame = 14, startup = 4, active = 14, dmg = 60, stun = 18, bstun = 12, box = {6, -72, 72, 46}, hits = "high",
         push = 5},
    JA = {frame = 58, startup = 3, active = 10, dmg = 44, stun = 16, bstun = 10, box = {14, -96, 66, 40},
          hits = "high", push = 4},
    JB = {frame = 59, startup = 7, active = 8, dmg = 74, stun = 20, bstun = 14, box = {0, -96, 96, 70},
          hits = "high", push = 6},
    special = {s = {35, 36}, a = {37}, r = {38, 39}, startup = 16, active = 2, recovery = 26, kind = "special",
               spawn = "pinnacle", name = "PINACLE"},
    special2 = {s = {65, 66}, a = {67}, r = {68, 69}, startup = 14, active = 2, recovery = 22, kind = "special",
                spawn = "salamander", name = "SALAMANDRA"},
    super = {length = 76, spawn = "wave", name = "ONADA DE TRENCADÍS"},
  }),
}

local function common(t) -- the blows every fighter has the shape of, with its own reach and damage
  return normals(t)
end

F.fabra = {
  key = "fabra", name = "POMPEU FABRA", short = "FABRA", alias = "EL CORRECTOR DEFINITIU", style = "NORMATIVA",
  quote = "«LA CORRECCIÓ TAMBÉ ÉS UN COMBAT»", stats = {3, 5, 3, 5}, art = "SPR_FABRA", portrait = 9,
  super_bg = "BG_SUPER_FABRA", colour = 0x2A3A70, stage = "institut", ending_art = "END_FABRA",
  hp = 980, walk = 2.5, back = 2.2, -- (1060: with his CORRECCIÓ, the league's strongest at any weight)
  vs = {default = "ABANS DE COMENÇAR: AQUÍ NO S'ADMETEN BARBARISMES.",
        verdaguer = "MOSSÈN CINTO, ELS SEUS VERSOS SÓN SUBLIMS. LA SEVA ORTOGRAFIA, NO TANT.",
        dali = "SENYOR DALÍ, «PARANOIC» PORTA ACCENT? NO. VOSTÈ, EN CANVI, SÍ.",
        gaudi = "SENYOR GAUDÍ, LES SEVES CORBES SÓN BELLES. LES MEVES REGLES, EXACTES.",
        miro = "JOVE MIRÓ, UN ESTEL ES DIBUIXA. UNA LLENGUA ES DEFENSA.",
        fabra = "UN ALTRE FABRA? CAL REVISAR AQUESTA ERRATA."},
  wins = {default = "ERRATA CORREGIDA.",
          verdaguer = "UN GRAN POETA, MOSSÈN. ARA AMB LES REGLES, PERFECTE.",
          dali = "ERRATA CORREGIDA. EL BIGOTI, EN CANVI, NO TÉ ARREGLAMENT.",
          gaudi = "UNA BONA OBRA, MESTRE. LI FALTAVA UNA COMA.",
          miro = "MOLTS COLORS, POQUES REGLES. ACCEPTABLE.",
          fabra = "LA NORMA ÉS UNA I AQUÍ NOMÉS N'HI HA UN."},
  rival = "verdaguer",
  ending = {"FABRA TORNA A LA BIBLIOTECA DE L'INSTITUT AMB EL TROFEU.",
            "EL FA SERVIR DE PUNTAL PER ALS VOLUMS DEL DICCIONARI.",
            "«UNA LLENGUA BEN FETA», ESCRIU, «TAMBÉ ÉS UNA FORMA DE LLIBERTAT.»",
            "AL MATÍ, LA SALA ES FA PETITA: TOTHOM HI VOL LLEGIR."},
  moves = common({
    A = {s = {15}, a = {16}, r = {15}, startup = 4, active = 3, recovery = 8, dmg = 34, stun = 15, bstun = 11,
         box = {24, -134, 84, 22}, push = 5, chain = {B = true, FC = true, DA = true}, cancel = true},
    B = {s = {17}, a = {18}, r = {19}, startup = 11, active = 4, recovery = 20, dmg = 80, stun = 22, bstun = 16,
         box = {30, -140, 90, 40}, push = 11, cancel = true},
    C = {s = {20}, a = {21}, r = {20}, startup = 5, active = 3, recovery = 10, dmg = 38, stun = 16, bstun = 11,
         box = {22, -134, 96, 30}, push = 6, chain = {B = true, FC = true}, cancel = true},
    FC = {s = {22}, a = {23}, r = {24}, startup = 11, active = 4, recovery = 18, dmg = 80, stun = 22, bstun = 16,
          box = {28, -200, 104, 50}, push = 10, cancel = true},
    DC = {s = {26}, a = {25}, r = {26}, startup = 7, active = 4, recovery = 20, dmg = 62, stun = 0, bstun = 14,
          box = {20, -30, 104, 30}, hits = "low", push = 8, knock = true, crouch = true, cancel = true},
    J = {frame = 14, startup = 4, active = 14, dmg = 56, stun = 18, bstun = 12, box = {6, -72, 74, 46}, hits = "high",
         push = 5},
    JA = {frame = 58, startup = 3, active = 10, dmg = 42, stun = 16, bstun = 10, box = {14, -96, 72, 40},
          hits = "high", push = 4},
    JB = {frame = 59, startup = 6, active = 8, dmg = 70, stun = 20, bstun = 14, box = {-6, -104, 100, 70},
          hits = "high", push = 6},
    -- CORRECCIÓ: a guard that answers: a blow or a shot that meets it is corrected (A briefly, B longer)
    special = {s = {35}, a = {36}, r = {37, 38, 39}, startup = 2, active = 12, recovery = 26, kind = "special",
               counter = true, name = "CORRECCIÓ"},
    special2 = {s = {65, 66}, a = {67}, r = {68, 69}, startup = 11, active = 2, recovery = 20, kind = "special",
                spawn = "letters", name = "DIACRÍTICS"},
    super = {length = 90, spawn = "dictionary", name = "EL DICCIONARI"},
  }),
}

F.miro = {
  key = "miro", name = "JOAN MIRÓ", short = "MIRÓ", alias = "L'ABSTRACTE CÒSMIC", style = "ABSTRACCIÓ",
  quote = "«EL COLOR TAMBÉ ÉS COMBAT»", stats = {3, 3, 4, 4}, art = "SPR_MIRO", portrait = 4,
  super_bg = "BG_SUPER_MIRO", colour = 0x2A2A60, stage = "nit", ending_art = "END_MIRO",
  hp = 1000, walk = 2.7, back = 2.4,
  vs = {default = "UNA ESTRELLA, UNA LLUNA, UN OCELL. I UN COP DE PINZELL.",
        dali = "SALVADOR, TU SOMNIES DESPERT. JO PINTO ADORMIT.",
        gaudi = "MESTRE GAUDÍ, EL SEU DRAC I LES MEVES ESTRELLES FARIEN BONA PARELLA.",
        fabra = "MESTRE FABRA, UN ESTEL NO PORTA ACCENT. O SÍ?",
        miro = "DOS MIRÓS? AIXÒ JA ÉS UN QUADRE!"},
  wins = {default = "EL COLOR TAMBÉ ÉS COMBAT.",
          dali = "EL TEU BIGOTI ERA UN BON PINZELL, SALVADOR.",
          gaudi = "UN TRENCADÍS MÉS: EL DEL SEU ORGULL.",
          fabra = "ESTEL, LLUNA, OCELL. TRES PARAULES, CAP ERRATA.",
          miro = "L'ART ÉS UN UNIVERS ON TOT ÉS POSSIBLE. FINS I TOT AIXÒ."},
  rival = "dali",
  ending = {"MIRÓ TORNA AL SEU TALLER DE MALLORCA AMB EL TROFEU.",
            "EL PINTA DINS D'UN QUADRE GEGANT, ENTRE ESTRELLES I LLUNES.",
            "«EL COLOR», DIU, «TAMBÉ ÉS COMBAT.»",
            "AQUELLA NIT, EL CEL DE BARCELONA TÉ UN ESTEL DE MÉS."},
  moves = common({
    A = {s = {15}, a = {16}, r = {15}, startup = 4, active = 3, recovery = 8, dmg = 30, stun = 15, bstun = 11,
         box = {24, -134, 80, 22}, push = 5, chain = {B = true, FC = true, DA = true}, cancel = true},
    B = {s = {17}, a = {18}, r = {19}, startup = 10, active = 5, recovery = 19, dmg = 66, stun = 22, bstun = 16,
         box = {30, -150, 110, 50}, push = 10, cancel = true},
    C = {s = {20}, a = {21}, r = {20}, startup = 5, active = 3, recovery = 10, dmg = 36, stun = 16, bstun = 11,
         box = {22, -140, 100, 30}, push = 6, chain = {B = true, FC = true}, cancel = true},
    FC = {s = {22}, a = {23}, r = {24}, startup = 11, active = 4, recovery = 18, dmg = 76, stun = 22, bstun = 16,
          box = {28, -200, 112, 50}, push = 10, cancel = true},
    DC = {s = {26}, a = {25}, r = {26}, startup = 7, active = 4, recovery = 20, dmg = 58, stun = 0, bstun = 14,
          box = {20, -30, 104, 30}, hits = "low", push = 8, knock = true, crouch = true, cancel = true},
    J = {frame = 14, startup = 4, active = 14, dmg = 52, stun = 18, bstun = 12, box = {6, -72, 74, 46}, hits = "high",
         push = 5},
    JA = {frame = 58, startup = 3, active = 10, dmg = 40, stun = 16, bstun = 10, box = {14, -96, 72, 40},
          hits = "high", push = 4},
    JB = {frame = 59, startup = 6, active = 8, dmg = 66, stun = 20, bstun = 14, box = {-6, -104, 100, 70},
          hits = "high", push = 6},
    -- ESTEL: a star painted near (A) or far (B) stays as a trap; TAQUES: paint thrown in an arc, hits high
    special = {s = {35, 36}, a = {37}, r = {38, 39}, startup = 12, active = 2, recovery = 20, kind = "special",
               spawn = "star", name = "ESTEL"},
    special2 = {s = {65, 66}, a = {67}, r = {68, 69}, startup = 10, active = 2, recovery = 24, kind = "special",
                spawn = "blob", name = "TAQUES DE COLOR"}, -- (18: it flew over every straight shot, and won)
    super = {length = 96, spawn = "vortex", name = "VÒRTEX UNIVERSAL"},
  }),
}

local R = require("roster")
F.list = {F.dali, F.gaudi, F.fabra, F.miro}
F.by_key = {dali = F.dali, gaudi = F.gaudi, fabra = F.fabra, miro = F.miro}
for _, f in ipairs(R.list) do
  F.list[#F.list + 1] = f
  F.by_key[f.key] = f
end
F.secrets = R.secrets -- not in the list (the ladder, the demo) until they are found; each in a slot of its own
F.boss = R.boss -- the arcade's last two fights; never in the list (main.lua puts them at the ladder's end)
for _, f in ipairs(R.secrets) do F.by_key[f.key] = f end
for _, f in ipairs(R.boss) do F.by_key[f.key] = f end
-- the blows' hit boxes measured on their drawings (art/boxes.py), over the ones typed by hand. Their reach (px from
-- the body's middle to the box's far end) is brought halfway to the roster's median for that blow: as drawn, a jab
-- went from 60 px (En Patufet) to 154 (Fabra), and the long ones won at a distance the short could not answer.
-- Who has a cane still reaches further, by half as much.
local REACH = {A = 98, B = 131, C = 113, FC = 112, DC = 94, DA = 81} -- the medians (tests/balance/league.py)
for key, t in pairs(require("boxes")) do
  local d = F.by_key[key]
  for name, b in pairs(t) do
    if d and d.moves[name] then
      local r = REACH[name]
      if r then b = {b[1], b[2], math.floor(r + (b[1] + b[3] - r) * 0.5 - b[1] + 0.5), b[4]} end
      d.moves[name].box = b
    end
  end
end
-- each one's body, as wide as its drawing (Caballé's dress, Brossa's thin suit): the hurt boxes and the push
for key, b in pairs(require("bodies")) do
  local d = F.by_key[key]
  if d and not d.body then
    local w = b.right - b.left
    d.body = {stand = {b.left, -160, w, 160}, crouch = {b.left - 2, -100, w + 4, 100},
              air = {b.left + 2, -150, w - 4, 120}, puddle = {-40, -24, 80, 24}}
    d.half = b.half
  end
end
for key, w in pairs(require("balance")) do if F.by_key[key] then F.by_key[key].power = w end end
F.roster = {} -- the 16 of the select screen, in the order of the portraits
for i, key in ipairs({"dali", "verdaguer", "casals", "gaudi", "miro", "rodoreda", "llull", "caballe", "cerda", "fabra",
                      "rusinol", "brossa", "pla", "catala", "tapies", "peret"}) do
  local f = F.by_key[key]
  F.roster[i] = {name = f.name, fighter = f, key = key}
end

F.PALETTES = 4 -- the original and three more: picked with A, B, C or START at the select screen

return F
