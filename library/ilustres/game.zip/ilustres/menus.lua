-- The screens around the fight, the arcade way: choosing a fighter (and its colours), the versus with its two
-- lines, the winner's quote, CONTINUAR? with its countdown, GAME OVER, the ending and the credits, the initials of a
-- new record and the table of records, the options, and training's own menu. Each screen has a draw and, where it
-- takes input, a tick that returns what comes next (main.lua moves between them).
local F = require("fighters")
local hud = require("hud")
local gfx = require("gfx")
local opt = require("options")
local ai = require("ai")
local bstage = require("bonus")

local M = {}

local INK = 0x200010
local GOLD = {color = 0xFFE070, gradient = 0xFF8020}
local SMALL_W = {font = "small", align = "center", color = 0xFFFFFF}
local SMALL_Y = {font = "small", align = "center", color = 0xFFE070}
local SMALL_G = {font = "small", align = "center", color = 0x8090B0}
local HINT_Y = 298 -- every screen's line of help or prompt, at the bottom: small, grey (help) or gold (go on)
local SMALL_PLAIN = {font = "small", align = "center", color = 0xFFFFFF, plain = true}

local function ground() -- the screens' own dark blue, with lines
  rect(0, 0, 480, 320, 0x0C1428)
  for y = 0, 320, 16 do rect(0, y, 480, 1, 0x101C36) end
end

local function title_line(s, right)
  hud.cap(s, 14, 14, {color = 0xFFE070, gradient = 0xFF8020})
  if right then hud.cap(right, 466, 14, {align = "right", color = 0xFFFFFF}) end
end

local function typed(t, speed) return math.max(0, t // (speed or 2)) end -- how many letters are out yet

-- ------------------------------------------------------------------ choosing a fighter

M.SELECT_TICKS = 15 * 60
local STAT_NAMES = {"ATAC", "DEFENSA", "VELOCITAT", "TÈCNICA"}
local STAT_COLOURS = {0xE04040, 0x40A0E0, 0x40D070, 0xE0C040}
local PAL_KEYS = {"a", "b", "c", "start"} -- the button that chose a fighter picks its colours too

-- sel: {pick, chosen (def), palette, t_chosen, heading}; returns "back", "done" or nil
local secret_slots = {}
local SLOTS = #F.roster + #F.secrets + 1 -- the 16, the four secrets, the boss
local function slot(i) -- what slot i holds: the 16, then the four secrets (no name, no fighter until found and drawn),
  if i <= #F.roster then return F.roster[i] end -- then the boss (in VERSUS only, once the arcade is complete)
  local d = F.secrets[i - #F.roster] or F.boss[1]
  local s = secret_slots[i] or {secret = true}
  secret_slots[i] = s
  local open = opt.unlocked(d.key) and gfx.drawn(d) and (not d.boss or game.mode == "versus")
  s.name, s.fighter = open and d.name or "????", open and d or nil
  return s
end

local function vertical(pick, d) -- up (-1) or down (1): four rows of four, the row of five (secrets, boss) under them
  local n = #F.roster
  if pick > n then
    local col = math.min(4, pick - n)
    return d > 0 and col or n - 4 + col
  end
  local to = pick + d * 4
  return (to < 1 or to > n) and n + (pick - 1) % 4 + 1 or to
end

function M.select_tick(sel, t)
  if sel.chosen then
    return t - sel.t_chosen > 50 and "done" or nil
  end
  local moved = (btnp("right") and 1 or 0) - (btnp("left") and 1 or 0)
  local vert = (btnp("down") and 1 or 0) - (btnp("up") and 1 or 0)
  if vert ~= 0 then sel.pick = vertical(sel.pick, vert) end
  if moved ~= 0 or vert ~= 0 then
    sel.pick = (sel.pick - 1 + moved) % SLOTS + 1
    sfx("SND_MOVE", 0.5)
  end
  local auto = t >= M.SELECT_TICKS
  for k, key in ipairs(PAL_KEYS) do
    if btnp(key) or (auto and k == 1) then
      local def = slot(sel.pick).fighter or (auto and F.dali)
      if not def then sfx("SND_NO") return end
      if sel.avoid and def == sel.avoid.def and k == sel.avoid.palette then k = k % F.PALETTES + 1 end -- not twins
      sel.chosen, sel.palette, sel.t_chosen = def, k, t
      sfx("SND_PICK")
      return
    end
  end
end

-- the select screen on its own picture (art/select_bg.png, from the mock-up): where each thing goes on it
local CELL_X, CELL_Y, CELL_W, CELL_H = {130, 186, 243, 300}, {50, 91, 133, 174}, 50, 37
local SECRET_X, SECRET_Y, SECRET_W, SECRET_H = {153, 198, 243, 287, 359}, 228, 40, 36 -- (the 5th: the boss)
-- the panels drawn in the picture, measured on it (their dark insides): the name's, the standing fighter's
local NAME_PANEL, POSE_PANEL = {135, 274, 271, 35}, {14, 226, 121, 83}
M.SELECT_FRAMES = {NAME_PANEL, POSE_PANEL} -- (the text check reads them)
local STATS_X = NAME_PANEL[1] + NAME_PANEL[3] - 62 -- the four bars, at the panel's right end
local NAME_X, NAME_MAX = 142, STATS_X - 142 - 8
local NAME = {color = 0xFFE070, gradient = 0xFF8020}
local ALIAS = {font = "small", color = 0xFFFFFF}
local TITLE = {font = "small", align = "center", color = 0xFFE070}
local KEYS = {font = "small", align = "center", color = 0xFFFFFF, outline = 0x200010}
local CLOCK = {align = "center", color = 0xFFF0B0, gradient = 0xFFB040}
local SOON, P1 = {font = "small", color = 0x8090B0}, {font = "small", align = "center", color = 0xFFFFFF, outline = 0x200010}
local NAME_W = {font = "arcade"}
local SELECT_META = require("selectmeta")
local SELECT_ONE = {frames = {45}, mid = 0, scale = 1}

local function lock(x, y) -- a padlock: the secrets are not even named until they are found (GDD 11.1)
  rect(x - 6, y - 2, 13, 10, 0xB08A3A)
  rect(x - 4, y - 7, 2, 6, 0xB08A3A)
  rect(x + 3, y - 7, 2, 6, 0xB08A3A)
  rect(x - 4, y - 8, 9, 2, 0xB08A3A)
  rect(x - 1, y + 1, 2, 4, 0x201008)
end

function M.select_draw(sel, t)
  if not gfx.pic("BG_SELECT", 0, 0) then ground() end
  for i, r in ipairs(F.roster) do
    local x, y = CELL_X[(i - 1) % 4 + 1], CELL_Y[(i - 1) // 4 + 1]
    gfx.portrait(i - 1, x, y, "c", not r.fighter)
    if not r.fighter then lock(x + CELL_W - 9, y + CELL_H - 9) end -- in the corner: the face stays seen
  end
  for i = 1, 4 do -- the secret ones (their faces once found), and the hidden boss: dark, locked
    local d = slot(#F.roster + i).fighter
    if d then
      clip(SECRET_X[i], SECRET_Y, SECRET_W, SECRET_H)
      gfx.portrait(d.portrait, SECRET_X[i] - 5, SECRET_Y, "c")
      clip()
    else
      lock(SECRET_X[i] + 20, SECRET_Y + 18)
    end
  end
  local the_boss = slot(SLOTS).fighter
  if the_boss then
    clip(SECRET_X[5], SECRET_Y, SECRET_W, SECRET_H)
    gfx.portrait(the_boss.portrait, SECRET_X[5] - 5, SECRET_Y, "c")
    clip()
  end
  for k = 0, 5 do -- the boss's slot: a glitch, as the boss is (GDD 10)
    rect(352 + ((t * 7 + k * 13) % 50), SECRET_Y + 4 + k * 6, 6 + (k * 5) % 10, 2, ({0xFF2080, 0x20E0FF, 0xFFE020})[k % 3 + 1])
  end
  if not the_boss then lock(379, SECRET_Y + 18) end
  -- the cursor
  local x, y, w, h = CELL_X[(sel.pick - 1) % 4 + 1], CELL_Y[(sel.pick - 1) // 4 + 1], CELL_W, CELL_H
  if sel.pick > #F.roster then x, y, w, h = SECRET_X[sel.pick - #F.roster], SECRET_Y, SECRET_W, SECRET_H end
  local c = t // 6 % 2 == 0 and 0xFF3030 or 0xFFE070
  box(x - 2, y - 2, w + 4, h + 4, c)
  box(x - 1, y - 1, w + 2, h + 2, c)
  rect(x - 2, y - 2, 20, 16, 0xD02020) -- the P1 tab in the cursor's top-left corner, over the face's corner
  hud.cap("P1", x + 9, y + 2, P1)
  -- what the timer and the heading say, on the map's corner
  hud.plate(386, 4, 90, 40)
  hud.cap(sel.heading or "TRIA", 431, 9, TITLE)
  hud.cap(sel.chosen and "--" or tostring(math.max(0, (M.SELECT_TICKS - t) // 60)), 431, 25, CLOCK)
  -- the one under the cursor: big, with name and alias and four bars
  local r = slot(sel.pick)
  local d = r.fighter
  if d and not sel.chosen and t // 40 % 2 == 0 then -- (on a plate under the clock, clear of the portraits)
    hud.plate(386, 48, 90, 34)
    hud.cap("A B C START:", 431, 53, KEYS)
    hud.cap("COLOR", 431, 67, KEYS)
  end
  if sel.chosen then -- chosen: the fighter himself, in the colours picked, celebrating, in the big frame
    -- standing in the frame at full size, the body rising out of it over the mountain: the victory frames that
    -- fit beside the portraits, in turn, in the middle of that room (selectmeta.lua, made with the art)
    local m = SELECT_META[sel.chosen.key] or SELECT_ONE
    local frame = m.frames[(t - sel.t_chosen) // 16 % #m.frames + 1]
    clip(0, 36, 126, 273)
    gfx.fighter(sel.chosen, frame, math.floor(62 - m.mid * m.scale), 306, false, sel.palette, nil,
                m.scale < 1 and m.scale or nil)
    clip()
  elseif d and gfx.has("SELECT_POSE") then -- the one under the cursor, whole, standing in its guard (one picture
    gfx.pic("SELECT_POSE", 0, 66, sel.pick - 1) -- for all twenty: moving the cursor loads nothing)
  elseif r.secret then -- a secret not found: a dark frame and a padlock
    rect(14, 227, 121, 82, 0x0A0E18)
    lock(74, 268)
  else
    gfx.portrait(sel.pick - 1, 14, 227, "b", not d)
  end
  -- in the name's panel: the name, the alias under it, the four bars at its right end
  NAME.font = textw(d and d.name or r.name, NAME_W) > NAME_MAX and "small" or "arcade"
  hud.cap(d and d.name or r.name, NAME_X, NAME.font == "small" and 281 or 278, NAME)
  if d then
    hud.cap(d.alias, NAME_X, 296, ALIAS)
    for k = 1, 4 do
      local by = 279 + (k - 1) * 7
      for j = 1, 5 do rect(STATS_X + (j - 1) * 12, by, 10, 5, j <= d.stats[k] and STAT_COLOURS[k] or 0x2A3450) end
    end
  elseif not r.secret then
    hud.cap("PROPERAMENT", NAME_X, 296, SOON)
  end
end

-- a secret found in the run just over: its name, at last
local UNLOCK_NAME = {align = "center", color = 0xFFE070, gradient = 0xFF8020}
function M.unlock_draw(keys, t)
  ground()
  hud.band(50, 64, t)
  hud.big("NOU LLUITADOR!", 62, 0xFFE070, t < 20 and 2 or 0)
  for i, k in ipairs(keys) do
    local d = F.by_key[k]
    hud.cap(d.name, 240, 126 + (i - 1) * 46, UNLOCK_NAME)
    hud.cap(d.alias, 240, 150 + (i - 1) * 46, SMALL_W)
  end
  local versus = #keys == 1 and keys[1] == "joeljoan" -- (he is chosen in VERSUS only)
  if t > 60 and #keys < 4 then
    hud.cap(versus and "ES POT TRIAR AL VERSUS" or "JA ES POT TRIAR A LA PANTALLA DE SELECCIÓ", 240, HINT_Y, SMALL_G)
  end
end

-- ------------------------------------------------------------------ versus: two portraits, two lines

local VS_NAME = {align = "center", color = 0xFFE070, gradient = 0xFF8020}
local VS_NAME_S = {font = "small", align = "center", color = 0xFFE070}
local VS_LINE = {font = "small", align = "center", color = 0xFFFFFF, plain = true}
local VS_COL = 208 -- each half's room for words (a margin on each side of the line between them)

-- Each one under their own portrait: name (in the small font when the big one would not fit the half), alias, and
-- what they say to the other, typed out in turn, in their own column (up to four lines)
function M.vs_draw(a, b, stage_name, t)
  ground()
  local slide = math.max(0, 40 - t) * 6
  gfx.portrait(a.portrait, -slide, 26, "l", false)
  gfx.portrait(b.portrait, 240 + slide, 26, "l", false)
  rect(239, 26, 2, 50, 0x0C1428) -- the line between the two portraits, broken where the VS stands
  rect(239, 130, 2, 46, 0x0C1428)
  if t > 60 then hud.band(226, 74, t - 60) rect(239, 232, 2, 62, 0x30384C) end
  local la, lb = M.vs_line(a, b), M.vs_line(b, a)
  -- both names in one size: the big one only when both fit their half
  local o = textw(a.name, VS_NAME) <= VS_COL and textw(b.name, VS_NAME) <= VS_COL and VS_NAME or VS_NAME_S
  for i, d in ipairs({a, b}) do
    local x = i == 1 and 120 or 360
    hud.cap(d.name, x, o == VS_NAME and 186 or 190, o)
    hud.cap(d.alias, x, 211, SMALL_W)
    if t > 60 then
      local shown = i == 1 and typed(t - 70) or typed(t - 90 - #la * 2)
      if shown > 0 then hud.wrap(i == 1 and la or lb, x, 236, VS_COL, 18, VS_LINE, shown) end
    end
  end
  if t > 30 then hud.big("VS", 80, 0xFF5030, t < 45 and 3 or 0) end
  hud.cap(stage_name, 240, 305, SMALL_G)
end
function M.vs_line(a, b) return a.vs[b.key] or a.vs.default or a.quote end -- what a says to b

function M.vs_ticks(a, b) return 120 + 2 * (#M.vs_line(a, b) + #M.vs_line(b, a)) + 50 end

-- ------------------------------------------------------------------ the winner's word

function M.winquote_draw(w, l, t)
  ground()
  gfx.portrait(w.def.portrait, 120, 30, "l", false)
  box(120, 30, 240, 150, 0xC09030)
  hud.cap(w.def.name, 240, 196, {align = "center", color = 0xFFE070, gradient = 0xFF8020})
  hud.band(222, 70, t)
  local line = w.def.wins[l.def.key] or w.def.wins.default or w.def.quote
  hud.wrap(line, 240, 234, 440, 20, SMALL_PLAIN, typed(t - 10))
  if t > 40 + #line * 2 and t // 30 % 2 == 0 then
    hud.cap(game.mode == "versus" and "A: TORNAR A TRIAR     B: SORTIR" or "PREM A", 240, HINT_Y, SMALL_Y)
  end
end

-- ------------------------------------------------------------------ CONTINUAR?

function M.continue_draw(f, t)
  ground()
  gfx.portrait(f.def.portrait, 120, 40, "l", false)
  shade(120, 40, 240, 150)
  if t // 60 >= 9 then shade(120, 40, 240, 150) end
  hud.big("CONTINUAR?", 210, 0xFFFFFF)
  local n = math.max(0, 9 - t // 60)
  hud.big(tostring(n), 80, n <= 3 and 0xFF4030 or 0xFFE070, t % 60 < 6 and 3 or 0, 3)
  if t // 30 % 2 == 0 then hud.cap("A: SÍ", 240, 286, SMALL_Y) end
end

function M.gameover_draw(t)
  rect(0, 0, 480, 320, 0x000000)
  hud.band(120, 80, t)
  hud.big("GAME OVER", 142, 0xFF4030, 0, 2)
end

-- ------------------------------------------------------------------ the ending and the credits

M.LINE_TICKS = 200

function M.ending_draw(f, t)
  if not gfx.pic(f.def.ending_art, 0, 0) then rect(0, 0, 480, 320, 0x101828) end
  local i = math.min(#f.def.ending, 1 + t // M.LINE_TICKS)
  shade(0, 236, 480, 84)
  shade(0, 236, 480, 84)
  rect(0, 236, 480, 2, 0xC09030)
  hud.wrap(f.def.ending[i], 240, 248, 450, 20, SMALL_W, typed(t % M.LINE_TICKS, 2))
end

function M.ending_ticks(f) return #f.def.ending * M.LINE_TICKS + 60 end

-- The credits roll as a Neo Geo staff roll: the people who made it, then each fighter with their face (the portraits'
-- small size), the legends and the boss, the references; then the logo and FI. Rows: {words, kind, portrait}.
local CREDITS = {
  {"IL·LUSTRES", "title"}, {"COMBAT DE LLEGENDA", "head"}, {""},
  {"IDEA, DIRECCIÓ I DISSENY", "head"}, {"PAU AVILA"}, {""},
  {"PROGRAMACIÓ, ART I MÚSICA", "head"}, {"PAU AVILA AMB CLAUDE"}, {"IMATGES GENERADES AMB IA (GPT IMAGE)"}, {"I RETOCADES"}, {""},
  {"MOTOR", "head"}, {"PINYOL · CIRERA ESP32-S3"}, {""},
  {"LLETRES", "head"}, {"JERSEY (SIL OPEN FONT LICENSE)"}, {""},
  {"PERSONATGES", "head"},
  {"SALVADOR DALÍ (1904-1989)", nil, 0}, {"JACINT VERDAGUER (1845-1902)", nil, 1}, {"PAU CASALS (1876-1973)", nil, 2},
  {"ANTONI GAUDÍ (1852-1926)", nil, 3}, {"JOAN MIRÓ (1893-1983)", nil, 4}, {"MERCÈ RODOREDA (1908-1983)", nil, 5},
  {"RAMON LLULL (1232-1316)", nil, 6}, {"MONTSERRAT CABALLÉ (1933-2018)", nil, 7}, {"ILDEFONS CERDÀ (1815-1876)", nil, 8},
  {"POMPEU FABRA (1868-1948)", nil, 9}, {"SANTIAGO RUSIÑOL (1861-1931)", nil, 10}, {"JOAN BROSSA (1919-1998)", nil, 11},
  {"JOSEP PLA (1897-1981)", nil, 12}, {"CATERINA ALBERT, VÍCTOR CATALÀ (1869-1966)", nil, 13},
  {"ANTONI TÀPIES (1923-2012)", nil, 14}, {"PERET (1935-2014)", nil, 15}, {""},
  {"I LES LLEGENDES", "head"}, {"EN PATUFET", nil, 16}, {"EL TIÓ", nil, 17}, {"LA PRINCESA DE SANT JORDI", nil, 18},
  {"EL TIMBALER DEL BRUC", nil, 19}, {""},
  {"EL DIRECTOR DE TOT PLEGAT", "head"}, {"JOEL JOAN, EN PARÒDIA AFECTUOSA", nil, 20},
  {"EL PRODUCTOR EXECUTIU", nil, 21}, {""},
  {"FOTOGRAFIES DE REFERÈNCIA", "head"}, {"JOEL JOAN: ALEEIX, CC BY-SA 3.0"}, {"VÍCTOR CATALÀ: FEMINAL, 1917,"},
  {"RETALL DE BLAU-BARCELONA, CC BY-SA 4.0"}, {"PERET: BERT VERHOEFF / ANEFO, CC0"},
  {"GAUDÍ: FOTOS DE 1910 I 1924, DOMINI PÚBLIC"}, {"LA PRINCESA: BERNAT MARTORELL, 1435"},
  {"TOTES DE WIKIMEDIA COMMONS"}, {"FONTS COMPLETES: SOURCES.LUA DEL JOC"}, {""},
  {"ELS SPRITES DE JOEL JOAN I DE"}, {"VÍCTOR CATALÀ ES BASEN EN AQUESTES"}, {"FOTOS I ES COMPARTEIXEN AMB CC BY-SA."}, {""},
  {"SENSE RELACIÓ AMB ELS RETRATATS,"}, {"LES SEVES FAMÍLIES O FUNDACIONS, NI TV3."}, {""},
  {"UN HOMENATGE, NO UNA BIOGRAFIA:"}, {"ELS COMBATS SÓN INVENTATS."}, {""}, {""}, {""}, {""}, {""}, {""},
  {"FI", "end"}, -- (the logo stands over FI: the empty rows before it are its room)
}
local ROW, FACE_ROW = 26, 44 -- a line's height; a line with a face
local rows_y, rows_h = {}, 0
for i, c in ipairs(CREDITS) do rows_y[i], rows_h = rows_h, rows_h + (c[3] and FACE_ROW or ROW) end
local SPEED = 0.6 -- pixels a tick
M.CREDITS_TICKS = math.floor((330 + rows_h - 160) / SPEED) + 240 -- (FI stops in the middle of the screen, a while)
local C_TITLE = {align = "center", color = 0xFFE070, gradient = 0xE04010}
local C_NAME = {font = "small", color = 0xFFFFFF}

function M.credits_draw(t)
  rect(0, 0, 480, 320, 0x05070C)
  for y = 0, 320, 16 do rect(0, y, 480, 1, 0x0A0E18) end
  local y0 = 330 - math.min(t * SPEED, 330 + rows_h - 160 - (rows_h - rows_y[#CREDITS]))
  for i, c in ipairs(CREDITS) do
    local y = math.floor(y0 + rows_y[i])
    if y > -50 and y < 330 and c[1] ~= "" then
      if c[2] == "title" then hud.cap(c[1], 240, y, C_TITLE)
      elseif c[2] == "end" then
        if gfx.has("LOGO") then local w = imgsize("LOGO") gfx.pic("LOGO", 240 - w // 2, y - 120) end
        hud.cap(c[1], 240, y, C_TITLE)
      elseif c[2] == "head" then hud.cap(c[1], 240, y, SMALL_Y)
      elseif c[3] then -- a face beside the name, the pair centred
        local w = textw(c[1], C_NAME) + 60
        local x = 240 - w // 2
        gfx.portrait(c[3], x, y - 12, "c")
        box(x - 1, y - 13, 52, 39, 0xC09030)
        hud.cap(c[1], x + 60, y + 2, C_NAME)
      else hud.cap(c[1], 240, y, SMALL_W) end
    end
  end
end

-- after a champion's ending, the title again and thanks, before the credits (the Neo Geo's "thank you for playing")
local THANKS = {align = "center", color = 0xFFE070, gradient = 0xFF8020}
function M.thanks_draw(f, t, title)
  title(t)
  shade(0, 140, 480, 180)
  shade(0, 140, 480, 180)
  if t < 40 then return end
  hud.band(150, 52, t - 40)
  hud.cap("MOLTES GRÀCIES PER JUGAR", 240, 166, THANKS)
  if t < 90 then return end
  local name = f.def.name
  local w = math.max(textw(T("CAMPIÓ"), SMALL_Y), textw(name, NAME_W)) + 80
  local x = 240 - w // 2
  hud.plate(x, 218, w, 58)
  gfx.portrait(f.def.portrait, x + 8, 228, "c")
  box(x + 7, 227, 52, 39, 0xC09030)
  hud.cap("CAMPIÓ", x + 70, 228, {font = "small", color = 0xFFE070})
  hud.cap(name, x + 70, 246, {color = 0xFFFFFF})
  if t > 160 and t // 30 % 2 == 0 then hud.cap(T("PUNTS") .. " " .. string.format("%07d", f.score or 0), 240, HINT_Y, SMALL_W) end
end
M.THANKS_TICKS = 480

-- ------------------------------------------------------------------ the gallery (GDD 12): who they are, and the endings seen

local G_NAME = {align = "center", color = 0xFFE070, gradient = 0xFF8020}
local G_TEXT = {font = "small", align = "center", color = 0xFFFFFF}

-- the design sheet a fighter was drawn from (art/make_art.py blueprints), if there is one
function M.blueprint(i)
  local id = "BLUEPRINT_" .. F.roster[i].key:upper()
  return gfx.has(id) and id or nil
end

local SHEET_TAG = {font = "small", align = "right", color = 0xFFE070}

function M.gallery_draw(g, t)
  local r = F.roster[g.at]
  local d = r.fighter
  if g.sheet and M.blueprint(g.at) then -- the sheet, the screen's width, scrolled; a bar shows where
    local id = M.blueprint(g.at)
    local _, h = imgsize(id)
    gfx.pic(id, 0, -(g.scroll or 0))
    local bar = math.max(16, 300 * 320 // h)
    rect(472, 10, 4, 300, 0x0C1428)
    rect(472, 10 + (300 - bar) * (g.scroll or 0) // math.max(1, h - 320), 4, bar, 0xFFE070)
    hud.plate(330, 4, 136, 22)
    hud.cap(T("FITXA") .. " · " .. (d and d.short or r.name), 460, 9, SHEET_TAG)
    if t // 40 % 2 == 0 then
      hud.plate(120, 292, 240, 24)
      hud.cap("AMUNT/AVALL: LLEGIR   B: TORNAR", 240, 297, SMALL_W)
    end
    return
  end
  if g.ending and d and gfx.pic(d.ending_art, 0, 0) then
    shade(0, 286, 480, 34)
    hud.cap(T("FINAL DE") .. " " .. d.short, 240, 294, G_NAME)
    return
  end
  ground()
  title_line("GALERIA", g.at .. " / " .. #F.roster)
  gfx.portrait(g.at - 1, 120, 40, "l", false)
  box(119, 39, 242, 152, 0xC09030)
  hud.cap(d and d.name or r.name, 240, 196, G_NAME)
  if d then
    hud.cap(d.alias .. "  ·  " .. d.style, 240, 222, G_TEXT)
    hud.wrap(d.quote, 240, 246, 440, 18, G_TEXT)
  end
  local help = {} -- what can be done here (the ending only once it has been seen)
  if opt.seen[r.key] then help[#help + 1] = T("A: FINAL") end
  if M.blueprint(g.at) then help[#help + 1] = T("START: FITXA") end
  help[#help + 1] = T("C: MÚSICA")
  help[#help + 1] = T("B: TORNAR")
  hud.cap(table.concat(help, "   "), 240, HINT_Y, SMALL_G)
end

-- the jukebox (GDD 11.3): every tune of the game, two columns
local TUNES = {{"TITLE", "TÍTOL"}, {"SELECT", "TRIA"}, {"PARK", "PARK GÜELL"}, {"CADAQUES", "PORTLLIGAT"},
  {"INSTITUT", "L'INSTITUT"}, {"NIT", "BARCELONA DE NIT"}, {"MONTSERRAT", "MONTSERRAT"},
  {"PALAU", "PALAU DE LA MÚSICA"}, {"DIAMANT", "PLAÇA DEL DIAMANT"}, {"MONESTIR", "MIRAMAR"},
  {"LICEU", "EL LICEU"}, {"EIXAMPLE", "L'EIXAMPLE"}, {"CAUFERRAT", "CAU FERRAT"},
  {"POESIA", "POESIA VISUAL"}, {"EMPORDA", "L'EMPORDÀ"}, {"MUNTANYA", "MUNTANYA I VENT"},
  {"TALLER", "ESPAI MATÈRIC"}, {"GRACIA", "FESTA DE GRÀCIA"}, {"PLATO", "PLATÓ"}, {"RIVAL", "RIVALS"}, {"GLORY", "MOMENT DE GLÒRIA"}, {"WIN", "VICTÒRIA"},
  {"CONTINUE", "CONTINUAR?"}, {"ENDING", "FINAL"}, {"GAMEOVER", "GAME OVER"}}
local ROWS = (#TUNES + 1) // 2 -- two columns, as many rows as half the tunes
local ROW_STEP = math.min(19, (282 - 52) // (ROWS - 1)) -- (down to the help line, whatever their number)
local J_ROW = {font = "small", color = 0xC0C0C0}

function M.jukebox_tick(j) -- returns "back", a tune to play, or nil
  local d = (btnp("down") and 1 or 0) - (btnp("up") and 1 or 0) + (btnp("right") and ROWS or 0) - (btnp("left") and ROWS or 0)
  if d ~= 0 then j.at = math.max(1, math.min(#TUNES, j.at + d)) sfx("SND_MOVE", 0.5) end
  if btnp("b") then return "back" end
  if btnp("a") then j.playing = j.at return TUNES[j.at][1] end
end

function M.jukebox_draw(j, t)
  ground()
  title_line("MÚSICA", j.at .. " / " .. #TUNES)
  for i, tune in ipairs(TUNES) do
    local x, y = 24 + (i - 1) // ROWS * 228, 52 + (i - 1) % ROWS * ROW_STEP
    local here = i == j.at
    if here then rect(x - 6, y - 4, 222, 18, 0x6A2010) end
    J_ROW.color = here and 0xFFE070 or i == j.playing and 0x80E0FF or 0xC0C0C0
    hud.cap((i == j.playing and (t // 15 % 2 == 0 and "> " or "  ") or "") .. tune[2], x, y, J_ROW)
  end
  hud.cap(opt.v.music and "A: ESCOLTAR     B: TORNAR" or "LA MÚSICA ÉS APAGADA A LES OPCIONS", 240, HINT_Y, SMALL_G)
end

-- ------------------------------------------------------------------ a new record: three letters

local LETTERS = {} -- A to Z, then a few signs
for c in ("ABCDEFGHIJKLMNOPQRSTUVWXYZ.!- "):gmatch(".") do LETTERS[#LETTERS + 1] = c end

function M.initials_new() return {chars = {1, 1, 1}, at = 1} end

function M.initials_tick(ini) -- returns the name when the three are set
  local c = ini.chars
  local d = (btnp("up") and 1 or 0) - (btnp("down") and 1 or 0)
  if d ~= 0 then
    c[ini.at] = (c[ini.at] - 1 + d) % #LETTERS + 1
    sfx("SND_MOVE", 0.5)
  end
  if btnp("b") and ini.at > 1 then ini.at = ini.at - 1 sfx("SND_NO") end
  if btnp("a") or btnp("start") then
    sfx("SND_PICK")
    if ini.at == 3 then
      local s = ""
      for i = 1, 3 do s = s .. M.letter(c[i]) end
      return s
    end
    ini.at = ini.at + 1
  end
end

function M.letter(i) return LETTERS[i] end

local PLACES = {"PRIMERA POSICIÓ", "SEGONA POSICIÓ", "TERCERA POSICIÓ", "QUARTA POSICIÓ", "CINQUENA POSICIÓ"}

function M.initials_draw(ini, score, rank, t)
  ground()
  title_line("NOU RÈCORD!")
  hud.big(string.format("%07d", score), 70, 0xFFE070)
  hud.cap(PLACES[rank] or "", 240, 130, SMALL_W)
  for i = 1, 3 do
    local x = 160 + (i - 1) * 60
    local here = i == ini.at
    rect(x, 170, 40, 54, here and 0x6A2010 or 0x14203C)
    box(x, 170, 40, 54, here and (t // 8 % 2 == 0 and 0xFFE070 or 0xFF8020) or 0x2A3A60)
    hud.cap(M.letter(ini.chars[i]), x + 20, 182, {align = "center", scale = 2, color = 0xFFFFFF})
  end
  hud.cap("AMUNT/AVALL: LLETRA   A: OK   B: ENRERE", 240, 260, SMALL_G)
end

function M.records_draw(t)
  ground()
  title_line("RÈCORDS")
  for i, e in ipairs(opt.scores) do
    local y = 70 + (i - 1) * 42
    local c = i == 1 and 0xFFE070 or 0xFFFFFF
    hud.cap(i .. ".", 110, y, {color = c})
    hud.cap(e.name, 170, y, {color = c})
    hud.cap(string.format("%07d", e.score), 380, y, {align = "right", color = c})
  end
end

-- ------------------------------------------------------------------ options

local OPTIONS = {"DIFICULTAT", "INPUTS", "TEMPS", "MÚSICA", "EFECTES", "IDIOMA", "SORTIR"}

local function value(i)
  local v = opt.v
  if i == 1 then return opt.LEVELS[v.level]
  elseif i == 2 then return v.simple and "SIMPLES" or "CLÀSSICS"
  elseif i == 3 then return opt.TIMES[v.time] > 0 and tostring(opt.TIMES[v.time]) or "SENSE"
  elseif i == 4 then return v.music and "SÍ" or "NO"
  elseif i == 5 then return v.sfx and "SÍ" or "NO"
  elseif i == 6 then return opt.LANGS[v.lang] end
  return ""
end

function M.options_tick(o) -- returns "back" when left
  local d = (btnp("down") and 1 or 0) - (btnp("up") and 1 or 0)
  if d ~= 0 then o.at = (o.at - 1 + d) % #OPTIONS + 1 sfx("SND_MOVE", 0.5) end
  local ch = (btnp("right") and 1 or 0) - (btnp("left") and 1 or 0)
  if ch == 0 and btnp("a") and o.at < #OPTIONS then ch = 1 end
  if ch ~= 0 then
    local v = opt.v
    if o.at == 1 then v.level = (v.level - 1 + ch) % #opt.LEVELS + 1
    elseif o.at == 2 then v.simple = not v.simple
    elseif o.at == 3 then v.time = (v.time - 1 + ch) % #opt.TIMES + 1
    elseif o.at == 4 then v.music = not v.music
    elseif o.at == 5 then v.sfx = not v.sfx
    elseif o.at == 6 then v.lang = v.lang % #opt.LANGS + 1 end
    sfx("SND_MOVE", 0.5)
    return "changed"
  end
  if btnp("b") or (btnp("a") and o.at == #OPTIONS) then return "back" end
end

function M.options_draw(o, t)
  ground()
  title_line("OPCIONS")
  for i, name in ipairs(OPTIONS) do
    local y = 60 + (i - 1) * 31
    local here = i == o.at
    if here then rect(40, y - 6, 400, 30, 0x6A2010) end
    hud.cap(name, 56, y, {color = here and 0xFFE070 or 0xC0C0C0})
    local v = value(i)
    if v ~= "" then hud.cap(here and "< " .. v .. " >" or v, 424, y, {align = "right", color = 0xFFFFFF}) end
  end
  local help = o.at == 2 and "ESPECIAL: ENDAVANT O ENRERE + B   SUPER: B+C" or o.at == 1 and
    "LES DUES MÉS ALTES: EL CHIP POT GUANYAR" or "ESQUERRA/DRETA: CANVIA     B: TORNA"
  hud.cap(help, 240, HINT_Y, SMALL_G)
end

-- ------------------------------------------------------------------ VERSUS: a handicap (GDD 12)

M.HANDICAPS = {1, 0.75, 0.5} -- the life each may start with
local HC_ROW = {color = 0xC0C0C0}
local HC_VAL = {font = "small", color = 0xFFFFFF}

function M.handicap_tick(h) -- returns "go", "back" or nil; rows: the two fighters, then COMBATRE
  local d = (btnp("down") and 1 or 0) - (btnp("up") and 1 or 0)
  if d ~= 0 then h.at = (h.at - 1 + d) % 3 + 1 sfx("SND_MOVE", 0.5) end
  local ch = (btnp("right") and 1 or 0) - (btnp("left") and 1 or 0)
  if ch ~= 0 and h.at <= 2 then
    h.v[h.at] = math.max(1, math.min(#M.HANDICAPS, h.v[h.at] + ch))
    sfx("SND_MOVE", 0.5)
  end
  if btnp("b") then return "back" end
  if (btnp("a") or btnp("start")) and (h.at == 3 or btnp("start")) then sfx("SND_PICK") return "go" end
  if btnp("a") then h.at = 3 sfx("SND_MOVE", 0.5) end
end

function M.handicap_draw(h, v, t)
  ground()
  title_line("HANDICAP")
  hud.cap("MENYS VIDA PER IGUALAR EL COMBAT", 240, 48, SMALL_G)
  for i, d in ipairs({v.a, v.b}) do
    local y = 86 + (i - 1) * 64
    local here = h.at == i
    if here then rect(40, y - 8, 400, 52, 0x6A2010) end
    gfx.portrait(d.portrait, 52, y - 4, "c", false)
    HC_ROW.color = here and 0xFFE070 or 0xC0C0C0
    hud.cap(d.name, 116, y - 2, HC_ROW)
    local pct = math.floor(M.HANDICAPS[h.v[i]] * 100) .. " %"
    hud.cap(T("VIDA") .. "  " .. (here and "< " .. pct .. " >" or pct), 116, y + 22, HC_VAL)
  end
  local here = h.at == 3
  if here then rect(160, 220, 160, 34, 0x6A2010) end
  hud.cap("COMBATRE", 240, 228, {align = "center", color = here and 0xFFE070 or 0xC0C0C0})
  hud.cap("ESQUERRA/DRETA: VIDA   A: COMBATRE   B: TORNAR", 240, HINT_Y, SMALL_G)
end

-- ------------------------------------------------------------------ BONUS: the bonus stages played, again

local BONUS_ORDER = {}
for _, pool in ipairs(bstage.POOLS) do for _, k in ipairs(pool) do BONUS_ORDER[#BONUS_ORDER + 1] = k end end
BONUS_ORDER[#BONUS_ORDER + 1] = "plato" -- (the secret one: open once met before the boss)

function M.bonus_menu_tick(b) -- returns the bonus to play, "back", or nil
  local d = (btnp("down") and 1 or 0) - (btnp("up") and 1 or 0)
  if d ~= 0 then b.at = (b.at - 1 + d) % #BONUS_ORDER + 1 sfx("SND_MOVE", 0.5) end
  if btnp("b") then return "back" end
  if btnp("a") or btnp("start") then
    local k = BONUS_ORDER[b.at]
    if opt.bonus[k] then sfx("SND_PICK") return k end
    sfx("SND_NO")
  end
end

function M.bonus_menu_draw(b, t)
  ground()
  title_line("BONUS", "RÈCORD")
  for i, k in ipairs(BONUS_ORDER) do
    local y = 64 + (i - 1) * 34
    local here, best = i == b.at, opt.bonus[k]
    if here then rect(40, y - 6, 400, 30, 0x6A2010) end
    local c = here and 0xFFE070 or best and 0xC0C0C0 or 0x506080
    local name = best and bstage.LIST[k].name or "????"
    hud.cap(name, 56, y, {color = c, font = textw(name, NAME_W) > 260 and "small" or nil}) -- (clear of the score)
    hud.cap(best and string.format("%07d", best) or "-------", 424, y, {align = "right", color = c})
  end
  hud.cap(opt.bonus[BONUS_ORDER[b.at]] and "A: JUGAR     B: TORNAR" or "ES DESBLOQUEJA JUGANT-LO A L'ARCADE", 240, HINT_Y, SMALL_G)
end

-- ------------------------------------------------------------------ training's menu, and what the pad does

local TRAIN = {"RIVAL", "CAIXES", "ENTRADES", "REINICIAR", "CONTINUAR", "SORTIR"}

function M.train_tick(tr) -- returns "resume", "reset" or "quit"
  local d = (btnp("down") and 1 or 0) - (btnp("up") and 1 or 0)
  if d ~= 0 then tr.at = (tr.at - 1 + d) % #TRAIN + 1 sfx("SND_MOVE", 0.5) end
  local ch = (btnp("right") and 1 or 0) - (btnp("left") and 1 or 0)
  local go = btnp("a")
  if btnp("start") then return "resume" end
  local item = TRAIN[tr.at]
  if item == "RIVAL" and (ch ~= 0 or go) then
    tr.dummy = (tr.dummy - 1 + (ch ~= 0 and ch or 1)) % #ai.DUMMIES + 1
    sfx("SND_MOVE", 0.5)
  elseif item == "CAIXES" and (ch ~= 0 or go) then tr.boxes = not tr.boxes
  elseif item == "ENTRADES" and (ch ~= 0 or go) then tr.inputs = not tr.inputs
  elseif go then return item == "REINICIAR" and "reset" or item == "CONTINUAR" and "resume" or "quit" end
end

function M.train_draw(tr)
  shade(0, 0, 480, 320)
  hud.band(60, 220, 99)
  hud.cap("ENTRENAMENT", 240, 72, {align = "center", color = 0x80E0FF})
  local vals = {ai.DUMMIES[tr.dummy], tr.boxes and "SÍ" or "NO", tr.inputs and "SÍ" or "NO", "", "", ""}
  for i, name in ipairs(TRAIN) do
    local y = 108 + (i - 1) * 27
    local here = i == tr.at
    hud.cap(name, 130, y, {font = "small", color = here and 0xFFE070 or 0xC0C0C0})
    if vals[i] ~= "" then hud.cap(here and "< " .. vals[i] .. " >" or vals[i], 350, y, {font = "small", align = "right",
                                                                                      color = 0xFFFFFF}) end
  end
end

-- the last moves pressed, as arrows and buttons down the left side (training)
local ANG = {[6] = 0, [3] = 45, [2] = 90, [1] = 135, [4] = 180, [9] = -45, [8] = -90, [7] = -135}
local BTN = {a = 0xC03030, b = 0xD0A020, c = 0x3070C0}
local ABC, UPPER, LOG_TEXT = {"a", "b", "c"}, {a = "A", b = "B", c = "C"}, {font = "small", align = "center", color = 0xFFFFFF}

function M.inputs_draw(pad)
  local log = pad.log
  if not log then return end
  for i = 1, #log do
    local e = log[#log - i + 1]
    local y = 80 + (i - 1) * 20
    if y > 270 then break end
    rect(6, y - 2, 64, 18, INK)
    if e.d ~= 5 then
      local cx, cy, c, s = 16, y + 7, math.cos(math.rad(ANG[e.d])), math.sin(math.rad(ANG[e.d]))
      line(cx - c * 5, cy - s * 5, cx + c * 4, cy + s * 4, 0xFFFFFF)
      tri(cx + c * 7, cy + s * 7, cx + c * 2 - s * 3, cy + s * 2 + c * 3, cx + c * 2 + s * 3, cy + s * 2 - c * 3, 0xFFFFFF)
    end
    local x = 32
    for _, k in ipairs(ABC) do
      if e[k] then circ(x, y + 7, 6, BTN[k]) text(UPPER[k], x, y, LOG_TEXT) end
      x = x + 13
    end
  end
end

return M
