-- Where the pictures come from, in full (the credits show it short). The game is CC BY 4.0, by Pau Avila; its sprites,
-- portraits and backgrounds were generated with an image model (GPT Image) and retouched. Five fighters were drawn
-- after photographs or a painting, listed here; the sprites and portraits of Joel Joan and of Víctor Català are based
-- on photographs under CC BY-SA and are shared under the same licence (CC BY-SA 4.0). The people portrayed, their
-- families and foundations, and TV3 have no part in this game: it is a homage and a parody, and the fights are made up.
-- Their likenesses are not licensed by any of these licences.
return {
  {who = "Joel Joan", title = "Joel Joan (2012)", author = "Aleeix", licence = "CC BY-SA 3.0",
   licence_url = "https://creativecommons.org/licenses/by-sa/3.0/",
   url = "https://commons.wikimedia.org/wiki/File:Joel_Joan_(2012).jpg",
   changes = "used as a reference for a pixel-art caricature; not reproduced"},
  {who = "Caterina Albert (Víctor Català)", title = "Caterina Albert i Paradís (Víctor Català), Feminal, November 1917",
   author = "unknown (Feminal); cropped by Blau-Barcelona", licence = "CC BY-SA 4.0",
   licence_url = "https://creativecommons.org/licenses/by-sa/4.0/",
   url = "https://commons.wikimedia.org/wiki/File:Caterina_albert_i_paradis_victor_catala_-_revista_feminal_novembre_1917_(cropped).jpg",
   changes = "used as a reference for a pixel-art caricature; not reproduced"},
  {who = "Peret", title = "Peret at Schiphol with the gold record for Borriquito, 17 November 1971",
   author = "Bert Verhoeff / Anefo, Nationaal Archief", licence = "CC0 1.0",
   url = "https://commons.wikimedia.org/wiki/File:Aankomst_Spaanse_zanger_Peret_op_Schiphol,_Peret_met_gouden_plaat,_Bestanddeelnr_925-1520.jpg"},
  {who = "Antoni Gaudí", title = "Antoni Gaudí (1910), published in Joan Bergós, Gaudí, l'home i l'obra",
   author = "unknown", licence = "public domain",
   url = "https://commons.wikimedia.org/wiki/File:Antoni_Gaud%C3%AD_(1910).jpg"},
  {who = "Antoni Gaudí", title = "Gaudí in the Corpus Christi procession, Barcelona, 19 June 1924",
   author = "Josep Brangulí", licence = "public domain",
   url = "https://commons.wikimedia.org/wiki/File:Brangul%C3%AD_-_Gaud%C3%AD_Corpus_Cat_BCN_1924.jpg"},
  {who = "La Princesa", title = "Saint George Killing the Dragon (1434-1435), Art Institute of Chicago",
   author = "Bernat Martorell", licence = "public domain",
   url = "https://commons.wikimedia.org/wiki/File:Bernat_Martorell_-_Saint_George_Killing_the_Dragon_-_Google_Art_Project.jpg"},
}
