-- What is drawn over the fight (GDD 6): life, time, rounds won, the SUPER stocks, the SENY/RAUXA axis, combos and
-- the messages of the round. Each thing has its own band of the screen, so nothing covers anything else:
--
--   y   2-46   life bars (6-24), the clock's plate between them
--   y  26-46   names under the bars, round medals by the clock
--   y  49-70   SENY [axis] RAUXA, or the MAX bar running out
--   y  85-134  the combo, on the side of who is hitting
--   y 141-200  short messages (CONTRACOP!, a SUPER's name), on the side of who did it
--   y 291-312  SUPER and its three stocks
--
-- Text is placed by where its capitals start (cap), measured from the game's fonts: the arcade font's capitals
-- start 7 px below the y given to text() and are 20 tall, the small font's 6 px and 15; accents rise 5 above.
local M = {}

local INK = 0x200010
local SENY, RAUXA, GOLD = 0x50A8FF, 0xFF4A3A, 0xF0C020
local CAP = {big = 7, arcade = 6, small = 5} -- (Jersey 20, 15 and 10: the capitals 20, 15 and 10 px)
local BAR_W, BAR_X1, BAR_X2 = 196, 8, 276 -- each life bar's width and left edge (with its frame)

function M.cap(s, x, top, o) -- text whose capitals start at row `top`
  o.font, o.outline = o.font or "arcade", o.outline or INK
  text(s, x, top - CAP[o.font] * (o.scale or 1), o)
end
local cap

local wrapped = {} -- the lines a text breaks into, worked out once for each text, width and font

local function lines(s, width, o)
  local key = s .. "\0" .. width .. (o.font or "arcade")
  local got = wrapped[key]
  if got then return got end
  got = {}
  local line = ""
  for word in s:gmatch("%S+") do
    local try = line == "" and word or line .. " " .. word
    if line ~= "" and textw(try, o) > width then
      got[#got + 1], line = line, word
    else
      line = try
    end
  end
  got[#got + 1] = line
  wrapped[key] = got
  return got
end

-- words broken into lines no wider than `width`, each line's capitals `step` below the one before; with `shown`,
-- only that many letters of the whole (typed out letter by letter)
function M.wrap(s, x, top, width, step, o, shown)
  s = T(s) -- the whole text first: its lines are not in the dictionary one by one
  local left = shown or math.huge
  for _, line in ipairs(lines(s, width, o)) do
    if left <= 0 then break end
    local n = utf8.len(line) or #line
    if o.plain then -- no ring round the letters: plain text, cheap even while it is typed out
      text(line, x, top - CAP[o.font], o.color, o.font, o.align or "left", nil, left < n and left or nil)
    else
      o.chars = left < n and left or nil
      M.cap(line, x, top, o)
    end
    left, top = left - n - 1, top + step
  end
  o.chars = nil
  return top
end

function M.label(s, x, y, o) -- text at y (the font's own top), in the game's look
  o = o or {}
  o.font, o.outline = o.font or "arcade", o.outline or INK
  text(s, x, y, o)
end

local O_BIG = {font = "big", align = "center", gradient = 0xFF5020, outline = INK, shadow = 0x000000}
-- big words, their capitals from row `top`; shake: they jump about by that many pixels (the whole word moves, so the
-- console draws the same picture of it each frame instead of working the letters out again)
function M.big(s, top, colour, shake, scale)
  O_BIG.scale, O_BIG.color = scale or 2, colour or 0xFFE070
  while O_BIG.scale > 1 and textw(s, O_BIG) > 464 do -- (a long name: smaller, in the middle of the same room)
    O_BIG.scale, top = O_BIG.scale - 1, top + 10
  end
  local dx, dy = 0, 0
  if shake and shake > 0 then dx, dy = math.random(-shake, shake), math.random(-shake, shake) end
  text(s, 240 + dx, top - CAP.big * O_BIG.scale + dy, O_BIG)
end

-- a band across the screen for big words, opening from the middle in `t` ticks: a dark fill with see-through
-- edges (darkening a whole band of the fight under it, twice, cost the console a frame in two). True once open:
-- its words wait for that (drawn on a band still opening, they stuck out of it)
function M.band(y, h, t)
  local w = math.min(480, (t or 99) * 48)
  local x = 240 - w // 2
  rect(x, y + 6, w, h - 12, 0x0A0C16)
  shade(x, y + 2, w, 4)
  shade(x, y + h - 6, w, 4)
  rect(x, y, w, 2, 0xC09030)
  rect(x, y + h - 2, w, 2, 0xC09030)
  return w >= 480
end

function M.plate(x, y, w, h) -- a small dark sign for a line of help
  rect(x, y, w, h, INK)
  box(x, y, w, h, 0x806030)
end

-- the option tables are made once: the HUD is drawn every frame
local O_NAME = {font = "small", color = 0xFFFFFF}
local O_SENY = {font = "small", color = SENY}
local O_RAUXA = {font = "small", color = RAUXA, align = "right"}
local O_MODE = {font = "small", align = "center"}
local O_SUPER = {font = "small"}
local O_CLOCK = {scale = 2, align = "center", color = 0xFFF0B0, gradient = 0xFFB040}
local O_COMBO = {color = 0xFFE070, gradient = 0xFF6020}
local O_HITS = {font = "small", color = 0xFFFFFF}
local O_BANNER = {align = "center", shadow = 0x000000}
cap = M.cap

local function life(f, right)
  local x = right and BAR_X2 or BAR_X1
  rect(x, 6, BAR_W, 18, 0x101018)
  box(x, 6, BAR_W, 18, 0x806030)
  local w = BAR_W - 4
  local lost, now = math.floor(w * f.shown / f.def.hp), math.floor(w * f.hp / f.def.hp)
  local colour = f.hp < f.def.hp * 0.25 and ticks() // 8 % 2 == 0 and 0xFF7030 or GOLD
  local x0 = x + 2 -- the arcade way: what is left stays at the outer edge, the loss shows by the clock
  if right then
    rect(x0 + w - lost, 8, lost, 14, 0xD02020)
    rect(x0 + w - now, 8, now, 14, colour)
    rect(x0 + w - now, 8, now, 3, 0xFFF0B0)
  else
    rect(x0, 8, lost, 14, 0xD02020)
    rect(x0, 8, now, 14, colour)
    rect(x0, 8, now, 3, 0xFFF0B0)
  end
  O_NAME.align = right and "right" or "left"
  cap(f.def.short, right and 472 or 8, 31, O_NAME)
  for i = 1, 2 do -- two medals to win: gold when won
    local mx = right and 290 + (i - 1) * 16 or 190 - (i - 1) * 16
    circ(mx, 38, 6, INK)
    circ(mx, 38, 5, i <= f.wins and GOLD or 0x2A3450)
  end
end

local function axis(f, right)
  local x = right and BAR_X2 or BAR_X1
  if f.mode then -- the MAX: the whole row in its colour, running out
    local c = f.mode == "seny" and SENY or RAUXA
    local w = math.floor(BAR_W * f.mode_t / 480)
    rect(x, 56, BAR_W, 12, INK)
    rect(right and x + BAR_W - w or x, 57, w, 10, ticks() // 6 % 2 == 0 and c or 0xFFFFFF)
    O_MODE.color = c
    cap(f.mode == "seny" and "SENY MAX" or "RAUXA!", x + BAR_W // 2, 54, O_MODE)
    return
  end
  cap("SENY", x, 54, O_SENY)
  cap("RAUXA", x + BAR_W, 54, O_RAUXA)
  local ax, aw = x + 58, BAR_W - 58 - 66 -- between the two words
  local mid = ax + aw // 2
  rect(ax - 1, 57, aw + 2, 10, INK)
  rect(ax, 58, aw // 2, 8, 0x1C2C48)
  rect(mid, 58, aw - aw // 2, 8, 0x4A1C1C)
  local v = math.floor(f.axis * aw / 200)
  if v < 0 then rect(mid + v, 58, -v, 8, SENY) elseif v > 0 then rect(mid, 58, v, 8, RAUXA) end
  rect(mid + v - 1, 55, 3, 14, 0xFFFFFF)
end

local function stocks(f, right, max, cost)
  local n = max // 100
  local x = right and 472 - 60 - n * 34 or 8 + 60 -- after the word, towards the middle
  O_SUPER.color, O_SUPER.align = f.meter >= cost and 0xFFE070 or 0xC0C0C0, right and "right" or "left"
  cap("SUPER", right and 472 or 8, 296, O_SUPER)
  local full = f.meter // 100
  for i = 0, n - 1 do
    local sx = right and x + (n - 1 - i) * 34 or x + i * 34 -- they fill from the word outwards
    rect(sx, 298, 30, 11, INK)
    local w = i < full and 28 or i == full and math.floor(28 * (f.meter % 100) / 100) or 0
    local c = i < full and (ticks() // 10 % 2 == 0 and 0xFFE070 or 0xFFB020) or 0x3A7AD0
    if w > 0 then rect(right and sx + 29 - w or sx + 1, 299, w, 9, c) end
  end
end

local function combo(o, right) -- o is the one being hit: the count shows on the hitter's side
  if o.combo < 2 or o.combo_t <= 0 then return end
  local x = right and 472 or 8
  O_COMBO.align, O_HITS.align = right and "right" or "left", right and "right" or "left"
  cap(o.combo .. " " .. T("COPS"), x, 92, O_COMBO)
  cap(o.combo_dmg .. " " .. T("DE DANY"), x, 118, O_HITS)
end

local function clock_plate(clock) -- no clock (training, or the option): two dashes
  rect(214, 2, 52, 44, INK)
  box(214, 2, 52, 44, 0x806030)
  cap(clock and string.format("%02d", math.max(0, (clock + 59) // 60)) or "--", 240, 7, O_CLOCK)
end

local O_SCORE = {font = "small", align = "center", color = 0xFFFFFF}

local stack = {0, 0}

-- side: draw combos and messages (only while fighting: a round's big words have the middle to themselves);
-- score: show the player's score (arcade), between the two SUPER rows
function M.draw(fight, clock, side, score, quiet) -- quiet: the round is over, the SENY/RAUXA row makes room
  local p1, p2 = fight.p[1], fight.p[2]
  life(p1, false)
  life(p2, true)
  clock_plate(clock)
  if not quiet then
    axis(p1, false)
    axis(p2, true)
  end
  stocks(p1, false, fight.METER_MAX, fight.SUPER_COST)
  stocks(p2, true, fight.METER_MAX, fight.SUPER_COST)
  if score then cap(string.format("%07d", p1.score), 240, 296, O_SCORE) end
  if not side then return end
  combo(p2, false)
  combo(p1, true)
  stack[1], stack[2] = 0, 0
  for _, b in ipairs(fight.banners) do
    local s = b.who == p2 and 2 or 1
    local top = 146 + stack[s] * 30
    stack[s] = stack[s] + 1
    if stack[s] <= 2 and (b.t < 70 or b.t % 4 < 2) then
      O_BANNER.font, O_BANNER.color = "arcade", b.colour
      local w = textw(b.text, O_BANNER)
      if w > 220 then O_BANNER.font, w = "small", textw(b.text, {font = "small"}) end
      local half = w // 2 + 4
      cap(b.text, math.max(half, math.min(480 - half, s == 1 and 120 or 360)), top, O_BANNER)
    end
  end
end

return M
