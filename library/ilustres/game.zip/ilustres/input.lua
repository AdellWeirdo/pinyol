-- A fighter's pad: the buttons this tick, when each was last pressed, and the history of directions in numpad
-- notation relative to where the fighter faces (6 forward, 4 back, 2 down, 8 up, 5 nothing), from which motions
-- are read. The player and the CPU fill it the same way, with a table of keys each tick.
local M = {}

local BUTTONS = {"a", "b", "c"}
local HISTORY = 24 -- direction changes kept

function M.new()
  return {held = {}, hist = {}, at = {}, tick = 0, dir = 5, cmd = nil}
end

-- frozen: the picture stands still (a hit's stop): what is pressed is kept for when it moves again
function M.feed(pad, keys, facing, frozen)
  if not frozen then pad.tick = pad.tick + 1 end
  local x = ((keys.right and 1 or 0) - (keys.left and 1 or 0)) * facing
  local y = (keys.up and 1 or 0) - (keys.down and 1 or 0)
  local d = 5 + x + 3 * y
  if d ~= pad.dir or not pad.hist[1] then
    pad.dir = d
    pad.hist[#pad.hist + 1] = {d, pad.tick}
    if #pad.hist > HISTORY then table.remove(pad.hist, 1) end
  end
  local pressed = false
  for _, k in ipairs(BUTTONS) do -- keys may be a table its owner refills: only its values are kept
    local down = keys[k] or false
    if down and not pad.held[k] then pad.at[k] = pad.tick pressed = true end
    pad.held[k] = down
  end
  local log = pad.log -- training shows the last inputs: a new direction, or a button pressed
  local last = log and log[#log]
  if log and not frozen and (pressed or (d ~= 5 and (not last or last.d ~= d))) then
    log[#log + 1] = {d = d, a = pressed and keys.a and pad.at.a == pad.tick, b = pressed and keys.b and pad.at.b == pad.tick,
                     c = pressed and keys.c and pad.at.c == pad.tick}
    if #log > 10 then table.remove(log, 1) end
  end
end

-- pressed within the last `within` ticks and not used yet
function M.fresh(pad, k, within)
  local at = pad.at[k]
  return at ~= nil and pad.tick - at < (within or 1)
end

function M.use(pad) -- the buttons' presses are spent
  pad.at.a, pad.at.b, pad.at.c = nil, nil, nil
end

-- the directions of seq were held in that order (others may come between), all within `window` ticks
function M.motion(pad, seq, window)
  local i, h = #seq, pad.hist
  for k = #h, 1, -1 do
    local ended = k < #h and h[k + 1][2] or pad.tick
    if pad.tick - ended > window then return false end
    if h[k][1] == seq[i] then
      i = i - 1
      if i == 0 then return true end
    end
  end
  return false
end

-- d, let go, d again, just now (or the tick before) and nothing else between (a dash): the first d let go within `window` ticks
function M.double(pad, d, window)
  local h = pad.hist
  local n = #h
  return n >= 3 and h[n][1] == d and pad.tick - h[n][2] <= 1 and h[n - 1][1] == 5 and h[n - 2][1] == d
    and pad.tick - h[n - 1][2] <= window
end

return M
