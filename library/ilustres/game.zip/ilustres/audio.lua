-- The game's sounds, made from numbers when it starts (sfxr-style recipes, no files), and its music
-- (audio/*.mod, written by music/compose.py). The options can silence either.
local M = {}

M.music_on, M.sfx_on = true, true
local playing = nil

local function make()
  sound("SND_HIT", "hit", 7)
  local heavy = sound("SND_HEAVY", "hit", 7)
  heavy.freq, heavy.decay = heavy.freq * 0.6, heavy.decay * 1.6
  sound("SND_HEAVY", heavy)
  sound("SND_COUNTER", {wave = "square", freq = 660, arp = 1.5, arp_time = 0.05, sustain = 0.05, decay = 0.15,
                        volume = 0.35})
  sound("SND_BLOCK", "blip", 3)
  sound("SND_SWING", {wave = "noise", freq = 900, slide = -4000, sustain = 0.03, decay = 0.08, volume = 0.25})
  sound("SND_DASH", {wave = "noise", freq = 500, slide = -1500, sustain = 0.05, decay = 0.12, volume = 0.25})
  sound("SND_JUMP", {wave = "square", freq = 220, slide = 900, sustain = 0.04, decay = 0.06, volume = 0.18, duty = 0.25})
  sound("SND_STEP", {wave = "noise", freq = 300, sustain = 0.01, decay = 0.06, volume = 0.25})
  sound("SND_GRAB", {wave = "noise", freq = 700, slide = -300, sustain = 0.04, decay = 0.1, volume = 0.35})
  sound("SND_TAUNT", {wave = "square", freq = 520, vibrato = 0.4, vibrato_speed = 12, sustain = 0.2, decay = 0.2,
                      volume = 0.2, duty = 0.25})
  -- Dalí: a clock that boings, a melting slide down; Gaudí: stone that rises and rumbles
  sound("SND_CLOCK", {wave = "sine", freq = 880, vibrato = 0.6, vibrato_speed = 18, slide = -600, sustain = 0.12,
                      decay = 0.25, volume = 0.35})
  sound("SND_MELT", {wave = "triangle", freq = 600, slide = -900, vibrato = 0.5, vibrato_speed = 9, sustain = 0.25,
                     decay = 0.3, volume = 0.35})
  sound("SND_STONE", {wave = "noise", freq = 140, slide = 60, sustain = 0.18, decay = 0.3, volume = 0.45,
                      lowpass = 0.35})
  local special = sound("SND_SPECIAL", "laser", 4) -- (half: it is the sound most specials make, and was the loudest)
  special.volume = (special.volume or 0.5) * 0.5
  sound("SND_SPECIAL", special)
  -- the others' shots, each its own (roster.lua: shot.sound)
  sound("SND_CELLO", {wave = "saw", freq = 131, vibrato = 0.25, vibrato_speed = 6, sustain = 0.22, decay = 0.25,
                      volume = 0.3, lowpass = 0.5})
  sound("SND_VOICE", {wave = "sine", freq = 1047, vibrato = 0.5, vibrato_speed = 7, sustain = 0.3, decay = 0.2,
                      volume = 0.3})
  sound("SND_CHIME", {wave = "triangle", freq = 1320, arp = 1.5, arp_time = 0.06, sustain = 0.08, decay = 0.3,
                      volume = 0.42})
  sound("SND_PETALS", {wave = "noise", freq = 2400, slide = -1500, sustain = 0.06, decay = 0.25, volume = 0.8})
  sound("SND_BRUSH", {wave = "noise", freq = 1600, slide = -2500, sustain = 0.05, decay = 0.12, volume = 0.6})
  sound("SND_PUFF", {wave = "noise", freq = 350, slide = -200, sustain = 0.1, decay = 0.3, volume = 0.75, lowpass = 0.4})
  sound("SND_WIND", {wave = "noise", freq = 600, vibrato = 0.4, vibrato_speed = 4, sustain = 0.3, decay = 0.35,
                     volume = 0.8, lowpass = 0.5})
  sound("SND_COIN", "coin", 7)
  sound("SND_WOOD", {wave = "square", freq = 180, slide = -200, sustain = 0.02, decay = 0.12, volume = 0.3, duty = 0.4})
  -- the boss: a plate thrown (porcelain ringing), and the screen's tricks (a crackle of a signal lost)
  sound("SND_PLATE", {wave = "triangle", freq = 2093, arp = 1.26, arp_time = 0.03, sustain = 0.04, decay = 0.2,
                      volume = 0.35})
  sound("SND_GLITCH", {wave = "square", freq = 90, slide = 900, vibrato = 0.8, vibrato_speed = 30, sustain = 0.12,
                       decay = 0.1, volume = 0.22, duty = 0.2})
  sound("SND_DRUM", {wave = "noise", freq = 160, sustain = 0.03, decay = 0.2, volume = 0.8, lowpass = 0.3})
  sound("SND_SUPER", "powerup", 9)
  sound("SND_KO", "explosion", 5)
  sound("SND_ROUND", "powerup", 2)
  sound("SND_MODE", "powerup", 5)
  sound("SND_LAND", {wave = "noise", freq = 200, slide = -300, sustain = 0.02, decay = 0.15, volume = 0.35})
  sound("SND_MOVE", "blip", 1)
  sound("SND_PICK", "coin", 2)
  sound("SND_NO", {wave = "square", freq = 120, sustain = 0.08, decay = 0.1, volume = 0.3})
  sound("SND_TICK", {wave = "square", freq = 1400, sustain = 0.01, decay = 0.03, volume = 0.2, duty = 0.125})
end

function M.init() make() end

function M.music(id) -- id: a tune of audio/, or nil to stop; the same one again keeps playing
  if not M.music_on then id = nil end
  if id == playing then return end
  playing = id
  if id then music(id) else music() end
end

function M.playing() return playing end

function M.set(music_on, sfx_on)
  M.music_on, M.sfx_on = music_on, sfx_on
  if not music_on then M.music(nil) end
end

local raw = sfx
local SFX_GAIN = 0.65 -- every sound a little under its recipe, so the music is heard under the blows (measured)
function sfx(id, gain, opts) -- every sound of the game goes through here, so the option can silence them
  if not M.sfx_on then return nil end
  return raw(id, (gain or 1) * SFX_GAIN, opts)
end

return M
