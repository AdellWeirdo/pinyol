-- Drawing shared by the screens: pictures that may not exist yet (a checkout before art.py), fighters from their
-- two strips and four palettes, portraits.
local F = require("fighters")

local M = {}

M.ART = {W = 312, H = 272, AX = 124, AY = 268} -- a fighter's frame, and its feet's middle in it
M.look = {} -- one options table for img(), reused

local has = {}
function M.has(id) -- is this picture in the game? (asked once; asking loads it, as drawing it would)
  if has[id] == nil then has[id] = imgsize(id) ~= nil end
  return has[id]
end

-- is this fighter drawn yet? Asked of its second palette, a file of a few bytes made with its strips (asking of a
-- strip would load all of it: 3 MB at the start for five fighters, measured on the console)
function M.drawn(def) return M.has(def.art .. "_P2") end

local ids = {} -- ids[base][strip][palette] = {strip's name, palette picture or false, its pieces' names}, made once
local function id(base, strip, palette)
  local b = ids[base]
  if not b then b = {{}, {}} ids[base] = b end
  local p = b[strip][palette]
  if not p then
    local pic = base .. (strip == 2 and "2" or "")
    p = {pic, palette > 1 and (pic .. "_P" .. palette) or false, {}}
    b[strip][palette] = p
  end
  return p
end
local function piece(p, k) -- the picture holding frames k * CHUNK.. of that strip (pieces of a sheet: fighters.lua F.CHUNK)
  local s = p[3][k]
  if not s then s = p[1] .. "_C" .. k p[3][k] = s end
  return s
end

-- frame f of a fighter (def), its feet at (x, y), facing right unless flip; palette 1-4; tint (a hit's flash)
function M.fighter(def, frame, x, y, flip, palette, tint, scale) -- scale: smaller, from the picture's corner
  local strip = frame >= F.STRIP and 2 or 1
  local base = def.art
  if palette == 4 and def.alt_art and M.has(def.alt_art .. "_P2") then -- a second costume in the fourth colours' place
    base, palette = def.alt_art, 1
  end
  local p = id(base, strip, palette or 1)
  local f = strip == 2 and frame - F.STRIP or frame -- the frame in its strip, drawn from the piece that holds it
  local sheet = piece(p, f // F.CHUNK)
  if not M.has(sheet) then return false end
  local L = M.look
  local k = scale or 1
  L.frame, L.flip_x, L.tint, L.angle, L.scale = f % F.CHUNK, flip, tint, nil, scale
  L.pal = p[2] and M.has(p[2]) and p[2] or nil
  img(sheet, math.floor(flip and x - (M.ART.W - M.ART.AX) * k or x - M.ART.AX * k), math.floor(y - M.ART.AY * k), L)
  L.pal = nil
  return true
end

-- name, width, height, the dark one, and (the big one) the frames to a piece: PORTRAITS_L_C0.. of 4 (tools/pk_split.py, run by
-- art.py); the whole atlas was 825 KB and the VS screen could find no block for it on the console
local SIZES = {c = {"PORTRAITS_C", 50, 37, "PORTRAITS_C_DARK"}, b = {"PORTRAITS_B", 121, 82, "PORTRAITS_B_DARK"},
               l = {"PORTRAITS_L", 240, 150, nil, 4}}

-- portrait i (0-15, the roster's order) at size "c" (50x37, a select cell), "b" (121x82) or "l" (240x150);
-- the ones not playable yet in the dark (their own darkened colours: free to draw)
function M.portrait(i, x, y, size, locked)
  local s = SIZES[size]
  local sheet, frame = s[1], i
  if s[5] then sheet, frame = s[1] .. "_C" .. (i // s[5]), i % s[5] end
  if M.has(sheet) then
    local L = M.look
    L.frame, L.flip_x, L.tint, L.scale, L.angle = frame, false, nil, nil, nil
    L.pal = locked and s[4] and M.has(s[4]) and s[4] or nil
    img(sheet, x, y, L)
    L.pal = nil
  else
    rect(x, y, s[2], s[3], locked and 0x141C2C or 0x5060A0)
  end
end

function M.pic(pid, x, y, frame, flip) -- any picture, if it is there
  if not M.has(pid) then return false end
  local L = M.look
  L.frame, L.flip_x, L.tint, L.scale, L.angle = frame or 0, flip or false, nil, nil, nil
  img(pid, x, y, L)
  return true
end

return M
