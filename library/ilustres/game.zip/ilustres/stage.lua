-- The stages (GDD 14): a far layer that moves at its own pace behind a near one where the fighters stand, and life:
-- the people watching (each with a few frames: watching, cheering, wild), who cheer the big blows and go wild at a
-- SUPER or a K.O., as a Neo Geo crowd does; Park Güell's pigeons walk, peck and fly off when the fight comes close;
-- Cadaqués' gulls cross the sky. A fighter fights on the other's home stage, as the arcade route would.
local gfx = require("gfx")

local M = {}

-- crowd: who watches, where (x along the stage, y the screen row of their feet or seat), facing left or not
M.LIST = {
  parkguell = {name = "PARK GÜELL", far = "BG_FAR", near = "BG_NEAR", music = "PARK", birds = "pigeons",
               crowd = {{pic = "CROWD_TOURIST", x = 150, y = 238}, {pic = "CROWD_GRANDPA", x = 600, y = 238, flip = true}}},
  cadaques = {name = "PORTLLIGAT, CADAQUÉS", far = "BG_FAR_CADAQUES", near = "BG_NEAR_CADAQUES", music = "CADAQUES",
              birds = "gulls",
              crowd = {{pic = "CROWD_FISHER", x = 240, y = 214}, {pic = "CROWD_PAINTER", x = 70, y = 250},
                       {pic = "CROWD_LOCALS", x = 560, y = 250, flip = true}}},
  institut = {name = "INSTITUT D'ESTUDIS CATALANS", far = "BG_FAR_INSTITUT", near = "BG_NEAR_INSTITUT",
              music = "INSTITUT", crowd = {{pic = "CROWD_LIBRARIAN", x = 150, y = 256},
                                           {pic = "CROWD_STUDENT", x = 530, y = 256, flip = true}}},
  nit = {name = "BARCELONA DE NIT", far = "BG_FAR_NIT", near = "BG_NEAR_NIT", music = "NIT",
         crowd = {{pic = "CROWD_JAZZ", x = 150, y = 262}, {pic = "CROWD_ARTLOVERS", x = 530, y = 262, flip = true}}},
}

-- the other twelve home stages and the boss's set (art/roster.py): two people watching each, behind the fight
for key, name in pairs({montserrat = "MONTSERRAT", palau = "PALAU DE LA MÚSICA", diamant = "PLAÇA DEL DIAMANT",
                        monestir = "MONESTIR DE MIRAMAR", liceu = "GRAN TEATRE DEL LICEU", eixample = "L'EIXAMPLE",
                        cauferrat = "CAU FERRAT, SITGES", poesia = "ESCENARI DE POESIA VISUAL", emporda = "L'EMPORDÀ",
                        muntanya = "MUNTANYA I VENT", taller = "ESPAI MATÈRIC", gracia = "FESTA DE GRÀCIA",
                        plato = "PLATÓ DE TELEVISIÓ"}) do
  local up = key:upper()
  M.LIST[key] = {name = name, far = "BG_FAR_" .. up, near = "BG_NEAR_" .. up, music = up,
                 crowd = {{pic = "CROWD_" .. up, x = 140, y = 262}, {pic = "CROWD_" .. up, x = 560, y = 262, flip = true,
                                                                      late = true}}}
end

local mood, mood_t = "calm", 0 -- "calm", "cheer" (a big blow, a combo) or "wild" (a SUPER, a K.O.), for how long

function M.excite(how, ticks) -- the crowd reacts; a stronger reaction is not cut short by a weaker one
  local rank = {calm = 0, cheer = 1, wild = 2}
  if rank[how] > rank[mood] or ticks > mood_t then mood, mood_t = how, math.max(mood_t, ticks) end
end

M.width = 720
local cur = M.LIST.parkguell
local birds = {}

-- The far layer lives in the world: a canvas at half size on BG3, which the PPU doubles under the overlay. Drawn by
-- img each frame, a 480x320 picture cost 7 ms of CPU on the console; as a layer, 2 (the engine's docs/measurements.md,
-- 2026-10-22). The near layer, the crowd and the fighters stay on the overlay, at the screen's own resolution.
local far_world, far_w = false, 640

function M.set(key)
  cur = M.LIST[key] or M.LIST.parkguell
  if not gfx.has(cur.far) then cur = M.LIST.nit end -- (a stage whose pictures are not made yet: Barcelona at night)
  local w = gfx.has(cur.near) and imgsize(cur.near)
  M.width = w or 720
  far_world = false
  if gfx.has(cur.far) then
    local fw, fh = imgsize(cur.far)
    far_w = fw
    canvas("FAR", fw // 2, fh // 2)
    target("FAR")
    img(cur.far, 0, 0, {scale = 0.5})
    target()
    bg(3, {image = "FAR", wrap = false})
    far_world = true
  end
  birds = {}
  mood, mood_t = "calm", 0
  if not cur.birds then -- indoors, or a night with no birds
  elseif cur.birds == "pigeons" then -- on the floor between the bench and the fighters
    for i, x in ipairs({70, 160, M.width - 150, M.width - 60}) do
      birds[i] = {x = x, y = 290 - (i % 2) * 6, dir = i % 2 == 0 and -1 or 1, state = "walk", t = i * 37, vx = 0, vy = 0}
    end
  else -- gulls: two, crossing the sky now and then
    for i = 1, 2 do birds[i] = {x = -40 - i * 200, y = 40 + i * 22, dir = 1, state = "fly", t = 0, vx = 1.2 + i * 0.3, vy = 0} end
  end
  return cur
end

function M.current() return cur end

-- fighters: where the fight is; a pigeon within reach of a fighter, or of a landing, takes off
function M.update(fighters)
  if mood_t > 0 then
    mood_t = mood_t - 1
    if mood_t == 0 then mood = "calm" end
  end
  for _, b in ipairs(birds) do
    b.t = b.t + 1
    if b.state == "walk" then
      for _, f in ipairs(fighters) do
        if math.abs(f.x - b.x) < 90 and (f.act ~= "free" or math.abs(f.vx) > 0) then
          b.state, b.dir, b.vx, b.vy = "fly", f.x < b.x and 1 or -1, 0, -2.6
          b.vx = b.dir * 2.2
        end
      end
      if b.t % 120 < 40 then b.x = b.x + b.dir * 0.3 end
    else
      b.x, b.y = b.x + b.vx, b.y + b.vy
      if cur.birds == "gulls" then
        b.y = b.y + math.sin(b.t / 30) * 0.3
        if b.x > M.width + 60 then b.x, b.t = -60 - math.random(300), 0 end
      elseif b.y < -40 then -- a pigeon that flew off lands again later, somewhere else
        b.state, b.x, b.y, b.vy = "walk", 40 + math.random(M.width - 80), 290 - math.random(0, 6), 0
      end
    end
  end
end

local function draw_crowd()
  local t = ticks()
  for i, c in ipairs(cur.crowd) do
    if gfx.has(c.pic) then
      local w, h = imgsize(c.pic)
      local frame, hop = 0, 0
      local k = t + i * 17 -- each in their own time
      if mood == "wild" then
        frame = (k // 7) % 2 == 0 and 3 or 4
        hop = frame == 4 and -4 or 0
      elseif mood == "cheer" then
        frame = (k // 10) % 2 == 0 and 2 or 3
      else
        frame = (k // 50) % 4 == 3 and 1 or 0
      end
      gfx.pic(c.pic, math.floor(c.x - w / 2), c.y - h + hop, frame, c.flip)
    end
  end
end

local function draw_birds()
  if not cur.birds then return end
  local pid = cur.birds == "pigeons" and "BIRD_PIGEON" or "BIRD_GULL"
  if not gfx.has(pid) then return end
  local w, h = imgsize(pid)
  for _, b in ipairs(birds) do
    local frame
    if cur.birds == "gulls" then frame = (b.t // 6) % 5
    elseif b.state == "fly" then frame = 2 + (b.t // 4) % 3
    else frame = (b.t % 120 < 40 or (b.t // 30) % 3 ~= 0) and 0 or 1 end
    gfx.pic(pid, math.floor(b.x - w / 2), math.floor(b.y - h), frame, b.dir < 0)
  end
end

-- cam: the stage's left edge on the screen; super: a fighter whose SUPER shows its background
function M.draw(cam, ox, oy, super, flashing)
  camera(ox, oy)
  local own_bg = super and gfx.has(super.def.super_bg)
  show(far_world and not own_bg and BG3 or 0) -- (the SUPER's own background covers the world: no use composing it)
  if own_bg then
    gfx.pic(super.def.super_bg, 0, 0)
  elseif far_world then -- the layer's scroll: the camera's share of the far picture, and the screen's shake, halved
    local k = M.width > 480 and (far_w - 480) / (M.width - 480) or 0
    scroll(3, math.floor((cam * k + ox) / 2), math.floor(oy / 2))
  else
    rect(0, 0, 480, 320, 0x3A5A8A)
    rect(0, 200, 480, 120, 0x6A5030)
  end
  if flashing then camera(math.floor(cam) + ox, oy) return end -- the SUPER's flash: only its background, the
  camera(math.floor(cam) + ox, oy)                                -- fighters in front of it (darkening it all costs)
  if cur.birds == "gulls" and not super then draw_birds() end -- in the sky, behind the terrace
  if gfx.has(cur.near) then
    local _, nh = imgsize(cur.near)
    if super then clip(0, 268, 480, 52) end -- a SUPER: its background whole, the near layer only as the floor
    gfx.pic(cur.near, 0, 320 - nh)
    if super then clip() end
  else
    rect(0, 292, M.width, 28, 0xB08850)
  end
  if super then return end -- (a SUPER's vision: no one watching in it)
  draw_crowd()
  if cur.birds == "pigeons" then draw_birds() end
end

return M
