-- IL·LUSTRES: COMBAT DE LLEGENDA. The vertical slice of the GDD (docs/GDD_v1.0.pdf, 17.1): Dalí against Gaudí, each
-- on the other's home stage, best of three rounds, against the console; with the arcade's whole flow around it
-- (docs/SLICE.md says what is in). Everything drawn at the screen's full 480x320 from packed pictures (art.py), but
-- the stage's far layer, which lives in the world at half size (stage.lua: a third of the frame's CPU, measured).
--
-- Buttons (the console has three, the GDD four): A light punch, B strong punch, C kick; down + A/B/C crouching blows
-- (down+B knocks jumpers down, down+C sweeps); forward+C strong kick; A+C throw; A+B taunt; in the air A, B or C;
-- down, down-forward, forward + A/B special; down, down-back, back + A/B second special; twice forward + B SUPER;
-- back to block (down-back for low blows); forward forward dash, back back step away; on the floor, back or forward
-- to roll. START pauses (training: its menu, where the boxes are shown). (The console's MENU acts as START.)
local juice = require("juice")
local lockstep = require("lockstep")
local F = require("fighters")
local fight = require("fight")
local hud = require("hud")
local ai = require("ai")
local screens = require("title")
local menus = require("menus")
local gfx = require("gfx")
local stage = require("stage")
local powers = require("powers")
local FXMETA = require("fxmeta")
local bstage = require("bonus")
local audio = require("audio")
local opt = require("options")
local boss = require("boss")
local rivals = require("rivals")

local ROUNDS = {"PRIMER ASSALT", "SEGON ASSALT", "ASSALT FINAL"}
local ATTRACT_TICKS = 15 * 60 -- the title left alone this long: the console plays itself (a demo)
local INTRO = 100             -- the first round starts with each fighter's entrance
local NONE = {}

game = {state = "boot", round = 1, p = {}, clock = 0, debug = false, paused = false, results = {}, mode = "arcade",
        found = {}, preload_from = 0}
local timer, cam = 0, 0
local brains = {} -- one CPU mind per fighter the console plays
local sel, opts, train = nil, {at = 1}, {at = 1, dummy = 1, boxes = false, inputs = true}
local ini, ini_score, ini_rank
local verdict, perfect, narrator, bonus = nil, false, nil, 0

local function go(s) game.state, timer = s, 0 end

-- Castilian (GDD 2): while the option asks for it, every text drawn or measured is looked up in es.lua (loaded the
-- first time it is needed); T() is there for the texts made of pieces ("GUANYA " .. name)
local raw_text, raw_textw, ES = text, textw, nil
function T(s)
  if opt.v.lang ~= 2 or type(s) ~= "string" then return s end
  ES = ES or require("es")
  return ES[s] or s
end
function text(s, ...) return raw_text(T(s), ...) end
function textw(s, ...) return raw_textw(T(s), ...) end

local function apply_options()
  audio.set(opt.v.music, opt.v.sfx)
  fight.simple = opt.v.simple
  fight.chip_kills = opt.v.level >= 3 -- GDD 4.5: in the higher levels the chip may finish
  fight.power = opt.code.rauxa and 2 or 1 -- the codes that change the fights
  fight.weight = opt.code.lluna and 0.4 or 1
  fight.one_hit = opt.code.uncop == true
  ai.level(opt.v.level)
end

-- ------------------------------------------------------------------ two consoles (VERSUS > DUES CONSOLES)
-- Both consoles run the same fight in step (lib/lockstep: only buttons travel; each tick waits for both players'
-- buttons, two frames of three ticks after they were pressed). The console with the smaller id is P1; its rules
-- (round time, simple inputs, the codes) hold for both, and the secrets both have found can be picked. While the
-- other's buttons are not here nothing moves (a short wait is the normal lag; ten seconds and it is gone).
local lk = nil -- the session: ls (the lockstep), other (its id), hello (what each console said), rules, the two
               -- players' bits, held and pressed this tick, and quiet (ticks waiting for the other)
local LINK_KEYS = {"up", "down", "left", "right", "a", "b", "c", "start"}
local LINKED = {select = true, vs = true, intro = true, fight = true, ko = true, over = true, winquote = true}

local function pressed(i, k) -- player i's button went down this tick (the pad's, when not linked)
  if lk then return lk.pressed[i][k] end
  return btnp(k)
end
local function any_pressed(k) return pressed(1, k) or (lk ~= nil and pressed(2, k)) end
local function code(k) if lk then return lk.rules[k] end return opt.code[k] end -- the codes in force

local function link_keys(i, bits) -- player i's buttons this tick, from the bits that came in step
  local before = lk.bits[i]
  for _, k in ipairs(LINK_KEYS) do
    local down = lockstep.down(bits, k)
    lk.held[i][k], lk.pressed[i][k] = down, down and not lockstep.down(before, k)
  end
  lk.bits[i] = bits
end

local function my_rules()
  return {time = opt.v.time, simple = opt.v.simple == true, chip = opt.v.level >= 3, rauxa = opt.code.rauxa == true,
          lluna = opt.code.lluna == true, uncop = opt.code.uncop == true, turbo = opt.code.turbo == true}
end

local function rules_ok(r) -- what the other console sent, checked before it is believed
  if type(r) ~= "table" or type(r.time) ~= "number" or opt.TIMES[r.time] == nil then return false end
  for _, k in ipairs({"simple", "chip", "rauxa", "lluna", "uncop", "turbo"}) do
    if type(r[k]) ~= "boolean" then return false end
  end
  return true
end

local function unlocked_keys()
  local list = {}
  for k in pairs(opt.SECRETS) do if opt.unlocked(k) then list[#list + 1] = k end end
  table.sort(list)
  return list
end

local function link_hello() link.send({h = 1, r = my_rules(), u = unlocked_keys()}) end

local function link_new()
  lk = {hello = {}, bits = {0, 0}, held = {{}, {}}, pressed = {{}, {}}, quiet = 0}
  game.link = lk -- (tests read it)
end

local function link_end()
  lk, game.link, game.link_unlocked = nil, nil, nil
  apply_options()
end

function _init()
  show(0) -- no 240x160 world: every pixel at the screen's own resolution
  opt.load()
  -- who has no pictures yet (the roster is drawn as it is made) waits behind a padlock, and is no one's rival
  local ready = {}
  for _, f in ipairs(F.list) do if gfx.drawn(f) then ready[#ready + 1] = f end end
  F.list = ready
  for _, r in ipairs(F.roster) do if r.fighter and not gfx.drawn(r.fighter) then r.fighter = nil end end
  audio.init()
  apply_options()
end

-- ------------------------------------------------------------------ the match

local function round_ticks() -- nil: no clock (training, or the option)
  if game.mode == "training" then return nil end
  if lk then local t = opt.TIMES[lk.rules.time] return t > 0 and t * 60 or nil end -- (P1's option)
  return opt.round_ticks()
end

local function new_round()
  stage.set(game.p[2].def.stage) -- on the other's home ground
  fight.stage_w = stage.width
  fight.start_round(game.p[1], game.p[2])
  game.state, timer, verdict, perfect, narrator, bonus = "intro", 0, nil, false, nil, 0
  game.clock, game.glory = round_ticks(), false
  for _, f in ipairs(game.p) do
    brains[f] = ai.new()
    if game.round == 1 and game.mode ~= "training" then f.act, f.t = "intro", 0 end
  end
  if game.mode == "training" then game.p[1].pad.log = {} end
  boss.round_start()
  game.make_preload()
  audio.music(stage.current().music)
  sfx("SND_ROUND")
end

local function other_palette(a, b, pal1) return a == b and pal1 % F.PALETTES + 1 or 1 end -- a mirror match: another

-- mode: "arcade", "training" or "demo" (the console plays both)
-- score: what p1 brings from the fights before (the arcade's ladder)
function game.start(p1_def, p2_def, mode, pal1, pal2, score, handicap)
  game.mode = mode or "arcade"
  game.demo = game.mode == "demo"
  game.training = game.mode == "training"
  brains = {}
  pal1 = pal1 or 1
  pal2 = pal2 or other_palette(p1_def, p2_def, pal1)
  local the_boss = game.mode == "arcade" and p2_def.boss
  if the_boss then p2_def = boss.as_boss(p2_def) end -- (more life than in VERSUS, and played a level up)
  ai.level(the_boss and math.min(4, opt.v.level + 1) or opt.v.level)
  game.p = {fight.fighter(p1_def, game.demo, pal1), fight.fighter(p2_def, game.mode ~= "link", pal2)}
  if the_boss == 1 and game.boss_stock then -- DESTROSSA EL PLATÓ! done whole: one SUPER stock to start (GDD 9.3)
    game.p[1].meter, game.boss_stock = fight.METER_MAX // 3, nil
  end
  if handicap then game.p[1].handicap, game.p[2].handicap = handicap[1], handicap[2] end
  game.p[1].score = score or 0
  game.round = 1
  new_round()
end

local function round_over(winner, why)
  game.state, timer, verdict = "ko", 0, why
  local p1 = game.p[1]
  if winner then
    winner.wins = winner.wins + 1
    perfect = not winner.hurt_round
    if winner == p1 and game.mode == "arcade" then -- GDD 8.3: life, time and a perfect round count
      bonus = p1.hp * 10 + (game.clock and game.clock // 60 * 100 or 0) + (perfect and 10000 or 0)
      p1.score = p1.score + bonus
      game.bonus_text = "BONUS " .. bonus
    end
    -- the narrator speaks only at rare moments (GDD 6.3)
    if perfect then narrator = "A PASTAR FANG!"
    elseif fight.last_kind == "super" and why == "K.O." then narrator = "QUINA CASTANYA!"
    elseif winner.hp < winner.def.hp * 0.08 then narrator = "PER UN PÈL!" end
    narrator = boss.narrator(game, narrator)
  else -- both down at once, or the same life when time runs out: a round for each
    for _, f in ipairs(game.p) do f.wins = f.wins + 1 end
  end
  if why == "TEMPS!" then
    for _, f in ipairs(game.p) do
      if f ~= winner and f.act ~= "fall" and f.act ~= "down" then f.act, f.t, f.move = "lose", 0, nil end
    end
  end
  game.winner = winner
  fight.shots, fight.walls = {}, {}
  stage.excite("wild", 200)
  sfx("SND_KO")
  juice.freeze(24)
end

local held = {} -- the player's keys, one table refilled each tick

local function keys_of(f, frozen)
  if game.state ~= "fight" or f.act == "win" then return NONE end
  if lk then return lk.held[f == game.p[1] and 1 or 2] end -- both players' buttons came in step
  if f.cpu then
    if game.cpu_off or frozen then return NONE end -- tests stop it
    local mode = game.training and ai.DUMMIES[train.dummy]
    if mode and mode ~= "CPU" then return ai.dummy(brains[f], f, fight.other(f), fight, mode) end
    return ai.keys(brains[f], f, fight.other(f), fight)
  end
  held.up, held.down, held.left, held.right = btn("up"), btn("down"), btn("left"), btn("right")
  held.a, held.b, held.c = btn("a"), btn("b"), btn("c")
  return held
end

local function play_tick()
  local frozen = fight.flash ~= nil -- a SUPER's flash: presses are kept, time does not run for them
  for _, f in ipairs(game.p) do fight.feed(f.pad, keys_of(f, frozen), f.dir, frozen) end
  fight.update()
  if code("rauxa") then for _, f in ipairs(game.p) do f.meter = fight.METER_MAX end end
  for _, sp in ipairs(fight.sparks) do -- the crowd: a heavy blow or a long combo makes it cheer
    if sp.t == 0 and sp.kind == "heavy" then stage.excite("cheer", 50) end
  end
  for _, f in ipairs(game.p) do if f.combo >= 3 and f.combo_t == 90 then stage.excite("cheer", 70) end end
  if fight.flash and fight.flash.t == 1 then stage.excite("wild", 100) end
  stage.update(game.p)
  if fight.glory and not game.glory then -- MOMENT DE GLÒRIA: its own music to the end of the round
    game.glory = true
    audio.music("GLORY")
    sfx("SND_MODE")
  end
end

local function training_tick() -- no clock, no K.O.: life and SUPER come back when the combo is over
  play_tick()
  for _, f in ipairs(game.p) do
    if f.combo_t <= 0 and f.act == "free" then f.hp = math.min(f.def.hp, f.hp + 20) end
    f.hp = math.max(1, f.hp)
    f.meter = fight.METER_MAX
  end
end

local function fight_tick()
  if game.training then return training_tick() end
  local p1, p2 = game.p[1], game.p[2]
  play_tick()
  boss.tick(game)
  if game.clock and not fight.flash then game.clock = game.clock - 1 end
  if p1.hp <= 0 or p2.hp <= 0 then
    round_over(p1.hp > 0 and p1 or p2.hp > 0 and p2 or nil, "K.O.")
  elseif game.clock and game.clock <= 0 then
    local a, b = p1.hp / (p1.def.hp * (p1.handicap or 1)), p2.hp / (p2.def.hp * (p2.handicap or 1)) -- (own share)
    round_over(a ~= b and (a > b and p1 or p2) or nil, "TEMPS!")
  end
end

local function after_ko()
  play_tick()
  local w = game.winner
  if w and timer >= 70 and w.act == "free" then w.act, w.t = "win", 0 end
  if timer < 170 then return end
  local p1, p2 = game.p[1], game.p[2]
  if p1.wins >= 2 or p2.wins >= 2 or game.round >= 5 then
    go("over")
    game.champion = p1.wins ~= p2.wins and (p1.wins > p2.wins and p1 or p2) or nil
    game.over_text = game.champion and (T("GUANYA") .. " " .. game.champion.def.short) or "EMPAT"
    game.results[#game.results + 1] = game.champion and game.champion.def.key or "empat" -- read by tests
    if game.champion then game.champion.act, game.champion.t = "win", 0 end
    local mine = lk and game.p[lk.ls.me] or p1 -- (linked: the fighter this console plays)
    audio.music((game.champion == mine or game.demo) and "WIN" or "GAMEOVER")
  else
    game.round = game.round + 1
    new_round()
  end
end

-- ------------------------------------------------------------------ the screens around it

function game.to_title()
  if lk then link_end() end
  game.demo, game.training, game.paused = false, false, false
  game.preload_list, game.demo_pair = nil, nil -- (the title loads only the next demo's pictures)
  go("title")
  screens.enter(fight.fx)
  audio.music("TITLE")
end

local function after_scores() -- a score worth keeping asks for initials, then the table; or straight to the title
  if #game.found > 0 then go("unlock") audio.music("WIN") return end -- (first, a secret found in the run)
  local s = math.max(game.p[1] and game.p[1].score or 0, game.best_credit or 0)
  game.best_credit = 0
  ini_rank = game.mode == "arcade" and opt.rank(s) or nil
  if ini_rank and s > 0 then
    ini, ini_score = menus.initials_new(), s
    go("initials")
    audio.music("SELECT")
  else
    go("records")
  end
end

-- the arcade's ladder (GDD 8): every other fighter in a random order, the personal rival last
local function ladder(def)
  local list = {}
  for _, f in ipairs(F.list) do if f ~= def and f.key ~= def.rival then list[#list + 1] = f end end
  for i = #list, 2, -1 do local j = math.random(i) list[i], list[j] = list[j], list[i] end
  local rival = F.by_key[def.rival]
  rival = rival and gfx.drawn(rival) and rival or nil
  while #list > (rival and 9 or 10) do list[#list] = nil end -- nine fights (GDD 8.1), then the rival (ten when
  if rival then list[#list + 1] = rival end                    -- the rival has no pictures yet: the bonus after the 9th)
  if gfx.drawn(F.boss[1]) and gfx.drawn(F.boss[2]) then -- then the boss, in two phases (GDD 8.1, 10)
    list[#list + 1], list[#list + 2] = F.boss[1], F.boss[2]
  end
  return list
end

local function to_select(mode)
  game.mode = mode
  sel = {pick = 1, heading = mode == "link" and "TRIA P1" or nil}
  game.sel = sel -- tests read it
  go("select")
  audio.music("SELECT")
end

local function menu_tick()
  local n = #screens.MENU
  local moved = (btnp("down") and 1 or 0) - (btnp("up") and 1 or 0)
  if moved ~= 0 then game.menu = (game.menu - 1 + moved) % n + 1 sfx("SND_MOVE", 0.5) end
  if btnp("b") then go("title") return end
  if not (btnp("a") or btnp("start")) then return end
  sfx("SND_PICK")
  local item = screens.MENU[game.menu]
  if item == "CONTROLS" then go("controls")
  elseif item == "GALERIA" then game.gal = {at = 1, ending = false} go("gallery")
  elseif item == "OPCIONS" then opts.at = 1 go("options")
  elseif item == "BONUS" then game.bonus_menu = {at = 1} go("bonus_menu")
  elseif item == "VERSUS" then game.vmenu = {at = 1} go("versus_menu") -- against the console, or another console
  else to_select(item == "ENTRENAMENT" and "training" or "arcade") end
end

local function select_tick()
  local who = lk and (sel.first and 2 or 1) -- linked: P1 picks first with P1's buttons, then P2 with P2's
  local r = menus.select_tick(sel, timer, who and lk.pressed[who])
  if r == "back" then
    go("menu")
  elseif r == "done" then
    if (game.mode == "training" or game.mode == "versus" or lk) and not sel.first then -- then the rival
      sel = {pick = sel.pick == 1 and 4 or 1, first = sel, heading = lk and "TRIA P2" or "TRIA RIVAL",
             tag = lk and "P2" or nil, avoid = {def = sel.chosen, palette = sel.palette}}
      game.sel, timer = sel, 0
    elseif lk then -- two consoles: no handicap, straight to the VS screen
      game.vs = {a = sel.first.chosen, b = sel.chosen, pal = sel.first.palette, pal2 = sel.palette, mode = "link"}
      go("vs")
    elseif game.mode == "training" then
      game.start(sel.first.chosen, sel.chosen, "training", sel.first.palette, sel.palette)
    elseif game.mode == "versus" then -- the handicap, then the VS screen as the arcade (loading behind it)
      game.vs = {a = sel.first.chosen, b = sel.chosen, pal = sel.first.palette, pal2 = sel.palette, mode = "versus"}
      game.hcap = {at = 3, v = {1, 1}}
      go("handicap")
    elseif game.mode == "bonus" then -- BONUS mode: the chosen one, alone with the bonus stage picked
      game.p = {fight.fighter(sel.chosen, false, sel.palette)}
      game.p[1].score = 0
      game.start_bonus(game.bonus_menu.key)
    else
      game.ladder, game.step, game.continues, game.cleared = ladder(sel.chosen), 1, 0, false
      game.vs = {a = sel.chosen, b = game.ladder[1], pal = sel.palette}
      game.scene(rivals.prologue(sel.chosen), "vs") -- the invitation first (the arcade's story)
    end
  end
end

local function go_training_menu()
  train.at = 1
  go("training_menu")
end

local function fighting_update(frozen)
  local s = game.state
  if s == "fight" and any_pressed("start") then
    if game.training then go_training_menu() return end
    game.paused = not game.paused
  end
  if game.paused then
    if any_pressed("b") then game.paused = false game.to_title() end
    return
  end
  if frozen then
    if s == "fight" then for _, f in ipairs(game.p) do fight.feed(f.pad, keys_of(f, true), f.dir, true) end end
    return
  end
  if s == "intro" then
    play_tick()
    local first = game.round == 1 and game.mode ~= "training" and INTRO or 0
    if timer >= first + 120 then
      go("fight")
      for _, f in ipairs(game.p) do if f.act == "intro" then f.act, f.t = "free", 0 end end
    end
  elseif s == "fight" then
    fight_tick()
    if code("turbo") and game.state == "fight" then fight_tick() end -- (the code: two ticks of the fight a frame)
  elseif s == "ko" then
    after_ko()
  elseif s == "over" then
    play_tick()
    if timer > 170 then
      if game.demo then go("records") audio.music("SELECT")
      else
        go("winquote")
        audio.music("SELECT")
      end
    end
  end
  local mid = (game.p[1].x + game.p[2].x) / 2
  local want = math.max(0, math.min(fight.stage_w - 480, mid - 240))
  cam = cam + (want - cam) * 0.25
end

local TICK = {} -- each screen's input and passing of time; fighting states are handled apart

function game.scene(scene, after) -- a scene of lines (rivals.lua), then the screen `after`; the fight's pictures
  game.rival, game.after_scene = rivals.new(scene), after -- load behind it when a VS comes next
  go("rival")
  audio.music("RIVAL")
  local v = game.vs
  if after == "vs" and v then
    game.make_preload({{def = v.a, palette = v.pal}, {def = v.b, palette = v.pal2 or other_palette(v.a, v.b, v.pal)}})
    v.preload = true
  end
end

local function to_vs() -- the VS screen; before the arcade's fight with one's own rival, their scene first (GDD 8.2)
  local v = game.vs
  local scene = game.mode == "arcade" and v and v.b and v.b.key == v.a.rival and rivals.find(v.a.key, v.b.key)
  if scene then
    game.scene(scene, "vs")
  else
    go("vs")
  end
end

TICK.boot = function() if timer > screens.SPLASH_TICKS or btnp("a") or btnp("start") then game.to_title() end end
TICK.title = function()
  if btnp("a") or btnp("start") then game.menu = 1 go("menu") sfx("SND_PICK")
  elseif #F.list >= 2 and timer == ATTRACT_TICKS - 120 then -- the demo's two, chosen early: loaded behind the title
    local a = math.random(#F.list)
    local b = (a + math.random(#F.list - 1) - 1) % #F.list + 1 -- anyone else
    game.demo_pair = {F.list[a], F.list[b]}
    game.make_preload({{def = F.list[a], palette = 1}, {def = F.list[b], palette = 1}})
  elseif timer > ATTRACT_TICKS and game.demo_pair then -- (a card with one fighter drawn yet has no demo)
    game.start(game.demo_pair[1], game.demo_pair[2], "demo", 1, 1)
    game.demo_pair = nil
  end
end
TICK.menu = menu_tick
TICK.controls = function() if timer > 10 and (btnp("a") or btnp("b") or btnp("start")) then go("menu") end end
TICK.options = function()
  local r = menus.options_tick(opts)
  if r == "changed" then apply_options()
  elseif r == "codes" then game.codes = menus.code_new() go("codes")
  elseif r == "back" then opt.save() go("menu") end
  if game.state == "menu" then audio.music("TITLE") end
end
TICK.codes = function()
  local r = menus.code_tick(game.codes, timer)
  if r == "entered" then apply_options()
  elseif r == "back" then go("options") end
end
TICK.records = function() if timer > 360 or (timer > 20 and (btnp("a") or btnp("start"))) then game.to_title() end end
TICK.select = select_tick
TICK.vs = function()
  local v = game.vs
  if not v.preload then -- what the fight will draw starts loading behind this still screen
    v.preload = true
    game.make_preload({{def = v.a, palette = v.pal}, {def = v.b, palette = v.pal2 or other_palette(v.a, v.b, v.pal)}})
  end
  if timer > menus.vs_ticks(v.a, v.b) or (timer > 40 and any_pressed("a")) then
    game.start(v.a, v.b, v.mode or "arcade", v.pal, v.pal2, v.score, v.handicap)
  end
end
TICK.winquote = function()
  local w = game.champion or game.p[2]
  local line = w.def.wins[(w == game.p[1] and game.p[2] or game.p[1]).def.key] or w.def.wins.default or ""
  if timer > 60 + #line * 2 and (any_pressed("a") or any_pressed("b") or any_pressed("start") or timer > 600) then
    local p1 = game.p[1]
    if game.mode == "versus" or lk then -- free versus (one console or two): A chooses again, B leaves
      local linked = lk ~= nil
      if any_pressed("b") then
        if linked then link_end() end
        go("menu")
        audio.music("SELECT")
      else
        to_select(linked and "link" or "versus")
      end
    elseif game.champion ~= p1 then go("continue") audio.music("CONTINUE")
    elseif game.ladder and game.step < #game.ladder then -- on to the next one, the score carried
      if game.p[2].def.key == p1.def.rival then -- the personal rival beaten: a secret (shown when the run is over)
        for _, k in ipairs(opt.beat_rival()) do game.found[#game.found + 1] = k end
      end
      game.step = game.step + 1
      local next_one = game.ladder[game.step]
      game.vs = {a = p1.def, b = next_one, pal = p1.palette, score = p1.score}
      local pool = bstage.POOLS[(game.step - 1) // 3]
      if next_one.boss == 2 then -- the first phase's K.O. was not the end: false credits, then the producer (GDD 10)
        go("fakecredits")
        audio.music("ENDING")
      elseif next_one.boss == 1 then -- the secret bonus, only before the boss (GDD 9.3)
        game.start_bonus("plato")
      elseif (game.step - 1) % 3 == 0 and pool then -- after fights 3, 6 and 9: a bonus stage (GDD 8.1)
        game.start_bonus(pool[math.random(#pool)])
      else
        to_vs()
      end
    elseif game.p[2].def.boss == 2 then game.scene(rivals.epilogue(p1.def), "ending") -- the producer's last word
    else go("ending") audio.music("ENDING") end
  end
end
TICK.continue = function()
  if timer > 20 and (btnp("a") or btnp("start")) then
    local p1 = game.p[1]
    game.best_credit = math.max(game.best_credit or 0, p1.score) -- a new credit starts at 0, as in the arcade
    game.continues = (game.continues or 0) + 1
    game.start(p1.def, game.p[2].def, "arcade", p1.palette) -- a new credit: the score starts again
  elseif timer >= 600 then
    go("gameover")
    audio.music("GAMEOVER")
  end
end
TICK.gameover = function() if timer > 300 or (timer > 60 and btnp("a")) then after_scores() end end
TICK.gallery = function()
  local g, n = game.gal, #F.roster
  local d = (btnp("right") and 1 or 0) - (btnp("left") and 1 or 0)
  if d ~= 0 then
    g.at, g.ending, g.scroll = (g.at - 1 + d) % n + 1, false, 0
    g.sheet = g.sheet and menus.blueprint(g.at) ~= nil -- (the next one's sheet, if it has one)
    sfx("SND_MOVE", 0.5)
  end
  if g.sheet then -- a design sheet: up and down read it, B or START back to the page
    local _, _, h = menus.sheet(g.at)
    g.scroll = math.max(0, math.min(h - 320, (g.scroll or 0) + ((btn("down") and 6 or 0) - (btn("up") and 6 or 0))))
    if btnp("b") or btnp("start") then g.sheet = false sfx("SND_MOVE", 0.5) end
    return
  end
  if btnp("a") and opt.ending_open(F.roster[g.at].key) then g.ending = not g.ending sfx("SND_PICK") end
  if btnp("start") and menus.blueprint(g.at) then g.sheet, g.scroll, g.ending = true, 0, false sfx("SND_PICK") end
  if btnp("c") then game.juke = game.juke or {at = 1} go("jukebox") end
  if btnp("b") then go("menu") end
end
TICK.jukebox = function()
  local r = menus.jukebox_tick(game.juke)
  if r == "back" then go("gallery") audio.music("SELECT") game.juke.playing = nil
  elseif r then audio.music(r) end
end
local function found(keys) -- secrets just unlocked: shown once the run is over
  for _, k in ipairs(keys) do game.found[#game.found + 1] = k end
end

TICK.ending = function()
  opt.saw_ending(game.p[1].def.key)
  if not game.cleared then game.cleared = true found(opt.won_arcade(game.p[1].def.key)) end
  if timer > menus.ending_ticks(game.p[1]) or (timer > 30 and btnp("start")) then -- the title again, and thanks
    go("thanks")
    screens.enter(fight.fx)
    audio.music("TITLE")
  end
  if btnp("a") and timer % menus.LINE_TICKS > 20 then timer = (timer // menus.LINE_TICKS + 1) * menus.LINE_TICKS end
end
TICK.rival = function()
  if rivals.tick(game.rival, timer) ~= "done" then return end
  if game.after_scene == "ending" then go("ending") audio.music("ENDING") else go("vs") audio.music("SELECT") end
end
TICK.fakecredits = function()
  local v = game.vs
  if timer == 1 then -- the producer's pictures (and the others' things he will call in) load behind the credits
    boss.pick_cameos(F, v.a)
    game.make_preload({{def = v.a, palette = v.pal}, {def = v.b, palette = 1}})
  end
  if timer > boss.FAKE_TICKS or (timer > boss.FAKE_TEAR + 60 and btnp("a")) then
    game.start(v.a, v.b, "arcade", v.pal, nil, v.score)
  end
end
TICK.thanks = function()
  if timer > menus.THANKS_TICKS or (timer > 120 and (btnp("a") or btnp("start"))) then go("credits") audio.music("ENDING") end
end
TICK.credits = function()
  if timer > menus.CREDITS_TICKS or (timer > 30 and (btnp("a") or btnp("start"))) then after_scores() end
end
TICK.unlock = function()
  if timer > 300 or (timer > 60 and (btnp("a") or btnp("start"))) then
    game.found = {}
    if game.mode == "bonus" then go("bonus_menu") audio.music("SELECT") else after_scores() end
  end
end
TICK.initials = function()
  local name = menus.initials_tick(ini)
  if name then
    opt.add_score(name, ini_score)
    go("records")
  end
end
TICK.training_menu = function()
  local r = menus.train_tick(train)
  if r == "resume" then go("fight")
  elseif r == "reset" then
    fight.start_round(game.p[1], game.p[2])
    game.p[1].pad.log = {}
    go("fight")
  elseif r == "quit" then game.to_title() end
end

-- ------------------------------------------------------------------ the bonus stages

local facing = 1

function game.start_bonus(key)
  game.bonus_key = key
  local p1 = game.p[1]
  local where = bstage.LIST[key].stage -- (its own stage, or Barcelona at night while that one has no pictures yet)
  local st = stage.set(gfx.has(stage.LIST[where].far) and where or "nit")
  fight.stage_w = stage.width
  local score = p1.score
  game.p = {fight.fighter(p1.def, false, p1.palette), fight.fighter(p1.def, true, 1)}
  game.p[1].score = score
  fight.start_round(game.p[1], game.p[2])
  bstage.start(key, game.p[1], game.p[2], stage.width)
  facing = 1
  go("bonus_intro")
  audio.music(st.music)
end

local function bonus_tick()
  if btn("right") then facing = 1 elseif btn("left") then facing = -1 end
  bstage.place_other(facing)
  local p1, p2 = game.p[1], game.p[2]
  held.up, held.down, held.left, held.right = btn("up"), btn("down"), btn("left"), btn("right")
  held.a, held.b, held.c = btn("a"), btn("b"), btn("c")
  fight.feed(p1.pad, held, p1.dir)
  fight.feed(p2.pad, NONE, p2.dir)
  fight.update()
  stage.update({p1})
  bstage.tick()
  local want = math.max(0, math.min(fight.stage_w - 480, p1.x - 240))
  cam = cam + (want - cam) * 0.25
  if bstage.done then
    local rank, points = bstage.result()
    game.bonus_rank, game.bonus_points = rank or "-", points
    found(opt.bonus_rank(game.bonus_rank))
    game.bonus_best = opt.bonus_played(game.bonus_key, bstage.score + points)
    game.boss_stock = game.mode == "arcade" and bstage.reward() or nil
    p1.score = p1.score + bstage.score + points
    if game.vs then game.vs.score = p1.score end -- (BONUS mode, straight from the menu, has no VS)
    go("bonus_result")
    sfx(rank and "SND_MODE" or "SND_NO")
  end
end

TICK.bonus_intro = function() if timer > 150 or (timer > 30 and btnp("a")) then go("bonus") end end
TICK.bonus = function()
  if juice.update() then return end
  bonus_tick()
end
TICK.bonus_result = function()
  if timer > 200 or (timer > 60 and btnp("a")) then
    if game.mode ~= "bonus" then to_vs()
    elseif #game.found > 0 then go("unlock") audio.music("WIN") -- (the Tió, found here)
    else go("bonus_menu") audio.music("SELECT") end
  end
end
TICK.handicap = function()
  local r = menus.handicap_tick(game.hcap)
  if r == "go" then
    game.vs.handicap = {menus.HANDICAPS[game.hcap.v[1]], menus.HANDICAPS[game.hcap.v[2]]}
    go("vs")
  elseif r == "back" then to_select("versus") end
end
TICK.bonus_menu = function()
  local r = menus.bonus_menu_tick(game.bonus_menu)
  if r == "back" then go("menu")
  elseif r then game.bonus_menu.key = r to_select("bonus") end
end

-- VERSUS: against the console, or two consoles; then hellos until the other is heard with its rules
TICK.versus_menu = function()
  local r = menus.versus_tick(game.vmenu)
  if r == "console" then to_select("versus")
  elseif r == "link" then link_new() go("link_wait") link_hello()
  elseif r == "back" then go("menu") end
end

local function link_begin(other) -- the other console heard, and its rules: the session starts
  lk.other = other
  lk.ls = lockstep.new({step = 3, delay = 2, history = 4})
  lk.ls:start({other})
  lk.rules = lk.ls.players[1] == link.id() and my_rules() or lk.hello[other].r -- P1's rules, on both
  fight.simple, fight.chip_kills = lk.rules.simple, lk.rules.chip
  fight.power, fight.weight, fight.one_hit = lk.rules.rauxa and 2 or 1, lk.rules.lluna and 0.4 or 1, lk.rules.uncop
  local theirs = {}
  for _, k in ipairs(lk.hello[other].u) do if type(k) == "string" then theirs[k] = true end end
  game.link_unlocked = {} -- the secrets both have found (menus.lua reads it)
  for _, k in ipairs(unlocked_keys()) do if theirs[k] then game.link_unlocked[k] = true end end
  to_select("link")
end

TICK.link_wait = function()
  if btnp("b") then link_end() go("menu") return end
  if timer % 30 == 0 then link_hello() end
  for from, m in link.recv do
    if type(m) == "table" and m.h == 1 and rules_ok(m.r) and type(m.u) == "table" then lk.hello[from] = m end
  end
  local other = link.peers()[1]
  if other and lk.hello[other] then link_begin(other) end
end

TICK.link_lost = function() if timer > 240 or (timer > 30 and (btnp("a") or btnp("start"))) then game.to_title() end end

local FIGHTING = {intro = true, fight = true, ko = true, over = true}

function _update()
  if lk and lk.ls and LINKED[game.state] then -- in step: a tick runs only with both players' buttons
    local inputs = lk.ls:update(lockstep.buttons())
    if not inputs then
      lk.quiet = lk.quiet + 1
      local fr = lk.ls.frames[3] -- (the other's first frame: until it is here, it may still want our hello)
      if lk.quiet % 30 == 1 and not (fr and fr[lk.other]) then link_hello() end
      if lk.quiet > 600 then link_end() go("link_lost") end -- ten seconds without its buttons: it is gone
      return
    end
    lk.quiet = 0
    for i, id in ipairs(lk.ls.players) do link_keys(i, inputs[id] or 0) end
  end
  local frozen = juice.update()
  fight.fx:update()
  timer = timer + 1
  local s = game.state
  if game.demo and FIGHTING[s] and (btnp("a") or btnp("start")) then return game.to_title() end -- a button ends it
  if FIGHTING[s] then return fighting_update(frozen) end
  if TICK[s] then TICK[s]() end
end

-- ------------------------------------------------------------------ drawing the fight

local function shadow(x)
  shade(x - 40, fight.FLOOR - 3, 80, 5)
  shade(x - 26, fight.FLOOR - 5, 52, 9)
end

local function boxes(list, colour)
  for _, b in ipairs(list) do box(math.floor(b[1]), math.floor(b[2]), math.floor(b[3]), math.floor(b[4]), colour) end
end

local function show_boxes() return game.debug or (game.training and train.boxes) end

local function draw_fighter(f)
  local d = f.def
  local x, y = math.floor(f.x), math.floor(fight.FLOOR - f.y)
  if f.act ~= "thrown" and not f.melting then shadow(x) end
  -- a blow's white flash: three frames drawn (counted while drawn, so a long hitstop does not keep it white)
  f.flashed = f.flash > 0 and (f.flashed or 0) + 1 or 0
  local tint = f.flashed > 0 and f.flashed <= 3 and 0xFFFFFF or nil
  if not gfx.fighter(d, f.frame, x, y, f.dir < 0, f.palette, tint) then -- no art yet: the body as a box
    local b = fight.body(f)
    rect(math.floor(b[1]), math.floor(b[2]), b[3], b[4], f.flash > 0 and 0xFFFFFF or d.colour)
    if f.move and f.move.box and f.phase ~= "s" then
      local h = fight.at(f, f.move.box)
      rect(math.floor(h[1]), math.floor(h[2]), h[3], h[4], d.colour + 0x303030)
    end
  end
  if show_boxes() then
    boxes(fight.hurtboxes(f, true), 0x40FF40)
    local h = fight.hitbox(f)
    if h then boxes({h}, 0xFF3030) end
    local b = fight.body(f)
    box(math.floor(f.x) - 34, math.floor(b[2]) + b[4] - 4, 68, 4, 0x4080FF)
  end
end

local look = {}

local GLYPH = {font = "arcade", scale = 2, align = "center", color = 0xE02020, outline = 0xFFF8E0, shadow = 0x200010}

local function draw_shot(s)
  if s.glyph then -- Fabra's letters: the game's own font, red and outlined
    text(s.glyph, math.floor(s.x), math.floor(s.y - 20), GLYPH)
    if show_boxes() then box(math.floor(s.x - s.w / 2), math.floor(s.y - s.h / 2), s.w, s.h, 0xFF3030) end
    return
  end
  local id = s.pic
  if s.kind == "star" then -- Miró's star: still, and glowing as it nears its end
    s.frames[1] = s.life - s.t < 50 and (s.t // 4) % 2 or 0
  end
  if gfx.has(id) then
    local w, h = imgsize(id)
    local frame = s.frames[1 + (s.t // 4) % #s.frames]
    look.frame, look.flip_x, look.angle = frame, s.vx < 0 or (s.vx == 0 and s.owner.dir < 0), s.angle
    local m = FXMETA[id] -- a strip of things of different sizes: bottoms lined up, each frame's own height known
    local ch = m and m.frames[frame + 1] and m.frames[frame + 1][2] or h
    local y = s.ground and fight.FLOOR + 4 - h or m and s.y + ch / 2 - h or s.y - h / 2
    img(id, math.floor(s.x - w / 2), math.floor(y), look)
  else
    circ(math.floor(s.x), math.floor(s.y), s.w // 2, s.super and 0xFFE070 or 0xFFFFFF)
  end
  if show_boxes() then box(math.floor(s.x - s.w / 2), math.floor(s.y - s.h / 2), s.w, s.h, 0xFF3030) end
end

local function draw_book() -- Fabra's SUPER: the dictionary stands open while the letters fly out of it
  local b = powers.book
  if not b or not gfx.has("FX_FABRA") then return end
  local w, h = imgsize("FX_FABRA")
  local rise = math.min(1, (b.t + 1) / 8)
  b.t = b.t + 1
  clip(0, 0, 480, fight.FLOOR + 2)
  gfx.pic("FX_FABRA", math.floor(b.x - w / 2), math.floor(fight.FLOOR - h * rise), 0)
  clip()
end

local function draw_wall(w) -- a pillar comes up out of the floor, and blinks before it goes
  local h = w.box and w.box[4] or 0
  if w.life - w.t < 30 and w.t % 4 < 2 then return end
  local pic = w.pic or "FX_PILLAR"
  if gfx.has(pic) then
    local iw, ih = imgsize(pic)
    clip(0, 0, 480, fight.FLOOR + 2)
    gfx.pic(pic, math.floor(w.x - iw / 2), math.floor(fight.FLOOR - h - (ih - (w.wh or ih))), w.frame or 0)
    clip()
  else
    rect(math.floor(w.x) - 22, math.floor(fight.FLOOR - h), 44, math.floor(h), 0xE0C090)
  end
  if show_boxes() and w.box then boxes({w.box}, 0xFF3030) end
end

local SPARK = {hit = {0, 0}, heavy = {1, 2}, guard = {3, 4}} -- FX_HITS frames: the burst, then it breaking up

local function draw_sparks()
  if not gfx.has("FX_HITS") then return end
  local w, h = imgsize("FX_HITS")
  for _, s in ipairs(fight.sparks) do
    local fr = SPARK[s.kind]
    if s.kind ~= "hit" or s.t < 6 then
      gfx.pic("FX_HITS", math.floor(s.x - w / 2), math.floor(s.y - h / 2), s.t < 5 and fr[1] or fr[2])
    end
  end
end

local small = {font = "small", align = "center", color = 0xFFFFFF}
local O_LINE = {align = "center", color = 0xFFE070, gradient = 0xFF8020}

-- The fight's signs keep to the strip of sky under the HUD (y 72-136), above the fighters' heads, so the round's
-- start, a K.O. and the winner's celebration are all seen; the K.O. is big for a moment, then makes room.
local SKY = 72
local ROW = 48 -- once the round is over the SENY/RAUXA row is hidden: its signs go there, clear of a winner standing tall
local KO_BIG = 70 -- ticks the K.O. stays big; then the winner celebrates (fight.lua: their win pose starts then)
local function overlays()
  local s = game.state
  if s == "intro" then
    local t = timer - (game.round == 1 and game.mode ~= "training" and INTRO or 0)
    if t >= 0 then
      local word = boss.word(game, t < 60 and ROUNDS[math.min(game.round, 3)] or t < 100 and "PREPARATS?" or "FOT-LI!")
      if hud.band(SKY + 4, 52, t) then hud.big(word, SKY + 10, 0xFFE070, t >= 100 and 2 or 0) end
    end
  elseif s == "ko" then
    if timer < KO_BIG then -- the blow's word, big
      if hud.band(SKY, 66, timer) then hud.big(verdict, SKY + 3, 0xFFFFFF, timer < 30 and 3 or 0, 3) end
    else -- then, while the winner celebrates: what the round was, and its bonus
      local line = perfect and "IMPECABLE!" or narrator
      local from = line and KO_BIG or KO_BIG + 20 -- (a bonus alone shows with its band, never an empty one)
      if (line or bonus > 0) and timer >= from and hud.band(ROW, line and bonus > 0 and 50 or 30, timer - from) then
        if line then
          O_LINE.color = perfect and 0x80E0FF or 0xFFE070
          hud.cap(line, 240, ROW + 5, O_LINE)
        end
        if bonus > 0 and timer > KO_BIG + 20 then
          small.color = 0xFFE070
          hud.cap(game.bonus_text, 240, line and ROW + 30 or ROW + 8, small)
        end
      end
    end
  elseif s == "over" then
    if hud.band(ROW, 50, timer) then hud.big(game.over_text, ROW + 5) end
  end
  if game.glory and fight.glory_t < 110 and s == "fight" then -- (a sign the width of its words: the combo counts
    local w = textw("MOMENT DE GLÒRIA", O_LINE) + 28            -- stay clear at the sides)
    hud.plate(240 - w // 2, SKY + 4, w, 32)
    O_LINE.color = 0xFFE070
    hud.cap("MOMENT DE GLÒRIA", 240 + (fight.glory_t < 20 and math.random(-2, 2) or 0), SKY + 10, O_LINE)
  end
  if game.demo and timer // 30 % 2 == 0 then -- the sign blinks whole, plate and words
    hud.plate(150, 252, 180, 30)
    small.color = 0xFFFFFF
    hud.cap("DEMO  ·  PREM A", 240, 259, small)
  end
  if game.paused then
    shade(0, 0, 480, 320)
    hud.band(110, 104)
    hud.big("PAUSA", 124)
    small.color = 0xFFFFFF
    hud.cap("START: CONTINUAR     B: SORTIR", 240, 180, small)
  end
  if game.training and s == "training_menu" and train.inputs then menus.inputs_draw(game.p[1].pad) end
  if game.training and s == "fight" then -- (its menu has the word as its own title)
    if train.inputs then menus.inputs_draw(game.p[1].pad) end
    hud.plate(186, 76, 108, 24)
    small.color = 0x80E0FF
    hud.cap("ENTRENAMENT", 240, 81, small)
  end
end

local PRELOAD = {"FX_HITS"}
-- what the four first fighters throw (powers.lua, main.lua's draw_book and draw_wall); the others name theirs in def.fx
local OWN_FX = {dali = {"FX_CLOCK"}, gaudi = {"FX_PILLAR", "FX_SALAMANDER", "FX_WAVE"}, fabra = {"FX_FABRA"},
                miro = {"FX_MIRO", "FX_VORTEX"}}

-- behind the VS screen and in the round's intro, one picture every few ticks drawn where it cannot be seen, so nothing
-- is loaded from the card in the middle of the fight (a fighter's strip loaded mid-fight stopped the picture a quarter
-- second: the entrance draws only the second strip, so the first came in with the first blow)
local PRELOADING = {intro = true, vs = true, title = true, fakecredits = true, rival = true}
local function preload()
  if not PRELOADING[game.state] or (timer - game.preload_from) % 4 ~= 1 then return end
  local i = (timer - game.preload_from) // 4 + 1
  local list = game.preload_list
  if not list then return end
  local item = list[i]
  if not item then return end
  clip(0, 0, 1, 1) -- drawn over one pixel of the screen's corner (a picture drawn wholly off it is not loaded)
  if type(item) == "table" then gfx.fighter(item[1], item[3], gfx.ART.AX, gfx.ART.AY, false, item[2])
  else gfx.pic(item, 0, 0) end
  clip()
end

function game.make_preload(who) -- who: the fighters, or what they will be ({def, palette} each)
  local list = {}
  who = who or game.p
  local st = stage.LIST[who[2].def.stage] -- the stage: the second one's home
  if st then
    list[1], list[2] = st.far, st.near
    for _, c in ipairs(st.crowd or NONE) do list[#list + 1] = c.pic end
  end
  for _, f in ipairs(who) do
    for fr = 0, 79, F.CHUNK do list[#list + 1] = {f.def, f.palette, fr} end -- every piece of both strips (and their palette)
    if f.def.fx then list[#list + 1] = f.def.fx end
    for _, id in ipairs(OWN_FX[f.def.key] or NONE) do list[#list + 1] = id end -- (the four first fighters' effects)
  end
  -- Not here, on purpose: a SUPER's background (155 KB each) and the effects of fighters not in this fight. A fight's
  -- pictures came to about 2.8 MB against the 3 MB the console has for them once the game's own memory is counted
  -- (measured on the board, docs/measurements.md): over it a load fails and the picture stays missing. A SUPER's
  -- background loads in its own flash, when the picture stands still for 40 ticks anyway.
  for _, id in ipairs(PRELOAD) do list[#list + 1] = id end
  if who[2].def.boss == 2 then for _, c in ipairs(powers.cameo_list) do list[#list + 1] = c.pic end end
  game.preload_list, game.preload_from = list, timer -- (one picture every 4 ticks from now)
end

local function draw_fight()
  preload()
  local ox, oy = juice.offset()
  local super = fight.flash and fight.flash.who
  for _, f in ipairs(game.p) do if f.act == "super" then super = f end end
  stage.draw(cam, ox, oy, super, super and fight.flash)
  for _, w in ipairs(fight.walls) do draw_wall(w) end
  draw_book()
  local a, b = game.p[1], game.p[2] -- the one throwing a blow in front
  if b.act == "attack" or b.act == "super" or b.act == "throw" then a, b = b, a end
  draw_fighter(a)
  draw_fighter(b)
  for _, s in ipairs(fight.shots) do draw_shot(s) end
  draw_sparks()
  fight.fx:draw()
  camera()
  local quiet = (game.state == "ko" and timer >= KO_BIG) or game.state == "over"
  if not boss.hud_hidden() then
    hud.draw(fight, game.clock, game.state == "fight", game.mode == "arcade" and opt.best().score or nil, quiet)
  end
  overlays()
  boss.draw(game, timer)
  if game.state == "training_menu" then menus.train_draw(train) end
  juice.draw()
end

-- ------------------------------------------------------------------ drawing the rest

local function draw_bonus(state)
  local ox, oy = juice.offset()
  stage.draw(cam, ox, oy)
  camera(math.floor(cam) + ox, oy)
  bstage.draw(cam)
  camera(math.floor(cam) + ox, oy)
  draw_fighter(game.p[1])
  draw_sparks()
  fight.fx:draw()
  camera()
  bstage.hud()
  small.color = 0xFFFFFF
  if state == "bonus_intro" then -- (under the bonus's own HUD, above the player)
    if hud.band(SKY - 18, 104, timer) then -- BONUS, its name, what to do: each on its own row inside the band
      hud.big("BONUS", SKY - 12, 0xFFE070)
      hud.big(bstage.b.name, SKY + 36, 0xFFFFFF, 0, 1)
      hud.cap(bstage.b.hint, 240, SKY + 64, small)
    end
  elseif state == "bonus_result" then
    if hud.band(SKY - 18, game.boss_stock and 98 or 80, timer) then
      hud.big(game.bonus_rank == "-" and "FALLAT" or T("RANG") .. " " .. game.bonus_rank, SKY - 12, 0xFFE070, timer < 30 and 2 or 0)
      hud.cap(T("PUNTS") .. " " .. bstage.score .. "  +  " .. game.bonus_points, 240, SKY + 38, small)
      if game.boss_stock then hud.cap("+1 SUPER PER AL COMBAT FINAL!", 240, SKY + 56, small) end
    end
  end
  juice.draw()
end

local title_has = {}
local DRAW = {
  bonus_intro = function() draw_bonus("bonus_intro") end,
  bonus = function() draw_bonus("bonus") end,
  bonus_result = function() draw_bonus("bonus_result") end,
  boot = function() screens.splash(timer) end,
  controls = function() screens.controls(timer) end,
  options = function() menus.options_draw(opts, timer) end,
  codes = function() menus.code_draw(game.codes, timer) end,
  records = function() menus.records_draw(timer) end,
  select = function() menus.select_draw(sel, timer) end,
  unlock = function() menus.unlock_draw(game.found, timer) end,
  bonus_menu = function() menus.bonus_menu_draw(game.bonus_menu, timer) end,
  handicap = function() menus.handicap_draw(game.hcap, game.vs, timer) end,
  vs = function() menus.vs_draw(game.vs.a, game.vs.b, stage.LIST[game.vs.b.stage].name, timer) preload() end,
  winquote = function()
    local w = game.champion or game.p[2]
    menus.winquote_draw(w, w == game.p[1] and game.p[2] or game.p[1], timer)
  end,
  continue = function() menus.continue_draw(game.p[1], timer) end,
  gameover = function() menus.gameover_draw(timer) end,
  ending = function() menus.ending_draw(game.p[1], timer) end,
  credits = function() menus.credits_draw(timer) end,
  thanks = function()
    title_has.logo, title_has.keyart = gfx.has("LOGO"), gfx.has("KEYART")
    camera(juice.offset())
    menus.thanks_draw(game.p[1], timer, function(t) screens.title(t, title_has, nil, true) end)
    camera()
    fight.fx:draw()
    juice.draw()
  end,
  fakecredits = function() boss.credits_draw(menus, timer) preload() end,
  rival = function() rivals.draw(game.rival, timer) preload() end,
  gallery = function() menus.gallery_draw(game.gal, timer) end,
  jukebox = function() menus.jukebox_draw(game.juke, timer) end,
  initials = function() menus.initials_draw(ini, ini_score, ini_rank, timer) end,
  versus_menu = function() menus.versus_draw(game.vmenu, timer) end,
  link_wait = function()
    menus.link_draw("ESPERANT L'ALTRA CONSOLA...", "A L'ALTRA: VERSUS > DUES CONSOLES   B: TORNAR", timer)
  end,
  link_lost = function() menus.link_draw("S'HA PERDUT L'ALTRA CONSOLA", "A: TORNAR", timer) end,
}

local function draw_screen()
  local s = game.state
  if s == "title" or s == "menu" then
    show(0) -- (the world holds the fight's far layer: only stage.draw shows it)
    title_has.logo, title_has.keyart = gfx.has("LOGO"), gfx.has("KEYART")
    camera(juice.offset())
    if s == "title" then screens.title(timer, title_has, "PREM START") else screens.menu(timer, game.menu, title_has) end
    camera()
    if s == "title" then preload() end
    fight.fx:draw()
    juice.draw()
    return
  end
  if DRAW[s] then
    show(0) -- (a bonus stage calls stage.draw, which shows the far layer again)
    return DRAW[s]()
  end
  draw_fight()
end

function _draw()
  draw_screen()
  if lk and lk.quiet > 10 then menus.waiting_draw() end -- the other console's buttons are late: the picture waits
end
