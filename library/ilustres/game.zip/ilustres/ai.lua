-- The console's fighter (GDD 13). It sees what anyone watching the screen sees (where the other is, what they are
-- doing, a blow once it has started) and never the other's buttons. It thinks in states: neutral, pressure,
-- defence, wake-up, low life. Its blows go through the same pad as a player's (pad.cmd), so it keeps to the same
-- frame data and the same SUPER meter. Four levels; and in training, a dummy that does one thing.
local M = {}

local LEVELS = { -- react: ticks to answer what it saw; guard: how often it blocks; push: how much it attacks;
  -- anti: knocks jumpers down; punish: hits a blow that missed; roll: rolls away on waking
  {react = 26, guard = 0.25, push = 0.5, anti = 0.15, punish = 0, roll = 0, super = 0.004},
  {react = 14, guard = 0.5, push = 1, anti = 0.35, punish = 0.2, roll = 0.2, super = 0.012},
  {react = 10, guard = 0.65, push = 1.3, anti = 0.55, punish = 0.45, roll = 0.35, super = 0.02},
  {react = 5, guard = 0.9, push = 1.6, anti = 0.9, punish = 0.9, roll = 0.6, super = 0.04},
}
local P = LEVELS[2]
function M.level(n) P = LEVELS[n] or LEVELS[2] end

M.DUMMIES = {"QUIET", "AJUPIT", "SALTA", "BLOCA", "CPU"}

function M.new() return {think = 0, plan = "near", guard = 0, low = false, seen = 0, wait = 0, keys = {}} end

local keys -- the brain's one table of keys, filled anew each tick
local function keys_for(f, fwd, down, up) -- fwd: 1 towards the other, -1 away, 0 still
  keys.right = fwd ~= 0 and fwd * f.dir > 0
  keys.left = fwd ~= 0 and fwd * f.dir < 0
  keys.down, keys.up = down or false, up or false
  return keys
end

local function incoming(f, o, fight, near) -- a shot of the other's coming at it, near: and is it a low one?
  for _, s in ipairs(fight.shots) do
    if s.owner == o and (s.x - f.x) * s.vx < 0 and math.abs(s.x - f.x) < (near or 170) then
      return true, s.hit.hits == "low", s
    end
  end
end

local function rnd(p) return math.random() < p * P.push end

function M.dummy(ai, f, o, fight, mode) -- training: one behaviour, and blocking everything when told to
  keys = ai.keys
  if mode == "AJUPIT" then return keys_for(f, 0, true) end
  if mode == "SALTA" then return keys_for(f, 0, false, f.act == "free") end
  if mode == "BLOCA" then
    local low = o.act == "attack" and o.move and o.move.hits == "low"
    local _, shot_low = incoming(f, o, fight)
    return keys_for(f, -1, low or shot_low)
  end
  return keys_for(f, 0)
end

-- what each of a fighter's two specials is, worked out once from its numbers: "special" or "special2"
local roles = {}
local function role(def)
  local r = roles[def]
  if r then return r end
  r = {}
  for _, k in ipairs({"special", "special2"}) do
    local m = def.moves[k]
    if m.counter then r.counter = r.counter or k
    elseif m.spawn == "star" or m.shot and m.shot.trap then r.trap = r.trap or k
    elseif m.rush then r.rush = r.rush or k
    elseif m.spawn == "pinnacle" or m.spawn == "pillar" then r.pillar = r.pillar or k
    elseif m.spawn == "clock" or m.spawn == "letters" or m.spawn == "blob" or m.spawn == "shot" or m.spawn == "salamander" then
      r.shot = r.shot or k
    else r.other = r.other or k end
  end
  roles[def] = r
  return r
end
local function cmd(k, strong) return k .. (strong and "_b" or "_a") end
-- what a combo ends in: never a pillar (it rises further off than a combo's reach) unless there is nothing else
local function combo_special(def)
  local r = role(def)
  return r.shot or r.rush or r.other or "special"
end

local function stars_of(f, fight)
  local n = 0
  for _, s in ipairs(fight.shots) do if s.owner == f and (s.kind == "star" or s.trap) then n = n + 1 end end
  return n
end

-- Fabra (counter): waits at mid range for a blow to correct, throws letters at a distance
local function counter_style(ai, f, o, fight, d)
  local pad = f.pad
  local r = role(f.def)
  if o.act ~= "attack" then ai.read = nil end
  local other = r.shot or r.trap or r.pillar
  if other and d > 180 and rnd(0.03) then
    pad.cmd, ai.wait = cmd(other, math.random() < 0.5), 30
    return keys_for(f, 0)
  end
  if d <= 92 and rnd(0.08) then
    local r = math.random()
    pad.cmd, ai.wait = r < 0.4 and "A" or r < 0.6 and "DA" or r < 0.8 and "throw" or "B", 14
    return keys_for(f, 0)
  end
  if d > 92 and d < 150 and rnd(0.02) then pad.cmd, ai.wait = "FC", 18 return keys_for(f, 0) end
  return keys_for(f, d > 200 and 1 or d < 170 and -1 or 0) -- keeps a reading distance, out of the others' reach
end

-- Miró (trap): paints stars between them, steps back, throws paint over them
local function trap_style(ai, f, o, fight, d)
  local pad = f.pad
  local r = role(f.def)
  if r.trap and stars_of(f, fight) < 1 and d > 140 and rnd(0.02) then
    pad.cmd, ai.wait = cmd(r.trap, d > 240), 34
    return keys_for(f, 0)
  end
  local other = r.shot or r.pillar
  if other and d > 180 and rnd(0.012) then
    pad.cmd, ai.wait = cmd(other, d > 260), 40
    return keys_for(f, 0)
  end
  if d <= 92 then
    if rnd(0.07) then
      local r = math.random()
      pad.cmd, ai.wait = r < 0.4 and "A" or r < 0.6 and "C" or r < 0.8 and "DC" or "B", 14
      return keys_for(f, 0)
    end
    if rnd(0.02) then return keys_for(f, -1, false, true) end -- a jump back, out of the corner
  end
  return keys_for(f, d < 200 and -1 or d > 280 and 1 or 0)
end

local function star_ahead(f, o, fight)
  for _, s in ipairs(fight.shots) do
    if s.owner == o and (s.kind == "star" or s.trap) and (s.x - f.x) * f.dir > 0 and math.abs(s.x - f.x) < 90 then
      return true
    end
  end
end

local function neutral(ai, f, o, fight, d, zoner)
  local pad = f.pad
  if star_ahead(f, o, fight) then
    if math.random() < P.guard * 0.15 then return keys_for(f, 1, false, true) end -- over it
    return keys_for(f, -1)
  end
  local r = role(f.def)
  if r.counter and ai.plan ~= "near" then return counter_style(ai, f, o, fight, d) end
  if r.trap and ai.plan ~= "near" then return trap_style(ai, f, o, fight, d) end
  if ai.think <= 0 then
    ai.think = 20 + math.random(30)
    local low_life = f.hp < f.def.hp * 0.25
    local r = math.random()
    if zoner then ai.plan = r < 0.55 and "far" or r < 0.85 and "near" or "wait"
    else ai.plan = r < (low_life and 0.4 or 0.65) and "near" or r < 0.85 and "mid" or "wait" end
    if r > 0.95 and d > 150 and d < 260 then return keys_for(f, 1, false, true) end -- a jump in, now and then
  end
  if d <= 92 then -- pressure, up close
    local r = math.random()
    if r < 0.06 * P.push then pad.cmd = "A"
    elseif r < 0.09 * P.push then pad.cmd = "DA"
    elseif r < 0.12 * P.push then pad.cmd = "C"
    elseif r < 0.15 * P.push then pad.cmd = "DC"
    elseif r < 0.17 * P.push then pad.cmd = "throw"
    elseif r < 0.19 * P.push then pad.cmd = "B" end
    if pad.cmd then ai.wait = 14 end
    if f.def.key == "dali" and (f.x < 90 or f.x > fight.stage_w - 90) and rnd(0.02) then -- cornered: melts out
      pad.cmd, ai.wait = "special2_b", 50
    end
    return keys_for(f, ai.plan == "far" and -1 or 0)
  end
  if d <= 150 and rnd(0.035) then
    pad.cmd, ai.wait = math.random() < 0.5 and "FC" or "B", 18
    return keys_for(f, 0)
  end
  if r.rush and d > 140 and d < 260 and rnd(f.def.ai == "rush" and 0.03 or 0.012) then -- a charge from mid range
    pad.cmd, ai.wait = cmd(r.rush, false), 40
    return keys_for(f, 0)
  end
  if zoner then
    if r.shot and d > 170 and rnd(0.025) then
      pad.cmd, ai.wait = cmd(r.shot, math.random() < 0.5), 40
      return keys_for(f, 0)
    end
    if f.def.key == "dali" and d > 260 and rnd(0.006) then pad.cmd, ai.wait = "special2_a", 50 return keys_for(f, 0) end
  else
    -- against a zoner far away: a wall far ahead as a shield (who can raise one), then in behind it, dashing
    if (o.def.ai == "zoner" or o.def.key == "dali") and d > 230 then
      local shield = false
      for _, w in ipairs(fight.walls) do if w.owner == f then shield = true end end
      local wall = r.pillar and (f.def.moves[r.pillar].spawn == "pinnacle" or f.def.moves[r.pillar].pillar.wall)
      if wall and not shield and rnd(0.02) then pad.cmd, ai.wait = cmd(r.pillar, true), 30 return keys_for(f, 0) end
      if shield and rnd(0.05) then pad.cmd, ai.wait = "dash", 16 return keys_for(f, 0) end
      if rnd(0.012) then return keys_for(f, 1, false, true) end -- or over the clocks
    end
    if r.other and d < 140 and rnd(0.015) then -- a blow of its own from close
      pad.cmd, ai.wait = cmd(r.other, d > 100), 30
      return keys_for(f, 0)
    end
    local near_one = r.pillar or r.other
    if near_one and d > 100 and d < 230 and rnd(0.01) then
      pad.cmd, ai.wait = cmd(near_one, d > 160), 40
      return keys_for(f, 0)
    end
    if r.shot and d > 160 and rnd(0.012) then
      pad.cmd, ai.wait = cmd(r.shot, d > 260), 40
      return keys_for(f, 0)
    end
  end
  if ai.plan == "near" then return keys_for(f, d > 80 and 1 or 0)
  elseif ai.plan == "mid" then return keys_for(f, d > 140 and 1 or d < 110 and -1 or 0)
  elseif ai.plan == "far" then return keys_for(f, d < 230 and -1 or d > 300 and 1 or 0) end
  return keys_for(f, 0)
end

function M.keys(ai, f, o, fight)
  keys = ai.keys
  local d = math.abs(o.x - f.x)
  local zoner = f.def.ai == "zoner" or f.def.key == "dali"
  local pad = f.pad
  ai.think = ai.think - 1
  ai.wait = math.max(0, ai.wait - 1)

  if f.act == "down" then -- waking up: roll away now and then, never the same way twice in a row
    if ai.rolled == nil then ai.rolled = math.random() < P.roll end
    return ai.rolled and keys_for(f, -1) or keys_for(f, 0)
  end
  ai.rolled = nil

  local counter = role(f.def).counter
  if counter and f.act == "free" and ai.wait == 0 then -- who has a counter answers before guarding
    if incoming(f, o, fight, 70) and math.random() < 0.1 + P.punish * 0.3 then
      pad.cmd, ai.wait = cmd(counter, true), 40
      return keys_for(f, 0)
    end
    -- a blow seen starting that can reach it (a read, not a certainty: at 0.6 it corrected every blow there was)
    if o.act == "attack" and o.move ~= ai.read and o.phase == "s" and d < 170 then
      ai.read = o.move
      if math.random() < 0.1 + P.punish * 0.3 then pad.cmd, ai.wait = cmd(counter, d >= 120), 40 return keys_for(f, 0) end
    end
  end
  -- a shot coming close: who does not fight from afar jumps over it now and then, once for each shot, and comes
  -- down on the other with a blow (or the one shooting all day wins every match)
  -- timed: in the air when it arrives (ticks to meet it, jumping towards it), decided once
  local _, near_low, near = incoming(f, o, fight, 300)
  if near and near ~= ai.over and not zoner and f.act == "free" and not near_low and not near.gravity then
    local t = (math.abs(near.x - f.x) - near.w / 2 - 26) / (math.abs(near.vx) + 3.4)
    if t <= 22 then
      ai.over = near
      if t >= 12 and math.random() < P.anti * 0.8 then return keys_for(f, 1, false, true) end
    end
  end
  -- defence: a blow or a shot it has had time to see
  local shot, shot_low = incoming(f, o, fight)
  local threat = (o.act == "attack" and (d < 190 or o.move and o.move.kind == "special")) or (o.act == "jump" and d < 200 and o.jk)
    or shot or o.act == "super"
  if threat then ai.seen = ai.seen + 1 else ai.seen = 0 end
  if ai.seen == P.react and f.act == "free" and math.random() < P.guard then
    ai.guard = 24
    ai.low = (o.act == "attack" and o.move and o.move.hits == "low" or shot_low) and math.random() < P.guard + 0.2
  end
  if f.act == "rise" and math.random() < 0.5 then ai.guard, ai.low = 30, false end -- wake-up: careful
  if ai.guard > 0 then
    -- a shot still on its way from afar: guarding is holding back, which walks away; so it goes on (who fights
    -- from afar waits) and holds back once the shot is near, as a player does
    local _, _, s = incoming(f, o, fight)
    if s and d > 190 and math.abs(s.x - f.x) > 70 then return keys_for(f, ai.low and 0 or zoner and 0 or 1, ai.low) end
    ai.guard = ai.guard - 1
    return keys_for(f, -1, ai.low)
  end
  -- going on after a blow that touched
  if f.act == "attack" and f.contact and ai.wait == 0 then
    local r = math.random()
    if f.name == "A" or f.name == "C" or f.name == "DA" then
      local sp = combo_special(f.def)
      pad.cmd = r < 0.5 and "B" or r < 0.75 and cmd(sp, false) or nil
    elseif f.name == "B" or f.name == "FC" or f.name == "DB" then
      local sp = combo_special(f.def)
      pad.cmd = r < 0.35 and (f.meter >= fight.SUPER_COST and r < 0.12 and "super" or cmd(sp, true)) or nil
    end
    ai.wait = 20
    return keys_for(f, 0)
  end
  if f.act == "jump" then -- in the air: one blow when close above the other
    if d < 120 and f.vy < 0 and not f.jk then pad.cmd = math.random() < 0.5 and "JB" or "J" end
    return keys_for(f, 0)
  end
  if f.act ~= "free" or ai.wait > 0 then return keys_for(f, 0) end

  -- the other jumping in: knock it out of the air
  if o.act == "jump" and d < 170 and o.vy < 2 and math.random() < P.anti * 0.3 then
    local pil = role(f.def).pillar
    pad.cmd = pil and math.random() < 0.5 and cmd(pil, false) or "DB"
    ai.wait = 30
    return keys_for(f, 0)
  end
  -- a blow that missed, still recovering, near: punish it
  if o.act == "attack" and o.phase == "r" and d < 130 and math.random() < P.punish * 0.25 then
    pad.cmd, ai.wait = d < 95 and "B" or "FC", 20
    return keys_for(f, 0)
  end
  local rush = role(f.def).rush -- a special thrown from afar, still recovering: a charge reaches it
  if rush and o.act == "attack" and o.phase == "r" and o.move and o.move.kind == "special" and d < 280
     and math.random() < P.punish * 0.3 then
    pad.cmd, ai.wait = cmd(rush, true), 40
    return keys_for(f, 0)
  end
  -- a shot thrown from afar, its thrower still recovering: who does not fight from afar closes in (as a player
  -- does: a dash, or a jump in), or the one shooting all day wins every match
  if not zoner and o.act == "attack" and o.phase == "r" and o.move and o.move.kind == "special" and d > 150 and d < 320
     and math.random() < P.punish * 0.15 then
    if d < 230 and math.random() < 0.4 then return keys_for(f, 1, false, true) end
    pad.cmd, ai.wait = "dash", 12
    return keys_for(f, 0)
  end
  if f.meter >= fight.SUPER_COST and (zoner or d < 300) and math.random() < P.super then
    pad.cmd, ai.wait = "super", 60
    return keys_for(f, 0)
  end
  return neutral(ai, f, o, fight, d, zoner)
end

return M
