-- The final boss (GDD 10): Joel Joan knows he is inside a video game. In the first phase he talks over the narrator
-- and starts the rounds himself ("ACCIÓ!"); his defeat is a false K.O. followed by false credits, torn by a glitch.
-- In the second, the Executive Producer plays with the screen: the HUD flickers and goes, a false PAUSA, the two
-- fighters swap sides, the others' signatures fly in at his call. Each trick is announced first (a tear across the
-- screen and his line, WARN ticks before) and none touches the controls or the rules (GDD 10.3: meta, not unfair).
local fight = require("fight")
local hud = require("hud")
local powers = require("powers")

local M = {}

local WARN = 50 -- ticks from the announcement to the trick
local EVERY = {360, 520} -- ticks between two tricks (the producer is wild: often)
local TRICKS = {"swap", "hud", "pausa", "cameo"} -- in turn, so each one is seen
local SAY = {swap = "CANVI DE PLA!", hud = "AQUESTES DADES NO CALEN", pausa = "PAUSA PUBLICITÀRIA!",
             cameo = "QUE PASSI EL SEGÜENT!"}
local LASTS = {hud = 240, pausa = 150}
local PINK = 0xFF60C0

local s = {next = 0, trick = nil, warn = 0, active = nil, left = 0, n = 0, tear = 0}

function M.phase(game) -- 1 or 2 while the console's fighter is the arcade's boss, else nil
  local p = game.p and game.p[2]
  return game.mode == "arcade" and p and p.def.boss or nil
end

function M.as_boss(def) -- the arcade's boss: the same fighter with the boss's life (VERSUS has the plain one)
  if not def.boss or def.hp == def.boss_hp then return def end
  return setmetatable({hp = def.boss_hp}, {__index = def})
end

function M.round_start()
  s.next, s.trick, s.warn, s.active, s.left, s.tear = 360, nil, 0, nil, 0, 0
end

-- four of the others' things for the second phase (powers.cameo): chosen as the false credits roll, loaded behind them
function M.pick_cameos(F, avoid)
  local all = {}
  for _, d in ipairs(F.list) do
    local c = d ~= avoid and powers.cameo_of(d)
    if c then all[#all + 1] = c end
  end
  for i = #all, 2, -1 do local j = math.random(i) all[i], all[j] = all[j], all[i] end
  local list = {}
  for i = 1, math.min(4, #all) do list[i] = all[i] end
  powers.cameo_list = list
end

local function calm(f) return f.act == "free" and f.y == 0 end

local function trick_now(game)
  local boss, p1 = game.p[2], game.p[1]
  if s.trick == "swap" then
    p1.x, boss.x = boss.x, p1.x
    p1.dir, boss.dir = -p1.dir, -boss.dir
    for _, f in ipairs({p1, boss}) do
      fight.fx:burst(f.x, fight.FLOOR - 90, 12, {speed = 3, colours = {PINK, 0x20E0FF, 0xFFE020}, life = 14})
    end
  elseif s.trick == "cameo" then
    powers.cameo(boss, s.n)
  else
    s.active, s.left = s.trick, LASTS[s.trick]
  end
  s.tear = 12
  sfx("SND_GLITCH")
end

function M.tick(game)
  if M.phase(game) ~= 2 then return end
  s.left, s.tear = math.max(0, s.left - 1), math.max(0, s.tear - 1)
  if s.left == 0 then s.active = nil end
  if game.state ~= "fight" or fight.flash then return end
  local boss, p1 = game.p[2], game.p[1]
  if s.trick then
    s.warn = s.warn - 1
    if s.warn > 0 then return end
    if s.trick == "swap" and not (calm(p1) and calm(boss)) then return end -- (both on their feet, out of any blow)
    trick_now(game)
    s.trick = nil
    return
  end
  s.next = s.next - 1
  if s.next <= 0 and calm(boss) then
    s.n = s.n + 1
    s.trick, s.warn, s.tear = TRICKS[(s.n - 1) % #TRICKS + 1], WARN, 20
    s.next = math.random(EVERY[1], EVERY[2])
    fight.say(SAY[s.trick], boss, PINK)
    sfx("SND_GLITCH")
  end
end

function M.state() return s end -- (tests read it)

function M.hud_hidden() return s.active == "hud" end

-- the round's start and the narrator's lines are his (GDD 10.2)
function M.word(game, word) return M.phase(game) and word == "FOT-LI!" and "ACCIÓ!" or word end
function M.narrator(game, line) return M.phase(game) and line and "TALLEU! AQUÍ QUI PARLA SÓC JO." or line end

local function tear(t, n, lo, hi) -- a signal torn: thin bars of colour across rows lo to hi (where no words are
  lo, hi = lo or 0, hi or 300       -- being read), where t puts them (no randomness)
  for k = 1, n do
    local y = lo + (t * 53 + k * 97) % (hi - lo)
    local x = (t * 29 + k * 61) % 400
    rect(x, y, 30 + (k * 37) % 120, 2 + k % 3, ({PINK, 0x20E0FF, 0xFFE020, 0xFFFFFF})[k % 4 + 1])
  end
  shade(0, lo + (t * 71) % (hi - lo), 480, 6)
end

local SMALL = {font = "small", align = "center", color = 0xFFFFFF}
local SKY = 72

function M.draw(game, t)
  local ph = M.phase(game)
  if not ph then return end
  -- (in the fight: over the floor only, below the signs and banners, above the SUPER bars)
  if s.tear > 0 then tear(t, 8, 216, 280)
  elseif ph == 2 and t % 200 < 3 then tear(t, 3, 216, 280) end -- (now and then a crackle: the producer's screen)
  if s.active == "pausa" then -- a false PAUSA, in the strip of signs (as a round's), the fight going on under it
    local shown = LASTS.pausa - s.left
    if hud.band(SKY + 4, 52, shown) then hud.big(shown < 90 and "PAUSA" or "ÉS BROMA!", SKY + 10, shown < 90 and 0xFFFFFF or PINK) end
  elseif s.active == "hud" then
    hud.plate(176, 6, 128, 24)
    SMALL.color = s.left // 20 % 2 == 0 and PINK or 0xFFFFFF
    hud.cap("SENYAL PERDUT", 240, 11, SMALL)
    SMALL.color = 0xFFFFFF
  end
end

-- the false credits after the first phase: they roll as the real ones do, then the signal tears and he is back
M.FAKE_TEAR = 300 -- ticks of credits before the tear
M.FAKE_TICKS = 470
local BACK = {align = "center", color = 0xFFE070, gradient = 0xFF8020}
function M.credits_draw(menus, t)
  local u = t - M.FAKE_TEAR
  if u < 30 then menus.credits_draw(math.min(t, M.FAKE_TEAR)) else rect(0, 0, 480, 320, 0x05070C) end -- (then, gone)
  if u < 0 then return end
  if u > 30 then tear(t, 4, 214, 300) else tear(t, 10) end -- (once the words are up, below them)
  if u > 30 then
    if hud.band(110, 90, u - 30) then
      hud.big("UN MOMENT!", 118, PINK, u < 45 and 3 or 0)
      hud.wrap("QUI HA DIT QUE AIXÒ S'HAVIA ACABAT?", 240, 168, 440, 24, BACK)
    end
  end
end

return M
