-- What the player sets and what the game keeps (GDD 16.4): the options, and the best scores with their initials.
-- Saved with store() when they change, read back when the game starts.
local M = {}

M.LEVELS = {"TRANQUIL", "NORMAL", "ARCADE", "LLEGENDA"} -- GDD 13
M.TIMES = {60, 99, 0} -- 0: no clock
M.LANGS = {"CATALÀ", "CASTELLANO"} -- GDD 2: Catalan, and Castilian from the launch

M.v = {level = 2, simple = false, time = 1, music = true, sfx = true, lang = 1, blood = false}

local DEFAULT_SCORES = {
  {name = "SDL", score = 120000}, {name = "AGC", score = 90000}, {name = "PAU", score = 60000},
  {name = "RET", score = 30000}, {name = "GO!", score = 10000},
}
M.scores = DEFAULT_SCORES
M.seen = {} -- the endings seen: key -> true (the gallery shows them)
M.bonus = {} -- the bonus stages played (BONUS mode replays them): key -> best points
-- what unlocks the secrets (GDD 11.1, made easier: all four within two arcades, at any level): the personal rival
-- beaten, a bonus ranked A or better, an arcade won, an arcade won with a second fighter. (They asked for 3 and 8
-- arcades, three S ranks and an arcade without a continue: hardly anyone would have met them.)
M.progress = {clears = {}, rival = false, s = 0} -- s: bonus stages ranked A or better
local function clears() local n = 0 for _ in pairs(M.progress.clears) do n = n + 1 end return n end
M.SECRETS = {patufet = function() return clears() >= 1 end, tio = function() return M.progress.s >= 1 end,
             princesa = function() return M.progress.rival end, timbaler = function() return clears() >= 2 end}
-- Joel Joan, for VERSUS (GDD 11.2): the four secrets found
M.SECRETS.joeljoan = function()
  for _, k in ipairs({"patufet", "tio", "princesa", "timbaler"}) do if not M.SECRETS[k]() then return false end end
  return true
end

-- the codes (OPCIONS > CODIS), as the old games had them: a word typed in letter by letter. The first three open for
-- good what is otherwise found by playing; the others change the fights until the console is turned off, and typed
-- again they are turned off.
M.CODES = {
  {word = "LLEGENDES", key = "secrets", keep = true}, -- the four secret fighters
  {word = "DIRECTOR", key = "boss", keep = true},     -- Joel Joan, for VERSUS
  {word = "TOTOBERT", key = "all", keep = true},      -- both, every bonus stage and every ending in the gallery
  {word = "RAUXA", key = "rauxa"},                    -- every blow hits twice as hard, the SUPER bar always full
  {word = "UNCOP", key = "uncop"},                    -- one clean blow wins the round
  {word = "LLUNA", key = "lluna"},                    -- jumps as on the moon
  {word = "TURBO", key = "turbo"},                    -- the fights at twice the speed
}
M.code = {} -- the codes on: key -> true

local function valid_scores(t) -- what comes back from the card is checked before it is used: five whole scores,
  if type(t) ~= "table" or #t ~= 5 then return false end -- best first, names of up to three letters
  for i, e in ipairs(t) do
    if type(e) ~= "table" or type(e.name) ~= "string" or #e.name > 3 or math.type(e.score) ~= "integer"
       or e.score < 0 or e.score > 9999999 or (i > 1 and e.score > t[i - 1].score) then return false end
  end
  return true
end

function M.load()
  local v = stored("options")
  if type(v) == "table" then
    if M.LEVELS[v.level] then M.v.level = v.level end
    if type(v.simple) == "boolean" then M.v.simple = v.simple end
    if M.TIMES[v.time] then M.v.time = v.time end
    if type(v.music) == "boolean" then M.v.music = v.music end
    if type(v.sfx) == "boolean" then M.v.sfx = v.sfx end
    if M.LANGS[v.lang] then M.v.lang = v.lang end
    if type(v.blood) == "boolean" then M.v.blood = v.blood end
  end
  local s = stored("scores")
  if valid_scores(s) then M.scores = s end
  local p = stored("progress")
  if type(p) == "table" then
    if type(p.clears) == "table" then
      for k, v in pairs(p.clears) do if type(k) == "string" and #k <= 12 and v == true then M.progress.clears[k] = true end end
    end
    M.progress.rival = p.rival == true or p.clean == true -- (clean: an arcade without a continue, which found her before)
    if math.type(p.s) == "integer" and p.s >= 0 and p.s < 1000 then M.progress.s = p.s end
  end
  local b = stored("bonus")
  if type(b) == "table" then
    for k, v in pairs(b) do
      if type(k) == "string" and #k <= 12 and math.type(v) == "integer" and v >= 0 and v <= 9999999 then M.bonus[k] = v end
    end
  end
  local seen = stored("seen")
  if type(seen) == "table" then
    for k, v in pairs(seen) do if type(k) == "string" and #k <= 12 and v == true then M.seen[k] = true end end
  end
  local code = stored("codes")
  if type(code) == "table" then
    for _, c in ipairs(M.CODES) do if c.keep and code[c.key] == true then M.code[c.key] = true end end
  end
end

function M.save() store("options", M.v) end

function M.level_name() return M.LEVELS[M.v.level] end
function M.round_ticks() local t = M.TIMES[M.v.time] return t > 0 and t * 60 or nil end

function M.rank(score) -- where a score would go in the table (1-5), or nil
  for i, e in ipairs(M.scores) do if score > e.score then return i end end
end

function M.add_score(name, score)
  score = math.min(9999999, math.floor(score))
  local i = M.rank(score)
  if not i then return end
  table.insert(M.scores, i, {name = name, score = score})
  M.scores[6] = nil
  store("scores", M.scores)
  return i
end

function M.best() return M.scores[1] end

local function by_code(key)
  local c = M.code
  return c.all or (key == "joeljoan" and c.boss or key ~= "joeljoan" and c.secrets)
end
function M.unlocked(key) local f = M.SECRETS[key] return f ~= nil and (by_code(key) or f()) end
function M.bonus_open(key) return M.bonus[key] ~= nil or M.code.all == true end
function M.ending_open(key) return M.seen[key] or M.code.all == true end

-- a word typed at CODIS: returns its code and "on", "off" or "already" (one that opens, typed again); nil if no code
function M.enter(word)
  for _, c in ipairs(M.CODES) do
    if c.word == word then
      local was = M.code[c.key]
      if c.keep then
        if was then return c, "already" end
        M.code[c.key] = true
        store("codes", M.code) -- (the others are saved with it, but only these are read back)
        return c, "on"
      end
      M.code[c.key] = not was or nil
      return c, was and "off" or "on"
    end
  end
end

-- something done: noted and saved; returns the secrets it has just unlocked (a list, maybe empty)
local function note(change)
  local before = {}
  for k in pairs(M.SECRETS) do before[k] = M.unlocked(k) end
  change(M.progress)
  store("progress", M.progress)
  local new = {}
  for _, k in ipairs({"patufet", "tio", "princesa", "timbaler", "joeljoan"}) do
    if M.unlocked(k) and not before[k] then new[#new + 1] = k end
  end
  return new
end
function M.won_arcade(key) return note(function(p) p.clears[key] = true end) end
function M.beat_rival() return note(function(p) p.rival = true end) end
function M.bonus_rank(rank)
  if rank ~= "A" and rank ~= "S" and rank ~= "RAUXA!" then return {} end
  return note(function(p) p.s = p.s + 1 end)
end

function M.bonus_played(key, points) -- true: a new best
  points = math.min(9999999, math.floor(points))
  if M.bonus[key] and M.bonus[key] >= points then return false end
  M.bonus[key] = points
  store("bonus", M.bonus)
  return true
end

function M.saw_ending(key)
  if M.seen[key] then return end
  M.seen[key] = true
  store("seen", M.seen)
end

return M
