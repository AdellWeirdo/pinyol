-- SANG I FETGE (OPCIONS): the blood of the blows. A blow that lands splashes (BLOOD_SPLASH) and throws drops and, when
-- it is a heavy one, bits of liver (BLOOD_BITS); what falls stains the floor (BLOOD_FLOOR) and the stains stay for the
-- whole match; the last blow of a round bursts (BLOOD_KO) over a pool. All of it is drawn BEHIND the fighters (floor
-- first, then what flies): the fighters are always on top of the blood. Only a picture: it never touches the fight's own
-- numbers, and has a random of its own, so two consoles in step (VERSUS > DUES CONSOLES) need not agree on it.
local gfx = require("gfx")

local M = {on = false, floor = 292, stage_w = 960}

local MAX_DROPS, MAX_STAINS, MAX_WOUNDS = 24, 70, 6
local BAND = {-11, 3} -- the rows (from the feet's) a drop can land on: above the HUD's bars
local GRAVITY = 0.28

local stains, splashes, drops, kos = {}, {}, {}, {}
local wounds = {} -- fighter -> {{dx, dy, kind}}: the marks of the blows it took this round, where they landed
local seed = 7
local function rnd(n) -- (an own random, a plain LCG)
  seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
  return (seed >> 8) % n
end

function M.reset(on) -- a new match: a clean floor; on: the option, and not against the boss (a living person)
  M.on = on == true
  gfx.blood = M.on
  stains, splashes, drops, kos, wounds, seed = {}, {}, {}, {}, {}, 7
end

-- the jokes of the mode (es.lua has them in Castilian): the one hit says one after a hard blow, and the round's last word
M.HURT_LINES = {"AUCH!", "MA MARE!", "QUINA TINTA!", "NO ÉS RES!", "KETXUP!", "LA CAMISA NOVA!"}
M.KO_LINES = {"A LA TINTORERIA!", "QUINA SANG!", "MÉS KETXUP, SISPLAU!", "FETGE DE PRIMERA!", "NO SURT AMB AIGUA!"}
function M.hurt_line() return M.HURT_LINES[rnd(#M.HURT_LINES) + 1] end
function M.ko_line() return M.KO_LINES[rnd(#M.KO_LINES) + 1] end
function M.chance(n) return rnd(n) == 0 end -- one in n

function M.new_round() wounds = {} end -- (everyone has their full life again)

local function stain(x, y, f)
  if #stains >= MAX_STAINS then table.remove(stains, 1) end
  stains[#stains + 1] = {x = x, y = y, f = f, flip = rnd(2) == 0}
end

-- a blow landed at (cx, cy) travelling towards dir (1: to the right); heavy: a strong one; last: it ends the round
function M.hit(cx, cy, dir, heavy, last, x, victim)
  if not M.on then return end
  sfx(last and "SND_GUSH" or heavy and "SND_SQUELCH" or "SND_SPLAT")
  if x then -- a blow that hurts leaves its own puddle under the one hit
    if heavy then stain(math.floor(x) + rnd(25) - 12, M.floor + rnd(7) - 5, 1 + rnd(2))
    elseif rnd(3) == 0 then stain(math.floor(x) + rnd(21) - 10, M.floor + rnd(7) - 5, 0) end
  end
  if victim and victim.y <= 0 and not victim.crouch then -- a mark on the body, where the blow landed (when it stands)
    local w = wounds[victim] or {}
    wounds[victim] = w
    if #w >= MAX_WOUNDS then table.remove(w, 1) end
    w[#w + 1] = {dx = (cx - victim.x) * victim.dir, dy = cy - M.floor, kind = rnd(10) == 0 and 4 or rnd(4)}
  end
  splashes[#splashes + 1] = {x = cx + dir * 22, y = cy, flip = dir < 0, heavy = heavy, t = 0} -- (out of the body it hit: the fighters are on top)
  for i = 1, heavy and 9 or 4 do
    if #drops < MAX_DROPS then
      local liver = heavy and i % 3 == 0 and rnd(2) == 0
      drops[#drops + 1] = {x = cx, y = cy, vx = dir * (1.1 + rnd(30) / 10), vy = -(0.8 + rnd(35) / 10),
                           f = liver and 3 + rnd(3) or rnd(3), land = M.floor + BAND[1] + rnd(BAND[2] - BAND[1])}
    end
  end
  if last then kos[#kos + 1] = {x = x or cx, t = 0, pool = false} end
end

function M.update()
  for i = #splashes, 1, -1 do
    local s = splashes[i]
    s.t = s.t + 1
    if s.t > (s.heavy and 11 or 9) then table.remove(splashes, i) end
  end
  for i = #drops, 1, -1 do
    local d = drops[i]
    d.x, d.vy = d.x + d.vx, d.vy + GRAVITY
    d.y = d.y + d.vy
    if d.y >= d.land then
      if d.f > 2 or rnd(3) == 0 then stain(math.floor(d.x), d.land, d.f > 2 and 0 or rnd(2) == 0 and 0 or 5) end
      table.remove(drops, i)
    elseif d.x < -30 or d.x > M.stage_w + 30 then
      table.remove(drops, i)
    end
  end
  for i = #kos, 1, -1 do
    local k = kos[i]
    k.t = k.t + 1
    if k.t >= 20 and not k.pool then k.pool = true stain(math.floor(k.x), M.floor - 2, 2) end
    if k.t > 40 then table.remove(kos, i) end
  end
end

local function frame_size(pid)
  local w, h = imgsize(pid)
  return w or 0, h or 0
end

function M.draw_floor() -- the stains: under everything
  if not M.on or #stains == 0 or not gfx.has("BLOOD_FLOOR") then return end
  local w, h = frame_size("BLOOD_FLOOR")
  for _, s in ipairs(stains) do gfx.pic("BLOOD_FLOOR", math.floor(s.x - w / 2), math.floor(s.y - h + 6), s.f, s.flip) end
end

function M.draw_back() -- what flies, behind the fighters
  if not M.on then return end
  if #splashes > 0 and gfx.has("BLOOD_SPLASH") then
    local w, h = frame_size("BLOOD_SPLASH")
    for _, s in ipairs(splashes) do
      local f = s.heavy and (s.t < 3 and 1 or s.t < 7 and 2 or 3) or (s.t < 4 and 0 or 4)
      gfx.pic("BLOOD_SPLASH", math.floor(s.flip and s.x - w or s.x), math.floor(s.y - h / 2), f, s.flip)
    end
  end
  if #drops > 0 and gfx.has("BLOOD_BITS") then
    local w, h = frame_size("BLOOD_BITS")
    for _, d in ipairs(drops) do gfx.pic("BLOOD_BITS", math.floor(d.x - w / 2), math.floor(d.y - h / 2), d.f) end
  end
  if #kos > 0 and gfx.has("BLOOD_KO") then
    local w, h = frame_size("BLOOD_KO")
    for _, k in ipairs(kos) do
      gfx.pic("BLOOD_KO", math.floor(k.x - w / 2), math.floor(M.floor + 2 - h), math.min(4, k.t // 5))
    end
  end
end

function M.draw_wounds(list) -- over the fighters (the ones standing: a crouch or a leap moves the body from the marks)
  if not M.on or not gfx.has("BLOOD_WOUNDS") then return end
  local w, h = frame_size("BLOOD_WOUNDS")
  for _, f in ipairs(list) do
    local ws = wounds[f]
    if ws and f.act == "free" and f.y <= 0 and not f.crouch then
      for _, m in ipairs(ws) do
        gfx.pic("BLOOD_WOUNDS", math.floor(f.x + m.dx * f.dir - w / 2), math.floor(M.floor + m.dy - h / 2), m.kind, f.dir < 0)
      end
    end
  end
end

function M.title(x, y) -- the sign, once the K.O.'s own word has made room
  if M.on and gfx.has("BLOOD_TITLE") then
    local w = frame_size("BLOOD_TITLE")
    gfx.pic("BLOOD_TITLE", math.floor(x - w / 2), y)
  end
end

return M
