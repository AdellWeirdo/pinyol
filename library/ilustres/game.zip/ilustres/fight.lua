-- The rules of a round: two fighters and every blow between them. Values from the GDD (docs/GDD_v1.0.pdf, 4-5 and
-- Annex A), its seconds turned into ticks at 60 a second. Positions are stage pixels: x along the stage, y the
-- height above the floor (0 standing on it). What specials make (clocks, pinnacles...) is in powers.lua.
local input = require("input")
local juice = require("juice")
local particles = require("particles")
local powers = require("powers")
local FR = require("fighters").frames

local M = {}

M.FLOOR = 292            -- the screen row of the feet
M.stage_w = 720          -- main sets it from the stage's picture
M.EDGE = 36
M.fx = particles.new()
M.chip_kills = false     -- in the harder difficulties a guard's chip can finish (GDD 4.5)
M.simple = false         -- simple inputs: specials as a direction + B, the SUPER as B+C (GDD 3.3)

local GRAVITY, JUMP_V, JUMP_X = 0.6, 11.5, 3.4
local SQUAT, LANDING = 4, 5                   -- ticks crouched before a jump leaves the floor, and after it lands
local SCALE = {1, 1, 1, 1, 0.9, 0.8, 0.7, 0.6} -- a combo's damage by hit (GDD 4.2)
local COUNTER = 1.15                          -- CONTRACOP!
local METER_MAX, SUPER_COST = 300, 200        -- three stocks, a SUPER costs two
local MODE_TICKS = 480                        -- SENY MAX / RAUXA MAX last 8 s
local DOWN_TICKS, RISE_TICKS = 42, 18         -- knockdown 0.7 s on the floor, then getting up
local ROLL_TICKS, ROLL_WINDOW = 24, 20        -- a wake-up roll, and how soon on the floor it can be asked for
local BUF = 6                                 -- a button pressed this many ticks before one can act still counts
local QCF, QCB, TWO_QCF = {2, 6}, {2, 4}, {2, 6, 2, 6}
local HALF_BODY, MAX_APART, EDGE, THROW_RANGE = 40, 400, M.EDGE, 100
local FLASH_TICKS = 40                        -- the picture stops while a SUPER starts
local BODY = {stand = {-28, -160, 56, 160}, crouch = {-30, -100, 60, 100}, air = {-26, -150, 52, 120},
              puddle = {-40, -24, 80, 24}}
local PILLAR_H, PILLAR_W = 190, 44

M.SUPER_COST, M.METER_MAX = SUPER_COST, METER_MAX
M.p, M.shots, M.walls, M.banners, M.sparks, M.flash = {}, {}, {}, {}, {}, nil
powers.bind(M)

-- ------------------------------------------------------------------ fighters

function M.fighter(def, cpu, palette)
  return {def = def, cpu = cpu, pad = input.new(), wins = 0, meter = 0, score = 0, palette = palette or 1}
end

local function place(f, x, dir)
  f.x, f.y, f.vx, f.vy, f.dir, f.slide, f.pad = x, 0, 0, 0, dir, 0, input.new()
  f.act, f.t, f.frame, f.move, f.name, f.phase, f.jk = "free", 0, 0, nil, nil, nil, nil
  f.hp = math.floor(f.def.hp * (f.handicap or 1)) -- (VERSUS: a handicap starts a fighter with less life)
  f.shown = f.hp
  f.axis, f.mode, f.mode_t = 0, nil, 0
  f.combo, f.combo_dmg, f.combo_t = 0, 0, 0
  f.stun, f.inv, f.flash, f.crouch, f.hurt_round, f.walk_t, f.melting = 0, 0, 0, false, false, 0, false
end

function M.start_round(p1, p2)
  M.p = {p1, p2}
  place(p1, M.stage_w / 2 - 110, 1)
  place(p2, M.stage_w / 2 + 110, -1)
  M.shots, M.walls, M.banners, M.sparks, M.flash = {}, {}, {}, {}, nil
  M.glory, M.glory_t = false, 0
  powers.book = nil
end

function M.other(f) return f == M.p[1] and M.p[2] or M.p[1] end

function M.say(text, who, colour) -- (the same words for the same one, still up: shown again, not twice)
  for _, b in ipairs(M.banners) do
    if b.text == text and b.who == who then b.t = 0 return end
  end
  M.banners[#M.banners + 1] = {text = text, who = who, colour = colour or 0xFFE070, t = 0}
end

local function gain(f, v) f.meter = math.min(METER_MAX, f.meter + v * (M.glory and 1.25 or 1)) end

-- SENY (-) or RAUXA (+): each action leans the axis; at an end, eight seconds of its MAX
function M.lean(f, d)
  if f.mode or d == 0 then return end
  f.axis = math.max(-100, math.min(100, f.axis + d))
  if math.abs(f.axis) < 100 then return end
  f.mode, f.mode_t, f.axis = f.axis > 0 and "rauxa" or "seny", MODE_TICKS, 0
  f.score = f.score + 1000
  M.say(f.mode == "rauxa" and "RAUXA!" or "SENY MAX", f, f.mode == "rauxa" and 0xFF5040 or 0x60B0FF)
  sfx("SND_MODE")
end
local lean = M.lean

local function speed(f) return f.mode == "rauxa" and 1.08 or 1 end
local function crouching(f) return f.pad.dir <= 3 end
local function holding_back(f) return f.pad.dir == 4 or f.pad.dir == 1 end
local function pick(list, i, len) return list[math.min(#list, 1 + i * #list // math.max(1, len))] end

local function spark(x, y, kind) -- "hit", "heavy" or "guard": FX_HITS frames, drawn by main
  M.sparks[#M.sparks + 1] = {x = x, y = y, kind = kind, t = 0}
end

-- ------------------------------------------------------------------ boxes

function M.at(f, b) -- one of f's boxes in stage pixels {x, y, w, h}; y is a screen row
  local x = f.dir > 0 and f.x + b[1] or f.x - b[1] - b[3]
  return {x, M.FLOOR - f.y + b[2], b[3], b[4]}
end
local at = M.at

local function overlap(a, b)
  return a[1] < b[1] + b[3] and b[1] < a[1] + a[3] and a[2] < b[2] + b[4] and b[2] < a[2] + a[4]
end

local function body_box(f) -- (a small fighter, as En Patufet, has a body of its own)
  local B = f.def.body or BODY
  if f.melting then return B.puddle end
  return f.y > 0 and B.air or (f.crouch or f.act == "land") and B.crouch or B.stand
end

local GONE = {down = true, rise = true, roll = true, thrown = true, ko = true, win = true, intro = true, lose = true}

function M.hurtboxes(f, juggle) -- where f can be hit now: the body, and the limb of a blow being thrown
  local a = f.act
  if f.inv > 0 or GONE[a] then return {} end
  if a == "fall" and not juggle then return {} end
  local list = {at(f, body_box(f))}
  if a == "attack" and f.phase ~= "s" and f.move.box then list[2] = at(f, f.move.box) end
  return list
end

function M.hitbox(f) -- where f's blow can land this tick, or nil
  local m = f.move
  if not m or f.done or not m.box then return nil end
  if f.act == "attack" and f.phase == "a" then return at(f, m.box) end
  if f.act == "jump" and f.jk and f.jk > m.startup and f.jk <= m.startup + m.active then return at(f, m.box) end
end

function M.body(f) return at(f, body_box(f)) end

-- ------------------------------------------------------------------ a blow lands

-- hit: {dmg, stun, bstun, push, hits = "mid"/"low"/"high", knock, kind = nil/"special"/"super"/"throw", juggle,
-- unblockable, from (the x it comes from)}; melee blows push the attacker back off a wall
local function correct(f, a, cx, cy, melee) -- Fabra's CORRECCIÓ meets a blow or a shot: it is turned back
  f.t, f.phase, f.done = f.startup + f.active, "r", true -- on into the slash of his recovery
  M.say(f.move.name .. "!", f, 0xFF5050)
  sfx("SND_COUNTER")
  spark(cx, cy, "guard")
  gain(f, 15)
  M.lean(f, -8)
  juice.freeze(10)
  if melee then
    M.land(f, a, {dmg = 76, stun = 0, bstun = 0, push = 10, knock = true, unblockable = true, kind = "special",
                  from = f.x}, cx, cy)
  end
  return "countered"
end

function M.land(a, o, hit, cx, cy, melee)
  if o.act == "attack" and o.move and o.move.counter and o.phase == "a" and not hit.unblockable
     and hit.kind ~= "super" and hit.kind ~= "throw" then
    return correct(o, a, cx, cy, melee)
  end
  local away = (hit.from or a.x) < o.x and 1 or -1 -- o goes this way
  local guarding = o.act == "free" or o.act == "blockstun" or o.act == "land"
  local blocked = not hit.unblockable and o.y <= 0 and guarding and holding_back(o)
    and not (hit.hits == "low" and not crouching(o)) and not (hit.hits == "high" and crouching(o))
  local walled = away > 0 and o.x > M.stage_w - EDGE - 24 or away < 0 and o.x < EDGE + 24
  if melee and walled then a.slide = -away * hit.push end
  if blocked then
    local chip = hit.kind == "super" and 0.15 or hit.kind == "special" and 0.08 or 0
    local dmg = math.floor(hit.dmg * chip * (a.def.power or 1) + 0.5)
    if dmg > 0 then -- chip never finishes anyone, unless the difficulty says so
      o.hp = M.chip_kills and math.max(0, o.hp - dmg) or math.max(math.min(o.hp, 1), o.hp - dmg)
    end
    if o.hp <= 0 then -- finished through the guard: down as from any blow
      M.last_kind = hit.kind or "normal"
      a.score = a.score + dmg * 10
      o.act, o.t, o.vy, o.vx, o.y, o.move = "fall", 0, 6.5, away * 2.6, 1, nil
      sfx("SND_HEAVY")
      spark(cx, cy, "heavy")
      juice.freeze(10)
      return "hit"
    end
    o.act, o.t, o.vx, o.crouch = "blockstun", 0, 0, crouching(o)
    o.stun = math.floor(hit.bstun * (o.mode == "seny" and 0.75 or 1))
    o.slide = away * hit.push * 0.8
    gain(a, hit.dmg * 0.04)
    if hit.kind then gain(o, 6) end
    lean(o, -5)
    sfx("SND_BLOCK")
    spark(cx, cy, "guard")
    juice.freeze(4)
    return "block"
  end
  -- a blow caught while starting is a counter; in SENY MAX also while hitting (GDD 5.3: more permissive)
  local counter = o.act == "attack" and (o.phase == "s" or a.mode == "seny" and o.phase == "a")
  if o.act == "hitstun" or o.act == "fall" then o.combo = o.combo + 1 else o.combo, o.combo_dmg = 1, 0 end
  local k = SCALE[math.min(o.combo, #SCALE)] * (counter and COUNTER or 1) * (a.mode == "rauxa" and 1.1 or 1)
    * (o.mode == "seny" and 0.9 or 1)
  local dmg = math.max(1, math.floor(hit.dmg * k * (a.def.power or 1) + 0.5)) -- (power: balance.lua)
  o.hp = math.max(0, o.hp - dmg)
  M.last_kind = hit.kind or "normal" -- the narrator wants to know what finished a round
  o.combo_dmg, o.combo_t, o.hurt_round = o.combo_dmg + dmg, 90, true
  a.score = a.score + dmg * 10 + (counter and 500 or 0) + (o.combo >= 3 and 100 * o.combo or 0)
  gain(a, dmg * 0.12 + (counter and 10 or 0))
  gain(o, dmg * 0.08)
  lean(a, counter and -8 or 4)
  if dmg >= 80 then lean(o, 5) end
  if counter then
    sfx("SND_COUNTER")
    if o.combo <= 1 and (a.counter_said or -999) + 180 <= M.ticks then -- (said on every trade, it was noise)
      a.counter_said = M.ticks
      M.say("CONTRACOP!", a, 0xFFB030)
    end
  end
  local low = o.crouch and o.y <= 0
  local big = hit.knock or hit.kind == "super" or hit.kind == "throw" or o.hp <= 0 -- (every blow white was noise)
  if big and (o.flash_at or -999) + 20 <= M.ticks then o.flash, o.flashed, o.flash_at = 8, 0, M.ticks end
  o.slide, o.move, o.jk, o.vx, o.melting = away * hit.push, nil, nil, 0, false
  if o.hp <= 0 or hit.knock or o.y > 0 or o.act == "fall" then
    o.act, o.t, o.vy, o.vx, o.y = "fall", 0, o.y > 0 and 4 or 6.5, away * 2.6, math.max(o.y, 1)
  else
    o.act, o.t, o.stun, o.crouch = "hitstun", 0, hit.stun + (counter and 6 or 0), low
  end
  local heavy = hit.dmg >= 60
  sfx(heavy and "SND_HEAVY" or "SND_HIT")
  spark(cx, cy, heavy and "heavy" or "hit")
  M.fx:burst(cx, cy, heavy and 6 or 3, {speed = heavy and 4 or 3, colours = {0xFFF080, 0xFF8030, 0xFFFFFF},
                                       life = 12, size = 2}) -- few: the drawn spark does the work
  juice.freeze((heavy and 7 or 4) + (counter and 4 or 0))
  if heavy then juice.shake(4) end
  return "hit"
end

-- ------------------------------------------------------------------ what a fighter starts

local function classic(pad, f, fa, fb, fc)
  local d = pad.dir
  if fb and f.meter >= SUPER_COST and input.motion(pad, TWO_QCF, 30) then return "super" end
  if (fa or fb) and input.motion(pad, QCF, 15) then return fb and "special_b" or "special_a" end
  if (fa or fb) and input.motion(pad, QCB, 15) then return fb and "special2_b" or "special2_a" end
  if fa and fb and math.abs(pad.at.a - pad.at.b) <= 1 then return "taunt" end
  if fa and fc and math.abs(pad.at.a - pad.at.c) <= 2 then return "throw" end
  if fb then return d <= 3 and "DB" or "B" end
  if fc then return d <= 3 and "DC" or d == 6 and "FC" or "C" end
  return d <= 3 and "DA" or "A"
end

local function simple(pad, f, fa, fb, fc) -- GDD 3.3: the same moves, easier to ask for
  local d = pad.dir
  if fb and fc and math.abs(pad.at.b - pad.at.c) <= 2 then return f.meter >= SUPER_COST and "super" or "FC" end
  if fb and d == 6 then return "special_b" end
  if fb and d == 4 then return "special2_b" end
  return classic(pad, f, fa, fb, fc)
end

-- the move the pad asks for now, or nil; the buttons it took are used up
local function command(f)
  local pad = f.pad
  if pad.cmd then
    local c = pad.cmd
    pad.cmd = nil
    return c
  end
  local fa, fb, fc = input.fresh(pad, "a", BUF), input.fresh(pad, "b", BUF), input.fresh(pad, "c", BUF)
  if not (fa or fb or fc) then return nil end
  local c = (M.simple and simple or classic)(pad, f, fa, fb, fc)
  input.use(pad)
  return c
end

local function begin(f, name)
  local m = f.def.moves[name]
  f.act, f.t, f.move, f.name, f.phase, f.done, f.contact = "attack", 0, m, name, "s", false, false
  f.crouch, f.vx = m.crouch or false, 0
  -- RAUXA MAX: specials start a little sooner; SENY MAX: they recover sooner (GDD 5.3-5.4)
  f.startup = m.startup - (f.mode == "rauxa" and m.kind == "special" and 2 or 0)
  f.active = m.active
  f.recovery = m.recovery - (f.mode == "seny" and m.kind == "special" and 5 or 0)
  sfx("SND_SWING", 0.5)
end

local ONE_OUT = {clock = "clock", salamander = "salamander", letters = "letter", blob = "blob", shot = "shot"}

local function special(f, which, strength)
  local m = f.def.moves[which]
  if ONE_OUT[m.spawn] and powers.mine(f, ONE_OUT[m.spawn]) then return false end -- one out at a time
  begin(f, which)
  f.strength = strength
  if m.counter then -- the correction's guard: B holds it longer, SENY half as long again
    f.active = math.floor((m.active + (strength == 2 and 8 or 0)) * (f.mode == "seny" and 1.5 or 1))
  end
  lean(f, 5)
  return true
end

local SPECIALS = {special_a = {"special", 1}, special_b = {"special", 2}, special2_a = {"special2", 1},
                  special2_b = {"special2", 2}}

local function super(f)
  f.meter = f.meter - SUPER_COST
  f.act, f.t, f.move, f.name, f.inv, f.vx, f.crouch = "super", 0, f.def.moves.super, "super", 60, 0, false
  M.flash = {who = f, t = 0}
  M.say(f.def.moves.super.name, f, 0xFFE070)
  sfx("SND_SUPER")
  lean(f, 6)
end

local THROWABLE = {free = true, attack = true, taunt = true, dash = true, land = true, squat = true}

local function throw(f, o)
  if math.abs(o.x - f.x) > THROW_RANGE or o.y > 0 or o.inv > 0 or not THROWABLE[o.act] then return false end
  f.act, f.t, f.vx, f.move, f.inv = "throw", 0, 0, nil, 18
  o.act, o.t, o.move, o.vx, o.slide, o.melting = "thrown", 0, nil, 0, 0, false
  sfx("SND_GRAB")
  return true
end

-- ------------------------------------------------------------------ each state, one tick

local function free(f, o)
  local pad = f.pad
  f.dir = o.x >= f.x and 1 or -1
  local c = command(f)
  if c == "super" and f.meter >= SUPER_COST then return super(f) end
  local sp = SPECIALS[c]
  if sp then
    special(f, sp[1], sp[2])
    return
  end
  if c == "dash" or c == "back" then -- the console's fighter asks for these by name
    f.act, f.t, f.inv = c, 0, c == "back" and 8 or 0
    sfx("SND_DASH", 0.6)
    return
  end
  if c == "taunt" then
    f.act, f.t, f.vx = "taunt", 0, 0
    lean(f, 15)
    sfx("SND_TAUNT")
    return
  end
  if c == "throw" then
    if throw(f, o) then return end
    c = "A"
  end
  local m = c and f.def.moves[c]
  if m and m.s then return begin(f, c) end -- a ground blow (air ones and powers have no "s")
  local d = pad.dir
  if d >= 7 then -- a jump: a few ticks crouched, then off
    f.act, f.t, f.crouch, f.jdir, f.vx = "squat", 0, false, d, 0
    f.frame = FR.squat
    return
  end
  if input.double(pad, 6, 12) then
    f.act, f.t = "dash", 0
    lean(f, 3)
    sfx("SND_DASH")
    return
  end
  if input.double(pad, 4, 12) then
    f.act, f.t, f.inv = "back", 0, 8
    lean(f, -4)
    sfx("SND_DASH", 0.6)
    return
  end
  f.crouch = d <= 3
  f.vx = f.crouch and 0 or d == 6 and f.def.walk * speed(f) * f.dir or d == 4 and -f.def.back * f.dir or 0
  if d ~= 6 and math.abs(o.x - f.x) > 200 then lean(f, -0.06) end -- keeping one's distance: seny
  if f.crouch then
    f.frame = FR.crouch
  elseif f.vx ~= 0 then
    f.walk_t = f.walk_t + 1
    local k = (f.walk_t // 6) % 5
    f.frame = FR.walk[1 + (d == 6 and k or 4 - k)]
  else
    f.frame = FR.idle[1 + (ticks() // 9) % 5]
  end
end

local function attack(f, o)
  local m = f.move
  f.t = f.t + 1
  local t, s, r, act = f.t, f.startup, f.recovery, f.active
  if t <= s then
    f.phase, f.frame = "s", pick(m.s, t - 1, s)
  elseif t <= s + act then
    f.phase, f.frame = "a", pick(m.a, t - s - 1, act)
    if t == s + 1 and m.spawn then powers[m.spawn](f, o) end
    if t == s + act and m.spawn == "melt" then powers.melt_end(f, o) end
  else
    f.phase, f.frame = "r", pick(m.r, t - s - act - 1, r)
  end
  if m.rush then -- a charge: forward while the blow is out (and a little after), the hit once
    f.vx = (f.phase == "a" and m.rush or f.phase == "r" and m.rush * 0.3 or 0) * f.dir * speed(f)
  end
  -- A and C pressed nearly together: the light blow becomes a throw
  if t <= 3 and (f.name == "A" and input.fresh(f.pad, "c", 3) or f.name == "C" and input.fresh(f.pad, "a", 3)) then
    input.use(f.pad)
    if throw(f, o) then return end
  end
  if f.contact and f.phase ~= "s" then -- it touched: it may go on into another
    local c = command(f)
    if c == "super" and f.meter >= SUPER_COST then return super(f) end
    local sp = SPECIALS[c]
    if m.cancel and sp and special(f, sp[1], sp[2]) then return end
    if c and m.chain and m.chain[c] then return begin(f, c) end
  end
  if t >= s + act + r then f.act, f.t, f.move, f.phase = "free", 0, nil, nil end
end

local AIR = {a = "JA", b = "JB", c = "J"}

local function jump(f)
  f.t = f.t + 1
  local pad = f.pad
  if not f.jk then -- one blow a jump: A a punch, B a heavy one, C a kick
    local name = pad.cmd == "J" and "J" or pad.cmd == "JA" and "JA" or pad.cmd == "JB" and "JB"
    if not name then
      for k, n in pairs(AIR) do if input.fresh(pad, k, BUF) then name = n end end
    end
    pad.cmd = nil
    if name then
      input.use(pad)
      f.jk, f.move, f.done, f.contact = 0, f.def.moves[name], false, false
      sfx("SND_SWING", 0.5)
    end
  else
    f.jk = f.jk + 1
  end
  f.x, f.y, f.vy = f.x + f.vx, f.y + f.vy, f.vy - GRAVITY
  if f.move then f.frame = f.move.frame
  elseif f.vy > 2.5 then f.frame = FR.rise_air
  elseif f.vy > -2.5 then f.frame = FR.top
  else f.frame = FR.drop end
  if f.y <= 0 then
    f.y, f.vy, f.vx, f.act, f.t, f.jk, f.move, f.frame = 0, 0, 0, "land", 0, nil, nil, FR.land
    M.fx:burst(f.x, M.FLOOR, 6, {speed = 1.5, angle = -90, spread = 140, colours = {0xC8A070, 0xE0C090}, life = 14})
    sfx("SND_STEP", 0.5)
  end
end

local function super_step(f, o)
  local m = f.move
  f.t = f.t + 1
  f.frame = FR.super[math.min(#FR.super, 1 + f.t * #FR.super // m.length)]
  powers[m.spawn](f, o, f.t)
  if f.t >= m.length then f.act, f.t, f.move = "free", 0, nil end
end

local function throw_step(f, o)
  f.t = f.t + 1
  f.frame = FR.throw[f.t < 8 and 1 or f.t < 18 and 2 or 3]
  if o.act == "thrown" then
    o.x, o.y, o.dir, o.frame = f.x + f.dir * (f.t < 18 and 56 or 80), f.t < 8 and 0 or 30, -f.dir, FR.hurt
    if f.t == 18 then
      o.act = "free" -- let go: the toss lands as a blow nobody can block
      M.land(f, o, {dmg = 100, stun = 0, bstun = 0, push = 0, knock = true, unblockable = true, kind = "throw",
                    from = f.x}, o.x, M.FLOOR - 110)
      o.vx = f.dir * 3.5
    end
  end
  if f.t >= 30 then f.act, f.t = "free", 0 end
end

local function down(f) -- on the floor: hold back or forward early to roll away (GDD 4.3), else get up where one is
  f.t, f.frame = f.t + 1, FR.lie
  local d = f.pad.dir
  if f.t <= ROLL_WINDOW and f.hp > 0 and (d == 4 or d == 6 or d == 1 or d == 3) then
    f.act, f.t, f.roll, f.inv = "roll", 0, (d == 6 or d == 3) and f.dir or -f.dir, ROLL_TICKS + 4
    sfx("SND_DASH", 0.6)
  elseif f.t >= DOWN_TICKS then
    f.act, f.t = "rise", 0
  end
end

local function timed(f, frames, every) f.frame = frames[1 + (f.t // every) % #frames] end

local function step(f, o)
  if f.inv > 0 then f.inv = f.inv - 1 end
  if f.flash > 0 then f.flash = f.flash - 1 end
  if f.combo_t > 0 then f.combo_t = f.combo_t - 1 end
  if f.mode then
    f.mode_t = f.mode_t - 1
    if f.mode_t <= 0 then f.mode = nil end
  end
  local a = f.act
  if a == "free" then free(f, o)
  elseif a == "attack" then attack(f, o)
  elseif a == "jump" then jump(f)
  elseif a == "squat" then
    f.t = f.t + 1
    if f.t >= SQUAT then
      local d = f.jdir
      f.act, f.t, f.vy, f.jk, f.move, f.y = "jump", 0, JUMP_V, nil, nil, 1
      f.vx = (d == 9 and JUMP_X or d == 7 and -JUMP_X or 0) * f.dir * speed(f)
      sfx("SND_JUMP", 0.5)
    end
  elseif a == "land" then
    f.t, f.frame = f.t + 1, FR.land
    if f.t >= LANDING then f.act, f.t = "free", 0 end
  elseif a == "super" then super_step(f, o)
  elseif a == "throw" then throw_step(f, o)
  elseif a == "hitstun" or a == "blockstun" then
    f.t = f.t + 1
    if a == "blockstun" then f.frame = f.crouch and FR.cblock or FR.block
    else f.frame = f.crouch and FR.hurt_low or FR.hurt end
    if f.t >= f.stun then f.act, f.t = "free", 0 end
  elseif a == "fall" then
    f.t = f.t + 1
    f.x, f.y, f.vy, f.frame = f.x + f.vx, f.y + f.vy, f.vy - GRAVITY, FR.fall
    if f.y <= 0 and f.t > 2 then
      f.y, f.vy, f.vx, f.act, f.t = 0, 0, 0, f.hp <= 0 and "ko" or "down", 0
      juice.shake(3)
      sfx("SND_LAND")
      M.fx:burst(f.x, M.FLOOR, 12, {speed = 2, angle = -90, spread = 160, colours = {0xC8A070, 0xE0C090}, life = 18})
    end
  elseif a == "down" then down(f)
  elseif a == "roll" then
    f.t = f.t + 1
    f.vx, f.frame = f.roll * 5, f.t < ROLL_TICKS - 8 and FR.roll[1] or FR.roll[2]
    if f.t >= ROLL_TICKS then f.act, f.t, f.vx, f.inv = "free", 0, 0, 4 end
  elseif a == "rise" then
    f.t, f.frame = f.t + 1, FR.rise
    if f.t >= RISE_TICKS then f.act, f.t, f.inv = "free", 0, 4 end
  elseif a == "ko" then
    f.frame = FR.lie
  elseif a == "thrown" and o.act ~= "throw" then -- the thrower was stopped: let go
    f.act, f.t, f.vy, f.vx = f.y > 0 and "fall" or "free", 0, 0, 0
  elseif a == "dash" then
    f.t = f.t + 1
    f.vx = f.dir * math.max(0, 8.5 - f.t * 0.45) * speed(f)
    timed(f, FR.dash, 4)
    if f.t >= 16 then f.act, f.t, f.vx = "free", 0, 0 end
  elseif a == "back" then
    f.t = f.t + 1
    f.vx, f.frame = -f.dir * math.max(0, 7.5 - f.t * 0.4), FR.back
    if f.t >= 18 then f.act, f.t, f.vx = "free", 0, 0 end
  elseif a == "taunt" then
    f.t = f.t + 1
    timed(f, FR.taunt, 25)
    if f.t >= 50 then f.act, f.t = "free", 0 end
  elseif a == "intro" then -- before the round: the entrance, then the stance held
    f.t, f.frame = f.t + 1, FR.intro[math.min(#FR.intro, 1 + f.t // 20)]
  elseif a == "win" then
    f.t = f.t + 1
    f.frame = FR.win[math.min(#FR.win, 1 + f.t // 40)]
  elseif a == "lose" then -- the time ran out on the one with less life: down to the floor if in the air, and still
    f.frame, f.vx, f.melting = FR.hurt_low, 0, false
    if f.y > 0 then f.y, f.vy = math.max(0, f.y + f.vy), f.vy - GRAVITY end
  end
  if f.act ~= "jump" and f.act ~= "fall" and f.act ~= "thrown" then f.x = f.x + f.vx end
  if f.slide ~= 0 then
    f.x, f.slide = f.x + f.slide, f.slide * 0.75
    if math.abs(f.slide) < 0.3 then f.slide = 0 end
  end
  if f.shown > f.hp then f.shown = math.max(f.hp, f.shown - 3) end
end

-- ------------------------------------------------------------------ shots and walls

local function wall_stops(s) -- a wall of the other's (Gaudí's pinnacles, or a pillar that stays) stops a shot
  for _, w in ipairs(M.walls) do
    if w.owner ~= s.owner and w.blocks ~= false and math.abs(s.x - w.x) < ((w.ww or PILLAR_W) + s.w) / 2
       and s.y > M.FLOOR - (w.wh or PILLAR_H) then
      return true
    end
  end
end

local live = {}

local function shots_step()
  for _, s in ipairs(M.shots) do
    if s.gravity then s.vy = s.vy + s.gravity end
    s.x, s.y, s.t, s.cool = s.x + s.vx, s.y + s.vy, s.t + 1, math.max(0, s.cool - 1)
    local o = M.other(s.owner)
    local alive = s.x > -60 and s.x < M.stage_w + 60 and (not s.life or s.t < s.life)
    if s.gravity and s.y >= M.FLOOR - s.h / 2 then -- a thrown thing that reaches the floor splashes there
      alive = false
      M.fx:burst(s.x, M.FLOOR - 4, 6, {speed = 2, angle = -90, spread = 140, colours = {0xD02020, 0x2050D0, 0xF0C020}, life = 12})
    end
    if s.pull and alive and o.inv <= 0 and o.act ~= "down" then -- the vortex draws its victim to its middle
      o.x = o.x + (s.x > o.x and 1.6 or -1.6)
    end
    if s.armed and alive then -- a star told to burst (the vortex): it does, on whoever is near
      alive = false
      M.fx:burst(s.x, s.y, 14, {speed = 3.5, colours = {0xD02020, 0x2050D0, 0xF0C020, 0x101010}, life = 16})
      if math.abs(o.x - s.x) < 110 and o.inv <= 0 then M.land(s.owner, o, s.hit, s.x, s.y) end
    end
    if s.kind == "rain" and s.y >= M.FLOOR - s.h / 2 then
      alive = false
      M.fx:burst(s.x, M.FLOOR - 6, 4, {speed = 2.5, angle = -90, spread = 150, colours = {0xFFD040, 0xFFFFFF}, life = 12})
    end
    if alive and not s.super and wall_stops(s) then
      alive = false
      M.fx:burst(s.x, s.y, 12, {speed = 3, colours = {0xE0C090, 0xFFFFFF}, life = 14})
    end
    -- a charge (Peret's RUMBA, the ESCOMESA, the Tió's RODOLA) goes through shots until it recovers: who has no
    -- shot of their own gets past the ones who do (a SUPER's still hit)
    local through = not s.super and o.act == "attack" and o.move and o.move.rush and o.phase ~= "r"
    if alive and s.cool == 0 and not through then
      local box = {s.x - s.w / 2, s.y - s.h / 2, s.w, s.h}
      for _, hb in ipairs(M.hurtboxes(o, s.hit.juggle)) do
        if overlap(box, hb) then
          if s.left then
            s.left, s.cool = s.left - 1, 7
            s.hit.knock = s.left == 0
          end
          s.hit.from = s.hit.from or s.x - (s.vx >= 0 and 1 or -1)
          local r = M.land(s.owner, o, s.hit, s.x, s.y)
          if s.kind == "star" or s.trap or r == "countered" then
            s.left = nil -- a star bursts; a corrected shot is gone
            M.fx:burst(s.x, s.y, 10, {speed = 3, colours = {0xD02020, 0x2050D0, 0xF0C020}, life = 14})
          end
          if s.kind ~= "rain" then s.hit.from = nil end
          alive = s.left ~= nil and s.left > 0
          break
        end
      end
    end
    s.dead = not alive
  end
  local shots = M.shots
  for i = 1, #shots do -- shots of the two meet: they break each other, unless one is stronger
    for j = i + 1, #shots do
      local a, b = shots[i], shots[j]
      if a.owner ~= b.owner and not a.dead and not b.dead and math.abs(a.x - b.x) < (a.w + b.w) / 2
         and math.abs(a.y - b.y) < (a.h + b.h) / 2 then
        a.dead = not (a.super or a.pierce) or (b.super and not a.super)
        b.dead = not (b.super or b.pierce) or (a.super and not b.super)
        M.fx:burst((a.x + b.x) / 2, (a.y + b.y) / 2, 14, {speed = 3, colours = {0xFFF080, 0xFFFFFF}, life = 14})
      end
    end
  end
  local n = 0 -- the live ones kept in place: no new table each tick
  for i = 1, #shots do
    if not shots[i].dead then n = n + 1 shots[n] = shots[i] end
  end
  for i = #shots, n + 1, -1 do shots[i] = nil end
end

local function walls_step()
  local walls, n = M.walls, 0
  for i = 1, #walls do
    local w = walls[i]
    w.t = w.t + 1
    local ww = w.ww or PILLAR_W
    local h = (w.wh or PILLAR_H) * math.min(1, w.t / 10)
    w.box = w.box or {}
    w.box[1], w.box[2], w.box[3], w.box[4] = w.x - ww / 2, M.FLOOR - h, ww, h
    if not w.done and w.t >= 2 and w.t <= 14 then
      local o = M.other(w.owner)
      for _, hb in ipairs(M.hurtboxes(o)) do
        if overlap(w.box, hb) then
          w.done, w.hit.from = true, w.owner.x
          M.land(w.owner, o, w.hit, w.x, hb[2] + 20)
          break
        end
      end
    end
    if w.t == 1 then
      M.fx:burst(w.x, M.FLOOR, 16, {speed = 3, angle = -90, spread = 70, colours = {0xC8A070, 0xE0C090}, life = 20})
    end
    if w.t < w.life then n = n + 1 walls[n] = w end
  end
  for i = #walls, n + 1, -1 do walls[i] = nil end
end

-- ------------------------------------------------------------------ the two bodies

local function clamp(f) f.x = math.max(EDGE, math.min(M.stage_w - EDGE, f.x)) end

local function separate(a, b)
  if a.y > 110 or b.y > 110 or a.act == "thrown" or b.act == "thrown" or a.melting or b.melting then return end
  local dx = b.x - a.x
  local need = (a.def.half or HALF_BODY) + (b.def.half or HALF_BODY) -- (each as wide as its drawing)
  if math.abs(dx) >= need then return end
  local side = dx ~= 0 and (dx > 0 and 1 or -1) or a.dir
  local push = (need - math.abs(dx)) / 2
  a.x, b.x = a.x - side * push, b.x + side * push
  clamp(a)
  clamp(b)
  if math.abs(b.x - a.x) < need then -- one against the wall: the other takes it all
    if a.x <= EDGE or a.x >= M.stage_w - EDGE then b.x = a.x + side * need else a.x = b.x - side * need end
  end
end

-- ------------------------------------------------------------------ one tick of the round

local hits = {{}, {}}

M.ticks = 0 -- the fight's own clock (banners and flashes kept apart by it)
function M.update()
  M.ticks = M.ticks + 1
  for _, b in ipairs(M.banners) do b.t = b.t + 1 end
  while M.banners[1] and M.banners[1].t > 80 do table.remove(M.banners, 1) end
  local sp, n = M.sparks, 0
  for i = 1, #sp do
    sp[i].t = sp[i].t + 1
    if sp[i].t < 12 then n = n + 1 sp[n] = sp[i] end
  end
  for i = #sp, n + 1, -1 do sp[i] = nil end
  if M.flash then -- the SUPER's flash: everything waits
    M.flash.t = M.flash.t + 1
    if M.flash.t >= FLASH_TICKS then M.flash = nil end
    return
  end
  local p1, p2 = M.p[1], M.p[2]
  step(p1, p2)
  step(p2, p1)
  walls_step()
  shots_step()
  local found = 0
  for _, f in ipairs(M.p) do -- both blows are found first, so two that meet trade
    local hb = M.hitbox(f)
    if hb then
      for _, hurt in ipairs(M.hurtboxes(M.other(f))) do
        if overlap(hb, hurt) then
          found = found + 1
          local h = hits[found]
          h[1], h[4] = f, f.move -- the move kept: a trade's first blow clears the other's
          h[2] = (math.max(hb[1], hurt[1]) + math.min(hb[1] + hb[3], hurt[1] + hurt[3])) / 2
          h[3] = (math.max(hb[2], hurt[2]) + math.min(hb[2] + hb[4], hurt[2] + hurt[4])) / 2
          break
        end
      end
    end
  end
  for i = 1, found do
    local h = hits[i]
    h[1].done, h[1].contact = true, true
    M.land(h[1], M.other(h[1]), h[4], h[2], h[3], true)
  end
  clamp(p1)
  clamp(p2)
  separate(p1, p2)
  local gap = math.abs(p1.x - p2.x) - MAX_APART -- never further apart than the screen shows
  if gap > 0 then
    local side = p1.x < p2.x and 1 or -1
    p1.x, p2.x = p1.x + side * gap / 2, p2.x - side * gap / 2
  end
  -- MOMENT DE GLÒRIA (GDD 5.5): both under a quarter of their life, once a round
  if not M.glory and p1.hp > 0 and p2.hp > 0 and p1.hp < p1.def.hp / 4 and p2.hp < p2.def.hp / 4 then
    M.glory, M.glory_t = true, 0
  end
  if M.glory then M.glory_t = M.glory_t + 1 end
end

M.feed = input.feed
return M
