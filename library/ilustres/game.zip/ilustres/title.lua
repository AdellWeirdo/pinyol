-- Everything before the fight, the arcade way: the console's own splash, the title with its logo falling into
-- place and glinting, the menu, how to play. main.lua decides which screen is shown; this draws them.
local juice = require("juice")
local hud = require("hud")
local audio = require("audio")
local opt = require("options")

local function tone_on(v, n, o) if audio.sfx_on then tone(v, n, o) end end -- the splash's notes, silenced by the option

local function art_has(id) return imgsize(id) ~= nil end

local M = {}

local INK = 0x200010
M.MENU = {"ARCADE", "VERSUS", "ENTRENAMENT", "BONUS", "GALERIA", "OPCIONS", "CONTROLS"}

-- ------------------------------------------------------------------ the console's splash

-- The RetroGO logo builds itself: its four squares pop in one by one round the cross, each with a note; the symbol
-- shrinks to its place; the name is wiped in from behind it, then the motto. Geometry from the logo's artwork
-- (assets/ref/retrogo_dark.png) at 0.3 of its size: the squares 26 px, the symbol's middle at (71, 157).
local BG = 0x161718
local CELL, SIDE = 26.4, 26
local SQUARES = { -- clockwise from the top, the order they appear: offset in cells, colour, note
  {0, -1, 0x6D8441, "C5"}, {1, 0, 0xD15E20, "E5"}, {0, 1, 0xCDBDA0, "G5"}, {-1, 0, 0xFEFEFE, "C6"},
}
local SYM_X, SYM_Y = 71, 157  -- the symbol's middle, at rest
local WORD_X, WORD_Y, TAG_Y = 124, 130, 191
M.SPLASH_TICKS = 235

local function rounded(x, y, size, colour) -- a square with round corners, as the logo's
  local r = math.max(1, math.floor(size * 0.15))
  x, y, size = math.floor(x), math.floor(y), math.floor(size)
  rect(x + r, y, size - 2 * r, size, colour)
  rect(x, y + r, size, size - 2 * r, colour)
  circ(x + r, y + r, r, colour)
  circ(x + size - r - 1, y + r, r, colour)
  circ(x + r, y + size - r - 1, r, colour)
  circ(x + size - r - 1, y + size - r - 1, r, colour)
end

local function out_back(u) -- 0 to 1, overshooting a little before it settles
  u = u - 1
  return 1 + 2.7 * u * u * u + 1.7 * u * u
end

local function smooth(u) u = math.max(0, math.min(1, u)) return u * u * (3 - 2 * u) end

function M.splash(t)
  rect(0, 0, 480, 320, BG)
  -- the symbol: built big in the middle, then to its place beside the name
  local move = smooth((t - 62) / 28)
  local k = 1.8 + (1 - 1.8) * move
  local cx, cy = 240 + (SYM_X - 240) * move, 160 + (SYM_Y - 160) * move
  for i, q in ipairs(SQUARES) do
    local born = 6 + i * 12
    if t >= born then
      if t == born then tone_on(0, q[4], {wave = "square", duty = 0.25, vol = 0.3, decay = 0.2}) end
      local size = SIDE * k * out_back(math.min(1, (t - born) / 10))
      local qx, qy = cx + q[1] * CELL * k, cy + q[2] * CELL * k
      rounded(qx - size / 2, qy - size / 2, size, t - born < 3 and 0xFFFFFF or q[3])
    end
  end
  -- the name, wiped in from the symbol's side; a light runs along the wipe's edge
  local u = smooth((t - 86) / 30)
  if u > 0 and art_has("RG_WORD") then
    local w = imgsize("RG_WORD")
    local edge = WORD_X + math.floor(w * u)
    clip(WORD_X, 0, edge - WORD_X, 320)
    img("RG_WORD", WORD_X, WORD_Y)
    clip()
    if u < 1 then rect(edge - 1, WORD_Y - 4, 2, 61, 0xFFFFFF) end
    if t == 86 then
      tone_on(1, "C4", {wave = "saw", vol = 0.25, decay = 0.4})
      tone_on(2, "G4", {wave = "square", duty = 0.5, vol = 0.2, decay = 0.5})
      tone_on(0, "C5", {wave = "square", duty = 0.25, vol = 0.25, decay = 0.6})
    end
  end
  local v = smooth((t - 122) / 18)
  if v > 0 and art_has("RG_TAG") then
    local w = imgsize("RG_TAG")
    clip(WORD_X, 0, math.floor(w * v), 320)
    img("RG_TAG", WORD_X, TAG_Y)
    clip()
  end
  if t > M.SPLASH_TICKS - 30 then -- then it all goes dark
    for _ = 1, (t - (M.SPLASH_TICKS - 30)) // 6 do shade(0, 0, 480, 320) end
  end
end

-- ------------------------------------------------------------------ the title and its menu

local logo = {y = -200}
local GLINTS = {{12, 30}, {38, 22}, {61, 28}, {84, 26}, {50, 72}, {28, 50}} -- where on the logo, in percent
local fx

function M.enter(particles_fx) -- the logo falls from above and lands with a thump
  fx = particles_fx
  logo.y, logo.landed = -200, false
  juice.tween(logo, {y = 6}, 0.7, "out_bounce")
end

local function draw_logo(t, has)
  if not has then -- no picture yet: the words, in the game's letters
    text("IL·LUSTRES", 240, logo.y + 10, {font = "arcade", scale = 3, align = "center", color = 0xFFE070,
                                          gradient = 0xE04010, outline = INK, shadow = 0x000000})
    text("COMBAT DE LLEGENDA", 240, logo.y + 80, {font = "arcade", scale = 1, align = "center", color = 0xFFFFFF,
                                                  gradient = 0xFFC060, outline = INK})
    return
  end
  local w, h = imgsize("LOGO")
  local x, y = 240 - w // 2, math.floor(logo.y)
  img("LOGO", x, y)
  if logo.landed then -- glints on the gold, one after another
    for i, g in ipairs(GLINTS) do
      local k = (t + i * 23) % 90
      if k < 12 then
        local r = k < 6 and k or 12 - k
        local gx, gy = x + g[1] * w // 100, y + g[2] * h // 100
        line(gx - r * 2, gy, gx + r * 2, gy, 0xFFFFFF)
        line(gx, gy - r * 2, gx, gy + r * 2, 0xFFFFFF)
        rect(gx - 1, gy - 1, 3, 3, 0xFFFFF0)
      end
    end
  end
end

function M.title(t, has, blink_text, menu)
  if has.keyart then img("KEYART", 0, 0) else rect(0, 0, 480, 320, 0x203050) end
  if not logo.landed and logo.y >= 5 and t > 30 then
    logo.landed = true
    juice.shake(6)
    juice.flash(0xFFFFFF, 6)
    sfx("SND_HEAVY")
    if fx then fx:burst(240, 110, 40, {speed = 4, colours = {0xFFE070, 0xFF8030, 0xFFFFFF}, life = 30, size = 2}) end
  end
  draw_logo(t, has.logo)
  if menu then return end
  if blink_text and t // 30 % 2 == 0 then -- (under the logo, in the sky: the fighters stand below it)
    hud.cap(blink_text, 240, 116, {font = "arcade", align = "center", color = 0xFFE070, gradient = 0xFF6020,
                                   shadow = 0x000000})
  end
  shade(0, 270, 480, 50) -- the small print on a dark strip, as SNK's line at the foot of its titles
  shade(0, 274, 480, 46)
  local best = opt.best()
  hud.cap(T("RÈCORD") .. "  " .. best.name .. "  " .. string.format("%07d", best.score), 240, 281,
          {font = "small", align = "center", color = 0xFFFFFF})
  hud.cap("© 2026 PAU AVILA  ·  RETROGO", 240, 300, {font = "small", align = "center", color = 0xC0C0C0})
end

-- The menu as the Neo Geo's home versions have it (The King of Fighters 2000-2002): slanted plates down the left,
-- the one chosen slid out and gold, what it does on a line at the foot; the key art dimmed behind.
local INFO = {ARCADE = "DEU COMBATS, TRES BONUS I EL COMBAT FINAL", VERSUS = "TRIA ELS DOS LLUITADORS I LA VIDA DE CADA U",
              ENTRENAMENT = "PRACTICA ELS COPS CONTRA UN NINOT", BONUS = "TORNA A JUGAR ELS BONUS QUE JA CONEIXES",
              GALERIA = "FITXES, FINALS I MÚSICA", OPCIONS = "DIFICULTAT, TEMPS, SO I IDIOMA",
              CONTROLS = "COM ES JUGA"}
local ITEM = {font = "arcade", color = 0xA8B0C8}
local ITEM_ON = {font = "arcade", color = 0xFFF0B0, gradient = 0xFFB040, shadow = INK}
local INFO_O = {font = "small", align = "center", color = 0xFFFFFF}
local PLATE_H, STEP, TOP = 23, 25, 114
local widths = {} -- the plates' width for each language: the longest item and room round it

local function plate_w()
  local lang = opt.v.lang
  if not widths[lang] then
    local w = 0
    for _, item in ipairs(M.MENU) do w = math.max(w, textw(item, ITEM)) end
    widths[lang] = w + 44
  end
  return widths[lang]
end

local function plate(x, y, w, h, colour) -- a parallelogram leaning right
  local s = h // 2
  rect(x + s, y, w - 2 * s, h, colour)
  tri(x, y + h, x + s, y, x + s, y + h, colour)
  tri(x + w - s, y, x + w, y, x + w - s, y + h, colour)
end

function M.menu(t, pick, has)
  M.title(t, has, nil, true)
  shade(0, 112, 480, 208)
  local PLATE_W = plate_w()
  for i, item in ipairs(M.MENU) do
    local here = i == pick
    local y = TOP + (i - 1) * STEP
    local x = here and 26 or 12
    rect(x + PLATE_H // 2 + 3, y + PLATE_H, PLATE_W - PLATE_H, 3, 0x000000) -- its shadow, below and to the right
    tri(x + PLATE_W - PLATE_H // 2, y + 3, x + PLATE_W + 3, y + 3, x + PLATE_W - PLATE_H // 2 + 3, y + PLATE_H + 3, 0x000000)
    plate(x, y, PLATE_W, PLATE_H, here and 0xB03010 or 0x18223C)
    if here then
      plate(x + 4, y + 1, PLATE_W - 8, 1, 0xFF9040) -- the light along its top
      local k = t // 4 % 4 -- and a pointer in front of it, nudging
      tri(x - 14 + k, y + 4, x - 4 + k, y + PLATE_H // 2, x - 14 + k, y + PLATE_H - 4, 0xFFE070)
    end
    hud.cap(item, x + 20, y + 4, here and ITEM_ON or ITEM)
  end
  hud.band(296, 22)
  hud.cap(INFO[M.MENU[pick]] or "", 240, 302, INFO_O)
end

-- ------------------------------------------------------------------ how to play

local ANGLE = {[6] = 0, [3] = 45, [2] = 90, [1] = 135, [4] = 180, [9] = -45, [8] = -90, [7] = -135}
local BUTTON = {A = 0xC03030, B = 0xD0A020, C = 0x3070C0}
local ROW_TEXT = {font = "small", color = 0xFFFFFF, outline = INK}

local PROMPT = {font = "small", align = "center", color = 0xFFE070}
local NOTE = {font = "small", color = 0xC0C8E0, plain = true}

local function arrow(x, y, d, colour) -- a direction in numpad notation as a small arrow (no arrows in the font)
  local r = math.rad(ANGLE[d])
  local c, s = math.cos(r), math.sin(r)
  line(x - c * 6, y - s * 6, x + c * 5, y + s * 5, colour)
  tri(x + c * 8, y + s * 8, x + c * 2 - s * 4, y + s * 2 + c * 4, x + c * 2 + s * 4, y + s * 2 - c * 4, colour)
end

local SMALL = {font = "small", align = "center", color = 0xFFFFFF, outline = INK}
local function centred(s, x, y) -- text whose middle is at (x, y)
  local _, h = textw(s, SMALL)
  text(s, x, y - h // 2, SMALL)
end

local function button(x, y, name)
  circ(x + 9, y + 9, 9, BUTTON[name])
  centred(name, x + 9, y + 9)
end

-- each row: what to press (numbers are directions, letters buttons) and what it does
local ROWS = {
  {{"A"}, "COP FLUIX"}, {{"B"}, "COP FORT"}, {{"C"}, "COP DE PEU"}, {{6, "C"}, "PEU FORT"},
  {{2, "C"}, "ESCOMBRADA"}, {{"A", "C"}, "PROJECCIÓ"}, {{4}, "BLOQUEIG"}, {{1}, "BLOQ. BAIX"},
  {{6, 6}, "ESPRINT"}, {{4, 4}, "PAS ENRERE"}, {{2, 3, 6, "A"}, "ESPECIAL"}, {{2, 3, 6, 2, 3, 6, "B"}, "SUPER"},
}
local NOTES = { -- blocking and waiting lean to SENY, attacking and taunting to RAUXA
  {"SENY", 0x50A8FF, "REPS MENYS DANY"},
  {"RAUXA", 0xFF4A3A, "FAS MÉS DANY"},
  {"SUPER", 0xFFE070, "3 BARRES, GASTA 2"},
}

function M.controls(t)
  rect(0, 0, 480, 320, 0x0C1428)
  for y = 0, 320, 16 do rect(0, y, 480, 1, 0x101C36) end
  hud.label("COM ES JUGA", 16, 10, {font = "arcade", color = 0xFFE070, gradient = 0xFF8020})
  for i, r in ipairs(ROWS) do
    local x, y = 16, 40 + (i - 1) * 21
    for _, k in ipairs(r[1]) do
      if type(k) == "number" then
        circ(x + 9, y + 9, 9, 0x2A3A60)
        arrow(x + 9, y + 9, k, 0xFFFFFF)
      else
        button(x, y, k)
      end
      x = x + 19
    end
    local _, h = textw(r[2], SMALL)
    text(r[2], 158, y + 9 - h // 2, ROW_TEXT) -- (clear of the longest row of buttons, the SUPER's seven)
  end
  rect(304, 40, 172, 246, 0x14203C) -- (clear of the longest label on the left, in both languages)
  hud.label("BLOCA I ESPERA", 390, 44, {font = "small", align = "center", color = 0x50A8FF})
  hud.label("ATACA I PROVOCA", 390, 61, {font = "small", align = "center", color = 0xFF4A3A})
  for i, n in ipairs(NOTES) do
    local y = 92 + (i - 1) * 66
    hud.label(n[1], 310, y, {font = "arcade", color = n[2]})
    hud.wrap(n[3], 310, y + 30, 160, 17, NOTE) -- (two lines when it does not fit the panel)
  end
  if t // 30 % 2 == 0 then hud.cap("PREM A", 240, 298, PROMPT) end -- (as every screen's prompt: small, gold)
end

return M
