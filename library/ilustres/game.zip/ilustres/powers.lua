-- What each fighter's specials and SUPER make: things that fly, rise, crawl or melt. fight.lua calls a power when
-- its move's blow comes out (and, for a SUPER, every tick of it, with the tick). They add shots (things with a box
-- that move and hit) or walls (Gaudí's pinnacles).
local M = {}

local F -- the fight module, set by fight.lua (they need each other)
function M.bind(fight) F = fight end

local function shot(t) F.shots[#F.shots + 1] = t return t end

-- a straight shot flies at hip height, its box no taller than SHOT_H nor wider than SHOT_W (the drawing may be): a
-- jump clears it from a little after leaving the floor to a little before landing, a crouch does not (Neo Geo's
-- fireballs). Higher, no jump cleared one and the fighters who shoot won every match.
local SHOT_Y, SHOT_H, SHOT_W = 80, 36, 48

local function mine(f, kind) -- does f already have one of these out?
  for _, s in ipairs(F.shots) do if s.owner == f and s.kind == kind then return true end end
end
M.mine = mine

function M.clock(f) -- Dalí: a soft clock flies (A slow, B fast); in RAUXA it goes through the other's shots
  local fast = f.strength == 2
  shot({owner = f, kind = "clock", x = f.x + f.dir * 74, y = F.FLOOR - SHOT_Y, vx = f.dir * (fast and 7.5 or 4.5),
        vy = 0, w = 44, h = SHOT_H, t = 0, cool = 0, frames = {0, 1, 2, 3, 4}, pic = "FX_CLOCK", pierce = f.mode == "rauxa",
        hit = {dmg = fast and 74 or 88, stun = 20, bstun = 16, push = 8, kind = "special"}})
  sfx("SND_CLOCK")
end

-- Dalí: he melts into a puddle (untouchable), slides, and stands up in front of the other (A) or behind (B).
-- In SENY he comes back together sooner (fighters.lua: the move's recovery, less in SENY).
function M.melt(f, o)
  f.inv = f.move.active + 6
  f.melting = true
  sfx("SND_MELT")
end

function M.melt_end(f, o) -- the puddle's last tick: where he rises
  local side = o.x >= f.x and 1 or -1 -- where the other is from him
  local x = o.x + (f.strength == 2 and side or -side) * 92
  f.x = math.max(F.EDGE, math.min(F.stage_w - F.EDGE, x))
  f.dir = o.x >= f.x and 1 or -1
  f.melting = false
  F.fx:burst(f.x, F.FLOOR - 10, 14, {speed = 2.5, angle = -90, spread = 120, colours = {0x3A4AA0, 0xFFD040}, life = 16})
end

function M.pinnacle(f) -- Gaudí: a pinnacle rises near (A) or far (B), a wall against shots; twice as long in SENY
  local far = f.strength == 2
  local keep = {}
  for _, w in ipairs(F.walls) do if w.owner ~= f then keep[#keep + 1] = w end end
  keep[#keep + 1] = {owner = f, x = f.x + f.dir * (far and 190 or 110), t = 0, life = f.mode == "seny" and 240 or 120,
                     hit = {dmg = 100, stun = 0, bstun = 18, push = 6, kind = "special", knock = true}}
  F.walls = keep
  sfx("SND_STONE")
end

-- Gaudí: a trencadís salamander scuttles along the floor (A slow, B fast; in RAUXA half as fast again). It hits
-- low: only a crouching guard stops it, and Dalí's clocks fly over it.
function M.salamander(f)
  local v = (f.strength == 2 and 4.4 or 2.8) * (f.mode == "rauxa" and 1.5 or 1)
  shot({owner = f, kind = "salamander", x = f.x + f.dir * 70, y = F.FLOOR - 18, vx = f.dir * v, vy = 0, w = 64,
        h = 34, t = 0, cool = 0, frames = {0, 1, 2, 3}, pic = "FX_SALAMANDER", ground = true,
        hit = {dmg = 90, stun = 20, bstun = 14, push = 6, kind = "special", hits = "low"}})
  sfx("SND_STONE")
end

local RAIN = {-24, 18, -8, 28, 4, -30, 14, -16, 0}
function M.rain(f, o, t) -- Dalí's SUPER: nine clocks fall on the other, the last knocks down
  if t < 8 or t > 72 or t % 8 ~= 0 then return end
  local n = t // 8
  shot({owner = f, kind = "rain", x = o.x + RAIN[n], y = F.FLOOR - 340, vx = 0, vy = 9, w = 44, h = 44, t = 0,
        cool = 0, frames = {0, 1, 2, 3, 4}, pic = "FX_CLOCK", super = true,
        hit = {dmg = 33, stun = 26, bstun = 12, push = 2, kind = "super", juggle = true, knock = n == #RAIN,
               from = f.x}})
  if n % 3 == 1 then sfx("SND_CLOCK", 0.6) end
end

function M.wave(f, o, t) -- Gaudí's SUPER: a trencadís bench rolls along the floor, six hits
  if t ~= 14 then return end
  shot({owner = f, kind = "wave", x = f.x + f.dir * 70, y = F.FLOOR - 48, vx = f.dir * 6, vy = 0, w = 150, h = 96,
        t = 0, cool = 0, frames = {0, 1, 2, 3}, pic = "FX_WAVE", ground = true, super = true, left = 6,
        hit = {dmg = 46, stun = 24, bstun = 10, push = 3, kind = "super", juggle = true}})
  sfx("SND_STONE")
end

-- ------------------------------------------------------------------ Fabra

local GLYPHS = {"À", "É", "Ò", "Ç", "Í", "Ú", "Ü", "Ï", "L·L"}

-- DIACRÍTICS: accented letters thrown (A straight at the hip, as every straight shot, B in an arc that comes down:
-- a high blow); in RAUXA two at a time, the second above the first
function M.letters(f)
  local n = f.mode == "rauxa" and 2 or 1
  local glyphs = f.move.glyphs or GLYPHS
  for k = 1, n do
    local arc = f.strength == 2
    shot({owner = f, kind = "letter", x = f.x + f.dir * 70, y = F.FLOOR - (arc and 150 - (k - 1) * 26 or SHOT_Y + (k - 1) * 26),
          vx = f.dir * (arc and 4.2 or 6.5) * (k == 2 and 0.85 or 1), vy = arc and -3.2 or 0, gravity = arc and 0.12 or 0,
          w = 30, h = 30, t = 0, cool = 0, glyph = glyphs[math.random(#glyphs)],
          hit = {dmg = arc and 76 or 70, stun = 18, bstun = 14, push = 6, kind = "special", hits = arc and "high" or nil}})
  end
  sfx("SND_SPECIAL")
end

-- EL DICCIONARI (SUPER): the dictionary opens in front of him and a storm of letters flies out, at three heights
function M.dictionary(f, o, t)
  if t == 10 then
    M.book = {owner = f, x = f.x + f.dir * 80, t = 0}
    sfx("SND_STONE")
  end
  if t >= 18 and t <= 78 and t % 5 == 0 then
    local n = (t - 18) // 5
    shot({owner = f, kind = "letter", x = f.x + f.dir * 90, y = F.FLOOR - 70 - (n % 3) * 50, vx = f.dir * 8, vy = 0,
          w = 30, h = 30, t = 0, cool = 0, glyph = GLYPHS[n % #GLYPHS + 1], super = true,
          hit = {dmg = 24, stun = 24, bstun = 10, push = 2, kind = "super", juggle = true, knock = n == 12}})
    if n % 4 == 0 then sfx("SND_SWING", 0.6) end
  end
  if t >= 88 then M.book = nil end
end

-- ------------------------------------------------------------------ Miró

local MAX_STARS = 1

-- ESTEL: a star painted near (A) or far (B), low over the floor; it stays (longer in SENY) and bursts on whoever
-- of the other side touches it (harder in RAUXA)
function M.star(f)
  local stars, oldest = 0, nil
  for _, s in ipairs(F.shots) do
    if s.owner == f and s.kind == "star" then
      stars = stars + 1
      oldest = oldest or s
    end
  end
  if stars >= MAX_STARS and oldest then oldest.t = oldest.life end -- the oldest goes
  shot({owner = f, kind = "star", x = f.x + f.dir * (f.strength == 2 and 210 or 120), y = F.FLOOR - 46, vx = 0,
        vy = 0, w = 30, h = 30, t = 0, cool = 0, life = f.mode == "seny" and 220 or 150, frames = {0}, pic = "FX_MIRO",
        hit = {dmg = f.mode == "rauxa" and 76 or 64, stun = 0, bstun = 14, push = 6, kind = "special", knock = true}})
  sfx("SND_MELT")
end

-- TAQUES DE COLOR: a blob of paint thrown in an arc (A short, B long); it comes down from above: a high blow
function M.blob(f)
  local far = f.strength == 2
  shot({owner = f, kind = "blob", x = f.x + f.dir * 60, y = F.FLOOR - 150, vx = f.dir * (far and 5.2 or 3.4),
        vy = -5, gravity = 0.22, w = 34, h = 30, t = 0, cool = 0, frames = {math.random(3, 4)}, pic = "FX_MIRO",
        hit = {dmg = 56, stun = 20, bstun = 14, push = 6, kind = "special", hits = "high"}})
  sfx("SND_SWING")
end

-- VÒRTEX UNIVERSAL (SUPER): a cosmic whirl opens on the other and pulls them in, eight hits; his stars burst too
function M.vortex(f, o, t)
  if t == 12 then
    shot({owner = f, kind = "vortex", x = o.x, y = F.FLOOR - 90, vx = 0, vy = 0, w = 120, h = 150, t = 0, cool = 0,
          left = 8, life = 80, frames = {0, 1, 2, 3}, pic = "FX_VORTEX", super = true, pull = true,
          hit = {dmg = 32, stun = 24, bstun = 10, push = 0, kind = "super", juggle = true}})
    for _, s in ipairs(F.shots) do
      if s.owner == f and s.kind == "star" then s.armed = true end -- they burst where they are
    end
    sfx("SND_SUPER")
  end
end

-- ------------------------------------------------------------------ the shapes every other fighter's powers take
-- Their numbers come from the move (fighters.lua): move.shot, move.pillar, move.wave, move.fall, move.stream,
-- move.blast. Strength 1 or 2 (A or B) picks between pairs of numbers. The pictures are frames of the fighter's
-- FX_<KEY> (fxmeta.lua says each frame's size).

local META = require("fxmeta")

local function size(f, frame, scale) -- a frame's drawn size, for its box
  local m = META[f.def.fx]
  local d = m and m.frames[frame + 1]
  if not d then return 40, 40 end
  return d[1] * (scale or 0.75), d[2] * (scale or 0.75)
end

local function pair(v, k) if type(v) == "table" then return v[k] or v[1] end return v end

-- a thing thrown: straight, in an arc, on the floor, or left where it is as a trap
function M.shot(f)
  local c, k = f.move.shot, f.strength or 1
  local w, h = size(f, c.frames[1])
  local trap = c.trap
  local straight = not trap and not c.arc
  shot({owner = f, kind = "shot", x = f.x + f.dir * (trap and pair(c.dist, k) or 70),
        y = F.FLOOR + (straight and math.max(c.y or -110, -SHOT_Y) or c.y or -110),
        vx = trap and 0 or f.dir * pair(c.speed, k), vy = c.arc and -4.5 or 0,
        gravity = c.arc and 0.2 or nil, w = c.w or straight and math.min(w, SHOT_W) or w,
        h = c.h or straight and math.min(h, SHOT_H) or h, t = 0, cool = 0, frames = c.frames, pic = f.def.fx,
        ground = c.ground, left = c.hits_n, life = trap and pair(c.life, k) or c.life, trap = trap,
        hit = {dmg = pair(c.dmg, k), stun = c.stun or 20, bstun = 14, push = c.push or 8, kind = "special",
               hits = c.hits, knock = c.knock}})
  sfx(c.sound or "SND_SPECIAL")
end

-- a pillar rises from the floor near (A) or far (B): it hits once as it comes up, and may stay as a wall
function M.pillar(f)
  local c, k = f.move.pillar, f.strength or 1
  local m = META[f.def.fx]
  local d = m and m.frames[(c.frame or 0) + 1] or {44, 190}
  local keep = {}
  for _, w in ipairs(F.walls) do if w.owner ~= f then keep[#keep + 1] = w end end
  keep[#keep + 1] = {owner = f, x = f.x + f.dir * pair(c.dist, k), t = 0, life = c.life or 60, pic = f.def.fx,
                     frame = c.frame or 0, wh = d[2], ww = d[1] * 0.6, blocks = c.wall,
                     hit = {dmg = pair(c.dmg, k), stun = 0, bstun = 18, push = 6, kind = "special", knock = true}}
  F.walls = keep
  sfx(c.sound or "SND_STONE")
end

-- SUPERs: a wave along the floor, things falling on the other, a stream thrown, a blast on the other
function M.groundwave(f, o, t)
  local c = f.move.wave
  if t ~= (c.at or 14) then return end
  local w, h = size(f, c.frames[1], 0.9)
  shot({owner = f, kind = "wave", x = f.x + f.dir * 70, y = F.FLOOR - h / 2, vx = f.dir * (c.speed or 6), vy = 0,
        w = w, h = h, t = 0, cool = 0, frames = c.frames, pic = f.def.fx, ground = true, super = true,
        left = c.hits_n or 6, hit = {dmg = c.dmg or 46, stun = 24, bstun = 10, push = 3, kind = "super", juggle = true}})
  sfx(c.sound or "SND_STONE")
end

local SPREAD = {-24, 18, -8, 28, 4, -30, 14, -16, 0, 10, -20, 22}
function M.fall(f, o, t)
  local c = f.move.fall
  local n_all, every = c.n or 9, c.every or 8
  if t < 8 or t > 8 + every * (n_all - 1) or (t - 8) % every ~= 0 then return end
  local n = (t - 8) // every + 1
  local w, h = size(f, c.frames[1])
  shot({owner = f, kind = "rain", x = o.x + SPREAD[(n - 1) % #SPREAD + 1], y = F.FLOOR - 340, vx = 0, vy = 9, w = w,
        h = h, t = 0, cool = 0, frames = c.frames, pic = f.def.fx, super = true,
        hit = {dmg = c.dmg or 33, stun = 26, bstun = 12, push = 2, kind = "super", juggle = true, knock = n == n_all,
               from = f.x}})
  if n % 3 == 1 then sfx(c.sound or "SND_SWING", 0.6) end
end

function M.stream(f, o, t)
  local c = f.move.stream
  local n_all = c.n or 12
  if t < 16 or (t - 16) % 5 ~= 0 or (t - 16) // 5 >= n_all then return end
  local n = (t - 16) // 5
  local w, h = size(f, c.frames[1])
  shot({owner = f, kind = "letter", x = f.x + f.dir * 90, y = F.FLOOR - 70 - (n % 3) * 50, vx = f.dir * 8, vy = 0,
        w = w, h = h, t = 0, cool = 0, frames = c.frames, pic = f.def.fx, glyph = c.glyphs and c.glyphs[n % #c.glyphs + 1],
        super = true, hit = {dmg = c.dmg or 24, stun = 24, bstun = 10, push = 2, kind = "super", juggle = true,
                             knock = n == n_all - 1}})
  if n % 4 == 0 then sfx(c.sound or "SND_SWING", 0.6) end
end

function M.blast(f, o, t)
  local c = f.move.blast
  if t ~= (c.at or 12) then return end
  local w, h = size(f, c.frames[1], 1)
  shot({owner = f, kind = "vortex", x = o.x, y = F.FLOOR - 90, vx = 0, vy = 0, w = math.max(100, w), h = 150, t = 0,
        cool = 0, left = c.hits_n or 8, life = c.life or 80, frames = c.frames, pic = f.def.fx, super = true,
        pull = c.pull, hit = {dmg = c.dmg or 32, stun = 24, bstun = 10, push = 0, kind = "super", juggle = true}})
  sfx(c.sound or "SND_SUPER")
end

-- Joel Joan's second phase (boss.lua): the others' signatures fly in at his call, from where he stands. cameo_list:
-- {pic, frames, w, h} each, chosen (and loaded) as the phase starts. His SUPER sends six; a trick of his sends one.
M.cameo_list = {}
function M.cameo(f, n, dmg)
  local c = M.cameo_list[(n - 1) % math.max(1, #M.cameo_list) + 1]
  if not c then return end
  shot({owner = f, kind = "cameo", x = f.x + f.dir * 70, y = F.FLOOR - (n % 2 == 0 and 70 or 125), vx = f.dir * 6.5,
        vy = 0, w = c.w, h = c.h, t = 0, cool = 0, frames = c.frames, pic = c.pic, super = dmg ~= nil,
        hit = {dmg = dmg or 56, stun = 22, bstun = 12, push = 6, kind = dmg and "super" or "special", juggle = dmg ~= nil}})
  sfx("SND_GLITCH", 0.6)
end

function M.cameos(f, o, t)
  local c = f.move.cameos
  if t < 10 or (t - 10) % c.every ~= 0 or (t - 10) // c.every >= c.n then return end
  M.cameo(f, (t - 10) // c.every + 1, c.dmg)
end

function M.cameo_of(def) -- what of def's can fly in: its thrown thing, at three quarters of its size (as M.shot)
  local sp = def.moves.special
  local c = sp and sp.shot
  if def.key == "dali" then return {pic = "FX_CLOCK", frames = {0, 1, 2, 3, 4}, w = 44, h = 44} end
  if not (c and def.fx and META[def.fx]) then return nil end
  local d = META[def.fx].frames[c.frames[1] + 1]
  return d and {pic = def.fx, frames = c.frames, w = d[1] * 0.75, h = d[2] * 0.75} or nil
end

return M
