-- The other twelve of the roster (GDD 7.1): who they are, what they say, their specials and SUPER. Their blows
-- share one shape (std), with each one's reach and weight; their powers are the shapes in powers.lua (shot,
-- pillar, groundwave, fall, stream, blast), with numbers from here. Frames as fighters.lua: 35-39 the special,
-- 65-69 the second special, 40-44 and 75-79 the SUPER.
local R = {}

-- the shared blows, given a reach (px added to the reach of the strikes) and a weight (damage multiplier)
local function std(reach, weight, extra)
  local function d(v) return math.floor(v * weight + 0.5) end
  local t = {
    A = {s = {15}, a = {16}, r = {15}, startup = 4, active = 3, recovery = 8, dmg = d(32), stun = 15, bstun = 11,
         box = {24, -134, 70 + reach, 24}, push = 5, chain = {B = true, FC = true, DA = true}, cancel = true},
    B = {s = {17}, a = {18}, r = {19}, startup = 10, active = 4, recovery = 20, dmg = d(70), stun = 22, bstun = 16,
         box = {30, -140, 90 + reach, 36}, push = 10, cancel = true},
    C = {s = {20}, a = {21}, r = {20}, startup = 5, active = 3, recovery = 10, dmg = d(38), stun = 16, bstun = 11,
         box = {22, -130, 90 + reach, 30}, push = 6, chain = {B = true, FC = true}, cancel = true},
    FC = {s = {22}, a = {23}, r = {24}, startup = 11, active = 4, recovery = 18, dmg = d(78), stun = 22, bstun = 16,
          box = {28, -196, 100 + reach, 50}, push = 10, cancel = true},
    DC = {s = {26}, a = {25}, r = {26}, startup = 7, active = 4, recovery = 20, dmg = d(60), stun = 0, bstun = 14,
          box = {20, -30, 100 + reach, 30}, hits = "low", push = 8, knock = true, crouch = true, cancel = true},
    J = {frame = 14, startup = 4, active = 14, dmg = d(55), stun = 18, bstun = 12, box = {6, -72, 74, 46},
         hits = "high", push = 5},
    JA = {frame = 58, startup = 3, active = 10, dmg = d(42), stun = 16, bstun = 10, box = {14, -96, 70, 40},
          hits = "high", push = 4},
    JB = {frame = 59, startup = 6, active = 8, dmg = d(68), stun = 20, bstun = 14, box = {-6, -104, 100, 70},
          hits = "high", push = 6},
    DA = {s = {11}, a = {55}, r = {11}, startup = 4, active = 3, recovery = 8, dmg = d(30), stun = 14, bstun = 10,
          box = {18, -84, 76, 22}, push = 5, crouch = true, chain = {DA = true, DC = true, B = true}, cancel = true},
    DB = {s = {57}, a = {56}, r = {57}, startup = 7, active = 5, recovery = 20, dmg = d(66), stun = 20, bstun = 14,
          box = {6, -214, 70, 150}, push = 8, crouch = true, cancel = true},
  }
  for k, v in pairs(extra) do t[k] = v end
  return t
end

local SP = {s = {35, 36}, a = {37}, r = {38, 39}}   -- the special's frames
local SP2 = {s = {65, 66}, a = {67}, r = {68, 69}}  -- the second special's

local function special(frames, t) -- a special with these frames and these numbers
  t.s, t.a, t.r, t.kind = frames.s, frames.a, frames.r, "special"
  t.startup, t.active, t.recovery = t.startup or 12, t.active or 2, t.recovery or 22
  return t
end

local function counter(name) -- a guard that answers a blow (as Fabra's)
  return {s = {65}, a = {66}, r = {67, 68, 69}, startup = 3, active = 12, recovery = 26, kind = "special",
          counter = true, name = name}
end

local function rush(name, speed, dmg, first) -- a charge forward, the body the blow (first: its frames start there)
  first = first or 65
  return {s = {first}, a = {first + 1, first + 2}, r = {first + 3, first + 4}, startup = 10, active = 14, recovery = 22, kind = "special",
          rush = speed, dmg = dmg, stun = 0, bstun = 16, box = {10, -150, 74, 130}, push = 14, knock = true, name = name}
end

local function fighter(t)
  t.art, t.fx = "SPR_" .. t.key:upper(), "FX_" .. t.key:upper()
  t.super_bg, t.ending_art = "BG_SUPER_" .. t.key:upper(), "END_" .. t.key:upper()
  return t
end

R.verdaguer = fighter({
  key = "verdaguer", name = "JACINT VERDAGUER", short = "VERDAGUER", alias = "EL POETA ÈPIC", style = "POESIA ÈPICA",
  quote = "«MÉS ENLLÀ DELS MUNTS TAMBÉ HI HA UN POBLE»", stats = {5, 4, 2, 3}, portrait = 1, colour = 0x202838,
  stage = "montserrat", hp = 1120, walk = 2.3, back = 1.9, rival = "fabra", ai = "power",
  vs = {default = "LA MUNTANYA ÉS PREGÀRIA, I LA PARAULA ÉS UNA ARMA.",
        fabra = "MESTRE FABRA, LES MEVES PARAULES VAN NÉIXER ABANS QUE LES SEVES REGLES."},
  wins = {default = "CANTEM LA TERRA, QUE ÉS LA NOSTRA MARE.",
          fabra = "AMB ACCENT O SENSE, EL CANIGÓ ÉS MEU."},
  ending = {"VERDAGUER PUJA AL CIM DE MONTSERRAT AMB EL TROFEU.",
            "DES D'ALLÀ RECITA UN POEMA NOU A TOTA LA VALL.",
            "ELS MONJOS SURTEN A ESCOLTAR-LO. ELS PASTORS TAMBÉ.",
            "AL CAPVESPRE, LA MUNTANYA SEMBLA QUE RESPIRI."},
  moves = std(18, 1.12, {
    special = special(SP, {spawn = "pillar", name = "MUNTANYA", startup = 13, recovery = 20,
                           pillar = {frame = 0, dist = {100, 180}, dmg = {95, 85}, life = 40, wall = false}}),
    special2 = rush("ESCOMESA", 7, 90),
    super = {length = 80, spawn = "groundwave", name = "CANIGÓ", wave = {frames = {1, 2, 3, 4}, dmg = 48}},
  }),
})

R.casals = fighter({
  key = "casals", name = "PAU CASALS", short = "CASALS", alias = "EL MESTRE DEL SILENCI", style = "MÚSICA",
  quote = "«EL SILENCI TAMBÉ POT SER UNA VICTÒRIA»", stats = {3, 4, 2, 5}, portrait = 2, colour = 0x3A2A1A,
  stage = "palau", hp = 980, walk = 2.3, back = 2.1, rival = "caballe", ai = "zoner",
  vs = {default = "LA MÚSICA TAMBÉ ÉS UNA FORMA DE LLUITA.",
        caballe = "SENYORA CABALLÉ, AVUI CANTAREM A DUES VEUS. O NOMÉS A UNA."},
  wins = {default = "ESCOLTA. AIXÒ QUE SENTS ÉS LA PAU.",
          caballe = "UN BON DUET, SENYORA. PERÒ EL SOLO ERA MEU."},
  ending = {"CASALS TORNA A SANT SALVADOR AMB EL TROFEU.",
            "TOCA EL CANT DELS OCELLS DAVANT DEL MAR.",
            "UN COLOM ES POSA A LA FINESTRA I S'HI QUEDA.",
            "«PER LA PAU», DIU, «I PER LA LLIBERTAT.»"},
  moves = std(20, 1.0, {
    special = special(SP, {spawn = "shot", name = "CANT DELS OCELLS", startup = 14, recovery = 26,
                           shot = {sound = "SND_CELLO", frames = {0, 1}, speed = {3.5, 5.5}, dmg = {74, 66}, y = -110}}),
    special2 = special(SP2, {name = "ARCADA", startup = 8, active = 4, recovery = 18, dmg = 78, stun = 22, bstun = 14,
                             box = {30, -130, 160, 24}, push = 10}),
    super = {length = 90, spawn = "fall", name = "LA FORÇA DEL SILENCI", fall = {frames = {2, 3}, n = 10, dmg = 30}},
  }),
})

R.rodoreda = fighter({
  key = "rodoreda", name = "MERCÈ RODOREDA", short = "RODOREDA", alias = "LA MEMÒRIA FLORIDA", style = "NARRATIVA",
  quote = "«TOTES LES COSES VISCUDES TORNEN EN FORMA DE FLOR»", stats = {3, 3, 4, 5}, portrait = 5, colour = 0x601828,
  stage = "diamant", hp = 960, walk = 2.6, back = 2.4, rival = "catala", ai = "technical",
  vs = {default = "TOT EL QUE PASSA TORNA, D'UNA ALTRA MANERA.",
        catala = "CATERINA, DUES DONES I UNA SOLA LLENGUA. QUE COMENCI LA HISTÒRIA."},
  wins = {default = "UN PÈTAL PER CADA COP. I EN TINC MOLTS.",
          catala = "EL TEU VENT, LES MEVES FLORS. AVUI HAN GUANYAT LES FLORS."},
  ending = {"RODOREDA TORNA AL JARDÍ DE ROMANYÀ AMB EL TROFEU.",
            "L'OMPLE DE TERRA I HI PLANTA UNA ROSA.",
            "ESCRIU FINS QUE SE LI FA FOSC.",
            "A LA PLAÇA DEL DIAMANT, ALGÚ BALLA SOL."},
  moves = std(15, 0.95, {
    special = special(SP, {spawn = "shot", name = "PÈTALS", startup = 12, recovery = 22,
                           shot = {sound = "SND_PETALS", frames = {0, 1}, speed = {3, 5}, dmg = {32, 28}, hits_n = 3, y = -100}}),
    special2 = counter("MIRALL"),
    super = {length = 90, spawn = "fall", name = "LA PLAÇA DEL DIAMANT", fall = {frames = {2, 4}, n = 10, dmg = 30}},
  }),
})

R.llull = fighter({
  key = "llull", name = "RAMON LLULL", short = "LLULL", alias = "EL SAVI COMBINATORI", style = "ARS MAGNA",
  quote = "«TOTES LES COSES ES PODEN COMPRENDRE PER COMBINACIÓ»", stats = {3, 4, 2, 5}, portrait = 6,
  colour = 0x5A3A1A, stage = "monestir", hp = 1000, walk = 2.2, back = 2.0, rival = "brossa", ai = "trap",
  vs = {default = "PER CADA COP TEU, CONEC TRES RESPOSTES.",
        brossa = "JOVE BROSSA, LES TEVES LLETRES SÓN JOC. LES MEVES, VERITAT."},
  wins = {default = "A, B, C: LA COMBINACIÓ ERA SENZILLA.",
          brossa = "DEL CAOS TAMBÉ EN SURT UN ORDRE."},
  ending = {"LLULL TORNA A MALLORCA AMB EL TROFEU.",
            "AL MONESTIR, EL COL·LOCA AL CENTRE D'UNA ROSA DE LLETRES.",
            "GIRA LES RODES DE L'ARS MAGNA. TOT ENCAIXA.",
            "ESCRIU EL LLIBRE NÚMERO DOS-CENTS SETANTA."},
  moves = std(12, 1.0, {
    special = special(SP, {spawn = "shot", name = "ARS MAGNA", startup = 13, recovery = 24,
                           shot = {sound = "SND_CHIME", frames = {0, 1, 2}, speed = {4, 6.5}, dmg = {88, 78}, y = -110}}),
    special2 = special(SP2, {spawn = "shot", name = "COMBINATÒRIA", startup = 10, recovery = 20,
                             shot = {sound = "SND_CHIME", frames = {4}, trap = true, dist = {110, 200}, life = {200, 200}, y = -40,
                                     dmg = {78, 78}, knock = true}}),
    super = {length = 90, spawn = "stream", name = "ARBRE DE LA CIÈNCIA",
             stream = {frames = {4}, glyphs = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "K"}, n = 12, dmg = 24}},
  }),
})

R.caballe = fighter({
  key = "caballe", name = "MONTSERRAT CABALLÉ", short = "CABALLÉ", alias = "LA VEU SOBIRANA", style = "BEL CANTO",
  quote = "«LA VEU ÉS UN PONT ENTRE LES PERSONES»", stats = {4, 4, 1, 5}, portrait = 7, colour = 0x601020,
  stage = "liceu", hp = 1020, walk = 1.9, back = 1.7, rival = "casals", ai = "zoner",
  vs = {default = "SILENCI A LA SALA, SI US PLAU.",
        casals = "MESTRE CASALS, EL SEU VIOLONCEL TÉ VEU. LA MEVA TÉ ÀNIMA."},
  wins = {default = "BRAVO! ARA EL BIS.",
          casals = "UN BON ACOMPANYAMENT, MESTRE."},
  ending = {"CABALLÉ TORNA AL LICEU AMB EL TROFEU.",
            "CANTA L'ÀRIA FINAL DAVANT D'UNA SALA PLENA.",
            "PLOUEN ROSES DES DE TOTES LES LLOTGES.",
            "TRES BISOS. QUATRE. LA NIT NO S'ACABA."},
  moves = std(5, 1.0, {
    special = special(SP, {spawn = "shot", name = "AGUT", startup = 16, recovery = 26,
                           shot = {sound = "SND_VOICE", frames = {0, 1}, speed = {4.5, 7}, dmg = {72, 64}, y = -120}}),
    special2 = special(SP2, {name = "CRIT", startup = 9, active = 6, recovery = 26, dmg = 80, stun = 0, bstun = 16,
                             box = {10, -180, 130, 170}, push = 16, knock = true}),
    super = {length = 90, spawn = "blast", name = "ÀRIA FINAL", blast = {frames = {2}, hits_n = 8, dmg = 32}},
  }),
})

R.cerda = fighter({
  key = "cerda", name = "ILDEFONS CERDÀ", short = "CERDÀ", alias = "L'URBANISTA TOTAL", style = "URBANISME",
  quote = "«ORDRE, HIGIENE I LLIBERTAT PER A TOTHOM»", stats = {3, 4, 3, 4}, portrait = 8, colour = 0x2A2A38,
  stage = "eixample", hp = 1140, walk = 2.5, back = 2.2, rival = "gaudi", ai = "setup",
  vs = {default = "LA CIUTAT HA DE SER PER A TOTS. I AQUEST CARRER, PER A MI.",
        gaudi = "SENYOR GAUDÍ, LES SEVES CORBES TRENQUEN LA MEVA QUADRÍCULA."},
  wins = {default = "XAMFRÀ A XAMFRÀ, ILLA A ILLA. TOT EN ORDRE.",
          gaudi = "LA LÍNIA RECTA TAMBÉ SAP GUANYAR."},
  ending = {"CERDÀ TORNA A L'EIXAMPLE AMB EL TROFEU.",
            "EL POSA AL MIG DE LA CRUÏLLA MÉS GRAN DE LA CIUTAT.",
            "AL VOLTANT, ELS CARRERS S'OMPLEN D'ARBRES I DE LLUM.",
            "«UNA CIUTAT ON HI CAPIGUEM TOTS», ESCRIU."},
  moves = std(22, 1.1, {
    special = special(SP, {spawn = "pillar", name = "QUADRÍCULA", startup = 13, recovery = 20,
                           pillar = {frame = 0, dist = {90, 170}, dmg = {92, 84}, life = 150, wall = true}}),
    special2 = special(SP2, {name = "COMPÀS", startup = 6, active = 5, recovery = 16, dmg = 100, stun = 22, bstun = 14,
                             box = {20, -200, 120, 170}, push = 10}),
    super = {length = 80, spawn = "groundwave", name = "L'EIXAMPLE", wave = {frames = {2, 3, 4}, dmg = 46}},
  }),
})

R.rusinol = fighter({
  key = "rusinol", name = "SANTIAGO RUSIÑOL", short = "RUSIÑOL", alias = "EL BOHEMI MODERNISTA", style = "MODERNISME",
  quote = "«LA BELLESA TAMBÉ ÉS UNA FORMA DE RESISTÈNCIA»", stats = {4, 3, 4, 3}, portrait = 10, colour = 0x3A2A10,
  stage = "cauferrat", hp = 990, walk = 2.4, back = 2.3, rival = "tapies", ai = "zoner",
  vs = {default = "L'ART ÉS LA MEVA MANERA DE VIURE. I DE LLUITAR.",
        tapies = "TÀPIES, TANTA MATÈRIA I CAP FLOR?"},
  wins = {default = "UNA PINZELLADA I PROU. LA RESTA ÉS BOHÈMIA.",
          tapies = "ELS TEUS MURS SÓN BONICS. ELS MEUS JARDINS, MÉS."},
  ending = {"RUSIÑOL TORNA AL CAU FERRAT DE SITGES AMB EL TROFEU.",
            "EL PENJA ENTRE ELS SEUS FERROS I ELS SEUS QUADRES.",
            "ELS AMICS AIXEQUEN LES COPES A LA SALUT DE L'ART.",
            "AL MATÍ, EL MAR TÉ ELS COLORS D'UN QUADRE SEU."},
  moves = std(10, 1.0, {
    special = special(SP, {spawn = "shot", name = "PINZELLADA", startup = 12, recovery = 22,
                           shot = {sound = "SND_BRUSH", frames = {0}, speed = {4.5, 6.5}, dmg = {72, 64}, y = -110}}),
    special2 = special(SP2, {spawn = "pillar", name = "FERRO FORJAT", startup = 13, recovery = 24,
                             pillar = {frame = 1, dist = {100, 180}, dmg = {92, 84}, life = 40, wall = false}}),
    super = {length = 90, spawn = "fall", name = "EL CAU FERRAT", fall = {frames = {3}, n = 9, dmg = 33}},
  }),
})

R.brossa = fighter({
  key = "brossa", name = "JOAN BROSSA", short = "BROSSA", alias = "EL POETA IMPOSSIBLE", style = "POESIA VISUAL",
  quote = "«FER VISIBLE L'INVISIBLE»", stats = {3, 3, 4, 5}, portrait = 11, colour = 0x101010,
  stage = "poesia", hp = 1000, walk = 2.7, back = 2.5, rival = "llull", ai = "zoner",
  vs = {default = "LA POESIA NO SERVEIX PER A RES. PER AIXÒ ÉS NECESSÀRIA.",
        llull = "MESTRE LLULL, LES SEVES RODES GIREN. LES MEVES LLETRES, BALLEN."},
  wins = {default = "ARA HI ÉS. ARA NO HI ÉS. ARA HAS PERDUT.",
          llull = "A + B = BROSSA."},
  ending = {"BROSSA TORNA AL SEU ESCENARI AMB EL TROFEU.",
            "EL FICA DINS DEL BARRET DE COPA.",
            "QUAN EL TORNA A TREURE, ÉS UN COLOM.",
            "EL PÚBLIC APLAUDEIX. EL COLOM, TAMBÉ."},
  moves = std(10, 1.0, {
    special = special(SP, {spawn = "letters", name = "LLETRES", startup = 11, recovery = 20,
                           glyphs = {"A", "B", "R", "O", "S", "A", "!", "?"}}),
    special2 = special(SP2, {spawn = "melt", name = "DESAPARICIÓ", startup = 12, active = 18, recovery = 18}),
    super = {length = 90, spawn = "fall", name = "POEMA VISUAL", fall = {frames = {0}, n = 10, dmg = 30}},
  }),
})

R.pla = fighter({
  key = "pla", name = "JOSEP PLA", short = "PLA", alias = "L'OBSERVADOR", style = "PROSA",
  quote = "«ÉS MÉS DIFÍCIL DESCRIURE QUE OPINAR»", stats = {3, 5, 2, 4}, portrait = 12, colour = 0x3A3A3A,
  stage = "emporda", hp = 1060, walk = 2.1, back = 2.0, rival = "peret", ai = "counter",
  vs = {default = "ESCOLTI, AIXÒ DE BARALLAR-SE NO ÉS GAIRE SENSAT.",
        peret = "TANT DE SOROLL, NOI. A L'EMPORDÀ ENS AGRADA EL SILENCI."},
  wins = {default = "HO APUNTO AL QUADERN. SENSE ADJECTIUS.",
          peret = "LA RUMBA ESTÀ BÉ. LA TRAMUNTANA, MILLOR."},
  ending = {"PLA TORNA AL MAS DE LLOFRIU AMB EL TROFEU.",
            "EL FA SERVIR DE CENDRER.",
            "ESCRIU TRES PÀGINES SOBRE COM ÉS EL TROFEU.",
            "AL VESPRE, LA TRAMUNTANA S'ENDÚ LES PÀGINES."},
  moves = std(5, 1.0, {
    special = special(SP, {spawn = "shot", name = "FUM", startup = 12, recovery = 22,
                           shot = {sound = "SND_PUFF", frames = {0, 1}, trap = true, dist = {90, 170}, life = {160, 200}, y = -80,
                                   dmg = {70, 70}, stun = 40}}),
    special2 = counter("PARADA"),
    super = {length = 90, spawn = "stream", name = "EL QUADERN GRIS", stream = {frames = {2}, n = 12, dmg = 24}},
  }),
})

R.catala = fighter({
  key = "catala", name = "VÍCTOR CATALÀ", short = "CATALÀ", alias = "LA VEU DE LA MUNTANYA", style = "NATURALISME",
  quote = "«SOLITUD NO ÉS SOLEDAT: ÉS FORÇA»", stats = {4, 4, 3, 3}, portrait = 13, colour = 0x2A2A20,
  stage = "muntanya", hp = 1140, walk = 2.4, back = 2.1, rival = "rodoreda", ai = "power",
  vs = {default = "A LA MUNTANYA EL VENT NO DEMANA PERMÍS.",
        rodoreda = "MERCÈ, LES TEVES FLORS NO AGUANTEN LA TRAMUNTANA."},
  wins = {default = "EL VENT HA PARLAT.",
          rodoreda = "LES FLORS TORNARAN A LA PRIMAVERA. JO JA HI SERÉ."},
  ending = {"CATERINA ALBERT TORNA A L'ESCALA AMB EL TROFEU.",
            "SIGNA EL NOU LLIBRE AMB EL NOM DE VÍCTOR CATALÀ.",
            "TOTHOM HO SAP. NINGÚ NO HO DIU.",
            "A LA MUNTANYA, EL VENT ESCRIU AMB ELLA."},
  moves = std(10, 1.22, {
    special = special(SP, {spawn = "shot", name = "TRAMUNTANA", startup = 13, recovery = 24,
                           shot = {sound = "SND_WIND", frames = {0, 1}, speed = {4, 6}, dmg = {80, 72}, push = 22, y = -110}}),
    special2 = rush("ESCOMESA", 7.5, 86),
    super = {length = 90, spawn = "blast", name = "SOLITUD", blast = {frames = {2, 3}, hits_n = 8, dmg = 36, pull = true}},
  }),
})

R.tapies = fighter({
  key = "tapies", name = "ANTONI TÀPIES", short = "TÀPIES", alias = "EL MUR", style = "INFORMALISME",
  quote = "«L'ART HA DE FER PENSAR»", stats = {5, 4, 2, 3}, portrait = 14, colour = 0x2A2018,
  stage = "taller", hp = 1080, walk = 2.2, back = 1.9, rival = "rusinol", ai = "power",
  vs = {default = "UNA CREU, UNA X, UN MUR. AMB AIXÒ EN TINC PROU.",
        rusinol = "RUSIÑOL, MASSA FLORS. EL MÓN TAMBÉ ÉS TERRA I PEDRA."},
  wins = {default = "MATÈRIA. NOMÉS MATÈRIA.",
          rusinol = "UN JARDÍ BONIC. ARA, UN MUR."},
  ending = {"TÀPIES TORNA AL SEU TALLER AMB EL TROFEU.",
            "L'ENTERRA DINS UNA PINTURA DE SORRA I POLS.",
            "HI GRAVA UNA CREU AL DAMUNT.",
            "«AIXÍ», DIU, «ES VEURÀ MILLOR.»"},
  moves = std(18, 1.12, {
    special = special(SP, {spawn = "shot", name = "CREU", startup = 12, recovery = 22,
                           shot = {sound = "SND_STONE", frames = {0}, speed = {3.5, 5}, life = 70, dmg = {95, 85}, y = -110}}),
    special2 = special(SP2, {spawn = "pillar", name = "MATÈRIA", startup = 15, recovery = 26,
                             pillar = {frame = 1, dist = {80, 150}, dmg = {88, 80}, life = 120, wall = true}}),
    super = {length = 80, spawn = "groundwave", name = "TERRA", wave = {frames = {2, 3, 4}, speed = 5.5, dmg = 48}},
  }),
})

R.peret = fighter({
  key = "peret", name = "PERET", short = "PERET", alias = "EL REI DE LA RUMBA", style = "RUMBA CATALANA",
  quote = "«NO ESTÀ MORT QUI PELEA»", stats = {4, 2, 5, 3}, portrait = 15, colour = 0x101010,
  stage = "gracia", hp = 1040, walk = 2.9, back = 2.6, rival = "pla", ai = "rush",
  vs = {default = "RUMBA, RUMBA! QUE AQUÍ NO S'ATURA NINGÚ!",
        pla = "SENYOR PLA, TANT DE SILENCI FA MAL A LES ORELLES!"},
  wins = {default = "I AIXÒ ÉS RUMBA CATALANA!",
          pla = "ESCRIGUI-HO AL QUADERN: HA GUANYAT EL RITME!"},
  ending = {"PERET TORNA A GRÀCIA AMB EL TROFEU.",
            "EL CARRER SENCER EL REP BALLANT.",
            "EL TROFEU ACABA FENT DE PERCUSSIÓ.",
            "FINS A LA MATINADA, NINGÚ NO SE'N VA A DORMIR."},
  moves = std(18, 1.05, {
    special = rush("RUMBA", 9, 95, 35),
    special2 = special(SP2, {name = "GIR", startup = 6, active = 10, recovery = 22, dmg = 72, stun = 22, bstun = 14,
                             box = {-40, -150, 130, 140}, push = 10}),
    super = {length = 90, spawn = "blast", name = "BORRIQUITO", blast = {frames = {4, 3}, hits_n = 8, dmg = 32}},
  }),
})

R.list = {R.verdaguer, R.casals, R.rodoreda, R.llull, R.caballe, R.cerda, R.rusinol, R.brossa, R.pla, R.catala,
          R.tapies, R.peret}

-- ------------------------------------------------------------------ the four secrets (GDD 11.1)
-- Found by playing (options.lua says how); until then the select screen shows a padlock and no name.

local function shrink(moves, k) -- a small fighter's blows: every box's height and row scaled to the body
  for _, m in pairs(moves) do
    local b = m.box
    if b then m.box = {b[1], math.floor(b[2] * k), b[3], math.floor(b[4] * k)} end
  end
  return moves
end

R.patufet = fighter({
  key = "patufet", name = "EN PATUFET", short = "PATUFET", alias = "EL MÉS PETIT", style = "RONDALLA",
  quote = "«PATIM, PATAM, PATUM!»", stats = {2, 2, 5, 4}, portrait = 16, colour = 0x7A1A10, secret = true,
  stage = "emporda", hp = 980, walk = 3.1, back = 2.8, rival = "tio", ai = "zoner",
  -- (a little taller than his drawing: at its height the blows aimed at a grown-up's chest went over him)
  body = {stand = {-20, -128, 40, 128}, crouch = {-22, -84, 44, 84}, air = {-18, -115, 36, 94}, puddle = {-30, -18, 60, 18}},
  vs = {default = "HOMES I DONES DEL CAP DRET, NO TREPITGEU EN PATUFET!",
        tio = "TIÓ, A MI NO M'HAS DE CAGAR TORRONS: AMB UN DINERET DE SAFRÀ EN TINC PROU."},
  wins = {default = "SÓC A LA PANXA DEL BOU, ON NO HI NEVA NI HI PLOU!",
          tio = "PETIT, PERÒ MÉS RÀPID QUE UN TRONC."},
  ending = {"EN PATUFET TORNA A CASA AMB EL TROFEU.",
            "ÉS TAN GRAN QUE HI CAP A DINS.",
            "LA MARE EL BUSCA PER TOT ARREU: «PATUFET, ON ETS?»",
            "«A DINS DEL TROFEU, ON NO HI NEVA NI HI PLOU!»"},
  moves = shrink(std(0, 0.9, {
    special = special(SP, {spawn = "shot", name = "DINERET DE SAFRÀ", startup = 10, recovery = 20,
                           shot = {sound = "SND_COIN", frames = {0, 1}, speed = {5, 7}, dmg = {62, 56}, y = -70}}),
    special2 = special(SP2, {spawn = "melt", name = "SOTA LA COL", startup = 12, active = 18, recovery = 18}),
    super = {length = 80, spawn = "groundwave", name = "LA PANXA DEL BOU", wave = {frames = {2, 3, 4}, dmg = 46}},
  }), 0.7),
})

R.tio = fighter({
  key = "tio", name = "EL TIÓ", short = "TIÓ", alias = "EL TRONC DE NADAL", style = "TRADICIÓ",
  quote = "«CAGA, TIÓ!»", stats = {4, 5, 1, 2}, portrait = 17, colour = 0x6A4020, secret = true,
  stage = "diamant", hp = 1150, walk = 1.8, back = 1.6, rival = "patufet", ai = "power",
  vs = {default = "CAGA, TIÓ, AVELLANES I TORRÓ!",
        patufet = "PATUFET, VIGILA: AQUÍ SOTA LA MANTA NO HI NEVA, PERÒ HI PLOUEN COPS."},
  wins = {default = "NO CAGUIS ARENGADES, QUE SÓN MASSA SALADES.",
          patufet = "UN TRONC NO TREPITJA. UN TRONC RODOLA."},
  ending = {"EL TIÓ TORNA AL BOSC AMB EL TROFEU.",
            "S'HI ESTÀ QUIET, TAPAT AMB LA SEVA MANTA.",
            "PER NADAL, LA MAINADA EL TORNA A PICAR.",
            "AQUEST ANY, EN LLOC DE TORRONS, CAGA UN TROFEU."},
  moves = std(10, 1.15, {
    special = special(SP, {spawn = "shot", name = "TORRÓ", startup = 13, recovery = 24,
                           shot = {sound = "SND_WOOD", frames = {0}, speed = {3.5, 5}, dmg = {84, 76}, arc = true, y = -90}}),
    special2 = rush("RODOLA", 7, 92),
    super = {length = 90, spawn = "fall", name = "CAGA, TIÓ!", fall = {frames = {1, 2}, n = 10, dmg = 32}},
  }),
})

R.princesa = fighter({ -- the princess of the legend of Sant Jordi, who did not wait for a knight
  key = "princesa", name = "LA PRINCESA", short = "PRINCESA", alias = "SENSE CAVALLER",
  style = "LLEGENDA", quote = "«EL DRAC EL VAIG VÈNCER JO»", stats = {4, 3, 5, 4}, portrait = 18, colour = 0xB02030,
  secret = true, stage = "parkguell", hp = 1000, walk = 2.8, back = 2.5, rival = "gaudi", ai = "rush",
  alt_art = "SPR_PRINCESAKF", -- her second costume, the martial artist's (START at the select screen)
  vs = {default = "NO NECESSITO CAP CAVALLER. EL DRAC EL VAIG DOMAR JO.",
        gaudi = "MESTRE GAUDÍ, EL SEU DRAC DEL PARC JA EM MENJA DE LA MÀ."},
  wins = {default = "UNA ROSA PER A TU. I UN LLIBRE: EN TENS MOLT A APRENDRE.",
          gaudi = "AL SEU DRAC LI CAL MÉS ENTRENAMENT, MESTRE."},
  ending = {"LA PRINCESA TORNA A MONTBLANC AMB EL TROFEU.",
            "AL PORTAL, UN CAVALLER ARRIBA CORRENTS. TARD.",
            "ELLA LI DONA UNA ROSA I UN LLIBRE: «ESTUDIA.»",
            "EL DRAC, AJAGUT A LA PLAÇA, ES MOR DE RIURE."},
  moves = std(15, 1.0, {
    special = special(SP, {spawn = "shot", name = "ROSA", startup = 10, recovery = 20,
                           shot = {sound = "SND_PETALS", frames = {0, 1}, speed = {6, 8.5}, dmg = {64, 56}, y = -110}}),
    special2 = special(SP2, {name = "CENT PUNTADES", startup = 6, active = 12, recovery = 20, dmg = 76, stun = 22,
                             bstun = 14, box = {10, -150, 120, 120}, push = 10}),
    super = {length = 80, spawn = "groundwave", name = "EL DRAC ÉS MEU", wave = {frames = {2, 3, 4}, dmg = 48}},
  }),
})

R.timbaler = fighter({
  key = "timbaler", name = "EL TIMBALER DEL BRUC", short = "TIMBALER", alias = "UN TAMBOR, MIL ECOS",
  style = "LLEGENDA", quote = "«ON SONA UN TAMBOR, HI HA UN EXÈRCIT»", stats = {3, 3, 4, 5}, portrait = 19,
  colour = 0x2A4A8A, secret = true, stage = "montserrat", hp = 980, walk = 2.6, back = 2.4, rival = "verdaguer",
  ai = "zoner",
  vs = {default = "ESCOLTA BÉ: AQUEST TAMBOR NO TOCA SOL.",
        verdaguer = "MOSSÈN, LA SEVA MUNTANYA I EL MEU TAMBOR FAN EL MATEIX ECO."},
  wins = {default = "L'ECO DE LA MUNTANYA HA GUANYAT UNA ALTRA BATALLA.",
          verdaguer = "MONTSERRAT HO HA SENTIT. I HO REPETIRÀ."},
  ending = {"EL TIMBALER TORNA AL BRUC AMB EL TROFEU.",
            "TOCA UN REDOBLE DES DEL CIM.",
            "LA MUNTANYA EL REPETEIX MIL VEGADES.",
            "DIUEN QUE ENCARA ES SENT, LES NITS DE VENT."},
  moves = std(10, 1.0, {
    special = special(SP, {spawn = "shot", name = "REDOBLE", startup = 12, recovery = 22,
                           shot = {sound = "SND_DRUM", frames = {0, 1}, speed = {4.5, 7}, dmg = {72, 64}, y = -110}}),
    special2 = counter("ECO"),
    super = {length = 90, spawn = "stream", name = "MIL ECOS", stream = {frames = {2}, n = 12, dmg = 24}},
  }),
})

R.secrets = {R.patufet, R.tio, R.princesa, R.timbaler}

-- The final boss (GDD 10): Joel Joan, who set the whole tournament up for television, in two phases: first as he was
-- in 1999 in the sitcom Plats bruts, then as he is today, the Executive Producer, wilder (the arcade's last
-- two fights, after DESTROSSA EL PLATÓ!). In the arcade he has more life (boss_hp) and the console plays him a level
-- up; once the arcade is complete he can be chosen in VERSUS, with the life of the rest (GDD 11.2).
R.joeljoan = fighter({
  key = "joeljoan", name = "JOEL JOAN", short = "JOEL JOAN", alias = "EL DE PLATS BRUTS", style = "SITCOM",
  quote = "«AQUÍ NINGÚ NO FREGA ELS PLATS»", stats = {5, 3, 5, 4}, portrait = 20, colour = 0x181818,
  boss = 1, stage = "plato", hp = 1000, boss_hp = 1200, walk = 3.0, back = 2.7, ai = "rush",
  vs = {default = "BENVINGUTS AL PLATÓ. AQUEST TORNEIG L'HE MUNTAT JO.",
        dali = "DALÍ, TU SÍ QUE SAPS FER ESPECTACLE. PERÒ AQUÍ EL DIRECTOR SÓC JO.",
        peret = "PERET! SENSE TU AQUEST PROGRAMA NO TINDRIA AUDIÈNCIA."},
  wins = {default = "TALLEM! BONA PRESA. LA SEGÜENT, AMB MÉS GANES.",
          dali = "TANT DE BIGOTI I TAN POCA AUDIÈNCIA."},
  moves = std(16, 1.08, {
    special = special(SP, {spawn = "shot", name = "PLATS BRUTS", startup = 9, recovery = 18,
                           shot = {sound = "SND_PLATE", frames = {0, 1}, speed = {6.5, 9}, dmg = {70, 62}, y = -110}}),
    special2 = rush("COP DE PAELLA", 8, 90),
    super = {length = 90, spawn = "blast", name = "RIALLES ENLLAUNADES", blast = {frames = {3, 4}, dmg = 34, hits_n = 8}},
  }),
})

R.productor = fighter({ -- the second phase: the same man, in the suit, with the headset (art/roster.py: a costume)
  key = "productor", name = "JOEL JOAN", short = "PRODUCTOR", alias = "PRODUCTOR EXECUTIU", style = "ESPECTACLE",
  quote = "«AQUÍ NO S'ACABA RES FINS QUE HO DIC JO»", stats = {5, 4, 4, 5}, portrait = 21, colour = 0x101010,
  boss = 2, stage = "plato", hp = 1000, boss_hp = 1250, walk = 3.1, back = 2.8, ai = "rush",
  vs = {default = "UN MOMENT. QUI HA DIT QUE AIXÒ S'HAVIA ACABAT?"},
  wins = {default = "EL PROGRAMA CONTINUA. TU NO."},
  moves = std(18, 1.12, {
    special = special(SP, {spawn = "shot", name = "TALLEM!", startup = 10, recovery = 18,
                           shot = {sound = "SND_WOOD", frames = {2}, speed = {6, 8.5}, dmg = {76, 68}, y = -120}}),
    special2 = counter("UN MOMENT"),
    super = {length = 96, spawn = "cameos", name = "TOTHOM AL PLATÓ!", cameos = {n = 6, every = 12, dmg = 40}},
  }),
})
R.productor.fx = R.joeljoan.fx -- (one strip of things for both: the plates, the clapperboard, the spotlight,
R.productor.super_bg = R.joeljoan.super_bg -- and one SUPER background: his set gone wild)
R.boss = {R.joeljoan, R.productor}

return R
