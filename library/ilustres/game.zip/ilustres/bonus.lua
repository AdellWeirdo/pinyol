-- The bonus stages (GDD 9): between the arcade's fights, the player's fighter alone against something Catalan
-- and festive, for points and a rank (C, B, A, S, RAUXA!). The fighter moves and strikes with the fight's own
-- rules (fight.lua); the other fighter is there but out of the game (high up, untouchable, never drawn), standing
-- where the player faces so turning works as in a fight. Each bonus is a table of four functions: start, tick,
-- draw and rank.
local fight = require("fight")
local gfx = require("gfx")
local hud = require("hud")
local juice = require("juice")

local M = {}

local FLOOR = fight.FLOOR

local function overlap(a, b)
  return a[1] < b[1] + b[3] and b[1] < a[1] + a[3] and a[2] < b[2] + b[4] and b[2] < a[2] + a[4]
end

local function struck(box) -- the player's blow, if it is out and meets this box this tick (once a blow)
  local p = M.p
  local hb = fight.hitbox(p)
  if hb and overlap(hb, box) then
    p.done, p.contact = true, true
    local m = p.move
    juice.freeze(m and m.dmg and m.dmg >= 60 and 5 or 3)
    return m and m.dmg or 40
  end
end

local function touches(box) return overlap(fight.body(M.p), box) end

local function hurt_player(from_x) -- something got through: the player is knocked back, the count goes up
  local p = M.p
  if p.inv > 0 or p.act == "fall" or p.act == "down" or p.act == "rise" then return false end
  p.act, p.t, p.vy, p.vx, p.y, p.flash = "fall", 0, 5, (p.x > from_x and 1 or -1) * 2.5, 1, 8
  M.hits_taken = M.hits_taken + 1
  sfx("SND_HIT")
  juice.shake(3)
  return true
end

-- frame of a bonus strip with its bottom's middle at (x, bottom); without the picture, a box of w x h there
local function thing(id, frame, x, bottom, flip, w, h, colour)
  if gfx.has(id) then
    local sw, sh = imgsize(id)
    gfx.pic(id, math.floor(x - sw / 2), math.floor(bottom - sh), frame, flip)
  else
    rect(math.floor(x - w / 2), math.floor(bottom - h), w, h, colour or 0xC08040)
  end
end

-- ------------------------------------------------------------------ the six

local B = {}

B.gegant = { -- TRENCA EL GEGANT: a giant of the festa, to be knocked to pieces before the time is up
  name = "TRENCA EL GEGANT", secs = 25, stage = "diamant", hint = "COLPEJA'L FINS QUE CAIGUI!",
  start = function(s) s.hp, s.max, s.x, s.shake = 1300, 1300, M.stage_w * 0.62, 0 end,
  tick = function(s)
    local box = {s.x - 60, FLOOR - 250, 120, 250}
    local dmg = s.hp > 0 and struck(box)
    if dmg then
      s.hp, s.shake = math.max(0, s.hp - dmg * 2), 8
      M.score = M.score + dmg * 10
      sfx("SND_HEAVY")
      fight.fx:burst(s.x, FLOOR - 140, 10, {speed = 3, colours = {0xC8A070, 0xFFFFFF, 0xD04020}, life = 16})
      if s.hp == 0 then
        M.done, M.score = true, M.score + 5000
        juice.shake(8)
        sfx("SND_KO")
      end
    end
    s.shake = math.max(0, s.shake - 1)
  end,
  draw = function(s, cam)
    local state = s.hp > s.max * 0.66 and 0 or s.hp > s.max * 0.33 and 1 or s.hp > 0 and 2 or 3
    local dx = s.shake > 0 and (s.shake % 2 * 4 - 2) or 0
    thing("BONUS_GEGANT", state, s.x - cam + dx, FLOOR + 4, false, 120, 250)
  end,
  rank = function(s) -- by the seconds left when it fell
    if s.hp > 0 then return nil end
    local left = M.clock // 60
    return left >= 14 and "RAUXA!" or left >= 10 and "S" or left >= 6 and "A" or left >= 3 and "B" or "C"
  end,
}

B.tio = { -- PICA EL TIÓ: strike the log in combos, it gives presents; pick them up
  name = "PICA EL TIÓ", secs = 20, stage = "diamant", hint = "PICA'L I RECULL ELS REGALS!",
  start = function(s) s.x, s.gifts, s.got, s.squint = M.stage_w * 0.6, {}, 0, 0 end,
  tick = function(s)
    local box = {s.x - 70, FLOOR - 170, 140, 170} -- a blow from above counts too: it is struck with a stick
    local dmg = struck(box)
    if dmg then
      s.squint = 10
      for _ = 1, (dmg >= 60 and 2 or 1) do
        s.gifts[#s.gifts + 1] = {x = s.x + math.random(-60, 60), y = FLOOR - 120, vx = math.random(-30, 30) / 10,
                                 vy = -4 - math.random() * 3, frame = 2 + math.random(0, 2), t = 0}
      end
      sfx("SND_PICK")
    end
    s.squint = math.max(0, s.squint - 1)
    local keep = {}
    for _, g in ipairs(s.gifts) do
      g.t = g.t + 1
      g.vy = g.vy + 0.3
      g.x, g.y = g.x + g.vx, math.min(FLOOR - 16, g.y + g.vy)
      if g.y >= FLOOR - 16 then g.vx = g.vx * 0.8 end
      if touches({g.x - 14, g.y - 14, 28, 28}) and g.t > 10 then
        s.got = s.got + 1
        M.score = M.score + 500
        sfx("SND_MOVE")
      elseif g.t < 600 then
        keep[#keep + 1] = g
      end
    end
    s.gifts = keep
  end,
  draw = function(s, cam)
    thing("BONUS_TIO", s.squint > 0 and 1 or 0, s.x - cam, FLOOR + 4, true, 140, 90, 0x8A5A30)
    for _, g in ipairs(s.gifts) do thing("BONUS_TIO", g.frame, g.x - cam, g.y + 14, false, 28, 28, 0xD02020) end
  end,
  rank = function(s)
    local n = s.got
    return n >= 30 and "RAUXA!" or n >= 22 and "S" or n >= 14 and "A" or n >= 7 and "B" or n >= 1 and "C" or nil
  end,
}

B.correfoc = { -- CORREFOC: the devils' fire rains down; dodge it, and strike the devils' fireworks for points
  name = "CORREFOC", secs = 25, stage = "gracia", hint = "ESQUIVA EL FOC!",
  start = function(s)
    s.sparks, s.devils, s.next = {}, {{x = 120, t = 0}, {x = M.stage_w - 120, t = 40}}, 30
  end,
  tick = function(s)
    s.next = s.next - 1
    if s.next <= 0 then -- sparks from a devil, more as the time runs out
      local d = s.devils[math.random(#s.devils)]
      s.sparks[#s.sparks + 1] = {x = d.x, y = FLOOR - 200, vx = (M.p.x - d.x) / 70 + math.random(-10, 10) / 10,
                                 vy = -2, t = 0}
      s.next = math.max(18, 34 - (25 * 60 - M.clock) // 90) -- (one every half second at first, at most three a second)
    end
    local keep = {}
    for _, sp in ipairs(s.sparks) do
      sp.t, sp.vy = sp.t + 1, sp.vy + 0.18
      sp.x, sp.y = sp.x + sp.vx, sp.y + sp.vy
      local box = {sp.x - 10, sp.y - 10, 20, 20}
      if touches(box) then
        hurt_player(sp.x)
      elseif struck(box) then
        M.score = M.score + 300 -- a spark knocked away
        fight.fx:burst(sp.x, sp.y, 8, {speed = 3, colours = {0xFFD040, 0xFF6020}, life = 12})
      elseif sp.y < FLOOR then
        keep[#keep + 1] = sp
      else
        fight.fx:burst(sp.x, FLOOR - 4, 4, {speed = 2, angle = -90, spread = 120, colours = {0xFFD040, 0xFF6020}, life = 10})
      end
    end
    s.sparks = keep
    for _, d in ipairs(s.devils) do d.t = d.t + 1 end
    M.score = M.score + 2 -- every tick still standing counts
  end,
  draw = function(s, cam)
    for _, d in ipairs(s.devils) do
      thing("BONUS_CORREFOC", (d.t // 8) % 2, d.x - cam, FLOOR - 40, d.x > M.stage_w / 2, 70, 110, 0xA02020)
    end
    for _, sp in ipairs(s.sparks) do
      thing("BONUS_CORREFOC", 2 + (sp.t // 4) % 2, sp.x - cam, sp.y + 12, false, 20, 20, 0xFFC020)
    end
  end,
  rank = function(s)
    local n = M.hits_taken
    return n == 0 and "RAUXA!" or n <= 2 and "S" or n <= 4 and "A" or n <= 7 and "B" or "C"
  end,
}

B.calcots = { -- CALÇOT CARNAGE: calçots pop up from the earth; strike them, not the red peppers
  name = "CALÇOT CARNAGE", secs = 20, stage = "emporda", hint = "NOMÉS ELS CALÇOTS!",
  start = function(s)
    s.holes = {}
    for i = 1, 6 do s.holes[i] = {x = 80 + (i - 1) * (M.stage_w - 160) / 5, up = 0, kind = nil, hit = 0} end
    s.next, s.good, s.bad = 20, 0, 0
  end,
  tick = function(s)
    s.next = s.next - 1
    if s.next <= 0 then
      local h = s.holes[math.random(#s.holes)]
      if h.up <= 0 then h.up, h.kind, h.hit = 70, math.random() < 0.72 and "calcot" or "pebrot", 0 end
      s.next = 12 + math.random(14)
    end
    for _, h in ipairs(s.holes) do
      if h.up > 0 then
        h.up = h.up - 1
        if h.hit == 0 and struck({h.x - 26, FLOOR - 170, 52, 170}) then
          h.hit, h.up = 1, 14
          if h.kind == "calcot" then s.good, M.score = s.good + 1, M.score + 400 sfx("SND_PICK")
          else s.bad, M.score = s.bad + 1, math.max(0, M.score - 600) sfx("SND_NO") end
        end
      end
    end
  end,
  draw = function(s, cam)
    for _, h in ipairs(s.holes) do
      thing("BONUS_CALCOTS", 4, h.x - cam, FLOOR + 4, false, 60, 20, 0x4A3020)
      if h.up > 0 then
        local frame = (h.kind == "calcot" and 0 or 2) + h.hit
        local rise = math.min(1, (70 - h.up) / 8)
        clip(0, 0, 480, FLOOR - 4)
        thing("BONUS_CALCOTS", frame, h.x - cam, FLOOR - 4 + 90 * (1 - rise), false, 40, 80,
              h.kind == "calcot" and 0x40A040 or 0xD02020)
        clip()
      end
    end
  end,
  rank = function(s)
    local n = s.good - s.bad * 2
    return n >= 26 and "RAUXA!" or n >= 20 and "S" or n >= 14 and "A" or n >= 8 and "B" or n >= 1 and "C" or nil
  end,
}

B.parada = { -- SALVA LA PARADA: little dragons come for the Sant Jordi stall's roses and books; stop them
  name = "SALVA LA PARADA", secs = 25, stage = "eixample", hint = "PROTEGEIX LA PARADA DE SANT JORDI!",
  start = function(s) s.x, s.hp, s.dragons, s.next = M.stage_w / 2, 5, {}, 40 end,
  tick = function(s)
    s.next = s.next - 1
    if s.next <= 0 then
      local left = math.random() < 0.5
      s.dragons[#s.dragons + 1] = {x = left and -30 or M.stage_w + 30, dir = left and 1 or -1, t = 0, dead = 0,
                                   speed = 1.2 + math.random() * 0.8 + (25 * 60 - M.clock) / 1500}
      s.next = math.max(25, 70 - (25 * 60 - M.clock) // 30)
    end
    local keep = {}
    for _, d in ipairs(s.dragons) do
      d.t = d.t + 1
      if d.dead > 0 then
        d.dead = d.dead - 1
        if d.dead > 0 then keep[#keep + 1] = d end
      else
        d.x = d.x + d.dir * d.speed
        if struck({d.x - 30, FLOOR - 160, 60, 160}) then
          d.dead = 20
          M.score = M.score + 400
          sfx("SND_HIT")
          keep[#keep + 1] = d
        elseif math.abs(d.x - s.x) < 50 then -- it reached the stall
          s.hp = s.hp - 1
          sfx("SND_NO")
          juice.shake(3)
          if s.hp <= 0 then M.done = true end
        else
          keep[#keep + 1] = d
        end
      end
    end
    s.dragons = keep
  end,
  draw = function(s, cam)
    thing("BONUS_PARADA", s.hp >= 3 and 0 or 1, s.x - cam, FLOOR + 4, false, 140, 120, 0xC04040)
    for _, d in ipairs(s.dragons) do
      thing("BONUS_PARADA", d.dead > 0 and 4 or 2 + (d.t // 8) % 2, d.x - cam, FLOOR + 4, d.dir < 0, 48, 50, 0x40A040)
    end
    for i = 1, 5 do circ(240 - 48 + i * 16, 70, 6, i <= s.hp and 0xE02040 or 0x302030) end
  end,
  rank = function(s)
    if s.hp <= 0 then return nil end
    return s.hp == 5 and "RAUXA!" or s.hp == 4 and "S" or s.hp == 3 and "A" or s.hp == 2 and "B" or "C"
  end,
}

B.cercavila = { -- CERCAVILA: the parade comes through; jump the big heads, duck the dragon, strike the gegantó
  name = "CERCAVILA", secs = 25, stage = "gracia", hint = "SALTA, AJUP-TE O COLPEJA!",
  start = function(s) s.things, s.next = {}, 40 end,
  tick = function(s)
    s.next = s.next - 1
    if s.next <= 0 then
      local r = math.random()
      local kind = r < 0.4 and "capgros" or r < 0.75 and "drac" or "geganto"
      s.things[#s.things + 1] = {kind = kind, x = M.stage_w + 40, t = 0, hp = kind == "geganto" and 2 or 1}
      s.next = math.max(55, 90 - (25 * 60 - M.clock) // 30) -- (room between them: each can be met in turn)
    end
    local keep = {}
    for _, o in ipairs(s.things) do
      o.t = o.t + 1
      o.x = o.x - (o.kind == "drac" and 3.2 or 2.2)
      local box = o.kind == "drac" and {o.x - 30, FLOOR - 150, 60, 50} or o.kind == "capgros" and {o.x - 22, FLOOR - 60, 44, 60}
                  or {o.x - 30, FLOOR - 140, 60, 140}
      local gone = false
      if o.kind == "geganto" and struck(box) then
        o.hp = o.hp - 1
        if o.hp <= 0 then gone, M.score = true, M.score + 800 sfx("SND_HEAVY") end
      elseif touches(box) then
        hurt_player(o.x)
        gone = o.kind ~= "geganto"
      end
      if o.x < -60 then
        gone = true
        M.score = M.score + 200 -- got past it
      end
      if not gone then keep[#keep + 1] = o end
    end
    s.things = keep
  end,
  draw = function(s, cam)
    for _, o in ipairs(s.things) do
      local frame = o.kind == "capgros" and (o.t // 10) % 2 or o.kind == "drac" and 2 + (o.t // 8) % 2 or 4
      local bottom = o.kind == "drac" and FLOOR - 100 or FLOOR + 4
      thing("BONUS_CERCAVILA", frame, o.x - cam, bottom, true, o.kind == "geganto" and 70 or 50,
            o.kind == "geganto" and 146 or 60, o.kind == "drac" and 0x40A040 or 0xC08040)
    end
  end,
  rank = function(s)
    local n = M.hits_taken
    return n == 0 and "RAUXA!" or n <= 1 and "S" or n <= 3 and "A" or n <= 5 and "B" or "C"
  end,
}

-- DESTROSSA EL PLATÓ! (GDD 9.3): the secret one, only before the boss. Twelve things of his television set, to break
-- in 30 seconds; all twelve give a SUPER stock for the boss (M.reward). Each: its strip and frame (art/make_art.py,
-- BONUS_H: three strips of five, the last strip's 2-4 the wreckage and the dust), its height, the blows it takes.
local B_LABEL = {font = "small", color = 0xFFE070}
local PLATO = {
  {"BONUS_PLATO1", 0, 150, 150}, {"BONUS_PLATO2", 2, 120, 90},  {"BONUS_PLATO1", 1, 130, 120},
  {"BONUS_PLATO2", 0, 140, 110}, {"BONUS_PLATO1", 4, 170, 180}, {"BONUS_PLATO3", 0, 90, 120},
  {"BONUS_PLATO2", 1, 170, 90},  {"BONUS_PLATO1", 3, 90, 140},  {"BONUS_PLATO2", 3, 150, 150},
  {"BONUS_PLATO1", 2, 170, 100}, {"BONUS_PLATO2", 4, 130, 90},  {"BONUS_PLATO3", 1, 160, 110},
}
B.plato = {
  name = "DESTROSSA EL PLATÓ!", short = "DESTROSSA!", secs = 30, stage = "plato",
  hint = "TRENCA ELS 12 OBJECTES DEL PLATÓ!",
  start = function(s)
    s.things, s.n = {}, 0
    for i, t in ipairs(PLATO) do
      s.things[i] = {pic = t[1], frame = t[2], h = t[3], hp = t[4], x = 70 + (i - 1) * (M.stage_w - 140) / 11,
                     shake = 0, gone = -1}
    end
  end,
  tick = function(s)
    for _, o in ipairs(s.things) do
      o.shake = math.max(0, o.shake - 1)
      if o.gone < 0 then
        local dmg = struck({o.x - 28, FLOOR - o.h, 56, o.h})
        if dmg then
          o.hp, o.shake = o.hp - dmg, 6
          M.score = M.score + dmg * 5
          sfx("SND_HIT")
          if o.hp <= 0 then
            o.gone, s.n = 0, s.n + 1
            M.score = M.score + 1000
            juice.shake(5)
            sfx("SND_HEAVY")
            fight.fx:burst(o.x, FLOOR - o.h / 2, 14, {speed = 3.5, colours = {0xC0C8D0, 0x303438, 0xFFE070}, life = 18})
            if s.n == #s.things then M.done, M.score = true, M.score + 5000 + M.clock // 60 * 200 end
          end
        end
      else
        o.gone = o.gone + 1
      end
    end
  end,
  draw = function(s, cam)
    for i, o in ipairs(s.things) do
      local dx = o.shake > 0 and (o.shake % 2 * 4 - 2) or 0
      if o.gone < 0 then
        thing(o.pic, o.frame, o.x - cam + dx, FLOOR + 4, false, 56, o.h, 0x707880)
      else -- the wreckage, and a puff of dust for a moment
        thing("BONUS_PLATO3", 2 + i % 2, o.x - cam, FLOOR + 4, false, 50, 30, 0x404448)
        if o.gone < 24 then thing("BONUS_PLATO3", 4, o.x - cam, FLOOR - 10, false, 60, 50, 0xC0B090) end
      end
    end
  end,
  hud = function(s) -- the DESTRUCCIÓ DEL PLATÓ bar, at the bottom
    local w = textw("DESTRUCCIÓ DEL PLATÓ", B_LABEL) -- (Castilian is longer: the bar starts where the words end)
    hud.plate(40, 284, 400, 30)
    hud.cap("DESTRUCCIÓ DEL PLATÓ", 52, 291, B_LABEL)
    local x = 52 + w + 10
    rect(x, 293, 384 - x, 12, 0x2A1010)
    rect(x, 293, (384 - x) * s.n // #s.things, 12, 0xE03020)
    hud.cap(s.n .. "/" .. #s.things, 430, 291, {font = "small", align = "right", color = 0xFFFFFF})
  end,
  rank = function(s)
    local n, left = s.n, M.clock // 60
    if n == #s.things then return left >= 12 and "RAUXA!" or left >= 6 and "S" or "A" end
    return n >= 9 and "B" or n >= 5 and "C" or nil
  end,
  reward = function(s) return s.n == #s.things end,
}

M.POOLS = {{"gegant", "tio"}, {"correfoc", "calcots"}, {"parada", "cercavila"}} -- after fights 3, 6 and 9
M.LIST = B
M.RANK_BONUS = {C = 2000, B = 5000, A = 10000, S = 20000, ["RAUXA!"] = 40000}

-- ------------------------------------------------------------------ playing one

function M.start(key, p1, p2, stage_w)
  M.key, M.b, M.p, M.other = key, B[key], p1, p2
  M.stage_w, M.score, M.hits_taken, M.done, M.clock, M.state = stage_w, 0, 0, false, B[key].secs * 60, {}
  M.b.start(M.state)
  p2.act, p2.y, p2.vy, p2.inv = "ko", 400, 0, 9999
end

function M.place_other(facing) -- before fight.update: the other out of the game, where the player faces
  local p2 = M.other
  p2.act, p2.y, p2.vy, p2.x = "ko", 400, 0, M.p.x + facing * 300
end

function M.tick() -- after fight.update: the bonus's own things, and the clock
  M.b.tick(M.state)
  M.clock = M.clock - 1
  if M.clock <= 0 then M.done = true end
end

function M.draw(cam) M.b.draw(M.state, cam) end
function M.reward() return M.b.reward ~= nil and M.b.reward(M.state) end -- (the plató's SUPER stock)

function M.result() -- the rank, and the points it is worth
  local r = M.b.rank(M.state)
  return r, r and M.RANK_BONUS[r] or 0
end

local O_TIME = {scale = 2, align = "center", color = 0xFFF0B0, gradient = 0xFFB040}
local O_SCORE = {font = "small", align = "right", color = 0xFFFFFF}
local O_NAME = {font = "small", align = "left", color = 0xFFE070}

function M.hud()
  hud.plate(214, 2, 52, 44)
  hud.cap(string.format("%02d", math.max(0, (M.clock + 59) // 60)), 240, 7, O_TIME)
  hud.cap(M.b.short or M.b.name, 8, 10, O_NAME) -- (left of the clock: a long name, shortened)
  hud.cap(string.format("%07d", M.score), 472, 10, O_SCORE)
  if M.b.hud then M.b.hud(M.state) end
end

return M
